library kvatt_core;
