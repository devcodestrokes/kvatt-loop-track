import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_core/domain/labels/label_style.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_public.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';
import 'package:kvatt_core/domain/packagings/packagings_repository_interface.dart';

class PackagingStatusSerialisationException implements Exception {
  String? message;
  PackagingStatusSerialisationException(message);
}

class PackagingsRepository implements PackagingsRepositoryInterface {
  static const String packagingsCollection = 'packagings';
  static const String packagingsPublicCollection = 'packagings_public';

  DbInterface db;

  PackagingsRepository({
    required this.db,
  });

  @override
  Future<List<Packaging>> createPackagings({
    required List<Packaging> packagings,
  }) async {
    List<Future<String>> operations = packagings
        .map(
          (Packaging packaging) => db.createDocument(
            collectionPath: packagingsCollection,
            data: _serialisePackaging(packaging: packaging),
          ),
        )
        .toList();

    List<String> identifiers = await Future.wait(operations);

    List<Future<void>> packagingsPublicOperations = [];

    for (int i = 0; i < packagings.length; i++) {
      packagings[i].identifier = identifiers[i];
      packagingsPublicOperations.add(
        db.updateDocument(
          documentPath: '$packagingsPublicCollection/${identifiers[i]}',
          data: _serialisePackagingPublic(packaging: packagings[i]),
        ),
      );
    }

    await Future.wait(packagingsPublicOperations);
    return packagings;
  }

  @override
  Future<void> updatePackaging({
    required Packaging packaging,
  }) async {
    await db.updateDocument(
      documentPath: '$packagingsCollection/${packaging.identifier}',
      data: _serialisePackaging(packaging: packaging),
    );
  }

  @override
  Future<void> updatePackagings({
    required List<Packaging> packagings,
  }) async {
    List<Future> updateTasks = packagings
        .map(
          (Packaging packaging) => db.updateDocument(
            documentPath: '$packagingsCollection/${packaging.identifier}',
            data: _serialisePackaging(packaging: packaging),
          ),
        )
        .toList();
    await Future.wait(updateTasks);
  }

  @override
  Future<void> updateMerchantIdForPublicPackagings({
    required String? merchantId,
    required List<String> packagingIds,
  }) async {
    List<Future> updateTasks = packagingIds
        .map(
          (String packagingId) => db.updateDocument(
            documentPath: '$packagingsPublicCollection/$packagingId',
            data: {
              'merchantId': merchantId,
            },
          ),
        )
        .toList();
    await Future.wait(updateTasks);
  }

  @override
  Future<List<Packaging>> retrievePackagings({
    int? code,
    PackagingStatus? status,
    String? type,
    String? merchantId,
    String? orderNumber,
    DateTime? earliestLastTrackedDate,
    int? limit,
    int? startAt,
    bool? merchantNameNotNull,
  }) async {
    List<String> fieldNamesEqual = [];
    List<dynamic> targetValuesEqual = [];
    List<String> fieldNamesGreaterThan = [];
    List<dynamic> targetValuesGreaterThan = [];

    if (code != null) {
      fieldNamesEqual.add('code');
      targetValuesEqual.add(code);
    }

    if (status != null) {
      fieldNamesEqual.add('status');
      targetValuesEqual.add(_serialisePackagingStatus(status: status));
    }

    if (type != null) {
      fieldNamesEqual.add('type');
      targetValuesEqual.add(type);
    }

    if (merchantId != null) {
      fieldNamesEqual.add('merchantId');
      targetValuesEqual.add(merchantId);
    }

    if (orderNumber != null) {
      fieldNamesEqual.add('orderNumber');
      targetValuesEqual.add(orderNumber);
    }

    if (earliestLastTrackedDate != null) {
      fieldNamesGreaterThan.add('lastTracked');
      targetValuesGreaterThan.add(earliestLastTrackedDate);
    }

    List<DocumentData> docs = await db.retrieveDocuments(
      collectionPath: packagingsCollection,
      fieldNamesEqual: fieldNamesEqual,
      targetValuesEqual: targetValuesEqual,
      fieldNamesGreaterThan: fieldNamesGreaterThan,
      targetValuesGreaterThan: targetValuesGreaterThan,
      orderByField: code == null ? 'code' : null,
      limit: limit,
      startAt: startAt,
      fieldNamesNotNull: merchantNameNotNull == true ? ['merchantName'] : null,
    );

    return docs.map((DocumentData doc) {
      return _deserialisePackaging(id: doc.id, data: doc.data);
    }).toList();
  }

  @override
  Stream<List<Packaging>> packagings({
    PackagingStatus? status,
    String? type,
    String? merchantId,
  }) {
    List<String> fieldNames = [];
    List<String> targetValues = [];

    if (status != null) {
      fieldNames.add('status');
      targetValues.add(_serialisePackagingStatus(status: status));
    }

    if (type != null) {
      fieldNames.add('type');
      targetValues.add(type);
    }

    if (merchantId != null) {
      fieldNames.add('merchantId');
      targetValues.add(merchantId);
    }

    return db
        .documents(
      collectionPath: packagingsCollection,
      fieldNames: fieldNames,
      targetValues: targetValues,
    )
        .map((List<DocumentData> docs) {
      return docs.map((DocumentData doc) {
        return _deserialisePackaging(id: doc.id, data: doc.data);
      }).toList();
    });
  }

  @override
  Future<Packaging?> retrievePackagingById({
    required String id,
  }) async {
    DocumentData? doc = await db.retrieveDocument(
      documentPath: '$packagingsCollection/$id',
    );
    if (doc == null) return null;
    return _deserialisePackaging(
      id: doc.id,
      data: doc.data,
    );
  }

  @override
  Future<Packaging?> retrievePackagingByCustomId({
    required String customId,
  }) async {
    List<DocumentData?> docs = await db.retrieveDocuments(
      collectionPath: packagingsCollection,
      fieldNamesEqual: ['customId'],
      targetValuesEqual: [customId],
    );
    if (docs.isEmpty) return null;
    return _deserialisePackaging(
      id: docs[0]!.id,
      data: docs[0]!.data,
    );
  }

  @override
  Future<int?> retrieveLastCode({
    PackagingStatus? status,
    String? type,
    String? merchantId,
    DateTime? earliestLastTrackedDate,
  }) async {
    List<String> fieldNamesEqual = [];
    List<String> targetValuesEqual = [];
    List<String> fieldNamesGreaterThan = [];
    List<dynamic> targetValuesGreaterThan = [];

    if (status != null) {
      fieldNamesEqual.add('status');
      targetValuesEqual.add(_serialisePackagingStatus(status: status));
    }

    if (type != null) {
      fieldNamesEqual.add('type');
      targetValuesEqual.add(type);
    }

    if (merchantId != null) {
      fieldNamesEqual.add('merchantId');
      targetValuesEqual.add(merchantId);
    }

    if (earliestLastTrackedDate != null) {
      fieldNamesGreaterThan.add('lastTracked');
      targetValuesGreaterThan.add(earliestLastTrackedDate);
    }

    List<DocumentData> docs = await db.retrieveDocuments(
      collectionPath: packagingsCollection,
      fieldNamesEqual: fieldNamesEqual,
      targetValuesEqual: targetValuesEqual,
      fieldNamesGreaterThan: fieldNamesGreaterThan,
      targetValuesGreaterThan: targetValuesGreaterThan,
      orderByField: 'code',
      orderDescending: true,
      limit: 1,
    );

    if (docs.isEmpty) return null;
    Packaging packaging = _deserialisePackaging(
      id: docs[0].id,
      data: docs[0].data,
    );
    return packaging.code;
  }

  @override
  Future<PackagingPublic?> getPackagingPublic({
    required String id,
  }) async {
    DocumentData? doc = await db.retrieveDocument(
      documentPath: '$packagingsPublicCollection/$id',
    );
    if (doc == null) return null;
    return _deserialisePackagingPublic(id: id, data: doc.data);
  }

  @override
  Future<int> getNumPackagings({
    String? type,
    PackagingStatus? status,
    bool? needsMaintenance,
  }) async {
    List<String> fieldNames = [];
    List<dynamic> targetValues = [];

    if (type != null) {
      fieldNames.add('type');
      targetValues.add(type);
    }

    if (status != null) {
      fieldNames.add('status');
      targetValues.add(_serialisePackagingStatus(status: status));
    }

    if (needsMaintenance != null) {
      fieldNames.add('needsMaintenance');
      targetValues.add(needsMaintenance);
    }

    return await db.countDocuments(
      collectionPath: packagingsCollection,
      fieldNamesEqual: fieldNames,
      targetValuesEqual: targetValues,
    );
  }

  @override
  Future<List<Packaging>> getPackagingsFromIds({
    required List<String> packagingIds,
  }) async {
    List<Future<DocumentData?>> fetches =
        packagingIds.map((String packagingId) {
      return db.retrieveDocument(
          documentPath: '$packagingsCollection/$packagingId');
    }).toList();

    List<DocumentData?> docs = await Future.wait(fetches);

    return docs
        .map((DocumentData? doc) {
          if (doc == null) return null;
          return _deserialisePackaging(
            id: doc.id,
            data: doc.data,
          );
        })
        .whereType<Packaging>()
        .toList();
  }

  Map<String, dynamic> _serialisePackaging({
    required Packaging packaging,
  }) {
    return {
      'type': packaging.type,
      'status': _serialisePackagingStatus(
        status: packaging.status,
      ),
      'merchantId': packaging.merchantId,
      'merchantName': packaging.merchantName,
      'lastTracked': packaging.lastTracked,
      'customerName': packaging.customerName,
      'orderNumber': packaging.orderNumber,
      'customId': packaging.customId,
      'code': packaging.code,
      'manufacturer': packaging.manufacturer,
      'labelStyle': _serialiseLabelStyle(style: packaging.labelStyle),
    };
  }

  Packaging _deserialisePackaging({
    required String id,
    required Map<String, dynamic> data,
  }) {
    return Packaging(
      identifier: id,
      code: data['code'],
      type: data['type'],
      status: data['status'] == null
          ? PackagingStatus.inStoreNew
          : _deserialisePackagingStatus(status: data['status']),
      merchantId: data['merchantId'],
      merchantName: data['merchantName'],
      lastTracked: data['lastTracked']?.toDate(),
      customerName: data['customerName'],
      orderNumber: data['orderNumber'],
      customId: data['customId'],
      manufacturer: data['manufacturer'],
      labelStyle: _deserialiseLabelStyle(style: data['labelStyle']),
    );
  }

  String _serialisePackagingStatus({
    required PackagingStatus status,
  }) {
    switch (status) {
      case PackagingStatus.inStoreNew:
        return 'in-store-new';
      case PackagingStatus.inStoreReturned:
        return 'in-store-returned';
      case PackagingStatus.enRouteToMerchant:
        return 'en-route-to-merchant';
      case PackagingStatus.withMerchant:
        return 'with-merchant';
      case PackagingStatus.withMerchantReturned:
        return 'with-merchant-returned';
      case PackagingStatus.withCustomer:
        return 'with-customer';
      case PackagingStatus.inMaintenance:
        return 'in-maintenance';
      case PackagingStatus.inStoreReady:
        return 'in-store-ready';
    }
  }

  PackagingStatus _deserialisePackagingStatus({
    required String status,
  }) {
    switch (status) {
      case 'in-store-new':
        return PackagingStatus.inStoreNew;
      case 'in-store-returned':
        return PackagingStatus.inStoreReturned;
      case 'en-route-to-merchant':
        return PackagingStatus.enRouteToMerchant;
      case 'with-merchant':
        return PackagingStatus.withMerchant;
      case 'with-merchant-returned':
        return PackagingStatus.withMerchantReturned;
      case 'with-customer':
        return PackagingStatus.withCustomer;
      case 'in-maintenance':
        return PackagingStatus.inMaintenance;
      case 'in-store-ready':
        return PackagingStatus.inStoreReady;
      default:
        throw PackagingStatusSerialisationException(
            'Packaging status $status is not a valid status');
    }
  }

  String? _serialiseLabelStyle({
    required LabelStyle? style,
  }) {
    switch (style) {
      case LabelStyle.gamifiedV1:
        return 'gamifiedv1';
      case LabelStyle.simpleV1:
        return 'simplev1';
      case LabelStyle.simpleV2:
        return 'simplev2';
      case LabelStyle.gamifiedV3:
        return 'gamifiedv3';
      case LabelStyle.simpleV3:
        return 'simplev3';
      case LabelStyle.customGoliathFR:
        return 'customGoliathFR';
      case LabelStyle.customGoliathEN:
        return 'customGoliathEN';
      case LabelStyle.minimal:
        return 'minimal';
      default:
        return null;
    }
  }

  LabelStyle? _deserialiseLabelStyle({
    required String? style,
  }) {
    switch (style) {
      case 'gamifiedv1':
        return LabelStyle.gamifiedV1;
      case 'simplev1':
        return LabelStyle.simpleV1;
      case 'simplev2':
        return LabelStyle.simpleV2;
      case 'gamifiedv3':
        return LabelStyle.gamifiedV3;
      case 'simplev3':
        return LabelStyle.simpleV3;
      case 'customGoliathFR':
        return LabelStyle.customGoliathFR;
      case 'customGoliathEN':
        return LabelStyle.customGoliathEN;
      case 'minimal':
        return LabelStyle.minimal;
      default:
        return null;
    }
  }

  Map<String, dynamic> _serialisePackagingPublic({
    required Packaging packaging,
  }) {
    return {
      'type': packaging.type,
      'code': packaging.code,
      'merchantId': packaging.merchantId,
    };
  }

  PackagingPublic _deserialisePackagingPublic({
    required String id,
    required Map<String, dynamic> data,
  }) {
    return PackagingPublic(
      id: id,
      code: data['code'],
      type: data['type'],
      merchantId: data['merchantId'],
    );
  }
}
