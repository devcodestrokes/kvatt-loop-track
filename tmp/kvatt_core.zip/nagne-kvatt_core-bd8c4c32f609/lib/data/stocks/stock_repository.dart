import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_core/domain/stocks/stock.dart';
import 'package:kvatt_core/domain/stocks/stock_repository_interface.dart';

@Deprecated(
  '''
      We are changing the approach for handling stocks.
      Stocks are now calculated directly by looking at packagings data.
      We are not using the stocks collection anymore.
    ''',
)
class StocksRepository implements StocksRepositoryInterface {
  final String stocksCollection = 'stocks';

  DbInterface db;

  StocksRepository({
    required this.db,
  });

  @override
  Future<Stock?> retrieveStock({
    required String merchantId,
  }) async {
    DocumentData? doc = await db.retrieveDocument(
      documentPath: '$stocksCollection/$merchantId',
    );
    if (doc == null) return null;
    return Stock(
      levels: Map<String, int>.from(doc.data['levels']),
    );
  }

  @override
  Future<void> updateStock({
    required Stock stock,
    required String merchantId,
  }) async {
    await db.updateDocument(
      documentPath: '$stocksCollection/$merchantId',
      data: {'levels': stock.levels},
    );
  }

  @override
  Future<void> deleteStock({
    required String merchantId,
  }) async {
    await db.deleteDocument(
      documentPath: '$stocksCollection/$merchantId',
    );
  }

  @override
  Future<List<Stock>> retrieveMerchantStocks(
      {required List<String> merchantIds}) async {
    List<Future<DocumentData?>> retrieveTasks =
        merchantIds.map((String merchantId) {
      return db.retrieveDocument(
        documentPath: '$stocksCollection/$merchantId',
      );
    }).toList();
    List<DocumentData?> docs = await Future.wait(retrieveTasks);
    return docs.map((DocumentData? doc) {
      if (doc == null) {
        return Stock(levels: {});
      }
      return Stock(
        levels: Map<String, int>.from(doc.data['levels']),
      );
    }).toList();
  }

  @override
  Stream<Stock?> stock({required String merchantId}) {
    return db
        .document(documentPath: '$stocksCollection/$merchantId')
        .map((DocumentData? doc) {
      if (doc == null) return null;
      return Stock(
        levels: Map<String, int>.from(doc.data['levels']),
      );
    });
  }
}
