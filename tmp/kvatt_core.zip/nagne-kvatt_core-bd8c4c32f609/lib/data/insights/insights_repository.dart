import 'package:kvatt_core/data/base/db/cloud_function_callable_interface.dart';
import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/insights/checkout_pick_up_info.dart';
import 'package:kvatt_core/domain/insights/insights_repository_interface.dart';
import 'package:kvatt_core/domain/insights/pack_info.dart';
import 'package:kvatt_core/domain/insights/pack_insight.dart';
import 'package:kvatt_core/domain/insights/return_info.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class InsightsRepository implements InsightsRepositoryInterface {
  final String merchantInsightsCollection = 'merchant_insights';

  DbInterface db;
  CloudFunctionCallableInterface callable;
  String region;

  InsightsRepository({
    required this.db,
    required this.callable,
    required this.region,
  });

  @override
  Future<ReturnInfo> getMerchantReturnInfo({
    required String merchantId,
    Period? period,
  }) async {
    Map<String, dynamic> payload = {
      'action': 'getReturnInfo',
      'merchantId': merchantId,
    };

    if (period != null) {
      payload['start'] = DateFormat('yyyy-MM-dd').format(period.start);
      payload['end'] = DateFormat('yyyy-MM-dd').format(period.end);
    }
    dynamic data = await callable.callFunction(
      functionName: 'insightsCallable',
      functionRegion: region,
      data: payload,
    );

    return ReturnInfo(
      numShipped: data['numShipped'],
      numReturned: data['numReturned'],
      numPending: data['numPending'],
      numLost: data['numLost'],
      returnRate: data['returnRate'],
      maxReturnDays: data['maxReturnDays'],
      minReturnDays: data['minReturnDays'],
      averageReturnDays: data['averageReturnDays'],
    );
  }

  @override
  Future<List<dynamic>> getPacksInfoForMerchant({
    required String merchantId,
    Period? period,
  }) async {
    Map<String, dynamic> payload = {
      'action': 'getPacksInfo',
      'merchantId': merchantId,
    };

    if (period != null) {
      payload['start'] = DateFormat('yyyy-MM-dd').format(period.start);
      payload['end'] = DateFormat('yyyy-MM-dd').format(period.end);
    }

    dynamic data = await callable.callFunction(
      functionName: 'insightsCallable',
      functionRegion: region,
      data: payload,
    );

    return data.map((dynamic data) {
      return PackInfo(
        code: data['code'],
        type: data['type'],
        insights: PackInsight(
          packId: '',
          numTimesShipped: data['numTimesShipped'],
          numTimesReturned: data['numTimesReturned'],
          averageReturnTimeInDays: data['averageReturnTimeInDays'],
          lastShippedDate: data['lastShippedDate'] != null
              ? DateTime.parse(data['lastShippedDate'])
              : null,
          lastReturnedDate: data['lastReturnedDate'] != null
              ? DateTime.parse(data['lastReturnedDate'])
              : null,
        ),
      );
    }).toList();
  }

  @override
  Future<CheckoutPickUpInfo?> getMerchantCheckoutPickUpInfo({
    required String merchantId,
    Period? period,
  }) async {
    Map<String, dynamic> payload = {
      'action': 'getCheckoutPickUpInfo',
      'merchantId': merchantId,
    };

    if (period != null) {
      payload['start'] = DateFormat('yyyy-MM-dd').format(period.start);
      payload['end'] = DateFormat('yyyy-MM-dd').format(period.end);
    }

    dynamic data = await callable.callFunction(
      functionName: 'insightsCallable',
      functionRegion: region,
      data: payload,
    );

    if (data == null) {
      return null;
    }

    return CheckoutPickUpInfo(
      totalOrders: data['totalOrders'],
      numOrdersWithKvattPack: data['numOrdersWithKvattPack'],
      pickUpRate: data['pickUpRate'],
    );
  }
}
