import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/domain/shopify/shopify_order_fulfillments_repository_interface.dart';

class ShopifyOrderFulfillmentsRepository
    implements ShopifyOrderFulfillmentsRepositoryInterface {
  static const String shopifyOrderFulfillmentsCollection =
      'shopify_order_fulfillments';

  DbInterface db;

  ShopifyOrderFulfillmentsRepository({
    required this.db,
  });

  @override
  Future<int> getQuantityShopifyOrderFulfillments({
    required String merchantId,
    DateTime? datedAfter,
  }) async {
    int quantity = await db.countDocuments(
      collectionPath: shopifyOrderFulfillmentsCollection,
      fieldNamesEqual: ['merchantId'],
      targetValuesEqual: [merchantId],
      fieldNamesGreaterThan: datedAfter != null ? ['date'] : null,
      targetValuesGreaterThan: datedAfter != null ? [datedAfter] : null,
    );

    return quantity;
  }
}
