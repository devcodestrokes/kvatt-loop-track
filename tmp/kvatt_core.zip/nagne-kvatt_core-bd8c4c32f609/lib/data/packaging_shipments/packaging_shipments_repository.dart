import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipment.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipment_status.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_repository_interface.dart';

class PackagingShipmentStatusSerialisationException implements Exception {
  String? message;
  PackagingShipmentStatusSerialisationException(message);
}

class PackagingShipmentsRepository
    implements PackagingShipmentsRepositoryInterface {
  static const String packagingShipmentsCollection = 'packaging_shipments';

  DbInterface db;

  PackagingShipmentsRepository({
    required this.db,
  });

  @override
  Future<List<PackagingShipment>> retrievePackagingShipments({
    required String merchantId,
    required PackagingShipmentStatus status,
  }) async {
    List<DocumentData> docs = await db.retrieveDocuments(
      collectionPath: packagingShipmentsCollection,
      fieldNamesEqual: [
        'merchantId',
        'status',
      ],
      targetValuesEqual: [
        merchantId,
        _serialisePackagingShipmentStatus(status: status),
      ],
    );

    return docs.map((DocumentData doc) {
      return _deserialisePackagingShipment(
        id: doc.id,
        data: doc.data,
      );
    }).toList();
  }

  @override
  Future<void> createPackagingShipment({
    required PackagingShipment packagingShipment,
  }) async {
    await db.createDocument(
      collectionPath: packagingShipmentsCollection,
      data: _serialisePackagingShipment(
        packagingShipment: packagingShipment,
      ),
    );
  }

  @override
  Future<void> updatePackagingShipmentStatus({
    required String packagingShipmentId,
    required PackagingShipmentStatus status,
  }) async {
    await db.updateDocument(
      documentPath: '$packagingShipmentsCollection/$packagingShipmentId',
      data: {
        'status': _serialisePackagingShipmentStatus(status: status),
      },
    );
  }

  Map<String, dynamic> _serialisePackagingShipment({
    required PackagingShipment packagingShipment,
  }) {
    return {
      'packagingIds': packagingShipment.packagingIds,
      'productQuantities': packagingShipment.productQuantities,
      'merchantId': packagingShipment.merchantId,
      'sentDate': packagingShipment.sentDate,
      'status': _serialisePackagingShipmentStatus(
        status: packagingShipment.status,
      ),
    };
  }

  PackagingShipment _deserialisePackagingShipment({
    required String id,
    required Map<String, dynamic> data,
  }) {
    return PackagingShipment(
      id: id,
      merchantId: data['merchantId'],
      packagingIds: (data['packagingIds'] as List<dynamic>)
          .map((e) => e.toString())
          .toList(),
      productQuantities: _parseProductQuantitiesMap(
        data: data['productQuantities'],
      ),
      sentDate: data['sentDate'].toDate(),
      status: _deserialisePackagingShipmentStatus(status: data['status']),
    );
  }

  String _serialisePackagingShipmentStatus({
    required PackagingShipmentStatus status,
  }) {
    switch (status) {
      case PackagingShipmentStatus.awaitingMerchantConfirmation:
        return 'awaiting-merchant-confirmation';
      case PackagingShipmentStatus.received:
        return 'received';
    }
  }

  PackagingShipmentStatus _deserialisePackagingShipmentStatus({
    required String status,
  }) {
    switch (status) {
      case 'awaiting-merchant-confirmation':
        return PackagingShipmentStatus.awaitingMerchantConfirmation;
      case 'received':
        return PackagingShipmentStatus.received;
      default:
        throw PackagingShipmentStatusSerialisationException(
            'Packaging shipment status $status is not valid');
    }
  }

  Map<String, int> _parseProductQuantitiesMap({
    required Map<String, dynamic> data,
  }) {
    Map<String, int> productQuantities = {};
    List<String> products = data.keys.toList();
    for (var product in products) {
      try {
        productQuantities[product] = int.parse(data[product].toString());
      } catch (e) {
        continue;
      }
    }
    return productQuantities;
  }
}
