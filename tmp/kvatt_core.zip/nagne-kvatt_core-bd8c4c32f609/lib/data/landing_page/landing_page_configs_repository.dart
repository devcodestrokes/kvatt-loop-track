import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_configs_repository_interface.dart';

class LandingPageConfigsRepository
    implements LandingPageConfigsRepositoryInterface {
  static const String landingPageConfigsCollection = 'landing_page_configs';

  DbInterface db;

  LandingPageConfigsRepository({
    required this.db,
  });

  @override
  Future<LandingPageConfig?> retrieveConfigs({
    required String merchantId,
  }) async {
    DocumentData? doc = await db.retrieveDocument(
      documentPath: '$landingPageConfigsCollection/$merchantId',
    );
    if (doc == null) {
      return null;
    }

    return _deserialiseLandingPageConfig(doc.data);
  }

  @override
  Future<void> updateConfigs({
    required String merchantId,
    required LandingPageConfig? config,
  }) async {
    await db.updateDocument(
      documentPath: '$landingPageConfigsCollection/$merchantId',
      data: _serialiseLandingPageConfig(config),
    );
  }

  Map<String, dynamic> _serialiseLandingPageConfig(LandingPageConfig? config) {
    return {
      'returnLocationUrl': config?.returnLocationUrl,
      'returnLocationLabel': config?.returnLocationLabel,
    };
  }

  LandingPageConfig _deserialiseLandingPageConfig(Map<String, dynamic> data) {
    return LandingPageConfig(
      returnLocationUrl: data['returnLocationUrl'],
      returnLocationLabel: data['returnLocationLabel'],
    );
  }
}
