abstract class CloudFunctionCallableInterface {
  Future<dynamic> callFunction({
    required String functionName,
    required String functionRegion,
    Map<String, dynamic>? data,
  });
}
