class DocumentData {
  String id;
  Map<String, dynamic> data;
  String? parentId;

  DocumentData({
    required this.id,
    required this.data,
    this.parentId,
  });
}
