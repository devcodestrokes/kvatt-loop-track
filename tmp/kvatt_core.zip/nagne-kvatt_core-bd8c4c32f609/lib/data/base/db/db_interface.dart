import 'document_data.dart';

abstract class DbInterface {
  Future<String> createDocument({
    required String collectionPath,
    required Map<String, dynamic> data,
  });

  Future<void> updateDocument({
    required String documentPath,
    required Map<String, dynamic> data,
  });

  Future<DocumentData?> retrieveDocument({
    required String documentPath,
  });

  Future<List<DocumentData>> retrieveDocuments({
    required String collectionPath,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
    List<String>? fieldNamesGreaterThan,
    List<dynamic>? targetValuesGreaterThan,
    List<String>? fieldNamesNotNull,
    String? orderByField,
    bool? orderDescending,
    int? limit,
    int? startAt,
  });

  Stream<List<DocumentData>> documents({
    required String collectionPath,
    List<String>? fieldNames,
    List<String>? targetValues,
  });

  Stream<DocumentData?> document({
    required String documentPath,
  });

  Future<int> countCollectionGroupDocuments({
    required String collectionGroupName,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
  });

  Future<int> countDocuments({
    required String collectionPath,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
    List<String>? fieldNamesNotNull,
    List<String>? fieldNamesGreaterThan,
    List<dynamic>? targetValuesGreaterThan,
  });

  Future<List<DocumentData>> retrieveCollectionGroupDocuments({
    required String collectionGroupName,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
    List<String>? fieldNamesGreaterThanOrEqualTo,
    List<dynamic>? targetValuesGreaterThanOrEqualTo,
    List<String>? fieldNamesLessThanOrEqualTo,
    List<dynamic>? targetValuesLessThanOrEqualTo,
  });

  Future<void> deleteDocument({
    required String documentPath,
  });
}
