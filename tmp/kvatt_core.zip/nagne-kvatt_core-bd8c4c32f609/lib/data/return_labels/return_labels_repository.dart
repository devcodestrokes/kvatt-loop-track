import 'package:kvatt_core/data/base/db/cloud_function_callable_interface.dart';
import 'package:kvatt_core/domain/return_labels/la_poste/la_poste_smart_data.dart';
import 'package:kvatt_core/domain/return_labels/return_labels_repository_interface.dart';

class ReturnLabelsRepository implements ReturnLabelsRepositoryInterface {
  CloudFunctionCallableInterface callable;
  String region;

  ReturnLabelsRepository({
    required this.callable,
    required this.region,
  });

  @override
  Future<List<LaPosteSmartData>> getLaposteSmartData({
    required int quantity,
  }) async {
    List<dynamic> results = await callable.callFunction(
      functionName: 'getLaPosteSDCallable',
      functionRegion: region,
      data: {
        'quantity': quantity,
      },
    );

    return results.map((dynamic data) {
      return _deserialiseLaPosteSmartData(data: data);
    }).toList();
  }

  LaPosteSmartData _deserialiseLaPosteSmartData({
    required dynamic data,
  }) {
    return LaPosteSmartData(
      datamatrixImage: data['datamatrixImage'],
      label: data['sdLabel'],
    );
  }
}
