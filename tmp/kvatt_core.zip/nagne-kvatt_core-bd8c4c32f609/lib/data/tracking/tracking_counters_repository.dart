import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_core/domain/tracking/tracking_counters_repository_interface.dart';
import 'package:kvatt_core/domain/tracking/tracking_event.dart';

class TrackingCountersRepository
    implements TrackingCountersRepositoryInterface {
  final String trackingCountersCollection = 'tracking_counters';

  DbInterface db;

  TrackingCountersRepository({
    required this.db,
  });

  @override
  Stream<int?> trackingCount({
    required String userId,
    required TrackingEvent event,
  }) {
    return db
        .document(
      documentPath: '$trackingCountersCollection/$userId',
    )
        .map((DocumentData? doc) {
      if (doc == null) {
        return null;
      }
      switch (event) {
        case TrackingEvent.returnedToKvatt:
          return doc.data['returnedToKvattCount'];
        default:
          return null;
      }
    });
  }
}
