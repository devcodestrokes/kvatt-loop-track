import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_core/data/packagings/packagings_repository.dart';
import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/tracking/tracking_event.dart';
import 'package:kvatt_core/domain/tracking/tracking_history.dart';
import 'package:kvatt_core/domain/tracking/tracking_history_repository_interface.dart';

class TrackingEventSerialisationException implements Exception {
  String? message;
  TrackingEventSerialisationException(message);
}

class TrackingHistoryRepository implements TrackingHistoryRepositoryInterface {
  static const String packagingsHistorySubCollection = 'history';

  DbInterface db;

  TrackingHistoryRepository({
    required this.db,
  });

  @override
  Future<void> addTrackingHistories({
    required List<TrackingHistory> trackingHistories,
  }) async {
    List<Future> createTasks = trackingHistories
        .map(
          (TrackingHistory history) => db.createDocument(
            collectionPath:
                '${PackagingsRepository.packagingsCollection}/${history.packagingId}/history',
            data: _serialiseTrackingHistory(trackingHistory: history),
          ),
        )
        .toList();
    await Future.wait(createTasks);
  }

  @override
  Future<List<TrackingHistory>> retrieveTrackingHistory({
    required String packagingId,
    String? merchantId,
  }) async {
    List<DocumentData> docs = await db.retrieveDocuments(
      collectionPath:
          '${PackagingsRepository.packagingsCollection}/$packagingId/$packagingsHistorySubCollection',
      fieldNamesEqual: merchantId != null ? ['merchantId'] : null,
      targetValuesEqual: merchantId != null ? [merchantId] : null,
      orderByField: 'date',
      orderDescending: true,
    );
    return docs.map((DocumentData doc) {
      return _deserialiseTrackingHistory(
        packagingId: packagingId,
        data: doc.data,
      );
    }).toList();
  }

  @override
  Future<List<TrackingHistory>> getTrackingHistoriesForMerchant({
    required String merchantId,
    TrackingEvent? event,
    Period? period,
  }) async {
    List<String> equalFilterNames = ['merchantId'];
    List<dynamic> equalFilterTargets = [merchantId];

    List<String>? greaterThanOrEqualToFilterNames =
        period != null ? ['date'] : null;
    List<dynamic>? greaterThanOrEqualToFilterTargets =
        period != null ? [period.start] : null;

    List<String>? lessThanOrEqualToFilterNames =
        period != null ? ['date'] : null;
    List<dynamic>? lessThanOrEqualToFilterTargets =
        period != null ? [period.end] : null;

    if (event != null) {
      equalFilterNames.add('event');
      equalFilterTargets.add(
        _serialiseTrackingEvent(event: event),
      );
    }

    List<DocumentData> docs = await db.retrieveCollectionGroupDocuments(
      collectionGroupName: packagingsHistorySubCollection,
      fieldNamesEqual: equalFilterNames,
      targetValuesEqual: equalFilterTargets,
      fieldNamesGreaterThanOrEqualTo: greaterThanOrEqualToFilterNames,
      targetValuesGreaterThanOrEqualTo: greaterThanOrEqualToFilterTargets,
      fieldNamesLessThanOrEqualTo: lessThanOrEqualToFilterNames,
      targetValuesLessThanOrEqualTo: lessThanOrEqualToFilterTargets,
    );

    return docs.map((DocumentData doc) {
      return _deserialiseTrackingHistory(
        packagingId: doc.parentId ?? '',
        data: doc.data,
      );
    }).toList();
  }

  @override
  Future<int> getTrackingHistoriesCountForMerchant({
    required String merchantId,
    TrackingEvent? event,
    Period? period,
  }) async {
    List<String> equalFilterNames = ['merchantId'];
    List<dynamic> equalFilterTargets = [merchantId];

    if (event != null) {
      equalFilterNames.add('event');
      equalFilterTargets.add(
        _serialiseTrackingEvent(event: event),
      );
    }

    int count = await db.countCollectionGroupDocuments(
      collectionGroupName: packagingsHistorySubCollection,
      fieldNamesEqual: equalFilterNames,
      targetValuesEqual: equalFilterTargets,
    );

    return count;
  }

  Map<String, dynamic> _serialiseTrackingHistory({
    required TrackingHistory trackingHistory,
  }) {
    return {
      'date': trackingHistory.date,
      'trackedByUserId': trackingHistory.trackedByUserId,
      'event': _serialiseTrackingEvent(event: trackingHistory.event),
      'merchantId': trackingHistory.merchantId,
      'merchantName': trackingHistory.merchantName,
      'customerName': trackingHistory.customerName,
      'orderNumber': trackingHistory.orderNumber,
    };
  }

  TrackingHistory _deserialiseTrackingHistory({
    required String packagingId,
    required Map<String, dynamic> data,
  }) {
    return TrackingHistory(
      packagingId: packagingId,
      date: data['date'].toDate(),
      event: _deserialiseTrackingEvent(event: data['event']),
      trackedByUserId: data['trackedByUserId'],
      merchantId: data['merchantId'],
      merchantName: data['merchantName'],
      customerName: data['customerName'],
      orderNumber: data['orderNumber'],
    );
  }

  String _serialiseTrackingEvent({
    required TrackingEvent event,
  }) {
    switch (event) {
      case TrackingEvent.shippedToMerchant:
        return 'shipped-to-merchant';
      case TrackingEvent.receivedByMerchant:
        return 'received-by-merchant';
      case TrackingEvent.shippedToCustomer:
        return 'shipped-to-customer';
      case TrackingEvent.returnedFromCustomer:
        return 'returned-from-customer';
      case TrackingEvent.returnedToKvatt:
        return 'returned-to-kvatt';
      case TrackingEvent.sentToMaintenance:
        return 'sent-to-maintenance';
      case TrackingEvent.outOfMaintenance:
        return 'out-of-maintenance';
      //Legacy events
      case TrackingEvent.returnedToKvattNoMaintenance:
        return 'returned-to-kvatt-no-maintenance';
      case TrackingEvent.returnedToKvattNeedsMaintenance:
        return 'returned-to-kvatt-needs-maintenance';
    }
  }

  TrackingEvent _deserialiseTrackingEvent({
    required String event,
  }) {
    switch (event) {
      case 'shipped-to-merchant':
        return TrackingEvent.shippedToMerchant;
      case 'received-by-merchant':
        return TrackingEvent.receivedByMerchant;
      case 'shipped-to-customer':
        return TrackingEvent.shippedToCustomer;
      case 'returned-from-customer':
        return TrackingEvent.returnedFromCustomer;
      case 'returned-to-kvatt':
        return TrackingEvent.returnedToKvatt;
      case 'sent-to-maintenance':
        return TrackingEvent.sentToMaintenance;
      case 'out-of-maintenance':
        return TrackingEvent.outOfMaintenance;
      //Legacy events
      case 'returned-to-kvatt-no-maintenance':
        return TrackingEvent.returnedToKvattNoMaintenance;
      case 'returned-to-kvatt-needs-maintenance':
        return TrackingEvent.returnedToKvattNeedsMaintenance;
      default:
        throw TrackingEventSerialisationException('Event $event is not valid');
    }
  }
}
