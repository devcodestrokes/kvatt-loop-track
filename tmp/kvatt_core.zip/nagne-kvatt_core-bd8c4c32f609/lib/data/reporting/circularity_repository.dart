import 'package:intl/intl.dart';
import 'package:kvatt_core/data/base/db/cloud_function_callable_interface.dart';
import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/reporting/circularity_report_comment.dart';
import 'package:kvatt_core/domain/reporting/circularity_repository_interface.dart';

class CircularityRepository implements CircularityRepositoryInterface {
  CloudFunctionCallableInterface callable;
  String region;

  CircularityRepository({
    required this.callable,
    required this.region,
  });

  @override
  Future<void> addComment({
    required String merchantId,
    required Period period,
    required String comment,
  }) async {
    Map<String, dynamic> payload = {
      'action': 'addComment',
      'merchantId': merchantId,
      'comment': comment,
      'from': DateFormat('yyyy-MM-dd').format(period.start),
      'to': DateFormat('yyyy-MM-dd').format(period.end),
    };

    await callable.callFunction(
      functionName: 'circularityCallable',
      functionRegion: region,
      data: payload,
    );
  }

  @override
  Future<List<CircularityReportComment>> retrieveComments({
    required String merchantId,
  }) async {
    Map<String, dynamic> payload = {
      'action': 'retrieveComments',
      'merchantId': merchantId,
    };

    List results = await callable.callFunction(
      functionName: 'circularityCallable',
      functionRegion: region,
      data: payload,
    );

    return results.map((data) {
      return CircularityReportComment(
        comment: data['comment'],
        from: DateTime.parse(data['from']),
        to: DateTime.parse(data['to']),
      );
    }).toList();
  }
}
