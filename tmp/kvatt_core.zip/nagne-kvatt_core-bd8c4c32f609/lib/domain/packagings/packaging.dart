import 'package:kvatt_core/domain/labels/label_style.dart';

import 'packaging_status.dart';

class Packaging {
  String identifier;
  int code;
  String type;
  String manufacturer;
  PackagingStatus status;
  LabelStyle? labelStyle;
  String? merchantId;
  DateTime? lastTracked;
  String? customerName;
  String? orderNumber;
  String? merchantName;
  String? customId;

  Packaging({
    required this.identifier,
    required this.code,
    required this.manufacturer,
    required this.type,
    required this.status,
    this.labelStyle,
    this.merchantId,
    this.lastTracked,
    this.customerName,
    this.orderNumber,
    this.merchantName,
    this.customId,
  });

  //TODO: Do not mutate objects here

  void markAsReturnedToKvatt({
    DateTime? date,
  }) {
    //TODO: What to do with custom id here?
    status = PackagingStatus.inStoreReturned;
    merchantId = null;
    merchantName = null;
    customerName = null;
    orderNumber = null;
    lastTracked = date ?? DateTime.now();
  }

  void markAsInMaintenance() {
    status = PackagingStatus.inMaintenance;
    merchantId = null;
    merchantName = null;
    customerName = null;
    orderNumber = null;
    lastTracked = DateTime.now();
  }

  void markAsReady() {
    status = PackagingStatus.inStoreReady;
    merchantId = null;
    merchantName = null;
    customerName = null;
    orderNumber = null;
    lastTracked = DateTime.now();
  }

  void markAsOnRouteToMerchant({
    required String? merchantId,
    required String? merchantName,
    DateTime? date,
  }) {
    status = PackagingStatus.enRouteToMerchant;
    this.merchantId = merchantId;
    this.merchantName = merchantName;
    lastTracked = date ?? DateTime.now();
    customerName = null;
    orderNumber = null;
  }

  void markAsShippedToMerchant({
    required String? merchantId,
    required String? merchantName,
    DateTime? date,
  }) {
    //TODO: How to handle needsMaintenance here
    status = PackagingStatus.withMerchant;
    this.merchantId = merchantId;
    this.merchantName = merchantName;
    lastTracked = date ?? DateTime.now();
    customerName = null;
    orderNumber = null;
  }

  void markAsShippedToCustomer({
    required String customerName,
    required String orderNumber,
    DateTime? date,
  }) {
    status = PackagingStatus.withCustomer;
    this.customerName = customerName;
    this.orderNumber = orderNumber;
    lastTracked = date ?? DateTime.now();
  }

  void markAsReturnedFromCustomer() {
    status = PackagingStatus.withMerchantReturned;
    customerName = null;
    orderNumber = null;
    lastTracked = DateTime.now();
  }
}
