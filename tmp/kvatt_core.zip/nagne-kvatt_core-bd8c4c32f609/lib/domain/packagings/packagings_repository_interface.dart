import 'package:kvatt_core/domain/packagings/packaging_public.dart';

import 'packaging.dart';
import 'packaging_status.dart';

abstract class PackagingsRepositoryInterface {
  Future<List<Packaging>> createPackagings({
    required List<Packaging> packagings,
  });

  Future<void> updatePackaging({
    required Packaging packaging,
  });

  Future<void> updatePackagings({
    required List<Packaging> packagings,
  });

  Future<void> updateMerchantIdForPublicPackagings({
    required String? merchantId,
    required List<String> packagingIds,
  });

  Future<List<Packaging>> retrievePackagings({
    int? code,
    PackagingStatus? status,
    String? type,
    String? merchantId,
    String? orderNumber,
    DateTime? earliestLastTrackedDate,
    int? limit,
    int? startAt,
    bool? merchantNameNotNull,
  });

  Stream<List<Packaging>> packagings({
    PackagingStatus? status,
    String? type,
    String? merchantId,
  });

  Future<Packaging?> retrievePackagingById({
    required String id,
  });

  Future<Packaging?> retrievePackagingByCustomId({
    required String customId,
  });

  Future<int?> retrieveLastCode({
    PackagingStatus? status,
    String? type,
    String? merchantId,
    DateTime? earliestLastTrackedDate,
  });

  Future<PackagingPublic?> getPackagingPublic({
    required String id,
  });

  Future<int> getNumPackagings({
    String? type,
    PackagingStatus? status,
    bool? needsMaintenance,
  });

  Future<List<Packaging>> getPackagingsFromIds({
    required List<String> packagingIds,
  });
}
