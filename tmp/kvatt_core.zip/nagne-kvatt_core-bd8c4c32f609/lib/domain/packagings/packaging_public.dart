class PackagingPublic {
  String id;
  int code;
  String type;
  String? merchantId;

  PackagingPublic({
    required this.id,
    required this.code,
    required this.type,
    this.merchantId,
  });
}
