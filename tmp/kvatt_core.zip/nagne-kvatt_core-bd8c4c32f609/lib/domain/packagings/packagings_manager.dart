import 'package:kvatt_core/data/base/db/cloud_function_callable_interface.dart';
import 'package:kvatt_core/domain/labels/custom/goliath_labels_config.dart';
import 'package:kvatt_core/domain/labels/kvatt/kvatt_labels_config.dart';
import 'package:kvatt_core/domain/labels/label_style.dart';
import 'package:kvatt_core/domain/labels/kvatt/label_version.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_manager.dart';
import 'package:kvatt_core/domain/packagings/packaging_public.dart';
import 'package:kvatt_core/domain/tracking/tracking_event.dart';
import 'package:kvatt_core/domain/tracking/tracking_history.dart';
import 'package:kvatt_core/domain/tracking/tracking_history_repository_interface.dart';

import 'packaging.dart';
import 'packaging_status.dart';
import 'packagings_repository_interface.dart';

class InvalidCustomIdsException implements Exception {
  String? message;
  InvalidCustomIdsException(message);
}

class MissingLabelTypeException implements Exception {
  String? message;
  MissingLabelTypeException(message);
}

class PackagingsManager {
  PackagingsRepositoryInterface packagingsRepo;
  TrackingHistoryRepositoryInterface trackingHistoryRepo;
  CloudFunctionCallableInterface cloudFunctionCallable;
  PackagingShipmentsManager packagingShipmentsManager;
  KvattLabelsConfig kvattLabelsConfig;
  GoliathLabelsConfig goliathLabelsConfig;

  PackagingsManager({
    required this.packagingsRepo,
    required this.trackingHistoryRepo,
    required this.cloudFunctionCallable,
    required this.packagingShipmentsManager,
    required this.kvattLabelsConfig,
    required this.goliathLabelsConfig,
  });

  Future<List<Packaging>> createNewGoliathPackagings({
    required int numPackagings,
    required String packagingType,
    required String manufacturer,
    required LabelStyle labelStyle,
  }) async {
    List<String> sp00Codes = goliathLabelsConfig.generateSp00Codes(
      quantity: numPackagings,
    );

    List<Packaging> goliathPacks = await createNewPackagings(
      numPackagings: numPackagings,
      packagingType: packagingType,
      manufacturer: manufacturer,
      labelVersion: null,
      customLabelStyle: labelStyle,
      customIds: sp00Codes,
    );

    return goliathPacks;
  }

  Future<List<Packaging>> createNewPackagings({
    required int numPackagings,
    required String packagingType,
    required String manufacturer,
    required LabelVersion? labelVersion,
    required LabelStyle? customLabelStyle,
    List<String>? customIds,
  }) async {
    if (customIds != null && (customIds.length != numPackagings)) {
      throw InvalidCustomIdsException(
        'The number of customIds provided does not match the number of packs you want to create.',
      );
    }

    if (labelVersion == null && customLabelStyle == null) {
      throw MissingLabelTypeException(
          'Either labelVersion (for Kvatt labels) or customLabelStyle (for custom labels) should be provided');
    }

    int? lastCode = await getLastPackagingCode();
    int nextCode = _getNextCode(lastCode);

    List<LabelStyle> styleAlternates = [];

    if (labelVersion != null) {
      styleAlternates = kvattLabelsConfig.getLabelStylesForLabelVersion(
        labelVersion: labelVersion,
      );
    } else {
      styleAlternates = [customLabelStyle!];
    }

    int alternateIndex = 0;
    int customIdIndex = 0;

    List<Packaging> packagings = List.generate(numPackagings, (index) {
      LabelStyle style = styleAlternates[alternateIndex];

      Packaging packaging = Packaging(
        identifier: '',
        type: packagingType,
        manufacturer: manufacturer,
        status: PackagingStatus.inStoreNew,
        code: nextCode,
        labelStyle: style,
        customId: customIds == null ? null : customIds[customIdIndex],
      );

      if (labelVersion != null) {
        if (alternateIndex == (styleAlternates.length - 1)) {
          alternateIndex = 0;
        } else {
          alternateIndex++;
        }
      }

      customIdIndex++;
      nextCode++;
      return packaging;
    });

    return await packagingsRepo.createPackagings(
      packagings: packagings,
    );
  }

  Future<Packaging?> retrievePackagingByIdentifier({
    required String identifier,
    required bool isCustom,
  }) {
    if (isCustom) {
      return retrievePackagingByCustomId(id: identifier);
    } else {
      return retrievePackaging(id: identifier);
    }
  }

  Future<Packaging?> retrievePackagingByCustomId({
    required String id,
  }) async {
    return await packagingsRepo.retrievePackagingByCustomId(customId: id);
  }

  Future<Packaging?> retrievePackaging({
    required String id,
  }) async {
    return await packagingsRepo.retrievePackagingById(id: id);
  }

  Future<void> updatePackagingCustomerName({
    required Packaging packaging,
    required String newCustomerName,
  }) async {
    await packagingsRepo.updatePackaging(
      packaging: Packaging(
        identifier: packaging.identifier,
        code: packaging.code,
        type: packaging.type,
        manufacturer: packaging.manufacturer,
        status: packaging.status,
        merchantId: packaging.merchantId,
        merchantName: packaging.merchantName,
        lastTracked: packaging.lastTracked,
        customerName: newCustomerName,
        orderNumber: packaging.orderNumber,
        labelStyle: packaging.labelStyle,
      ),
    );
  }

  Future<void> updatePackagingOrderNumber({
    required Packaging packaging,
    required String newOrderNumber,
  }) async {
    await packagingsRepo.updatePackaging(
      packaging: Packaging(
        identifier: packaging.identifier,
        code: packaging.code,
        type: packaging.type,
        manufacturer: packaging.manufacturer,
        status: packaging.status,
        merchantId: packaging.merchantId,
        merchantName: packaging.merchantName,
        lastTracked: packaging.lastTracked,
        customerName: packaging.customerName,
        orderNumber: newOrderNumber,
        labelStyle: packaging.labelStyle,
      ),
    );
  }

  Future<List<Packaging>> getPackagings({
    int? code,
    PackagingStatus? status,
    String? type,
    String? merchantId,
    String? orderNumber,
    int? numPackagings,
    DateTime? earliestLastTrackedDate,
    int? startAtPackagingCode,
    bool? merchantNameNotNull,
  }) async {
    return await packagingsRepo.retrievePackagings(
      code: code,
      status: status,
      type: type,
      merchantId: merchantId,
      orderNumber: orderNumber,
      earliestLastTrackedDate: earliestLastTrackedDate,
      limit: numPackagings,
      startAt: startAtPackagingCode,
      merchantNameNotNull: merchantNameNotNull,
    );
  }

  Stream<List<Packaging>> packagings({
    PackagingStatus? status,
    String? type,
    String? merchantId,
  }) {
    return packagingsRepo.packagings(
      status: status,
      type: type,
      merchantId: merchantId,
    );
  }

  Future<List<TrackingHistory>> getPackagingTrackingHistory({
    required String packagingId,
  }) async {
    return await trackingHistoryRepo.retrieveTrackingHistory(
      packagingId: packagingId,
    );
  }

  Future<int?> getLastPackagingCode({
    PackagingStatus? status,
    String? type,
    String? merchantId,
    DateTime? earliestLastTrackedDate,
  }) async {
    return await packagingsRepo.retrieveLastCode(
      status: status,
      type: type,
      merchantId: merchantId,
      earliestLastTrackedDate: earliestLastTrackedDate,
    );
  }

  Future<PackagingPublic?> getPackagingPublicInfo({
    required String id,
  }) async {
    return await packagingsRepo.getPackagingPublic(id: id);
  }

  Future<List<TrackingHistory>> getPackagingHistoriesForMerchant({
    required String merchantId,
  }) async {
    return await trackingHistoryRepo.getTrackingHistoriesForMerchant(
      merchantId: merchantId,
    );
  }

  Future<List<Packaging>> getPackagingsFromIds({
    required List<String> packagingIds,
  }) async {
    return await packagingsRepo.getPackagingsFromIds(
      packagingIds: packagingIds,
    );
  }

  Future<int> getNumPacksAvailableForUse({
    required String type,
  }) async {
    List<Future<int>> fetchTasks = [
      packagingsRepo.getNumPackagings(
        type: type,
        status: PackagingStatus.inStoreNew,
      ),
      packagingsRepo.getNumPackagings(
        type: type,
        status: PackagingStatus.inStoreReady,
      ),
    ];
    List<int> counts = await Future.wait(fetchTasks);
    return counts[0] + counts[1];
  }

  Future<int> getNumPacksReturned({
    required String type,
  }) async {
    return packagingsRepo.getNumPackagings(
      type: type,
      status: PackagingStatus.inStoreReturned,
    );
  }

  Future<int> getNumPacksInMaintenance({
    required String type,
  }) async {
    return packagingsRepo.getNumPackagings(
      type: type,
      status: PackagingStatus.inMaintenance,
    );
  }

  Future<int> getNumPacksEnRouteToMerchants({
    required String type,
  }) async {
    return packagingsRepo.getNumPackagings(
      type: type,
      status: PackagingStatus.enRouteToMerchant,
    );
  }

  Future<int> getNumPacksWithMerchants({
    required String type,
  }) async {
    return packagingsRepo.getNumPackagings(
      type: type,
      status: PackagingStatus.withMerchant,
    );
  }

  Future<int> getNumPacksWithMerchantsReturned({
    required String type,
  }) async {
    return packagingsRepo.getNumPackagings(
      type: type,
      status: PackagingStatus.withMerchantReturned,
    );
  }

  Future<int> getNumPacksWithCustomers({
    required String type,
  }) async {
    return packagingsRepo.getNumPackagings(
      type: type,
      status: PackagingStatus.withCustomer,
    );
  }

  Future<void> recordReturnedToKvattPackagings({
    required String userId,
    required List<Packaging> packagings,
    DateTime? date,
  }) async {
    List<TrackingHistory> trackingHistories = packagings
        .map(
          (Packaging packaging) => TrackingHistory(
            packagingId: packaging.identifier,
            date: date ?? DateTime.now(),
            merchantId: packaging.merchantId,
            merchantName: packaging.merchantName,
            event: TrackingEvent.returnedToKvatt,
            trackedByUserId: userId,
          ),
        )
        .toList();

    List<Packaging> updatedPackagings = packagings.map((Packaging packaging) {
      packaging.markAsReturnedToKvatt(
        date: date,
      );
      return packaging;
    }).toList();

    await packagingsRepo.updatePackagings(
      packagings: updatedPackagings,
    );

    List<String> packIds =
        updatedPackagings.map((Packaging pack) => pack.identifier).toList();

    await packagingsRepo.updateMerchantIdForPublicPackagings(
      merchantId: null,
      packagingIds: packIds,
    );

    await trackingHistoryRepo.addTrackingHistories(
      trackingHistories: trackingHistories,
    );

    await cloudFunctionCallable.callFunction(
      functionName: 'trackPacksCallable',
      functionRegion: 'europe-west2',
      data: {
        'trackingEvent': 'returned-to-kvatt',
        'numPacks': packagings.length,
      },
    );
  }

  Future<void> recordSentToMaintenancePackagings({
    required String userId,
    required List<Packaging> packagings,
  }) async {
    List<TrackingHistory> trackingHistories = packagings
        .map(
          (Packaging packaging) => TrackingHistory(
            packagingId: packaging.identifier,
            date: DateTime.now(),
            merchantId: packaging.merchantId,
            merchantName: packaging.merchantName,
            event: TrackingEvent.sentToMaintenance,
            trackedByUserId: userId,
          ),
        )
        .toList();

    List<Packaging> updatedPackagings = packagings.map((Packaging packaging) {
      packaging.markAsInMaintenance();
      return packaging;
    }).toList();

    await packagingsRepo.updatePackagings(
      packagings: updatedPackagings,
    );
    await trackingHistoryRepo.addTrackingHistories(
      trackingHistories: trackingHistories,
    );
  }

  Future<void> recordOutOfMaintenancePackagings({
    required String userId,
    required List<Packaging> packagings,
  }) async {
    List<TrackingHistory> trackingHistories = packagings
        .map(
          (Packaging packaging) => TrackingHistory(
            packagingId: packaging.identifier,
            date: DateTime.now(),
            merchantId: packaging.merchantId,
            merchantName: packaging.merchantName,
            event: TrackingEvent.outOfMaintenance,
            trackedByUserId: userId,
          ),
        )
        .toList();

    List<Packaging> updatedPackagings = packagings.map((Packaging packaging) {
      packaging.markAsReady();
      return packaging;
    }).toList();

    await packagingsRepo.updatePackagings(
      packagings: updatedPackagings,
    );
    await trackingHistoryRepo.addTrackingHistories(
      trackingHistories: trackingHistories,
    );
  }

  Future<void> recordOutboundToMerchantPackagings({
    required String userId,
    required String? merchantId,
    required String? merchantName,
    required List<Packaging> packagings,
    required DateTime? date,
  }) async {
    List<TrackingHistory> trackingHistories = packagings
        .map(
          (Packaging packaging) => TrackingHistory(
            packagingId: packaging.identifier,
            date: date ?? DateTime.now(),
            event: TrackingEvent.shippedToMerchant,
            trackedByUserId: userId,
            merchantId: merchantId,
            merchantName: merchantName,
          ),
        )
        .toList();

    List<Packaging> updatedPackagings = [];

    if (merchantId != null) {
      updatedPackagings = packagings.map((Packaging packaging) {
        packaging.markAsOnRouteToMerchant(
          merchantId: merchantId,
          merchantName: merchantName,
          date: date,
        );
        return packaging;
      }).toList();
      await packagingShipmentsManager.recordNewShipment(
        packagings: packagings,
        merchantId: merchantId,
      );
    } else {
      updatedPackagings = packagings.map((Packaging packaging) {
        packaging.markAsShippedToMerchant(
          merchantId: merchantId,
          merchantName: merchantName,
          date: date,
        );
        return packaging;
      }).toList();
    }

    await packagingsRepo.updatePackagings(
      packagings: updatedPackagings,
    );

    List<String> packIds =
        updatedPackagings.map((Packaging pack) => pack.identifier).toList();

    await packagingsRepo.updateMerchantIdForPublicPackagings(
      merchantId: merchantId,
      packagingIds: packIds,
    );

    await trackingHistoryRepo.addTrackingHistories(
      trackingHistories: trackingHistories,
    );
  }

  Future<void> recordOutboundToCustomerPackagings({
    required String merchantId,
    required List<Packaging> packagings,
    required String customerName,
    required String orderNumber,
    DateTime? date,
  }) async {
    List<TrackingHistory> trackingHistories = packagings
        .map(
          (Packaging packaging) => TrackingHistory(
            packagingId: packaging.identifier,
            date: date ?? DateTime.now(),
            event: TrackingEvent.shippedToCustomer,
            merchantId: merchantId,
            trackedByUserId: merchantId,
            customerName: customerName,
            orderNumber: orderNumber,
          ),
        )
        .toList();

    List<Packaging> updatedPackagings = packagings.map((Packaging packaging) {
      packaging.markAsShippedToCustomer(
        customerName: customerName,
        orderNumber: orderNumber,
        date: date,
      );
      return packaging;
    }).toList();

    await packagingsRepo.updatePackagings(
      packagings: updatedPackagings,
    );

    await trackingHistoryRepo.addTrackingHistories(
      trackingHistories: trackingHistories,
    );

    await cloudFunctionCallable.callFunction(
      functionName: 'trackPacksCallable',
      functionRegion: 'europe-west2',
      data: {
        'trackingEvent': 'shipped-to-customer',
      },
    );
  }

  Future<void> recordInboundFromCustomerPackagings({
    required String merchantId,
    required List<Packaging> packagings,
  }) async {
    List<TrackingHistory> trackingHistories = packagings
        .map(
          (Packaging packaging) => TrackingHistory(
            packagingId: packaging.identifier,
            date: DateTime.now(),
            event: TrackingEvent.returnedFromCustomer,
            merchantId: merchantId,
            trackedByUserId: merchantId,
          ),
        )
        .toList();

    List<Packaging> updatedPackagings = packagings.map((Packaging packaging) {
      packaging.markAsReturnedFromCustomer();
      return packaging;
    }).toList();

    await packagingsRepo.updatePackagings(
      packagings: updatedPackagings,
    );

    await trackingHistoryRepo.addTrackingHistories(
      trackingHistories: trackingHistories,
    );
  }

  int _getNextCode(int? lastCode) {
    if (lastCode == null) return 1;
    return lastCode + 1;
  }
}
