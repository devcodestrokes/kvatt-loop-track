class CircularityReportComment {
  DateTime from;
  DateTime to;
  String comment;

  CircularityReportComment({
    required this.from,
    required this.to,
    required this.comment,
  });
}
