import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/reporting/circularity_report_comment.dart';
import 'package:kvatt_core/domain/reporting/circularity_repository_interface.dart';

class CircularityManager {
  CircularityRepositoryInterface repo;

  CircularityManager({
    required this.repo,
  });

  Future<void> addCommentForMerchant({
    required String merchantId,
    required String comment,
    required DateTime from,
    required DateTime to,
  }) async {
    await repo.addComment(
      merchantId: merchantId,
      period: Period(
        start: from,
        end: to,
      ),
      comment: comment,
    );
  }

  Future<List<CircularityReportComment>> retrieveCommentsForMerchant({
    required String merchantId,
  }) async {
    return await repo.retrieveComments(
      merchantId: merchantId,
    );
  }
}
