import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/reporting/circularity_report_comment.dart';

abstract class CircularityRepositoryInterface {
  Future<void> addComment({
    required String merchantId,
    required Period period,
    required String comment,
  });

  Future<List<CircularityReportComment>> retrieveComments({
    required String merchantId,
  });
}
