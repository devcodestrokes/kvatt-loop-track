class Period {
  DateTime start;
  DateTime end;

  Period({
    required this.start,
    required this.end,
  });
}
