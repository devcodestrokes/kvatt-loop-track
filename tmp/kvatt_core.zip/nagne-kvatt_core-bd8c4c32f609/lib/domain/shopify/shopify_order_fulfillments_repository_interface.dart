abstract class ShopifyOrderFulfillmentsRepositoryInterface {
  Future<int> getQuantityShopifyOrderFulfillments({
    required String merchantId,
    DateTime? datedAfter,
  });
}
