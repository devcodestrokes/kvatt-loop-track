import 'package:kvatt_core/data/base/db/cloud_function_callable_interface.dart';
import 'package:kvatt_core/domain/shopify/connection_status.dart';
import 'package:kvatt_core/domain/shopify/shopify_order_fulfillments_repository_interface.dart';

class ShopifyManager {
  CloudFunctionCallableInterface callable;
  ShopifyOrderFulfillmentsRepositoryInterface shopifyOrderFulfillmentRepo;

  ShopifyManager({
    required this.callable,
    required this.shopifyOrderFulfillmentRepo,
  });

  Future<int> getNumberOfShopifyOrderFulfillmentsForMerchant({
    required String merchantId,
    DateTime? datedAfter,
  }) async {
    return await shopifyOrderFulfillmentRepo
        .getQuantityShopifyOrderFulfillments(
      merchantId: merchantId,
      datedAfter: datedAfter,
    );
  }

  String buildShopifyAuthUrl({
    required String endpoint,
    required String shopId,
  }) {
    return '$endpoint?shop=$shopId';
  }

  Future<void> connectShopToMerchant({
    required String checkCode,
    required String region,
  }) async {
    await callable.callFunction(
      functionName: 'shopifyConnectCallable',
      functionRegion: region,
      data: {
        'action': 'linkShopToMerchant',
        'checkCode': checkCode,
      },
    );
  }

  Future<ConnectionStatus> getConnectionStatus({
    required String region,
  }) async {
    var result = await callable.callFunction(
      functionName: 'shopifyConnectCallable',
      functionRegion: region,
      data: {
        'action': 'getConnectionStatus',
      },
    );
    return ConnectionStatus(
      isConnected: result['isConnected'],
      sendGenericReturnEmailNudge: result['sendGenericReturnEmailNudge'],
    );
  }

  Future<bool> getCheckoutAddedStatus({
    required String region,
    required String shippingMethodText,
  }) async {
    var result = await callable.callFunction(
      functionName: 'shopifyConnectCallable',
      functionRegion: region,
      data: {
        'action': 'checkShippingMethodAdded',
        'shippingMethodText': shippingMethodText,
      },
    );
    return result as bool;
  }

  Future<void> setGenericReturnEmailNudge({
    required String region,
    required bool sendGenericReturnEmailNudge,
  }) async {
    await callable.callFunction(
      functionName: 'shopifyConnectCallable',
      functionRegion: region,
      data: {
        'action': 'setGenericReturnEmailNudge',
        'sendGenericReturnEmailNudge': sendGenericReturnEmailNudge,
      },
    );
  }
}
