class ConnectionStatus {
  bool isConnected;
  bool sendGenericReturnEmailNudge;

  ConnectionStatus({
    required this.isConnected,
    required this.sendGenericReturnEmailNudge,
  });
}
