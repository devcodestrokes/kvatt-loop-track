import 'packaging_shipment.dart';
import 'packaging_shipment_status.dart';

abstract class PackagingShipmentsRepositoryInterface {
  Future<void> createPackagingShipment({
    required PackagingShipment packagingShipment,
  });

  Future<List<PackagingShipment>> retrievePackagingShipments({
    required String merchantId,
    required PackagingShipmentStatus status,
  });

  Future<void> updatePackagingShipmentStatus({
    required String packagingShipmentId,
    required PackagingShipmentStatus status,
  });
}
