enum PackagingShipmentStatus {
  received,
  awaitingMerchantConfirmation,
}
