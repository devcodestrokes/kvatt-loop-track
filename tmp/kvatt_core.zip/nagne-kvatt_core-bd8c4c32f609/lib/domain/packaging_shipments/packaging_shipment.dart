import 'packaging_shipment_status.dart';

class PackagingShipment {
  String id;
  List<String> packagingIds;
  Map<String, int> productQuantities;
  String merchantId;
  DateTime sentDate;
  PackagingShipmentStatus status;

  PackagingShipment({
    required this.id,
    required this.packagingIds,
    required this.productQuantities,
    required this.merchantId,
    required this.sentDate,
    required this.status,
  });

  List<String> get products => productQuantities.keys.toList();
}
