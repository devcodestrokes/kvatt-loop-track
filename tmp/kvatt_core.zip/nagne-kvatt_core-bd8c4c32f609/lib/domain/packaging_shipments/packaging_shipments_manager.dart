import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'packaging_shipment.dart';
// ignore: depend_on_referenced_packages
import "package:collection/collection.dart";

import 'packaging_shipment_status.dart';
import 'packaging_shipments_repository_interface.dart';

class PackagingShipmentsManager {
  PackagingShipmentsRepositoryInterface packagingShipmentsRepository;

  PackagingShipmentsManager({
    required this.packagingShipmentsRepository,
  });

  Future<void> recordNewShipment({
    required List<Packaging> packagings,
    required String merchantId,
  }) async {
    PackagingShipment shipment = PackagingShipment(
      id: '',
      packagingIds: packagings
          .map((Packaging packaging) => packaging.identifier)
          .toList(),
      productQuantities: _getProductQuantities(packagings: packagings),
      merchantId: merchantId,
      sentDate: DateTime.now().toUtc(),
      status: PackagingShipmentStatus.awaitingMerchantConfirmation,
    );

    await packagingShipmentsRepository.createPackagingShipment(
      packagingShipment: shipment,
    );
  }

  Future<List<PackagingShipment>> retrieveAwaitingConfirmationShipments({
    required String merchantId,
  }) async {
    List<PackagingShipment> shipments =
        await packagingShipmentsRepository.retrievePackagingShipments(
      merchantId: merchantId,
      status: PackagingShipmentStatus.awaitingMerchantConfirmation,
    );
    return shipments;
  }

  Future<void> markPackagingShipmentAsReceived({
    required PackagingShipment packagingShipment,
  }) async {
    await packagingShipmentsRepository.updatePackagingShipmentStatus(
      packagingShipmentId: packagingShipment.id,
      status: PackagingShipmentStatus.received,
    );
  }

  Map<String, int> _getProductQuantities({
    required List<Packaging> packagings,
  }) {
    Map<String, int> productQuantities = {};

    Map<String, List<Packaging>> groups = groupBy<Packaging, String>(
        packagings, (Packaging packaging) => packaging.type);

    List<String> differentPackagingTypes = groups.keys.toList();

    for (int i = 0; i < differentPackagingTypes.length; i++) {
      int numPacks = groups[differentPackagingTypes[i]]?.length ?? 0;
      productQuantities[differentPackagingTypes[i]] = numPacks;
    }

    return productQuantities;
  }
}
