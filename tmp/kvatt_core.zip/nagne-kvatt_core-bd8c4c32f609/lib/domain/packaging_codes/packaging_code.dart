class PackagingCode {
  String code;
  String? identifier;
  bool isCustom;

  PackagingCode({
    required this.code,
    this.identifier,
    this.isCustom = false,
  });

  factory PackagingCode.parse({
    required String code,
    required String kvattLabelPath,
  }) {
    String? packId;
    bool isCustom = false;
    try {
      Uri uri = Uri.parse(code);
      if (uri.path == kvattLabelPath) {
        packId = uri.queryParameters['id'];
      } else {
        packId = code;
        isCustom = true;
      }
    } catch (_) {
      packId = code;
      isCustom = true;
    }

    return PackagingCode(
      code: code,
      identifier: packId,
      isCustom: isCustom,
    );
  }
}
