import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/insights/checkout_pick_up_info.dart';
import 'package:kvatt_core/domain/insights/return_info.dart';
import 'package:kvatt_core/domain/shopify/shopify_manager.dart';
import 'package:kvatt_core/domain/tracking/tracking_manager.dart';

import 'insights_repository_interface.dart';

class InsightsManager {
  final int defaultReturnGracePeriodInDays = 14;

  TrackingManager trackingManager;
  ShopifyManager shopifyManager;
  InsightsRepositoryInterface insightsRepo;
  DateTime platformStartDate;

  InsightsManager({
    required this.trackingManager,
    required this.shopifyManager,
    required this.insightsRepo,
    required this.platformStartDate,
  });

  Future<List<dynamic>> getPacksInfoForMerchant({
    required String merchantId,
    Period? period,
  }) async {
    return await insightsRepo.getPacksInfoForMerchant(
      merchantId: merchantId,
    );
  }

  Future<ReturnInfo?> getMerchantReturnInfo({
    required String merchantId,
    Period? period,
    DateTime? today,
  }) async {
    return await insightsRepo.getMerchantReturnInfo(
      merchantId: merchantId,
      period: period,
    );
  }

  Future<CheckoutPickUpInfo?> getMerchantCheckoutPickUpInfo({
    required String merchantId,
    Period? period,
  }) async {
    return await insightsRepo.getMerchantCheckoutPickUpInfo(
      merchantId: merchantId,
      period: period,
    );
  }
}
