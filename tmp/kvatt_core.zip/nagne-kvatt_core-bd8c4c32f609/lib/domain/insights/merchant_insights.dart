@Deprecated(
  '''
      We are changing the approach for handling return rates and will not
      be using data from the insights collection anymore.
      To get a merchant's return rate, use InsightsManager.getMerchantReturnRate instead.
    ''',
)
class MerchantInsights {
  int totalDelivered;
  int totalReturned;

  MerchantInsights({
    required this.totalDelivered,
    required this.totalReturned,
  });

  @Deprecated('Use InsightsManger.getMerchantReturnRate instead')
  double? get returnRate {
    if (totalDelivered == 0 || totalReturned > totalDelivered) {
      return null;
    } else {
      return (totalReturned / totalDelivered);
    }
  }
}
