class CheckoutPickUpInfo {
  int totalOrders;
  int numOrdersWithKvattPack;
  double? pickUpRate;

  CheckoutPickUpInfo({
    required this.totalOrders,
    required this.numOrdersWithKvattPack,
    required this.pickUpRate,
  });
}
