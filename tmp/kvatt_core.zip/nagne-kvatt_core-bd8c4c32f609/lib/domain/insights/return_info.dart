class ReturnInfo {
  int numShipped;
  int numReturned;
  int numPending;
  int numLost;
  double? returnRate;
  int? maxReturnDays;
  int? minReturnDays;
  double? averageReturnDays;

  ReturnInfo({
    required this.numShipped,
    required this.numReturned,
    required this.numPending,
    required this.returnRate,
    required this.numLost,
    required this.maxReturnDays,
    required this.minReturnDays,
    required this.averageReturnDays,
  });

  @override
  String toString() {
    return 'numShipped: $numShipped, numReturned: $numReturned, numPending: $numPending, returnRate: $returnRate';
  }
}
