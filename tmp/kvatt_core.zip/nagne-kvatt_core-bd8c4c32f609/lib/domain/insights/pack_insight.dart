class PackInsight {
  String packId;
  int numTimesShipped;
  int numTimesReturned;
  double? averageReturnTimeInDays;
  DateTime? lastShippedDate;
  DateTime? lastReturnedDate;

  PackInsight({
    required this.packId,
    required this.numTimesShipped,
    required this.numTimesReturned,
    required this.averageReturnTimeInDays,
    required this.lastShippedDate,
    required this.lastReturnedDate,
  });
}
