import 'package:kvatt_core/domain/insights/pack_insight.dart';

class PackInfo {
  int code;
  String type;
  PackInsight insights;

  PackInfo({
    required this.code,
    required this.type,
    required this.insights,
  });
}
