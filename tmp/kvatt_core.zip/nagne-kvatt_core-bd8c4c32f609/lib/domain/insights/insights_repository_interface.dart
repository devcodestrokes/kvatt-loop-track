import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/insights/checkout_pick_up_info.dart';
import 'package:kvatt_core/domain/insights/return_info.dart';

abstract class InsightsRepositoryInterface {
  Future<ReturnInfo> getMerchantReturnInfo({
    required String merchantId,
    Period? period,
  });

  Future<CheckoutPickUpInfo?> getMerchantCheckoutPickUpInfo({
    required String merchantId,
    Period? period,
  });

  Future<List<dynamic>> getPacksInfoForMerchant({
    required String merchantId,
    Period? period,
  });
}
