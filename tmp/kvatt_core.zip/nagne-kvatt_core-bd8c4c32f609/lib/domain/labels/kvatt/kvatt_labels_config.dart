import '../label_style.dart';
import 'label_version.dart';

class KvattLabelsConfig {
  List<LabelStyle> getLabelStylesForLabelVersion({
    required LabelVersion labelVersion,
  }) {
    switch (labelVersion) {
      case LabelVersion.v1:
        return [
          LabelStyle.simpleV1,
        ];
      case LabelVersion.v2:
        return [
          LabelStyle.gamifiedV1,
          LabelStyle.simpleV2,
        ];
      case LabelVersion.v3:
        return [
          LabelStyle.simpleV3,
          LabelStyle.gamifiedV3,
        ];
    }
  }

  String get kvattQrCodeUrlPath => '/packaging-info';

  String generateKvattQrCodeUrl({
    required String baseUrl,
    required String packagingId,
    required LabelStyle? style,
  }) {
    String url = '$baseUrl$kvattQrCodeUrlPath?id=$packagingId&labelStyle=';
    switch (style) {
      case LabelStyle.simpleV2:
        url += 'simplev2';
        break;
      case LabelStyle.gamifiedV1:
        url += 'gamifiedv1';
        break;
      case LabelStyle.simpleV3:
        url += 'simplev3';
        break;
      case LabelStyle.gamifiedV3:
        url += 'gamifiedv3';
        break;
      case LabelStyle.minimal:
        url += 'minimal';
        break;
      default:
        break;
    }
    return url;
  }
}
