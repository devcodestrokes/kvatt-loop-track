enum LabelStyle {
  simpleV1,
  simpleV2,
  gamifiedV1,
  simpleV3,
  gamifiedV3,
  minimal,

  //Custom labels
  customGoliathFR,
  customGoliathEN,
}
