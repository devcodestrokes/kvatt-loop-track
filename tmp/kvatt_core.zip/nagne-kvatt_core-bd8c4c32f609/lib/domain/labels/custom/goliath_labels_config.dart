import 'dart:math';

class GoliathLabelsConfig {
  final String _supplierCode = 'V';
  final String _monthCode = 'H';
  final String _yearCode = '3';

  final List<String> _validUppercaseAlphaChars = [
    'B',
    'C',
    'D',
    'F',
    'G',
    'H',
    'J',
    'K',
    'L',
    'M',
    'N',
    'P',
    'Q',
    'R',
    'S',
    'T',
    'V',
    'W',
    'X',
    'Z'
  ];

  final List<String> _validLowercaseAlpha = [
    'b',
    'c',
    'd',
    'f',
    'g',
    'h',
    'j',
    'k',
    'l',
    'm',
    'n',
    'p',
    'q',
    'r',
    's',
    't',
    'v',
    'w',
    'x',
    'z'
  ];

  final List<String> _validNumChars = [
    '1',
    '2',
    '3',
    '4',
    '5',
    '6',
    '7',
    '8',
    '9'
  ];

  List<String> generateSp00Codes({
    required int quantity,
  }) {
    Random random = Random();

    List<String> codes = [];

    int fourthType = 0;

    for (int i = 0; i < quantity; i++) {
      //NOTE: The fourth character should alternate between
      //uppercase alpha, lowercase alpha, and numeric
      String fourthChar = '';

      switch (fourthType) {
        case 0:
          fourthChar = _getRandomValidUppercaseAlpha(random);
          break;
        case 1:
          fourthChar = _getRandomValidLowercaseAlpha(random);

          break;
        case 2:
          fourthChar = _getRandomValidNum(random);
          break;
      }

      if (fourthType == 2) {
        fourthType = 0;
      } else {
        fourthType++;
      }

      String last5Chars = _getRandom5Chars(random);

      codes.add('sp$_supplierCode$fourthChar$_monthCode$_yearCode$last5Chars');
    }

    return codes;
  }

  String _getRandom5Chars(Random random) {
    String chars = '';

    for (int i = 0; i < 5; i++) {
      int charType = random.nextInt(3);
      switch (charType) {
        case 0:
          chars += _getRandomValidUppercaseAlpha(random);
          break;
        case 1:
          chars += _getRandomValidLowercaseAlpha(random);
          break;
        case 2:
          chars += _getRandomValidNum(random);
          break;
      }
    }

    return chars;
  }

  String _getRandomValidUppercaseAlpha(Random random) {
    return _validUppercaseAlphaChars[
        random.nextInt(_validUppercaseAlphaChars.length - 1)];
  }

  String _getRandomValidLowercaseAlpha(Random random) {
    return _validLowercaseAlpha[
        random.nextInt(_validLowercaseAlpha.length - 1)];
  }

  String _getRandomValidNum(Random random) {
    return _validNumChars[random.nextInt(_validNumChars.length - 1)];
  }
}
