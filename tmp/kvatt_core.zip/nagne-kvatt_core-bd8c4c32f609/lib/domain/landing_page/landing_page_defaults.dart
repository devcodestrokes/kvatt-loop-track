class LandingPageDefaults {
  static String returnLocationLabel = 'Find your nearest RM postbox';
  static String returnLocationUrl =
      'https://www.royalmail.com/services-near-you#/';
}
