class LandingPageConfig {
  String? returnLocationUrl;
  String? returnLocationLabel;

  LandingPageConfig({
    this.returnLocationUrl,
    this.returnLocationLabel,
  });
}
