import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';

abstract class LandingPageConfigsRepositoryInterface {
  Future<LandingPageConfig?> retrieveConfigs({
    required String merchantId,
  });

  Future<void> updateConfigs({
    required String merchantId,
    required LandingPageConfig? config,
  });
}
