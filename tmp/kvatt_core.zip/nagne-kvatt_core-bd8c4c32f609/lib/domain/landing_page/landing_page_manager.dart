import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_configs_repository_interface.dart';

class LandingPageManager {
  LandingPageConfigsRepositoryInterface landingPageConfigsRepo;

  LandingPageManager({
    required this.landingPageConfigsRepo,
  });

  Future<LandingPageConfig?> getCustomConfigsForMerchant({
    required String merchantId,
  }) async {
    return await landingPageConfigsRepo.retrieveConfigs(merchantId: merchantId);
  }

  Future<void> setCustomConfigsForMerchant({
    required String merchantId,
    required LandingPageConfig? landingPageConfig,
  }) async {
    await landingPageConfigsRepo.updateConfigs(
      merchantId: merchantId,
      config: landingPageConfig,
    );
  }
}
