import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/tracking/tracking_counters_repository_interface.dart';

import 'tracking_event.dart';
import 'tracking_history.dart';
import 'tracking_history_repository_interface.dart';

class PackHistory {
  String packId;
  List<TrackingHistory> trackingHistories;

  PackHistory({
    required this.packId,
    required this.trackingHistories,
  });
}

class TrackingManager {
  TrackingHistoryRepositoryInterface trackingHistoryRepo;
  TrackingCountersRepositoryInterface trackingCountersRepo;

  TrackingManager({
    required this.trackingHistoryRepo,
    required this.trackingCountersRepo,
  });

  Stream<int?> returnedToKvattCount({
    required String userId,
  }) {
    return trackingCountersRepo.trackingCount(
      userId: userId,
      event: TrackingEvent.returnedToKvatt,
    );
  }

  Future<int> getNumPacksReturnedToKvattForMerchant({
    required String merchantId,
  }) async {
    List<Future<int>> tasks = [
      trackingHistoryRepo.getTrackingHistoriesCountForMerchant(
        merchantId: merchantId,
        event: TrackingEvent.returnedToKvattNeedsMaintenance,
      ),
      trackingHistoryRepo.getTrackingHistoriesCountForMerchant(
        merchantId: merchantId,
        event: TrackingEvent.returnedToKvattNoMaintenance,
      ),
      trackingHistoryRepo.getTrackingHistoriesCountForMerchant(
        merchantId: merchantId,
        event: TrackingEvent.returnedToKvatt,
      ),
    ];

    List<int> results = await Future.wait(tasks);
    return results[0] + results[1] + results[2];
  }

  Future<List<PackHistory>>
      getPackHistoriesOfPacksShippedByMerchantDuringPeriod({
    required String merchantId,
    required Period period,
  }) async {
    List<TrackingHistory> histories =
        await trackingHistoryRepo.getTrackingHistoriesForMerchant(
      merchantId: merchantId,
      event: TrackingEvent.shippedToCustomer,
      period: period,
    );

    return _getPackHistoriesFromTrackingHistoriesList(
      histories: histories,
      merchantId: merchantId,
    );
  }

  Future<List<PackHistory>> _getPackHistoriesFromTrackingHistoriesList({
    required List<TrackingHistory> histories,
    required String merchantId,
  }) async {
    List<String> packIds = histories
        .map((TrackingHistory history) => history.packagingId)
        .toSet()
        .toList();

    List<Future<List<TrackingHistory>>> fetchPackHistoriesTasks =
        packIds.map((String packId) {
      return trackingHistoryRepo.retrieveTrackingHistory(
        packagingId: packId,
        merchantId: merchantId,
      );
    }).toList();

    List<List<TrackingHistory>> packHistoriesList =
        await Future.wait(fetchPackHistoriesTasks);

    List<PackHistory> packHistories = [];

    for (var i = 0; i < packIds.length; i++) {
      packHistories.add(
        PackHistory(
          packId: packIds[i],
          trackingHistories: packHistoriesList[i],
        ),
      );
    }

    return packHistories;
  }
}
