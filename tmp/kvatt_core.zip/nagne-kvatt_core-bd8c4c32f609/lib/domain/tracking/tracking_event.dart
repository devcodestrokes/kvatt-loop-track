enum TrackingEvent {
  shippedToMerchant,
  receivedByMerchant,
  shippedToCustomer,
  returnedFromCustomer,
  returnedToKvatt,
  sentToMaintenance,
  outOfMaintenance,

  //Legacy events
  returnedToKvattNoMaintenance,
  returnedToKvattNeedsMaintenance,
}
