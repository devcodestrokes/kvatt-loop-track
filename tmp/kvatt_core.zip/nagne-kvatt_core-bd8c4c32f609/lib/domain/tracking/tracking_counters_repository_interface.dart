import 'package:kvatt_core/domain/tracking/tracking_event.dart';

abstract class TrackingCountersRepositoryInterface {
  Stream<int?> trackingCount({
    required String userId,
    required TrackingEvent event,
  });
}
