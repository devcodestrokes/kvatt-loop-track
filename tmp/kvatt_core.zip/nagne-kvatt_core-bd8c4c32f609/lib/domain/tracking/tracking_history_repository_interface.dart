import 'package:kvatt_core/domain/common/period.dart';

import 'tracking_event.dart';
import 'tracking_history.dart';

abstract class TrackingHistoryRepositoryInterface {
  Future<List<TrackingHistory>> retrieveTrackingHistory({
    required String packagingId,
    String? merchantId,
  });

  Future<void> addTrackingHistories({
    required List<TrackingHistory> trackingHistories,
  });

  Future<List<TrackingHistory>> getTrackingHistoriesForMerchant({
    required String merchantId,
    TrackingEvent? event,
    Period? period,
  });

  Future<int> getTrackingHistoriesCountForMerchant({
    required String merchantId,
    TrackingEvent? event,
    Period? period,
  });
}
