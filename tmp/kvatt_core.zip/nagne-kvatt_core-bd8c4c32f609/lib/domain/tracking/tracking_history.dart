import 'tracking_event.dart';

class TrackingHistory {
  String packagingId;
  DateTime date;
  TrackingEvent event;
  String trackedByUserId;
  String? merchantId;
  String? merchantName;
  String? customerName;
  String? orderNumber;

  TrackingHistory({
    required this.packagingId,
    required this.date,
    required this.event,
    required this.trackedByUserId,
    this.merchantId,
    this.merchantName,
    this.customerName,
    this.orderNumber,
  });

  @override
  String toString() {
    return '$date | $event | $merchantId | $packagingId';
  }
}
