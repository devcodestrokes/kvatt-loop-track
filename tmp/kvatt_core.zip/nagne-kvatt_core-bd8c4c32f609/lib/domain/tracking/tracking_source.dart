enum TrackingSource {
  kvattApp,
  shopify,
}
