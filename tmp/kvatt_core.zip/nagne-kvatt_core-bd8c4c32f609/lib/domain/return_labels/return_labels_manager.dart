import 'package:kvatt_core/domain/return_labels/la_poste/la_poste_smart_data.dart';
import 'package:kvatt_core/domain/return_labels/return_labels_repository_interface.dart';

class ReturnLabelsManager {
  ReturnLabelsRepositoryInterface returnLabelsRepo;

  ReturnLabelsManager({
    required this.returnLabelsRepo,
  });

  Future<List<LaPosteSmartData>> getLaPosteSmartData({
    required int quantity,
  }) async {
    return await returnLabelsRepo.getLaposteSmartData(
      quantity: quantity,
    );
  }
}
