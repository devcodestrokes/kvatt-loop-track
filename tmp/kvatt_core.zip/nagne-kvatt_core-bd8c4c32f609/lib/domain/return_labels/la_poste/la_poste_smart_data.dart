class LaPosteSmartData {
  String datamatrixImage;
  String label;

  LaPosteSmartData({
    required this.datamatrixImage,
    required this.label,
  });
}
