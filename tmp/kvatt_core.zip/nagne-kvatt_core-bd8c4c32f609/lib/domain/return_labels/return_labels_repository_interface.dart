import 'package:kvatt_core/domain/return_labels/la_poste/la_poste_smart_data.dart';

abstract class ReturnLabelsRepositoryInterface {
  Future<List<LaPosteSmartData>> getLaposteSmartData({
    required int quantity,
  });
}
