class Stock {
  Map<String, int> levels;

  Stock({
    required this.levels,
  });

  int get totalUnits {
    int total = 0;
    for (var key in levels.keys) {
      total += levels[key] as int;
    }
    return total;
  }
}
