import 'stock.dart';

abstract class StocksRepositoryInterface {
  Future<Stock?> retrieveStock({
    required String merchantId,
  });

  Future<void> updateStock({
    required Stock stock,
    required String merchantId,
  });

  Future<void> deleteStock({
    required String merchantId,
  });

  Stream<Stock?> stock({
    required String merchantId,
  });

  Future<List<Stock>> retrieveMerchantStocks({
    required List<String> merchantIds,
  });
}
