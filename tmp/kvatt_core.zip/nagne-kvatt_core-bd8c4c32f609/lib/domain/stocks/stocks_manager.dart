import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';

import 'stock.dart';
import 'stock_repository_interface.dart';

class StocksManager {
  StocksRepositoryInterface stocksRepository;
  PackagingsManager packagingsManager;

  StocksManager({
    required this.stocksRepository,
    required this.packagingsManager,
  });

  Future<Stock> computeMerchantStock({
    required String merchantId,
  }) async {
    List<Packaging> packagings = await packagingsManager.getPackagings(
      status: PackagingStatus.withMerchant,
      merchantId: merchantId,
    );

    Map<String, int> levels = {};

    for (var packaging in packagings) {
      String type = packaging.type;
      if (levels.containsKey(type)) {
        levels[type] = levels[type]! + 1;
      } else {
        levels[type] = 1;
      }
    }

    return Stock(levels: levels);
  }
}
