import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_manager.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<PackagingShipmentsManager>()])
void main() {}
