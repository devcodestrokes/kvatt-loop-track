import 'package:kvatt_core/domain/insights/insights_repository_interface.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<InsightsRepositoryInterface>()])
void main() {}
