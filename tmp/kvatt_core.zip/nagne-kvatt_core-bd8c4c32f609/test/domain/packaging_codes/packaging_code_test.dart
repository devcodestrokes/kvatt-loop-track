import 'package:flutter_test/flutter_test.dart';
import 'package:kvatt_core/domain/packaging_codes/packaging_code.dart';

void main() {
  group('PackagingCode', () {
    group('Parse correct kvatt url code', () {
      late PackagingCode code;
      setUp(() {
        code = PackagingCode.parse(
          code:
              'https://baseurl.com/label-path?id=packid&labelStyle=gamifiedv1',
          kvattLabelPath: '/label-path',
        );
      });
      test('sets identifier to pack ID', () {
        expect(code.identifier, 'packid');
      });

      test('sets isCustom to false', () {
        expect(code.isCustom, false);
      });
    });

    group('Parse incorrect kvatt url code', () {
      late PackagingCode code;
      setUp(() {
        code = PackagingCode.parse(
          code: 'https://baseurl.com/label-path?labelStyle=gamifiedv1',
          kvattLabelPath: '/label-path',
        );
      });
      test('sets identifier to null', () {
        expect(code.identifier, null);
      });

      test('sets isCustom to false', () {
        expect(code.isCustom, false);
      });
    });

    group('Parse custom code', () {
      late PackagingCode code;
      setUp(() {
        code = PackagingCode.parse(
          code: 'custom-code',
          kvattLabelPath: '/label-path',
        );
      });
      test('sets identifier to custom code', () {
        expect(code.identifier, 'custom-code');
      });

      test('sets isCustom to true', () {
        expect(code.isCustom, true);
      });
    });
  });
}
