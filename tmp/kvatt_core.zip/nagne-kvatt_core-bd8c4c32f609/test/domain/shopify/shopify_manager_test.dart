import 'package:kvatt_core/domain/shopify/shopify_manager.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<ShopifyManager>()])
void main() {}
