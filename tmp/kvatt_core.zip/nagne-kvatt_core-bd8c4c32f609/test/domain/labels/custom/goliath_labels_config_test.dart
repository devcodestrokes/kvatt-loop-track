import 'package:kvatt_core/domain/labels/custom/goliath_labels_config.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<GoliathLabelsConfig>()])
void main() {}
