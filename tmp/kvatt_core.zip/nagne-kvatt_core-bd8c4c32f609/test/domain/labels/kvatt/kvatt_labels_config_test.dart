import 'package:kvatt_core/domain/labels/kvatt/kvatt_labels_config.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<KvattLabelsConfig>()])
void main() {}
