import 'package:kvatt_core/domain/tracking/tracking_history_repository_interface.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<TrackingHistoryRepositoryInterface>()])
void main() {}
