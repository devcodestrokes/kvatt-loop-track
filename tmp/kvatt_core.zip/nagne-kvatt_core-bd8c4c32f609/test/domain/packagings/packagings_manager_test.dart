import 'package:flutter_test/flutter_test.dart';
import 'package:kvatt_core/domain/labels/label_style.dart';
import 'package:kvatt_core/domain/labels/kvatt/label_version.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:mockito/mockito.dart';

import '../../data/base/db/cloud_function_callable_interface_test.mocks.dart';
import '../labels/custom/goliath_labels_config_test.mocks.dart';
import '../labels/kvatt/labels_config_test.mocks.dart';
import '../packaging_shipments/packaging_shipments_manager_test.mocks.dart';
import '../tracking/tracking_history_repository_interface_test.mocks.dart';
import 'packagings_repository_interface_test.mocks.dart';

void main() {
  group('PackagingsManager', () {
    late MockPackagingsRepositoryInterface mockPackagingsRepo;
    late MockTrackingHistoryRepositoryInterface mockTrackingHistoryRepo;
    late MockPackagingShipmentsManager mockPackagingsShipmentsManager;
    late MockKvattLabelsConfig mockKvattLabelsConfig;
    late MockGoliathLabelsConfig mockGoliathLabelsConfig;
    late MockCloudFunctionCallableInterface mockCloudFunctionCallableInterface;

    late PackagingsManager manager;

    setUp(() async {
      mockPackagingsRepo = MockPackagingsRepositoryInterface();
      mockTrackingHistoryRepo = MockTrackingHistoryRepositoryInterface();
      mockPackagingsShipmentsManager = MockPackagingShipmentsManager();
      mockKvattLabelsConfig = MockKvattLabelsConfig();
      mockGoliathLabelsConfig = MockGoliathLabelsConfig();
      mockCloudFunctionCallableInterface = MockCloudFunctionCallableInterface();

      manager = PackagingsManager(
        packagingsRepo: mockPackagingsRepo,
        trackingHistoryRepo: mockTrackingHistoryRepo,
        packagingShipmentsManager: mockPackagingsShipmentsManager,
        kvattLabelsConfig: mockKvattLabelsConfig,
        goliathLabelsConfig: mockGoliathLabelsConfig,
        cloudFunctionCallable: mockCloudFunctionCallableInterface,
      );
    });

    group('createNewPackagings:with kvatt labels', () {
      late List<Packaging> createdPackagings;

      setUp(() async {
        when(mockPackagingsRepo.retrieveLastCode())
            .thenAnswer((_) => Future.value(10));

        when(mockKvattLabelsConfig.getLabelStylesForLabelVersion(
                labelVersion: LabelVersion.v2))
            .thenReturn(
          [
            LabelStyle.gamifiedV1,
            LabelStyle.simpleV2,
          ],
        );

        await manager.createNewPackagings(
          numPackagings: 3,
          packagingType: 'Charlie M',
          manufacturer: 'Nargul Canta',
          labelVersion: LabelVersion.v2,
          customLabelStyle: null,
        );

        VerificationResult result = verify(
          mockPackagingsRepo.createPackagings(
            packagings: captureAnyNamed('packagings'),
          ),
        );

        createdPackagings = result.captured[0];
      });

      test('creates correct number of packagings', () async {
        expect(createdPackagings.length, 3);
      });

      test('increments packaging code correctly', () async {
        expect(createdPackagings[0].code, 11);
        expect(createdPackagings[1].code, 12);
        expect(createdPackagings[2].code, 13);
      });

      test('sets alternate label styles correctly', () async {
        expect(createdPackagings[0].labelStyle, LabelStyle.gamifiedV1);
        expect(createdPackagings[1].labelStyle, LabelStyle.simpleV2);
        expect(createdPackagings[2].labelStyle, LabelStyle.gamifiedV1);
      });

      test('does not set customIds', () async {
        expect(createdPackagings[0].customId, null);
      });
    });

    group('createNewPackagings:with custom labels', () {
      late List<Packaging> createdPackagings;

      setUp(() async {
        when(mockPackagingsRepo.retrieveLastCode())
            .thenAnswer((_) => Future.value(10));

        await manager.createNewPackagings(
          numPackagings: 3,
          packagingType: 'Charlie M',
          manufacturer: 'Nargul Canta',
          labelVersion: null,
          customLabelStyle: LabelStyle.customGoliathFR,
          customIds: ['a', 'b', 'c'],
        );

        VerificationResult result = verify(
          mockPackagingsRepo.createPackagings(
            packagings: captureAnyNamed('packagings'),
          ),
        );

        createdPackagings = result.captured[0];
      });

      test('sets customIds correctly', () async {
        expect(createdPackagings[0].customId, 'a');
        expect(createdPackagings[1].customId, 'b');
        expect(createdPackagings[2].customId, 'c');
      });

      test('sets labelStyle correctly', () async {
        expect(createdPackagings[0].labelStyle, LabelStyle.customGoliathFR);
        expect(createdPackagings[1].labelStyle, LabelStyle.customGoliathFR);
        expect(createdPackagings[2].labelStyle, LabelStyle.customGoliathFR);
      });
    });
  });
}
