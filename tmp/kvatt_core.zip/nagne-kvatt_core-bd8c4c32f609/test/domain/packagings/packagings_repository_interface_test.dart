import 'package:kvatt_core/domain/packagings/packagings_repository_interface.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<PackagingsRepositoryInterface>()])
void main() {}
