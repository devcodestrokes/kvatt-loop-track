import 'package:kvatt_core/data/base/db/cloud_function_callable_interface.dart';
import 'package:mockito/annotations.dart';

@GenerateNiceMocks([MockSpec<CloudFunctionCallableInterface>()])
void main() {}
