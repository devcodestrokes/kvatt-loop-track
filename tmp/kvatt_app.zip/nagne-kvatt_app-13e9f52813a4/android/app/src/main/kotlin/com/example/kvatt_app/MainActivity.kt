package com.example.kvatt_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
