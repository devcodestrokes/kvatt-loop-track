# Kvatt Platform

## Happy path testing

Since the Kvatt Platform codebase does not have automated tests, it is a good idea to perform some manual testing of the following happy path scenarios after new changes are made to the codebase.

### Admin Dashboard

#### Packagings

##### Admin can create new packagings

- With Kvatt old labels
  - Ensure label designs are correct
  - Ensure generated QR code URL is correct
  - Ensure data for packaging correctly stored in db
- With Kvatt new labels
  - Ensure label designs are correct (for both small and large versions)
  - Ensure generated QR code URL is correct
  - Ensure data for packaging correctly stored in db
- With Goliath French labels
  - Ensure label designs are correct
  - Ensure generated QR code URL is correct (front)
  - Ensure generated sp00 barcode is correct (back)
  - Ensure data for packaging correctly stored in db
- With Goliath English Labels
  - Ensure label designs are correct
  - Ensure generated QR code URL is correct (front)
  - Ensure generated sp00 barcode is correct (back)
  - Ensure data for packaging correctly stored in db

##### Admin can filter packagings

- Ensure can filter packagings by type
- Ensure can filter packagings by status
- Ensure can filter packagings by merchant

#### Stock management

##### Admin can see stock numbers

- Ensure stock numbers are updated when tracked

### Merchant dashboard

#### Merchant can acknowledge packaging shipments

- Ensure unacknowledged packaging shipments appear on the dashboard
- Ensure unacknowledged packagings appear as En route in merchant packs table
- Ensure merchant can acknowledge packaging shipments
- Ensure packagings then appear as In Stock in merchant packs table
- Ensure stock levels are then updated

#### Merchant can manage packs

- Merchant can filter packs by product
- Merchant can filter packs by last tracked
- Merchant can filter packs by ID or order number
- Merchant can change status of pack