import 'package:kvatt_app/domain/merchant_settings/stock_level_reminder_setting.dart';

class MerchantSettings {
  List<StockLevelReminderSetting> stockLevelReminderSettings;

  MerchantSettings({
    required this.stockLevelReminderSettings,
  });
}
