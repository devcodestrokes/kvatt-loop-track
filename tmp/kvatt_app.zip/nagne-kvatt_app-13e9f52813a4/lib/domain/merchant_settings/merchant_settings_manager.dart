import 'package:kvatt_app/domain/merchant_settings/merchant_settings_repository_interface.dart';

import 'merchant_settings.dart';

class MerchantSettingsManager {
  MerchantSettingsRepositoryInterface merchantSettingsRepo;

  MerchantSettingsManager({
    required this.merchantSettingsRepo,
  });

  Future<MerchantSettings?> getSettingsForMerchant({
    required String merchantId,
  }) async {
    return await merchantSettingsRepo.retrieveMerchantSettings(
      merchantId: merchantId,
    );
  }

  Future<void> updateSettingsForMerchant({
    required String merchantId,
    required MerchantSettings merchantSettings,
  }) async {
    await merchantSettingsRepo.updateMerchantSettings(
      merchantId: merchantId,
      merchantSettings: merchantSettings,
    );
  }
}
