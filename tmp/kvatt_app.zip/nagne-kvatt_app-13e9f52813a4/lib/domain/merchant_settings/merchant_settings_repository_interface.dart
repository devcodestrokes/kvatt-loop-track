import 'package:kvatt_app/domain/merchant_settings/merchant_settings.dart';

abstract class MerchantSettingsRepositoryInterface {
  Future<MerchantSettings?> retrieveMerchantSettings({
    required String merchantId,
  });

  Future<void> updateMerchantSettings({
    required String merchantId,
    required MerchantSettings merchantSettings,
  });
}
