class StockLevelReminderSetting {
  String product;
  int minLevel;

  StockLevelReminderSetting({
    required this.product,
    required this.minLevel,
  });
}
