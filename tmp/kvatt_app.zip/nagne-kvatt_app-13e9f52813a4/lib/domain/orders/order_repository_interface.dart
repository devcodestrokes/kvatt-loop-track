import 'package:kvatt_app/domain/orders/order.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';

abstract class OrderRepositoryInterface {
  Future<String> createOrder({
    required Order order,
  });

  Future<void> updateOrder({
    required Order order,
  });

  Future<List<Order>> retrieveOrders({
    OrderStatus? orderStatus,
    int? limit,
    int? startAt,
  });

  Future<int?> retrieveLastOrderNumber();

  Future<Order?> retrieveOrderById({
    required String id,
  });

  Future<void> deleteOrder({
    required String id,
  });
}
