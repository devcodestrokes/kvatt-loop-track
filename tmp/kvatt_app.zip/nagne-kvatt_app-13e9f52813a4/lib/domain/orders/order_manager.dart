import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/services/cloud_functions/cloud_functions_service.dart';
import 'package:kvatt_app/domain/orders/order.dart';
import 'package:kvatt_app/domain/orders/order_repository_interface.dart';
import 'package:kvatt_app/domain/orders/order_source.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';

class OrderManager {
  CloudFunctionService cloudFunctionService;
  OrderRepositoryInterface orderRepo;
  Config config;

  OrderManager({
    required this.cloudFunctionService,
    required this.orderRepo,
    required this.config,
  });

  Future<void> createNewOrder({
    required OrderType orderType,
    required String product,
    required int quantity,
    String? merchantId,
    String? merchantName,
    String? contactEmail,
    String? shippingDetails,
    double? unitPriceInGBP,
    double? probability,
  }) async {
    int? lastOrderNumber = await getLastOrderNumber();
    int nextOrderNumber = _getNextOrderNumber(lastOrderNumber);
    Order newOrder = Order(
      number: nextOrderNumber,
      source: OrderSource.internal,
      orderType: orderType,
      productType: product,
      quantity: quantity,
      status: OrderStatus.open,
      merchantId: merchantId,
      merchantName: merchantName,
      contactEmail: contactEmail,
      shippingDetails: shippingDetails,
      unitPriceInGBP: unitPriceInGBP,
      probability: probability,
    );
    await orderRepo.createOrder(
      order: newOrder,
    );
  }

  Future<void> updateOrder({
    required Order previousOrder,
    required OrderStatus orderStatus,
    required OrderType orderType,
    required String product,
    required int quantity,
    String? merchantId,
    String? merchantName,
    String? contactEmail,
    String? shippingDetails,
    double? unitPriceInGBP,
    double? probability,
    String? tracking,
    String? invoiceLink,
    String? comments,
    DateTime? expectedDeliveryDate,
    DateTime? deliveryDate,
    bool? hasInvoiced,
  }) async {
    Order updatedOrder = Order(
      id: previousOrder.id,
      number: previousOrder.number,
      source: previousOrder.source,
      orderType: orderType,
      productType: product,
      quantity: quantity,
      status: orderStatus,
      hasInvoiced: hasInvoiced,
      merchantId: merchantId,
      merchantName: merchantName,
      comment: comments,
      contactEmail: contactEmail,
      shippingDetails: shippingDetails,
      unitPriceInGBP: unitPriceInGBP,
      probability: probability,
      tracking: tracking,
      expectedDeliveryDate: expectedDeliveryDate,
      deliveryDate: deliveryDate,
      invoiceLink: invoiceLink,
    );
    await orderRepo.updateOrder(order: updatedOrder);
  }

  Future<void> submitOrderRequest({
    required String orderType,
    required String productType,
    required int quantity,
    String? comment,
    required String merchantId,
  }) async {
    await cloudFunctionService.callFunction(
      functionName: 'orderRequestCallable',
      functionRegion: config.cloudFunctionRegion!,
      data: {
        'orderType': orderType,
        'productType': productType,
        'quantity': quantity,
        'comment': comment,
      },
    );
  }

  Future<List<Order>> getOrders({
    OrderStatus? status,
    int? startAtOrderNumber,
    int? numOrders,
  }) async {
    return await orderRepo.retrieveOrders(
      orderStatus: status,
      limit: numOrders,
      startAt: startAtOrderNumber,
    );
  }

  Future<Order?> getOrderById({
    required String id,
  }) async {
    return await orderRepo.retrieveOrderById(
      id: id,
    );
  }

  Future<int?> getLastOrderNumber() async {
    return await orderRepo.retrieveLastOrderNumber();
  }

  Future<void> deleteOrder({
    required String orderId,
  }) async {
    await orderRepo.deleteOrder(id: orderId);
  }

  int _getNextOrderNumber(int? lastOrderNumber) {
    if (lastOrderNumber == null) return 1;
    return lastOrderNumber + 1;
  }
}
