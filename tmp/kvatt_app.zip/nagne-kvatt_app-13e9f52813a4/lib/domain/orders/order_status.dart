enum OrderStatus {
  open,
  acknowledged,
  ready,
  inTransit,
  delivered,
  onHold,
}
