import 'package:kvatt_app/domain/orders/order_source.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';

class Order {
  String id;
  int number;
  OrderSource source;
  OrderType orderType;
  String productType;
  int quantity;
  OrderStatus status;
  bool? hasInvoiced;
  String? merchantId;
  String? merchantName;
  String? comment;
  String? contactEmail;
  String? shippingDetails;
  double? unitPriceInGBP;
  double? probability;
  String? tracking;
  DateTime? expectedDeliveryDate;
  DateTime? deliveryDate;
  String? invoiceLink;

  Order({
    this.id = '',
    required this.number,
    required this.source,
    required this.orderType,
    required this.productType,
    required this.quantity,
    required this.status,
    this.hasInvoiced = false,
    this.merchantId,
    this.merchantName,
    this.comment,
    this.contactEmail,
    this.shippingDetails,
    this.unitPriceInGBP,
    this.probability,
    this.tracking,
    this.expectedDeliveryDate,
    this.deliveryDate,
    this.invoiceLink,
  }) : assert(merchantId != null || merchantName != null);
}
