import 'package:kvatt_app/app/services/url_launcher/url_launcher_service.dart';

class CommunicationsManager {
  UrlLauncherService urlLauncherService;

  CommunicationsManager({
    required this.urlLauncherService,
  });

  launchCataloguePage() {
    urlLauncherService.openLink(
        url: 'https://www.kvatt.com/discoverourproducts');
  }

  launchSupportEmail() {
    urlLauncherService.openLink(url: 'mailto:team@kvatt.com');
  }

  launchReturnLabelDoc() {
    urlLauncherService.openLink(
      url:
          'https://firebasestorage.googleapis.com/v0/b/kvatt-platform-live.appspot.com/o/downloads%2Fkvatt-return-label.pdf?alt=media',
    );
  }

  launchReturnLocationLink(String url) {
    urlLauncherService.openLink(
      url: url,
    );
  }

  launchShopifyShippingAndDeliverySettings() {
    urlLauncherService.openLink(
      url:
          'https://admin.shopify.com/store/nagne-studio-development/settings/shipping',
    );
  }

  launchShopifyAdminDashboard() {
    urlLauncherService.openLink(
      url: 'https://admin.shopify.com/',
    );
  }

  launchShopifyShippingAndDeliveryDocs() {
    urlLauncherService.openLink(
      url: 'https://help.shopify.com/en/manual/shipping',
    );
  }

  launchKvattShopifyAppPage() {
    urlLauncherService.openLink(
      url: 'https://apps.shopify.com/kvatt',
    );
  }
}
