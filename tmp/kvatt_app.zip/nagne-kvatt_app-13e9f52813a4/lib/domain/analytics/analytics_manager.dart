import 'package:kvatt_app/domain/analytics/analytics_repository_interface.dart';
import 'package:kvatt_app/domain/analytics/landing_page_view_event.dart';

class AnalyticsManager {
  AnalyticsRepositoryInterface analyticsRepo;

  AnalyticsManager({
    required this.analyticsRepo,
  });

  Future<void> recordLandingPageViewEvent({
    String? packagingId,
    String? labelStyle,
    String? source,
    String? merchantId,
  }) async {
    await analyticsRepo.recordAnalyticsEvent(
      event: LandingPageViewEvent(
        date: DateTime.now(),
        packagingId: packagingId,
        labelStyle: labelStyle,
        source: source,
        merchantId: merchantId,
      ),
    );
  }
}
