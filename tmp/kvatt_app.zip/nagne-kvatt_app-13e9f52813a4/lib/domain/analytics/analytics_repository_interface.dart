import 'package:kvatt_app/domain/analytics/analytics_event.dart';

abstract class AnalyticsRepositoryInterface {
  Future<void> recordAnalyticsEvent({
    required AnalyticsEvent event,
  });
}
