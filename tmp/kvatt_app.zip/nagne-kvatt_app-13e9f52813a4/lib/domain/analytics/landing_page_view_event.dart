import 'package:kvatt_app/domain/analytics/analytics_event.dart';

class LandingPageViewEvent extends AnalyticsEvent {
  String? packagingId;
  String? labelStyle;
  String? source;
  String? merchantId;

  LandingPageViewEvent({
    required super.date,
    this.packagingId,
    this.labelStyle,
    this.source,
    this.merchantId,
  });
}
