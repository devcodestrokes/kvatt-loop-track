class AnalyticsEvent {
  DateTime date;

  AnalyticsEvent({
    required this.date,
  });
}
