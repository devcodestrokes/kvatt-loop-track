enum ContractType {
  rentalSmallLoop,
  rentalLargeLoop,
}
