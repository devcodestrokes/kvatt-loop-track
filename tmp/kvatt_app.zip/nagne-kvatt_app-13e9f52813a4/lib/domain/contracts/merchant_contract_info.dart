import 'package:kvatt_app/domain/contracts/packaging_info.dart';

class MerchantContractInfo {
  String deliveryAddress;
  String contractType;
  List<PackagingInfo> packagings;
  bool packagingLossCompensationIncluded;
  bool packagingMaintenanceIncluded;

  MerchantContractInfo({
    required this.deliveryAddress,
    required this.contractType,
    required this.packagings,
    required this.packagingLossCompensationIncluded,
    required this.packagingMaintenanceIncluded,
  });

  bool isSmallLoop() {
    return contractType == 'Rental Small Loop';
  }

  bool isLargeLoop() {
    return contractType == 'Rental Large Loop';
  }
}
