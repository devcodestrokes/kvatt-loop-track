const List<String> availableProducts = [
  'Ray S',
  'Ray M',
  'Ray L',
  'Charlie S',
  'Charlie M',
  'Charlie L',
  'Charlie A2',
  'Charlie A3',
  'Harry S',
  'Harry M',
  'Alfred M'
];
