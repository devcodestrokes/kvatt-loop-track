const List<String> availableManufacturers = [
  'Minerva Loose Leaf',
  'Nargul Canta',
  'FCM Plast',
];
