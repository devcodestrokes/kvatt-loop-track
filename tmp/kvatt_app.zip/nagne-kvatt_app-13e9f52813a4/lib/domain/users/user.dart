import 'package:kvatt_app/domain/users/user_account_status.dart';

abstract class User {
  String? uid;
  String email;
  UserAccountStatus accountStatus;

  User({
    required this.uid,
    required this.email,
    required this.accountStatus,
  });
}
