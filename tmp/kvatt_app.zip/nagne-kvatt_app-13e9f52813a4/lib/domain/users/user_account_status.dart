enum UserAccountStatus {
  active,
  pending,
}
