import 'package:kvatt_app/domain/contracts/contract_type.dart';
import 'package:kvatt_app/domain/users/user.dart';
import 'package:kvatt_app/domain/users/user_account_status.dart';
import 'package:kvatt_app/domain/users/user_type.dart';

abstract class UserRepositoryInterface {
  Future<void> createUser({
    required User user,
  });

  Future<void> updateUser({
    required User user,
  });

  Future<User?> findUserByEmail({
    required String email,
  });

  Future<User?> findUserById({
    required String userId,
  });

  Stream<List<User>> users({
    required UserType userType,
  });

  Future<List<User>> findUsers({
    required UserType userType,
    required UserAccountStatus accountStatus,
    ContractType? contractType,
  });
}
