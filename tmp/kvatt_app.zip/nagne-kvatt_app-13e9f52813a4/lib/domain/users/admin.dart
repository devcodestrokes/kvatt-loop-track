import 'package:kvatt_app/domain/users/user.dart';

class Admin extends User {
  String name;

  Admin({
    required super.uid,
    required super.email,
    required super.accountStatus,
    required this.name,
  });
}
