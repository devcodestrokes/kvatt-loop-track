import 'package:kvatt_app/domain/users/user.dart';

class Partner extends User {
  String name;
  List<String> assignedMerchantIds;

  Partner({
    required super.uid,
    required super.email,
    required super.accountStatus,
    required this.name,
    required this.assignedMerchantIds,
  });
}
