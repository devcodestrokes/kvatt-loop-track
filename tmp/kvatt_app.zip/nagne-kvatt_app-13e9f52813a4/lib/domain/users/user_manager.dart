import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/services/auth/auth_service.dart';
import 'package:kvatt_app/app/services/cloud_functions/cloud_functions_service.dart';
import 'package:kvatt_app/domain/contracts/contract_type.dart';
import 'package:kvatt_app/domain/contracts/merchant_contract_info.dart';
import 'package:kvatt_app/domain/contracts/packaging_info.dart';
import 'package:kvatt_app/domain/users/admin.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/partner.dart';
import 'package:kvatt_app/domain/users/user.dart';
import 'package:kvatt_app/domain/users/user_account_status.dart';
import 'package:kvatt_app/domain/users/user_repository_interface.dart';
import 'package:kvatt_app/domain/users/user_type.dart';
import 'package:kvatt_core/domain/stocks/stocks_manager.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';

class UserManager {
  UserRepositoryInterface userRepo;
  AuthService authService;
  StocksManager stocksManager;
  CloudFunctionService cloudFunctionService;
  Config config;

  UserManager({
    required this.userRepo,
    required this.authService,
    required this.stocksManager,
    required this.cloudFunctionService,
    required this.config,
  });

  Future<void> inviteAdmin({
    required String email,
    required String name,
  }) async {
    await userRepo.createUser(
      user: Admin(
        uid: null,
        email: email,
        accountStatus: UserAccountStatus.pending,
        name: name,
      ),
    );
  }

  Future<void> invitePartner({
    required String email,
    required String name,
    required List<String> assignedMerchantIds,
  }) async {
    await userRepo.createUser(
      user: Partner(
        uid: null,
        email: email,
        accountStatus: UserAccountStatus.pending,
        name: name,
        assignedMerchantIds: assignedMerchantIds,
      ),
    );
  }

  Future<void> inviteMerchant({
    required String email,
    required String name,
    required String deliveryAddress,
    required String contractType,
    required TrackingSource? trackingType,
    required List<PackagingInfo> packagingItems,
    required bool packagingLossCompensation,
    required bool packagingMaintenance,
  }) async {
    await userRepo.createUser(
      user: Merchant(
        uid: null,
        email: email,
        accountStatus: UserAccountStatus.pending,
        name: name,
        contractInfo: MerchantContractInfo(
          contractType: contractType,
          deliveryAddress: deliveryAddress,
          packagings: packagingItems,
          packagingLossCompensationIncluded: packagingLossCompensation,
          packagingMaintenanceIncluded: packagingMaintenance,
        ),
        trackingSource: trackingType,
      ),
    );
  }

  Stream<List<Admin>> admins() {
    return userRepo.users(userType: UserType.admin).map((List<User> users) {
      return users.map((User user) => user as Admin).toList();
    });
  }

  Stream<List<Partner>> partners() {
    return userRepo.users(userType: UserType.partner).map((List<User> users) {
      return users.map((User user) => user as Partner).toList();
    });
  }

  Stream<List<Merchant>> merchants() {
    return userRepo.users(userType: UserType.merchant).map((List<User> users) {
      return users.map((User user) => user as Merchant).toList();
    });
  }

  Future<List<Merchant>> retrieveActiveMerchants() async {
    List<User> users = await userRepo.findUsers(
      userType: UserType.merchant,
      accountStatus: UserAccountStatus.active,
    );
    return users.map((User user) => user as Merchant).toList();
  }

  Future<List<Merchant>> retrieveActiveLargeLoopMerchants() async {
    List<User> users = await userRepo.findUsers(
      userType: UserType.merchant,
      accountStatus: UserAccountStatus.active,
      contractType: ContractType.rentalLargeLoop,
    );
    return users.map((User user) => user as Merchant).toList();
  }

  Future<bool> isUserAlreadyInvited({
    required String email,
  }) async {
    User? user = await userRepo.findUserByEmail(email: email);
    return user != null;
  }

  Future<void> createAccount({
    required String password,
    required String code,
  }) async {
    await cloudFunctionService.callFunction(
      functionName: 'createAccountCallable',
      functionRegion: config.cloudFunctionRegion!,
      data: {
        'password': password,
        'code': code,
      },
    );
  }

  Future<void> resendInvite({
    required String email,
  }) async {
    await cloudFunctionService.callFunction(
      functionName: 'resendInviteCallable',
      functionRegion: config.cloudFunctionRegion!,
      data: {
        'email': email,
      },
    );
  }

  Future<User?> findUser({
    required String userId,
  }) async {
    return await userRepo.findUserById(userId: userId);
  }

  Future<void> updateUserDetails({
    required User user,
  }) async {
    return await userRepo.updateUser(user: user);
  }

  Future<void> updateUserEmail({
    required String userId,
    required String email,
  }) async {
    await cloudFunctionService.callFunction(
      functionName: 'changeEmailCallable',
      functionRegion: config.cloudFunctionRegion!,
      data: {
        'userId': userId,
        'email': email,
      },
    );
  }

  Future<void> removeMerchant({
    required Merchant merchant,
  }) async {
    await cloudFunctionService.callFunction(
      functionName: 'removeMerchantCallable',
      functionRegion: config.cloudFunctionRegion!,
      data: {
        'merchantId': merchant.uid,
        'merchantEmail': merchant.email,
      },
    );
  }
}
