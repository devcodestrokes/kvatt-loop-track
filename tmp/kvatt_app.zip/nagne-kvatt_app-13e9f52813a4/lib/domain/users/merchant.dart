import 'package:kvatt_app/domain/contracts/merchant_contract_info.dart';
import 'package:kvatt_app/domain/users/user.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';

class Merchant extends User {
  String name;
  MerchantContractInfo contractInfo;
  TrackingSource? trackingSource;

  Merchant({
    required super.uid,
    required super.email,
    required super.accountStatus,
    required this.name,
    required this.contractInfo,
    required this.trackingSource,
  });
}
