import 'package:kvatt_app/app/services/auth/auth_service.dart';

class AuthManager {
  AuthService authService;

  AuthManager({
    required this.authService,
  });

  Future<void> signIn({
    required String email,
    required String password,
  }) async {
    await authService.login(
      email: email,
      password: password,
    );
  }

  signOut() async {
    await authService.logout();
  }

  sendPasswordResetEmail({
    required String email,
  }) async {
    await authService.sendPasswordResetEmail(email: email);
  }

  setNewPassword({
    required String password,
    required String code,
  }) async {
    await authService.confirmPasswordReset(
      password: password,
      code: code,
    );
  }
}
