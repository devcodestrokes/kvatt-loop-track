import 'package:kvatt_app/app/services/csv/csv_service.dart';
import 'package:kvatt_app/app/services/downloads/downloader_service.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/packaging_status_display_name.dart';
import 'package:kvatt_core/domain/insights/insights_manager.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';

// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'package:kvatt_core/domain/tracking/tracking_manager.dart';

class ReportingManager {
  PackagingsManager packagingsManager;
  TrackingManager trackingManager;
  InsightsManager insightsManager;
  CSVService csvService;
  DownloaderService downloaderService;
  DateTime platformStartDate;

  ReportingManager({
    required this.packagingsManager,
    required this.trackingManager,
    required this.insightsManager,
    required this.csvService,
    required this.downloaderService,
    required this.platformStartDate,
  });

  Future<void> downloadPackagingsCsvData({
    PackagingStatus? status,
    String? type,
    String? merchantId,
    bool? nonRegisteredMerchants,
  }) async {
    List<Packaging> packagings = await packagingsManager.getPackagings(
      status: status,
      type: type,
      merchantId: merchantId,
      merchantNameNotNull: nonRegisteredMerchants,
      startAtPackagingCode: 1,
    );

    DateFormat formatter = DateFormat('yyyy-MM-dd');

    List<List<dynamic>> rows = [
      [
        'Code',
        'Custom ID',
        'Product Type',
        'Manufacturer',
        'Merchant Name',
        'Order Number',
        'Status',
        'Last Tracked',
      ]
    ];

    for (var packaging in packagings) {
      rows.add([
        packaging.code,
        packaging.customId ?? 'n/a',
        packaging.type,
        packaging.manufacturer,
        packaging.merchantName ?? 'n/a',
        packaging.orderNumber ?? 'n/a',
        packaging.status.displayName,
        packaging.lastTracked != null
            ? formatter.format(packaging.lastTracked!)
            : 'n/a',
      ]);
    }

    String csvOutput = csvService.generateCsv(rows: rows);

    downloaderService.downloadFile(
      data: csvOutput.codeUnits,
      name: '${DateTime.now()} - packagings-data.csv',
    );
  }

  Future<void> downloadMerchantPackagingDataForImpactReport({
    required String merchantId,
  }) async {
    List<dynamic> packsInfo = await insightsManager.getPacksInfoForMerchant(
      merchantId: merchantId,
    );

    DateFormat formatter = DateFormat('yyyy-MM-dd');
    List<List<dynamic>> rows = [
      [
        'Code',
        'Type',
        'Num times shipped',
        'Num times returned',
        'Average return time in days',
        'Last shipped date',
        'Last returned date',
      ]
    ];
    for (var i = 0; i < packsInfo.length; i++) {
      rows.add([
        packsInfo[i].code,
        packsInfo[i].type,
        packsInfo[i].insights.numTimesShipped,
        packsInfo[i].insights.numTimesReturned,
        packsInfo[i].insights.averageReturnTimeInDays ?? '',
        packsInfo[i].insights.lastShippedDate != null
            ? formatter.format(packsInfo[i].insights.lastShippedDate!)
            : '',
        packsInfo[i].insights.lastReturnedDate != null
            ? formatter.format(packsInfo[i].insights.lastReturnedDate!)
            : '',
      ]);
    }

    String csvOutput = csvService.generateCsv(rows: rows);

    downloaderService.downloadFile(
      data: csvOutput.codeUnits,
      name: '${DateTime.now()} - $merchantId - impact-report-data.csv',
    );
  }
}
