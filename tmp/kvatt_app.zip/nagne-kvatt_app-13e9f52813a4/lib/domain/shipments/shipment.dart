class Shipment {
  List<Map<String, String>> productQuantities;

  DateTime date;
  String? shippingService;
  String? trackingNumber;

  Shipment({
    required this.productQuantities,
    required this.date,
    this.shippingService,
    this.trackingNumber,
  });
}
