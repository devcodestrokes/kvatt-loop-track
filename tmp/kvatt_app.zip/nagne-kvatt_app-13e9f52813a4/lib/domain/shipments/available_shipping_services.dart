const List<String> availableShippingServices = [
  'UPS',
  'DHL',
  'Royal Mail',
  'DB Schenker'
];
