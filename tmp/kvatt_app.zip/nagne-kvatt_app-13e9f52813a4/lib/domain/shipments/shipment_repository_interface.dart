import 'package:kvatt_app/domain/shipments/shipment.dart';

abstract class ShipmentRepositoryInterface {
  Future<void> createShipment({
    required Shipment shipment,
    required String merchantId,
  });
}
