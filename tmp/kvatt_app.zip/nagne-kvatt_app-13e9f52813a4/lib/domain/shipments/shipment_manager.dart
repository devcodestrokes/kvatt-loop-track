import 'package:kvatt_app/domain/shipments/shipment.dart';
import 'package:kvatt_app/domain/shipments/shipment_repository_interface.dart';

class ShipmentManager {
  ShipmentRepositoryInterface shipmentRepo;

  ShipmentManager({
    required this.shipmentRepo,
  });

  Future<void> recordShipment({
    required Shipment shipment,
    required String merchantId,
  }) async {
    await shipmentRepo.createShipment(
      shipment: shipment,
      merchantId: merchantId,
    );
  }
}
