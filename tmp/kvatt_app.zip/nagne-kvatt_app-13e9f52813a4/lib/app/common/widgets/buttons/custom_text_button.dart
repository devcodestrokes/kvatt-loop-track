import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class CustomTextButton extends StatelessWidget {
  final Function? onTapped;
  final String text;
  final IconData? icon;
  final Color? textColor;
  final bool isUnderlined;

  const CustomTextButton({
    super.key,
    required this.onTapped,
    required this.text,
    this.icon,
    this.textColor,
    this.isUnderlined = false,
  });

  @override
  Widget build(BuildContext context) {
    return TextButton(
      style: ButtonStyle(
        overlayColor: MaterialStateProperty.resolveWith<Color>(
          (Set<MaterialState> states) {
            return Colors.transparent;
          },
        ),
      ),
      onPressed: onTapped != null ? () => onTapped!() : null,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const SizedBox(height: 2.0),
              Text(
                text,
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: textColor ??
                          Theme.of(context).colorScheme.secondaryColor,
                      decoration:
                          isUnderlined ? TextDecoration.underline : null,
                    ),
              ),
            ],
          ),
          icon != null
              ? Row(
                  children: [
                    const SizedBox(width: 12.0),
                    Icon(
                      icon,
                      size: 24,
                      color: Theme.of(context).colorScheme.secondaryColor,
                    ),
                  ],
                )
              : const SizedBox(),
        ],
      ),
    );
  }
}
