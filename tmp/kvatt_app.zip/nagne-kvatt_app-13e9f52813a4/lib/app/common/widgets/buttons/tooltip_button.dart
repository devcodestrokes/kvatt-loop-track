import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class ToolTipButton extends StatelessWidget {
  final Function onTapped;

  const ToolTipButton({
    super.key,
    required this.onTapped,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onTapped(),
      child: Container(
        height: 16.0,
        width: 16.0,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          border: Border.all(
            color: Theme.of(context).colorScheme.secondaryColor,
          ),
        ),
        child: Icon(
          Icons.question_mark,
          size: 10.0,
          color: Theme.of(context).colorScheme.secondaryColor,
        ),
      ),
    );
  }
}
