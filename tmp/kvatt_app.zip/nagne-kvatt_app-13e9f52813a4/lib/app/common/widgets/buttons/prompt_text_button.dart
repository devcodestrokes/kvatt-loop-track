import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class PromptTextButton extends StatelessWidget {
  final String promptText;
  final String actionLabel;
  final Function onPressed;
  final Color? fontColor;

  const PromptTextButton({
    Key? key,
    required this.promptText,
    required this.actionLabel,
    required this.onPressed,
    this.fontColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RichText(
      text: TextSpan(
        children: [
          TextSpan(
              text: promptText,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: fontColor,
                  )),
          const TextSpan(
            text: ' ',
          ),
          TextSpan(
            text: actionLabel,
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  decoration: TextDecoration.underline,
                  fontWeight: FontWeight.bold,
                  color: fontColor ??
                      Theme.of(context).colorScheme.onSurfaceDisabled,
                ),
            recognizer: TapGestureRecognizer()..onTap = () => onPressed(),
          ),
        ],
      ),
    );
  }
}
