import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class TextFieldWhite extends StatefulWidget {
  final Function(String?) validator;
  final String label;
  final TextInputType keyboardType;
  final TextEditingController controller;
  final bool obscureText;
  final String? errorText;

  const TextFieldWhite({
    Key? key,
    required this.validator,
    required this.label,
    required this.keyboardType,
    required this.controller,
    this.obscureText = false,
    this.errorText,
  }) : super(key: key);

  @override
  TextFieldWhiteState createState() => TextFieldWhiteState();
}

class TextFieldWhiteState extends State<TextFieldWhite> {
  bool _isObscure = false;
  @override
  void initState() {
    super.initState();
    _isObscure = widget.obscureText;
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      controller: widget.controller,
      obscureText: _isObscure,
      validator: (String? value) => widget.validator(value),
      keyboardType: widget.keyboardType,
      style: Theme.of(context).textTheme.titleSmall?.copyWith(
            color: Colors.white,
          ),
      cursorColor: Colors.white,
      decoration: InputDecoration(
        errorText: widget.errorText,
        contentPadding: const EdgeInsets.fromLTRB(16.0, 24.0, 16.0, 24.0),
        labelText: widget.label,
        labelStyle: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.onPrimaryMediumEmphasis,
            ),
        errorBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 1.0),
        ),
        focusedErrorBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 2.0),
        ),
        focusedBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 2.0),
        ),
        enabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 1.0),
        ),
        disabledBorder: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 1.0),
        ),
        border: const OutlineInputBorder(
          borderSide: BorderSide(color: Colors.white, width: 1.0),
        ),
        errorStyle: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onPrimaryMediumEmphasis,
            ),
        suffixIcon: widget.obscureText == true
            ? IconButton(
                onPressed: () {
                  setState(() {
                    _isObscure = !_isObscure;
                  });
                },
                icon: const ImageIcon(
                  AssetImage(AssetsFactory.eyeIcon),
                  color: Colors.white,
                  size: 24.0,
                ),
              )
            : null,
      ),
    );
  }
}
