import 'package:flutter/material.dart';

class CheckboxField extends StatefulWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  const CheckboxField({
    Key? key,
    required this.label,
    required this.value,
    required this.onChanged,
  }) : super(key: key);

  @override
  State<CheckboxField> createState() => _CheckboxFieldState();
}

class _CheckboxFieldState extends State<CheckboxField> {
  bool _isSelected = true;

  @override
  void initState() {
    _isSelected = widget.value;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () {
        widget.onChanged(!widget.value);
      },
      child: Padding(
        padding: const EdgeInsets.all(4.0),
        child: Row(
          children: <Widget>[
            Expanded(child: Text(widget.label)),
            Checkbox(
              activeColor: Theme.of(context).primaryColor,
              value: _isSelected,
              onChanged: (bool? newValue) {
                setState(() {
                  _isSelected = newValue!;
                });
                widget.onChanged(newValue!);
              },
            ),
          ],
        ),
      ),
    );
  }
}
