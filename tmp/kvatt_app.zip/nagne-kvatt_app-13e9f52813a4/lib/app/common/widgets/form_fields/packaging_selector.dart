import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/domain/products/available_products.dart';

class PackagingSelector extends StatefulWidget {
  final Function(List<Map<String, String>>) onItemAdded;
  final List<Map<String, String>> initialItems;
  final String? mainLabel;
  final String? productLabel;
  final String? quantityLabel;

  const PackagingSelector({
    super.key,
    required this.onItemAdded,
    required this.initialItems,
    this.mainLabel,
    this.productLabel,
    this.quantityLabel,
  });

  @override
  State<PackagingSelector> createState() => PackagingSelectorState();
}

class PackagingSelectorState extends State<PackagingSelector> {
  List<Map<String, String>> _addedItems = [];

  @override
  void initState() {
    _addedItems = [...widget.initialItems];
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(
              widget.mainLabel ?? 'Add packaging details',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            InkWell(
              hoverColor: Colors.transparent,
              onTap: () {
                setState(() {
                  _addedItems.add({
                    'type': '',
                    'numUnits': '',
                  });
                  widget.onItemAdded(_addedItems);
                });
              },
              child: Row(
                children: [
                  Icon(
                    Icons.add,
                    color: Theme.of(context).colorScheme.secondaryColor,
                    size: 14.0,
                  ),
                  const SizedBox(width: 2.0),
                  Text(
                    'add',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                          color: Theme.of(context).colorScheme.secondaryColor,
                        ),
                  )
                ],
              ),
            ),
          ],
        ),
        const SizedBox(height: 24.0),
        ListView.builder(
          addSemanticIndexes: false,
          addAutomaticKeepAlives: false,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          itemCount: _addedItems.length,
          itemBuilder: (BuildContext context, int index) {
            return Column(
              children: [
                _PackagingSelectorRow(
                  key: ValueKey('key-${_addedItems[index]['type']}'),
                  initialType: _addedItems[index]['type'],
                  initialNumUnits: _addedItems[index]['numUnits'],
                  productLabel: widget.productLabel,
                  quantityLabel: widget.quantityLabel,
                  onRowRemoved: () {
                    setState(() {
                      _addedItems.removeAt(index);
                      widget.onItemAdded(_addedItems);
                    });
                  },
                  onRowUpdated: (String type, String numUnits) {
                    _addedItems[index]['type'] = type;
                    _addedItems[index]['numUnits'] = numUnits;
                    widget.onItemAdded(_addedItems);
                  },
                ),
                const SizedBox(height: 16.0),
              ],
            );
          },
        ),
      ],
    );
  }
}

class _PackagingSelectorRow extends StatefulWidget {
  final Function(String type, String numUnits) onRowUpdated;
  final Function onRowRemoved;
  final String? initialType;
  final String? initialNumUnits;
  final String? productLabel;
  final String? quantityLabel;

  const _PackagingSelectorRow({
    Key? key,
    required this.onRowUpdated,
    required this.onRowRemoved,
    required this.initialType,
    required this.initialNumUnits,
    this.productLabel,
    this.quantityLabel,
  }) : super(key: key);

  @override
  State<_PackagingSelectorRow> createState() => _PackagingSelectorRowState();
}

class _PackagingSelectorRowState extends State<_PackagingSelectorRow> {
  TextEditingController textEditingController = TextEditingController();

  String? _selectedPackagingType;

  @override
  void initState() {
    textEditingController.text = widget.initialNumUnits ?? '';
    _selectedPackagingType =
        widget.initialType == null || widget.initialType!.isEmpty
            ? null
            : widget.initialType;
    textEditingController.addListener(() {
      widget.onRowUpdated(
        _selectedPackagingType ?? '',
        textEditingController.text,
      );
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Expanded(
          flex: 6,
          child: DropDownFieldBlack(
            initialValue: _selectedPackagingType,
            validator: (String? value) => Validators.validateNotEmpty(
              value,
              'Select ${widget.productLabel ?? 'Type'}',
            ),
            label: widget.productLabel ?? 'Type',
            items: availableProducts,
            onItemSelected: (String item) {
              _selectedPackagingType = item;
            },
          ),
        ),
        const SizedBox(width: 8.0),
        Expanded(
          flex: 3,
          child: TextFieldBlack(
            validator: (String? numUnits) => Validators.validateNotEmpty(
              numUnits,
              'Enter ${widget.quantityLabel ?? 'quantity'}',
            ),
            label: widget.quantityLabel ?? 'Quantity',
            keyboardType: TextInputType.number,
            controller: textEditingController,
          ),
        ),
        const SizedBox(width: 8.0),
        Expanded(
          flex: 1,
          child: InkWell(
            onTap: () => widget.onRowRemoved(),
            hoverColor: Colors.transparent,
            child: Align(
              alignment: Alignment.centerRight,
              child: Icon(
                Icons.close,
                color: Theme.of(context).colorScheme.onSurfaceDisabled,
              ),
            ),
          ),
        ),
      ],
    );
  }

  @override
  void dispose() {
    textEditingController.dispose();
    super.dispose();
  }
}
