import 'package:flutter/material.dart';

class RadioButtonField<T> extends StatelessWidget {
  final String label;
  final T value;
  final T? groupValue;
  final Function(T?) onChanged;

  const RadioButtonField({
    super.key,
    required this.label,
    required this.value,
    required this.groupValue,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      dense: true,
      contentPadding: EdgeInsets.zero,
      title: Text(label),
      leading: Radio<T>(
        activeColor: Theme.of(context).primaryColor,
        value: value,
        groupValue: groupValue,
        onChanged: (T? value) => onChanged(value),
      ),
    );
  }
}
