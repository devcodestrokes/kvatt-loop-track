import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class DropDownFieldBlack extends StatefulWidget {
  final String label;
  final List<String> items;
  final Function(String item) onItemSelected;
  final Function(String?)? validator;
  final String? initialValue;

  const DropDownFieldBlack({
    Key? key,
    required this.label,
    required this.items,
    required this.onItemSelected,
    this.validator,
    this.initialValue,
  }) : super(key: key);

  @override
  State<DropDownFieldBlack> createState() => _DropDownFieldBlackState();
}

class _DropDownFieldBlackState extends State<DropDownFieldBlack> {
  String? _selectedValue;

  @override
  void initState() {
    _selectedValue = widget.initialValue;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(
        focusColor: Colors.transparent,
      ),
      child: DropdownButtonFormField<String>(
        validator: widget.validator == null
            ? null
            : (String? value) => widget.validator!(value),
        value: _selectedValue,
        items: widget.items
            .map(
              (String item) => DropdownMenuItem<String>(
                value: item,
                child: Text(
                  item,
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color:
                            Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                      ),
                ),
              ),
            )
            .toList(),
        onChanged: (dynamic value) {
          setState(() {
            _selectedValue = value;
          });
          widget.onItemSelected(value);
        },
        decoration: InputDecoration(
          isDense: true,
          labelText: widget.label,
          labelStyle: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceDisabled,
              ),
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                width: 1.0),
          ),
          focusedErrorBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                width: 2.0),
          ),
          focusedBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                width: 2.0),
          ),
          enabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                width: 1.0),
          ),
          disabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                width: 1.0),
          ),
          border: OutlineInputBorder(
            borderSide: BorderSide(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                width: 1.0),
          ),
          errorStyle: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
        ),
      ),
    );
  }
}
