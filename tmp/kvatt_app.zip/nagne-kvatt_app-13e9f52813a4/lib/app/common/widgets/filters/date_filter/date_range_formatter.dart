import 'package:flutter/material.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class DateRangeFormatter {
  static formatDateRange(DateTimeRange range) {
    DateFormat formatter = DateFormat('d MMM yyyy');
    String formattedFrom = formatter.format(range.start);
    String formattedTo = formatter.format(range.end);
    return '$formattedFrom - $formattedTo';
  }
}
