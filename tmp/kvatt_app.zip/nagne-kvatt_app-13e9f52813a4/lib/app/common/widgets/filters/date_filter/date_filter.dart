import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/custom_text_button.dart';

import 'package:kvatt_app/app/common/widgets/filters/date_filter/date_range_formatter.dart';
import 'package:kvatt_app/app/common/widgets/filters/date_filter/presets_selector.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class DateFilter extends StatefulWidget {
  final DateTime earliestStartDate;
  final DateTime latestEndDate;
  final Function(DateTimeRange?) onRangeSelected;
  final String? label;

  const DateFilter({
    super.key,
    required this.earliestStartDate,
    required this.latestEndDate,
    required this.onRangeSelected,
    this.label,
  });

  @override
  State<DateFilter> createState() => _DateFilterState();
}

class _DateFilterState extends State<DateFilter> {
  DateTimeRange? _selectedRange;

  _FilterMode _filterMode = _FilterMode.range;

  void _onRangeSelected(DateTimeRange? range) {
    setState(() {
      _selectedRange = range;
    });
    widget.onRangeSelected(range);
  }

  Widget _buildDateFilterWidget({
    required Widget? dateRangeFilter,
    required StateSetter setState,
  }) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Container(
          color: Theme.of(context).colorScheme.surfaceColor,
          width: 400.0,
          height: 50.0,
          child: Row(
            children: [
              Expanded(
                flex: 1,
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _filterMode = _FilterMode.presets;
                    });
                  },
                  style: ButtonStyle(
                    overlayColor: MaterialStateProperty.all(Colors.transparent),
                  ),
                  child: Text(
                    'Presets',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: _filterMode == _FilterMode.range
                              ? Theme.of(context).colorScheme.onSurfaceDisabled
                              : Theme.of(context)
                                  .colorScheme
                                  .onSurfaceHighEmphasis,
                        ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
              Expanded(
                flex: 1,
                child: TextButton(
                  onPressed: () {
                    setState(() {
                      _filterMode = _FilterMode.range;
                    });
                  },
                  style: ButtonStyle(
                    overlayColor: MaterialStateProperty.all(Colors.transparent),
                  ),
                  child: Text(
                    'Range',
                    style: Theme.of(context).textTheme.titleSmall?.copyWith(
                          color: _filterMode == _FilterMode.presets
                              ? Theme.of(context).colorScheme.onSurfaceDisabled
                              : Theme.of(context)
                                  .colorScheme
                                  .onSurfaceHighEmphasis,
                        ),
                    textAlign: TextAlign.center,
                  ),
                ),
              ),
            ],
          ),
        ),
        ConstrainedBox(
          constraints: const BoxConstraints(
            maxWidth: 400.0,
            maxHeight: 472.0,
          ),
          child: _filterMode == _FilterMode.range
              ? dateRangeFilter
              : PresetsSelector(
                  onRangeSelected: (DateTimeRange range) =>
                      _onRangeSelected(range),
                ),
        ),
      ],
    );
  }

  showDateFilter() async {
    DateTimeRange? range = await showDateRangePicker(
        context: context,
        initialEntryMode: DatePickerEntryMode.calendarOnly,
        firstDate: widget.earliestStartDate,
        lastDate: widget.latestEndDate,
        locale: const Locale('en', 'GB'),
        builder: (context, child) {
          return StatefulBuilder(
              builder: (BuildContext context, StateSetter setState) {
            return _buildDateFilterWidget(
              dateRangeFilter: Theme(
                data: Theme.of(context).copyWith(
                  colorScheme: ColorScheme.light(
                    primary:
                        Theme.of(context).colorScheme.primaryAlternateColor,
                    onPrimary:
                        Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                    onSurface:
                        Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
                  textTheme: TextTheme(
                    labelLarge: Theme.of(context).textTheme.labelLarge,
                    labelSmall: Theme.of(context).textTheme.bodySmall,
                    headlineSmall: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(fontSize: 20.0),
                    bodySmall: Theme.of(context).textTheme.bodyMedium,
                  ),
                ),
                child: child!,
              ),
              setState: setState,
            );
          });
        });
    if (range != null) {
      _onRangeSelected(range);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        SizedBox(
          width: 280.0,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 16.0),
                child: Text(
                  widget.label == null ? 'Filter by date range' : widget.label!,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceHighEmphasis),
                ),
              ),
              CustomTextButton(
                onTapped: _selectedRange != null
                    ? () => _onRangeSelected(null)
                    : null,
                textColor: _selectedRange != null
                    ? Theme.of(context).primaryColor
                    : Theme.of(context).colorScheme.onSurfaceDisabled,
                text: 'Reset',
                isUnderlined: true,
              ),
            ],
          ),
        ),
        const SizedBox(height: 2.0),
        InkWell(
          onTap: () => showDateFilter(),
          child: Container(
            width: 280.0,
            padding: const EdgeInsets.fromLTRB(0.0, 8.0, 16.0, 8.0),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.kvattNewBlue,
              borderRadius: const BorderRadius.all(Radius.circular(16.0)),
            ),
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  right: 0.0,
                  child: Icon(
                    Icons.calendar_month,
                    size: 22.0,
                    color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                  ),
                ),
                Text(
                  _selectedRange == null
                      ? 'All time'
                      : DateRangeFormatter.formatDateRange(_selectedRange!),
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color:
                            Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                      ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

enum _FilterMode {
  range,
  presets,
}
