import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/filters/date_filter/date_range_formatter.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

import 'date_range_preset.dart';

class PresetsSelector extends StatefulWidget {
  final Function(DateTimeRange) onRangeSelected;

  const PresetsSelector({
    super.key,
    required this.onRangeSelected,
  });

  @override
  State<PresetsSelector> createState() => _PresetsSelectorState();
}

class _PresetsSelectorState extends State<PresetsSelector> {
  DateTimeRange? _selectedRange;
  DateRangePreset? _selectedPreset;

  void onPresetSelected(DateRangePreset preset) {
    setState(() {
      _selectedRange = _getDateRangeForPreset(preset: preset);
      _selectedPreset = preset;
    });
  }

  void onSaveTapped() {
    //Save button is disabled if _selectedRange is null
    widget.onRangeSelected(_selectedRange!);
    Navigator.of(context).pop();
  }

  String _getSelectedRangeLabel() {
    if (_selectedRange == null) {
      return 'Start date - End date';
    } else {
      return DateRangeFormatter.formatDateRange(_selectedRange!);
    }
  }

  String _getPresetLabel({
    required DateRangePreset preset,
  }) {
    switch (preset) {
      case DateRangePreset.last30days:
        return 'Last 30 days';
      case DateRangePreset.last7days:
        return 'Last 7 days';
      case DateRangePreset.last14days:
        return 'Last 14 days';
      case DateRangePreset.last90days:
        return 'Last 90 days';
    }
  }

  DateTimeRange _getDateRangeForPreset({
    required DateRangePreset preset,
  }) {
    DateTime startDate;
    DateTime now = DateTime.now().toUtc();
    switch (preset) {
      case DateRangePreset.last30days:
        startDate = DateTime(now.year, now.month, now.day - 29);
        break;
      case DateRangePreset.last7days:
        startDate = DateTime(now.year, now.month, now.day - 6);
        break;
      case DateRangePreset.last14days:
        startDate = DateTime(now.year, now.month, now.day - 13);
        break;
      case DateRangePreset.last90days:
        startDate = DateTime(now.year, now.month, now.day - 89);
        break;
    }
    return DateTimeRange(
      start: startDate,
      end: now,
    );
  }

  String _getFormattedDisplayForPreset({
    required DateRangePreset preset,
  }) {
    DateTimeRange range = _getDateRangeForPreset(preset: preset);
    return DateRangeFormatter.formatDateRange(range);
  }

  Widget _buildHeader() {
    return Container(
      color: Theme.of(context).colorScheme.primaryAlternateColor,
      padding: const EdgeInsets.fromLTRB(8.0, 3.0, 8.0, 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              IconButton(
                onPressed: () {
                  Navigator.of(context).pop();
                },
                icon: Icon(
                  Icons.close,
                  color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                ),
              ),
              TextButton(
                onPressed: _selectedRange == null ? null : () => onSaveTapped(),
                child: Text(
                  'SAVE',
                  style: Theme.of(context).textTheme.labelLarge?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onPrimaryMediumEmphasis
                            .withOpacity(_selectedRange == null ? 0.4 : 1.0),
                      ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 3.0),
          Padding(
            padding: const EdgeInsets.only(left: 64.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'SELECT RANGE',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color:
                            Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                      ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  _getSelectedRangeLabel(),
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        fontSize: 20.0,
                        color: Theme.of(context)
                            .colorScheme
                            .onPrimaryHighEmphasis
                            .withOpacity(_selectedRange == null ? 0.4 : 1.0),
                      ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildPresetsList() {
    return Column(
      children: DateRangePreset.values.map((DateRangePreset preset) {
        return Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            children: [
              InkWell(
                onTap: () => onPresetSelected(preset),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Row(
                      children: [
                        SizedBox(
                          width: 24.0,
                          child: preset == _selectedPreset
                              ? Icon(
                                  Icons.check,
                                  size: 20.0,
                                  color: Theme.of(context)
                                      .colorScheme
                                      .primaryAlternateColor,
                                )
                              : const SizedBox(),
                        ),
                        const SizedBox(width: 4.0),
                        Text(
                          _getPresetLabel(preset: preset),
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceHighEmphasis,
                                  ),
                        ),
                      ],
                    ),
                    Text(
                      _getFormattedDisplayForPreset(preset: preset),
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceMediumEmphasis,
                          ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 24.0),
            ],
          ),
        );
      }).toList(),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Material(
      child: Container(
        color: Theme.of(context).colorScheme.surfaceColor,
        child: Column(
          children: [
            _buildHeader(),
            const SizedBox(height: 24.0),
            _buildPresetsList(),
          ],
        ),
      ),
    );
  }
}
