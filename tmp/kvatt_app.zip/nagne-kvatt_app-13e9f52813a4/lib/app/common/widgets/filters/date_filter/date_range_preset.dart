enum DateRangePreset {
  last7days,
  last14days,
  last30days,
  last90days,
}
