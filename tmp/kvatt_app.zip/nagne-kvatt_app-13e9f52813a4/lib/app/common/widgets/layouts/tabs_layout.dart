import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class TabConfig {
  String label;
  Widget widget;

  TabConfig({
    required this.label,
    required this.widget,
  });
}

class TabsLayout extends StatelessWidget {
  final String title;
  final List<TabConfig> tabConfigs;
  final String? subText;
  final String? actionButtonLabel;
  final Function? onActionButtonTapped;
  final Function? onBackButtonTapped;
  final Color? backgroundColor;

  const TabsLayout({
    Key? key,
    required this.title,
    required this.tabConfigs,
    this.subText,
    this.actionButtonLabel,
    this.onActionButtonTapped,
    this.onBackButtonTapped,
    this.backgroundColor,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return DefaultTabController(
      length: tabConfigs.length,
      child: Scaffold(
        appBar: PreferredSize(
          preferredSize: const Size.fromHeight(148.0),
          child: AppBar(
            automaticallyImplyLeading: false,
            backgroundColor: Theme.of(context).primaryColor,
            flexibleSpace: _Header(
              title: title,
              description: subText,
              actionButtonLabel: actionButtonLabel,
              onActionButtonPressed: onActionButtonTapped == null
                  ? null
                  : () => onActionButtonTapped!(),
              onBackButtonPressed: onBackButtonTapped == null
                  ? null
                  : () => onBackButtonTapped!(),
            ),
            bottom: PreferredSize(
              preferredSize: const Size.fromHeight(kToolbarHeight),
              child: Align(
                alignment: Alignment.centerLeft,
                child: TabBar(
                  padding: const EdgeInsets.only(left: 24.0),
                  isScrollable: true,
                  indicatorWeight: 2.0,
                  labelStyle: Theme.of(context).textTheme.bodyMedium,
                  labelColor:
                      Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                  unselectedLabelStyle: Theme.of(context).textTheme.bodyMedium,
                  unselectedLabelColor:
                      Theme.of(context).colorScheme.onPrimaryMediumEmphasis,
                  indicatorColor: Theme.of(context).colorScheme.secondaryColor,
                  tabs: tabConfigs
                      .map((TabConfig config) => Tab(text: config.label))
                      .toList(),
                ),
              ),
            ),
          ),
        ),
        body: TabBarView(
          physics: const NeverScrollableScrollPhysics(),
          children: tabConfigs
              .map(
                (TabConfig config) => Container(
                  color: backgroundColor,
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(24.0, 0.0, 24.0, 0.0),
                    child: config.widget,
                  ),
                ),
              )
              .toList(),
        ),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final String title;
  final String? description;
  final String? actionButtonLabel;
  final Function? onActionButtonPressed;
  final Function? onBackButtonPressed;

  const _Header({
    Key? key,
    required this.title,
    required this.description,
    required this.actionButtonLabel,
    required this.onActionButtonPressed,
    this.onBackButtonPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).primaryColor,
      width: double.infinity,
      padding: const EdgeInsets.symmetric(horizontal: 28.0),
      child: Row(
        children: [
          Expanded(
            flex: 6,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                onBackButtonPressed != null
                    ? Column(
                        children: [
                          InkWell(
                            onTap: () => onBackButtonPressed!(),
                            child: Row(
                              children: [
                                ImageIcon(
                                  const AssetImage(AssetsFactory.arrowBackIcon),
                                  color: Theme.of(context)
                                      .colorScheme
                                      .secondaryColor,
                                ),
                                const SizedBox(width: 4.0),
                                Text(
                                  'Back',
                                  style: Theme.of(context)
                                      .textTheme
                                      .bodyMedium
                                      ?.copyWith(
                                        color: Theme.of(context)
                                            .colorScheme
                                            .onPrimaryHighEmphasis,
                                      ),
                                ),
                              ],
                            ),
                          ),
                          const SizedBox(height: 24.0),
                        ],
                      )
                    : const SizedBox(),
                Text(
                  title,
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onPrimaryHighEmphasis),
                ),
                const SizedBox(height: 24.0),
              ],
            ),
          ),
          Expanded(
            flex: 2,
            child: actionButtonLabel != null && onActionButtonPressed != null
                ? PrimaryButton(
                    label: actionButtonLabel!,
                    onPressed: () => onActionButtonPressed!(),
                  )
                : const SizedBox(),
          ),
        ],
      ),
    );
  }
}
