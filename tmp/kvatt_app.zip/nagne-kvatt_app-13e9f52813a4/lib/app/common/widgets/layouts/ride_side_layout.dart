import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';

class RightSideLayout extends StatelessWidget {
  final Widget widget;

  const RightSideLayout({
    Key? key,
    required this.widget,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Row(
        children: [
          Expanded(
            flex: 1,
            child: Padding(
              padding: const EdgeInsets.only(left: 96.0),
              child: Align(
                alignment: Alignment.centerLeft,
                child: Image.asset(
                  AssetsFactory.kvattLogoWhite,
                  width: 110.0,
                  height: 50.0,
                ),
              ),
            ),
          ),
          Flexible(
            flex: 1,
            child: Align(
              alignment: Alignment.center,
              child: SizedBox(
                width: MediaQuery.of(context).size.width * 0.3,
                child: widget,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
