import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_header.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/pagination_config.dart';
import 'package:kvatt_app/app/common/widgets/tables/paginator.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class CustomTable extends StatelessWidget {
  final List<HeaderConfig> headers;
  final List<Widget> rows;
  final bool? isLoading;
  final PaginationConfig? paginationConfig;
  final Color? backgroundColor;
  final BorderRadiusGeometry? borderRadius;
  final String? emptyStateMessage;
  final bool tableRowsExpandable;

  const CustomTable({
    super.key,
    required this.headers,
    required this.rows,
    this.isLoading = false,
    this.paginationConfig,
    this.backgroundColor,
    this.borderRadius,
    this.emptyStateMessage,
    this.tableRowsExpandable = false,
  });

  bool get _showPaginator {
    return paginationConfig != null;
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(32.0, 32.0, 32.0, 12.0),
      decoration: BoxDecoration(
        color: backgroundColor,
        borderRadius: borderRadius,
      ),
      child: Stack(
        children: [
          Column(
            children: [
              CustomTableHeader(
                headers: headers,
                tableRowsExpandable: tableRowsExpandable,
              ),
              const SizedBox(height: 24.0),
              isLoading == true
                  ? const Column(
                      children: [
                        SizedBox(height: 40.0),
                        LoadingSpinner(
                          width: 48.0,
                          height: 48.0,
                        ),
                      ],
                    )
                  : rows.isEmpty && emptyStateMessage != null
                      ? Column(
                          children: [
                            const SizedBox(height: 40.0),
                            Text(
                              emptyStateMessage!,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyLarge
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceDisabled,
                                  ),
                            ),
                          ],
                        )
                      : Flexible(
                          child: ScrollConfiguration(
                            behavior: ScrollConfiguration.of(context)
                                .copyWith(scrollbars: false),
                            child: ListView.builder(
                              shrinkWrap: true,
                              itemCount: rows.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Column(
                                  children: [
                                    rows[index],
                                    (index != rows.length - 1)
                                        ? Divider(
                                            height: 8.0,
                                            color: Theme.of(context)
                                                .colorScheme
                                                .onSurfaceDisabled,
                                          )
                                        : const SizedBox(),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
              const SizedBox(height: 40.0),
            ],
          ),
          _showPaginator
              ? Positioned(
                  bottom: 0.0,
                  right: 24.0,
                  child: Paginator(
                    initialDisplayPerPage:
                        paginationConfig!.initialDisplayPerPage,
                    onDisplayPerPageChanged:
                        paginationConfig!.onDisplayPerPageChanged,
                    onPreviousPageTapped: paginationConfig!.onPreviousTapped,
                    onNextPageTapped: paginationConfig!.onNextTapped,
                    padding: EdgeInsets.zero,
                  ),
                )
              : const SizedBox(),
        ],
      ),
    );
  }
}
