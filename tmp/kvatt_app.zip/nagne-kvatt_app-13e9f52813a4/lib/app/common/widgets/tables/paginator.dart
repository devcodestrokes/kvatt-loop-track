import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

//TODO: (LOW) Could make the different options configurable
class Paginator extends StatelessWidget {
  final int initialDisplayPerPage;
  final Function(int?)? onDisplayPerPageChanged;
  final Function()? onPreviousPageTapped;
  final Function()? onNextPageTapped;
  final EdgeInsets? padding;

  const Paginator({
    super.key,
    required this.initialDisplayPerPage,
    required this.onDisplayPerPageChanged,
    required this.onPreviousPageTapped,
    required this.onNextPageTapped,
    this.padding,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: padding ?? const EdgeInsets.fromLTRB(24.0, 20.0, 24.0, 20.0),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          Text(
            'Display per page:',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                ),
          ),
          const SizedBox(width: 12.0),
          SizedBox(
            width: 60.0,
            child: DropdownButtonFormField<int>(
              onChanged: (int? value) => onDisplayPerPageChanged == null
                  ? null
                  : onDisplayPerPageChanged!(value),
              value: initialDisplayPerPage,
              items: onDisplayPerPageChanged == null
                  ? null
                  : [
                      DropdownMenuItem(
                        value: 20,
                        child: Text(
                          '20',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceMediumEmphasis,
                                  ),
                        ),
                      ),
                      DropdownMenuItem(
                        value: 50,
                        child: Text(
                          '50',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceMediumEmphasis,
                                  ),
                        ),
                      ),
                      DropdownMenuItem(
                        value: 100,
                        child: Text(
                          '100',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceMediumEmphasis,
                                  ),
                        ),
                      ),
                      DropdownMenuItem(
                        value: 200,
                        child: Text(
                          '200',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceMediumEmphasis,
                                  ),
                        ),
                      )
                    ],
              decoration: InputDecoration(
                isDense: true,
                border: UnderlineInputBorder(
                  borderSide: BorderSide(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
                ),
                focusedBorder: UnderlineInputBorder(
                  borderSide: BorderSide(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 24.0),
          IconButton(
            onPressed: onPreviousPageTapped != null
                ? () => onPreviousPageTapped!()
                : null,
            icon: Icon(
              Icons.chevron_left,
              color: onPreviousPageTapped != null
                  ? Theme.of(context).colorScheme.onSurfaceMediumEmphasis
                  : Theme.of(context).colorScheme.outlineColor,
            ),
          ),
          IconButton(
            onPressed:
                onNextPageTapped != null ? () => onNextPageTapped!() : null,
            icon: Icon(
              Icons.chevron_right,
              color: onNextPageTapped != null
                  ? Theme.of(context).colorScheme.onSurfaceMediumEmphasis
                  : Theme.of(context).colorScheme.outlineColor,
            ),
          ),
        ],
      ),
    );
  }
}
