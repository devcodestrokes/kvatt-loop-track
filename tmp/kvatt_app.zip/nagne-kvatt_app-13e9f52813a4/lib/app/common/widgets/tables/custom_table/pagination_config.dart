class PaginationConfig {
  int initialDisplayPerPage;
  Function(int?)? onDisplayPerPageChanged;
  Function()? onPreviousTapped;
  Function()? onNextTapped;

  PaginationConfig({
    required this.initialDisplayPerPage,
    required this.onDisplayPerPageChanged,
    required this.onPreviousTapped,
    required this.onNextTapped,
  });
}
