import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/dropdown_table_cell.dart';

import 'editable_table_cell.dart';
import 'read_only_table_cell.dart';

abstract class CustomTableCell extends StatefulWidget {
  const CustomTableCell({
    super.key,
  });

  factory CustomTableCell.editable({
    required bool isEditing,
    required TextEditingController controller,
    int expandFlex = 1,
  }) {
    return EditableTableCell(
      isEditing: isEditing,
      controller: controller,
      expandFlex: expandFlex,
    );
  }

  factory CustomTableCell.readonly({
    required String text,
    int expandFlex = 1,
    bool isEnabled = true,
  }) {
    return ReadOnlyTableCell(
      text: text,
      expandFlex: expandFlex,
      isEnabled: isEnabled,
    );
  }

  factory CustomTableCell.header({
    required String text,
    int expandFlex = 1,
  }) {
    return ReadOnlyTableCell(
      text: text,
      isHeader: true,
      expandFlex: expandFlex,
    );
  }

  factory CustomTableCell.dropdown({
    required bool isEditing,
    required List<String> items,
    required String value,
    required Function(String?) onChanged,
    int expandFlex = 1,
  }) {
    return isEditing
        ? DropDownTableCell(
            items: items,
            initialValue: value,
            onChanged: onChanged,
            expandFlex: expandFlex,
          )
        : ReadOnlyTableCell(
            text: value,
            expandFlex: expandFlex,
          );
  }
}
