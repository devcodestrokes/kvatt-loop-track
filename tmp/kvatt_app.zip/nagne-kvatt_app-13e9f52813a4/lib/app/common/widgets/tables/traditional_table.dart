import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class TableConfig {
  List<String> headers;
  List<List<dynamic>> data;

  TableConfig({
    required this.headers,
    required this.data,
  });
}

class TraditionalTable extends StatelessWidget {
  final TableConfig tableConfig;

  const TraditionalTable({
    Key? key,
    required this.tableConfig,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Table(
      defaultColumnWidth: const IntrinsicColumnWidth(),
      border: TableBorder(
        horizontalInside: BorderSide(
          width: 1,
          color: Theme.of(context).colorScheme.outlineColor,
          style: BorderStyle.solid,
        ),
        top: BorderSide(
          width: 1,
          color: Theme.of(context).colorScheme.outlineColor,
          style: BorderStyle.solid,
        ),
        bottom: BorderSide(
          width: 1,
          color: Theme.of(context).colorScheme.outlineColor,
          style: BorderStyle.solid,
        ),
        left: BorderSide(
          width: 1,
          color: Theme.of(context).colorScheme.outlineColor,
          style: BorderStyle.solid,
        ),
        right: BorderSide(
          width: 1,
          color: Theme.of(context).colorScheme.outlineColor,
          style: BorderStyle.solid,
        ),
        borderRadius: const BorderRadius.all(Radius.circular(4.0)),
      ),
      children: [
        ...[_buildTableHeader(context)],
        ..._buildTableRows(context),
      ],
    );
  }

  TableRow _buildTableHeader(BuildContext context) {
    return TableRow(
        children: tableConfig.headers.map((String header) {
      return Padding(
        padding: const EdgeInsets.all(16.0),
        child: Text(
          header,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
        ),
      );
    }).toList());
  }

  List<TableRow> _buildTableRows(BuildContext context) {
    return tableConfig.data.map((List<dynamic> columns) {
      return TableRow(
          children: columns.map((dynamic item) {
        if (item is Widget) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(16.0, 12.0, 0.0, 4.0),
            child: item,
          );
        } else if (item is String) {
          return Padding(
            padding: const EdgeInsets.fromLTRB(16.0, 16.0, 0.0, 4.0),
            child: Text(
              item,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          );
        } else {
          return const Padding(
            padding: EdgeInsets.all(16.0),
            child: Text(''),
          );
        }
      }).toList());
    }).toList();
  }
}
