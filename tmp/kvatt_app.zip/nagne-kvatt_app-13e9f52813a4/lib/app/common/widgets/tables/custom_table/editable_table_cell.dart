import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_cell.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class EditableTableCell extends CustomTableCell {
  final bool isEditing;
  final TextEditingController controller;
  final int expandFlex;

  const EditableTableCell({
    super.key,
    required this.isEditing,
    required this.controller,
    required this.expandFlex,
  });

  @override
  State<EditableTableCell> createState() => _EditableTableCellState();
}

class _EditableTableCellState extends State<EditableTableCell> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: widget.expandFlex,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4.0),
        child: TextField(
          controller: widget.controller,
          readOnly: !widget.isEditing,
          cursorColor: Theme.of(context).primaryColor,
          textAlign: TextAlign.center,
          decoration: InputDecoration(
            isDense: true,
            border: InputBorder.none,
            filled: widget.isEditing,
          ),
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
        ),
      ),
    );
  }
}
