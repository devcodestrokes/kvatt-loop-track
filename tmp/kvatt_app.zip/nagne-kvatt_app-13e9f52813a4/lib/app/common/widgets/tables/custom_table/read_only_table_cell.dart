import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_cell.dart';

class ReadOnlyTableCell extends CustomTableCell {
  final String text;
  final bool isHeader;
  final int expandFlex;
  final bool isEnabled;

  const ReadOnlyTableCell({
    super.key,
    required this.text,
    this.isHeader = false,
    required this.expandFlex,
    this.isEnabled = true,
  });

  @override
  State<ReadOnlyTableCell> createState() => _ReadOnlyTableCellState();
}

class _ReadOnlyTableCellState extends State<ReadOnlyTableCell> {
  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: widget.expandFlex,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 4.0),
        child: Text(
          widget.text,
          style: widget.isHeader == true
              ? Theme.of(context).textTheme.titleSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  )
              : Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: widget.isEnabled == true
                        ? Theme.of(context).colorScheme.onSurfaceHighEmphasis
                        : Theme.of(context).colorScheme.onSurfaceDisabled,
                  ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
