import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_cell.dart';

class DropDownTableCell extends CustomTableCell {
  final List<String> items;
  final String initialValue;
  final Function(String?) onChanged;
  final int expandFlex;

  const DropDownTableCell({
    super.key,
    required this.items,
    required this.initialValue,
    required this.onChanged,
    this.expandFlex = 1,
  });

  @override
  State<DropDownTableCell> createState() => _DropDownTableCellState();
}

class _DropDownTableCellState extends State<DropDownTableCell> {
  String? _selectedValue;

  @override
  void initState() {
    _selectedValue = widget.initialValue;
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Expanded(
      flex: widget.expandFlex,
      child: DropdownButtonHideUnderline(
        child: DropdownButton2<String>(
          value: _selectedValue,
          customButton: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                _selectedValue ?? '',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    ),
              ),
              const SizedBox(width: 2.0),
              Icon(
                Icons.expand_more,
                size: 20.0,
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
            ],
          ),
          items: widget.items
              .map(
                (String item) => DropdownMenuItem<String>(
                  value: item,
                  child: Text(
                    item,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                ),
              )
              .toList(),
          onChanged: (String? item) {
            setState(() {
              _selectedValue = item;
            });
            widget.onChanged(item);
          },
          dropdownPadding: EdgeInsets.zero,
          isExpanded: true,
        ),
      ),
    );
  }
}
