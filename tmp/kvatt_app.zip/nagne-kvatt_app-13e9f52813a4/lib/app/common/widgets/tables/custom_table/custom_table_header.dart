import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_cell.dart';

class HeaderConfig {
  String label;
  int expandFlex;

  HeaderConfig({
    required this.label,
    required this.expandFlex,
  });
}

class CustomTableHeader extends StatelessWidget {
  final List<HeaderConfig> headers;
  final bool tableRowsExpandable;

  const CustomTableHeader({
    super.key,
    required this.headers,
    this.tableRowsExpandable = false,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ...headers.map((HeaderConfig header) {
          return CustomTableCell.header(
            text: header.label,
            expandFlex: header.expandFlex,
          );
        }).toList(),
        ...[
          SizedBox(
            width: tableRowsExpandable ? 38.0 : 0.0,
          )
        ]
      ],
    );
  }
}
