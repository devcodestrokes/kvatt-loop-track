import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

enum TrafficLightStatus {
  red,
  amber,
  green,
}

class TrafficLightPill extends StatelessWidget {
  final TrafficLightStatus status;
  final String label;

  const TrafficLightPill({
    Key? key,
    required this.status,
    required this.label,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Container(
          padding: const EdgeInsets.fromLTRB(16.0, 8.0, 16.0, 8.0),
          decoration: BoxDecoration(
            border: Border.all(
              color: Theme.of(context).colorScheme.outlineColor,
            ),
            borderRadius: const BorderRadius.all(Radius.circular(100.0)),
            color: _getBackgroundColor(context),
          ),
          child: Text(
            label,
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: _getTextColor(context),
                  fontSize: 12.0,
                  height: 1.0,
                ),
          ),
        ),
      ],
    );
  }

  Color _getBackgroundColor(BuildContext context) {
    switch (status) {
      case TrafficLightStatus.red:
        return Theme.of(context).colorScheme.trafficLightRed;
      case TrafficLightStatus.amber:
        return Theme.of(context).colorScheme.trafficLightAmber;
      case TrafficLightStatus.green:
        return Theme.of(context).colorScheme.trafficLightGreen;
    }
  }

  Color _getTextColor(BuildContext context) {
    switch (status) {
      case TrafficLightStatus.red:
        return Theme.of(context).colorScheme.onTrafficLightRed;
      case TrafficLightStatus.amber:
        return Theme.of(context).colorScheme.onTrafficLightAmber;
      case TrafficLightStatus.green:
        return Theme.of(context).colorScheme.onTrafficLightGreen;
    }
  }
}
