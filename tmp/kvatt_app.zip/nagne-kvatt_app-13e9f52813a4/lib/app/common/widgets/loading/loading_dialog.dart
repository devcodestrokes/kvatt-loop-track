import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

enum LoadingDialogMode {
  onPrimary,
  onSurface,
}

class LoadingDialog {
  static show(
    BuildContext context,
    String text, {
    loadingDialogMode = LoadingDialogMode.onSurface,
  }) {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          backgroundColor: loadingDialogMode == LoadingDialogMode.onSurface
              ? Theme.of(context).primaryColor
              : Theme.of(context).colorScheme.secondaryColor,
          content: SizedBox(
            height: 100.0,
            width: 50.0,
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                CircularProgressIndicator(
                  color: loadingDialogMode == LoadingDialogMode.onSurface
                      ? Theme.of(context).colorScheme.secondaryColor
                      : Theme.of(context).primaryColor,
                ),
                const SizedBox(height: 24.0),
                Text(
                  text,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: loadingDialogMode == LoadingDialogMode.onSurface
                            ? Theme.of(context).colorScheme.secondaryColor
                            : Theme.of(context).primaryColor,
                      ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
