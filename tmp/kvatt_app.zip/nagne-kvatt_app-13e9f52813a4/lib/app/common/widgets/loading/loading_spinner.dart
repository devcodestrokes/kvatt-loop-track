import 'package:flutter/material.dart';

class LoadingSpinner extends StatelessWidget {
  final double? width;
  final double? height;

  const LoadingSpinner({
    Key? key,
    this.width,
    this.height,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Center(
      child: SizedBox(
        width: width ?? 60.0,
        height: height ?? 60.0,
        child: CircularProgressIndicator(
          backgroundColor: Theme.of(context).primaryColor,
          color: Colors.white,
        ),
      ),
    );
  }
}
