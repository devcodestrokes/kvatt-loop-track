import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/custom_text_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class DataCard extends StatefulWidget {
  final double? value;
  final String? unit;
  final String label;
  final double? height;
  final Function? onDetailsToggled;
  final TextStyle? valueTextStyle;
  final double? elementsSpacing;
  final bool? isLoading;

  const DataCard({
    super.key,
    required this.value,
    required this.unit,
    required this.label,
    this.height,
    this.onDetailsToggled,
    this.valueTextStyle,
    this.elementsSpacing,
    this.isLoading = false,
  });

  @override
  State<DataCard> createState() => _DataCardState();
}

class _DataCardState extends State<DataCard> {
  bool _showDetails = false;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: widget.height,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.backgroundColor,
        borderRadius: const BorderRadius.all(Radius.circular(20.0)),
        border: Border.all(
          color: Theme.of(context).colorScheme.surfaceDarkColor,
        ),
      ),
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  widget.isLoading == true
                      ? Container(
                          margin: const EdgeInsets.only(right: 12.0),
                          child: const LoadingSpinner(
                            width: 50.0,
                            height: 50.0,
                          ),
                        )
                      : Text(
                          widget.value == null
                              ? 'n/a'
                              : NumberFormat('#,###,###.#')
                                  .format(widget.value),
                          style: widget.valueTextStyle ??
                              Theme.of(context)
                                  .textTheme
                                  .displaySmall
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceHighEmphasis,
                                  ),
                        ),
                  widget.unit != null && widget.value != null
                      ? Text(
                          widget.unit!,
                          style: Theme.of(context)
                              .textTheme
                              .headlineMedium
                              ?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceHighEmphasis,
                              ),
                        )
                      : const SizedBox(),
                ],
              ),
              SizedBox(height: widget.elementsSpacing ?? 16.0),
              Text(
                widget.label,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                    ),
              ),
              const SizedBox(height: 8.0),
              SizedBox(
                width: constraints.maxWidth * 0.5,
                child: Divider(
                  color: Theme.of(context).colorScheme.onSurfaceDisabled,
                ),
              ),
              widget.onDetailsToggled != null
                  ? Column(
                      children: [
                        SizedBox(height: widget.elementsSpacing ?? 16.0),
                        CustomTextButton(
                          onTapped: () {
                            setState(() {
                              _showDetails = !_showDetails;
                            });
                            widget.onDetailsToggled!();
                          },
                          icon: _showDetails == true
                              ? Icons.arrow_left
                              : Icons.arrow_right,
                          text: _showDetails == true
                              ? 'HIDE DETAILS'
                              : 'SHOW DETAILS',
                        ),
                      ],
                    )
                  : const SizedBox(),
            ],
          );
        },
      ),
    );
  }
}
