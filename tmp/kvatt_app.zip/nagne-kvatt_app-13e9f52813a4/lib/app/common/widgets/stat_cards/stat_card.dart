import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class StatCard extends StatelessWidget {
  final String value;
  final String label;
  final double? width;
  final double? height;

  const StatCard({
    super.key,
    required this.value,
    required this.label,
    this.width,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      padding: const EdgeInsets.symmetric(horizontal: 24.0),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceColor,
        border: Border.all(
          width: 2.0,
          color: Theme.of(context).colorScheme.outlineColor,
        ),
        borderRadius: const BorderRadius.all(
          Radius.circular(8.0),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Text(
            label,
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                ),
            textAlign: TextAlign.center,
          ),
          Text(
            value,
            style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
        ],
      ),
    );
  }
}
