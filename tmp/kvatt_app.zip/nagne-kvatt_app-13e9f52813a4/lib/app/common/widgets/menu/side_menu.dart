import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class SideMenuItem {
  String? iconPath;
  String label;
  bool isSelected;
  Function onSelected;
  IconData? icon;

  SideMenuItem({
    this.iconPath,
    required this.label,
    required this.isSelected,
    required this.onSelected,
    this.icon,
  }) : assert(iconPath != null || icon != null);
}

class SideMenu extends StatelessWidget {
  final List<SideMenuItem> menuItems;
  final Function onSignOutPressed;

  const SideMenu({
    Key? key,
    required this.menuItems,
    required this.onSignOutPressed,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.surfaceDarkColor,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              Container(
                alignment: Alignment.centerLeft,
                padding: const EdgeInsets.fromLTRB(24.0, 24.0, 0.0, 0.0),
                child: Image.asset(
                  AssetsFactory.kvattLogoBlack,
                  height: 30.0,
                ),
              ),
              const SizedBox(height: 24.0),
              menuItems.isNotEmpty
                  ? _SideMenuTile(
                      isSelected: menuItems[0].isSelected,
                      iconPath: menuItems[0].iconPath,
                      label: menuItems[0].label,
                      onTapped: () => menuItems[0].onSelected(),
                    )
                  : Container(),
              const SizedBox(height: 24.0),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: menuItems.length - 1,
                itemBuilder: (BuildContext context, int index) {
                  return _SideMenuTile(
                    isSelected: menuItems[index + 1].isSelected,
                    iconPath: menuItems[index + 1].iconPath,
                    label: menuItems[index + 1].label,
                    onTapped: () => menuItems[index + 1].onSelected(),
                    icon: menuItems[index + 1].icon,
                  );
                },
              ),
            ],
          ),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 28.0),
                child: InkWell(
                  onTap: () => onSignOutPressed(),
                  child: Row(
                    children: [
                      Icon(
                        Icons.logout,
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                      const SizedBox(width: 12.0),
                      Text(
                        'Sign Out',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceMediumEmphasis,
                            ),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 24.0),
            ],
          ),
        ],
      ),
    );
  }
}

class _SideMenuTile extends StatelessWidget {
  final bool isSelected;
  final String? iconPath;
  final String label;
  final Function onTapped;
  final IconData? icon;

  const _SideMenuTile({
    required this.isSelected,
    this.iconPath,
    required this.label,
    required this.onTapped,
    this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      color: isSelected ? Theme.of(context).primaryColor : Colors.transparent,
      child: ListTile(
        onTap: () => onTapped(),
        contentPadding: const EdgeInsets.only(left: 28.0),
        horizontalTitleGap: 0.0,
        tileColor: Colors.red,
        leading: icon != null
            ? Icon(
                icon,
                color: isSelected
                    ? Theme.of(context).colorScheme.onPrimaryHighEmphasis
                    : Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
              )
            : ImageIcon(
                AssetImage(iconPath!),
                color: isSelected
                    ? Theme.of(context).colorScheme.onPrimaryHighEmphasis
                    : Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
              ),
        title: Text(
          label,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: isSelected
                  ? Theme.of(context).colorScheme.onPrimaryHighEmphasis
                  : Theme.of(context).colorScheme.onSurfaceMediumEmphasis),
        ),
      ),
    );
  }
}
