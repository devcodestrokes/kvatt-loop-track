import 'package:dropdown_button2/dropdown_button2.dart';
import 'package:flutter/material.dart';

class MenuItemConfig {
  String label;
  Function onSelected;

  MenuItemConfig({
    required this.label,
    required this.onSelected,
  });
}

class MoreDropdownMenu extends StatelessWidget {
  final List<MenuItemConfig> menuItems;

  const MoreDropdownMenu({
    super.key,
    required this.menuItems,
  });

  @override
  Widget build(BuildContext context) {
    return DropdownButtonHideUnderline(
      child: DropdownButton2(
        buttonOverlayColor: MaterialStateProperty.resolveWith<Color>(
          (Set<MaterialState> states) {
            return Colors.transparent;
          },
        ),
        customButton: const Icon(Icons.more_horiz),
        buttonPadding: EdgeInsets.zero,
        items: menuItems
            .map(
              (MenuItemConfig item) => DropdownMenuItem(
                value: item.label,
                child: GestureDetector(
                  onTap: () => item.onSelected(),
                  child: Text(
                    item.label,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontSize: 12,
                        ),
                  ),
                ),
              ),
            )
            .toList(),
        onChanged: (dynamic value) {},
      ),
    );
  }
}
