import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class VerticalBleedLine extends pw.StatelessWidget {
  final double height;
  VerticalBleedLine({
    required this.height,
  });

  @override
  Widget build(context) {
    return pw.Container(
      height: height,
      width: 0.2 * PdfPageFormat.mm,
      color: PdfColor.fromHex('000000'),
    );
  }
}
