import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class HorizontalBleedLine extends pw.StatelessWidget {
  final double width;
  HorizontalBleedLine({
    required this.width,
  });

  @override
  Widget build(context) {
    return pw.Container(
      height: 0.2 * PdfPageFormat.mm,
      width: width,
      color: PdfColor.fromHex('000000'),
    );
  }
}
