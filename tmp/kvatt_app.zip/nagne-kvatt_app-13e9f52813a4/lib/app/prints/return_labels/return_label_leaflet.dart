import 'package:flutter/foundation.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';
import 'dart:math' as math;

class ReturnLabelLeaflet extends pw.StatelessWidget {
  final String qrCodeUrl;
  final pw.Widget label;
  final Map<String, Font> fonts;
  final Map<String, Uint8List> images;

  ReturnLabelLeaflet({
    required this.qrCodeUrl,
    required this.label,
    required this.fonts,
    required this.images,
  });

  pw.Widget _buildContent() {
    return pw.Stack(
      children: [
        pw.Expanded(
          flex: 1,
          child: pw.Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              pw.SizedBox(height: 20.0 * PdfPageFormat.mm),
              pw.Container(
                padding: const EdgeInsets.only(left: 12.0 * PdfPageFormat.mm),
                child: pw.Container(
                  width: 127 * PdfPageFormat.mm,
                  child: pw.Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      pw.Container(
                        margin:
                            const EdgeInsets.only(top: -4.0 * PdfPageFormat.mm),
                        child: pw.Text(
                          'Cet emballage Amazon',
                          style: pw.TextStyle(
                            fontSize: 30.0 * PdfPageFormat.point,
                            font: fonts['permanentMarker'],
                            color: PdfColor.fromHex('231f20'),
                          ),
                        ),
                      ),
                      pw.Container(
                        margin:
                            const EdgeInsets.only(top: -4.0 * PdfPageFormat.mm),
                        child: pw.Text(
                          'est réutilisable !',
                          style: pw.TextStyle(
                            fontSize: 31.0 * PdfPageFormat.point,
                            font: fonts['permanentMarker'],
                            color: PdfColor.fromHex('231f20'),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),
              pw.SizedBox(height: 16.0 * PdfPageFormat.mm),
              pw.Container(
                padding: const EdgeInsets.only(left: 14.0 * PdfPageFormat.mm),
                child: pw.Container(
                  width: 128 * PdfPageFormat.mm,
                  child: pw.Column(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      pw.Container(
                        child: pw.Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Container(
                              width: 10.0 * PdfPageFormat.mm,
                              child: Text(
                                '1',
                                style: pw.TextStyle(
                                  fontSize: 20.0 * PdfPageFormat.point,
                                  font: fonts['permanentMarker'],
                                  fontStyle: pw.FontStyle.italic,
                                ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                            pw.SizedBox(width: 1.5 * PdfPageFormat.mm),
                            pw.Container(
                              padding: const EdgeInsets.only(
                                top: 3.5 * PdfPageFormat.mm,
                              ),
                              child: Text(
                                'Veuillez vider l\'emballage.',
                                style: pw.TextStyle(
                                  fontSize: 13.0 * PdfPageFormat.point,
                                  font: fonts['helveticaNeueLight'],
                                  fontWeight: pw.FontWeight.bold,
                                ),
                              ),
                            ),
                          ],
                        ),
                      ),
                      pw.SizedBox(height: 3.0 * PdfPageFormat.mm),
                      pw.Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 10.0 * PdfPageFormat.mm,
                            child: Text(
                              '2',
                              style: pw.TextStyle(
                                fontSize: 20.0 * PdfPageFormat.point,
                                font: fonts['permanentMarker'],
                                // color: PdfColor.fromHex('231f20'),
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          pw.SizedBox(width: 1.5 * PdfPageFormat.mm),
                          pw.Container(
                            padding: const EdgeInsets.only(
                              top: 2.0 * PdfPageFormat.mm,
                            ),
                            child: Text(
                              'Collez l\'étiquette de retour jointe par dessus\nl\'étiquette contenant votre adresse.',
                              style: pw.TextStyle(
                                fontSize: 13.0 * PdfPageFormat.point,
                                font: fonts['helveticaNeueLight'],
                                // color: PdfColor.fromHex('231f20'),
                              ),
                            ),
                          ),
                        ],
                      ),
                      pw.SizedBox(height: 3.0 * PdfPageFormat.mm),
                      pw.Row(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Container(
                            width: 10.0 * PdfPageFormat.mm,
                            child: Text(
                              '3',
                              style: pw.TextStyle(
                                fontSize: 20.0 * PdfPageFormat.point,
                                font: fonts['permanentMarker'],
                              ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          pw.SizedBox(width: 1.5 * PdfPageFormat.mm),
                          pw.Container(
                            padding: const EdgeInsets.only(
                              top: 3.0 * PdfPageFormat.mm,
                            ),
                            child: Text(
                              'Déposez l\'emballage dans n\'importe quelle boîte aux\nlettres publique. Aucun timbre n\'est requis.\nNous nettoierons l\'emballage et le réutiliserons.',
                              style: pw.TextStyle(
                                fontSize: 13.0 * PdfPageFormat.point,
                                font: fonts['helveticaNeueLight'],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ],
                  ),
                ),
              ),
              pw.SizedBox(height: 17.0 * PdfPageFormat.mm),
              pw.Container(
                padding: const EdgeInsets.only(left: 16.0 * PdfPageFormat.mm),
                child: pw.Text(
                  'Si votre emballage est endommagé, veuillez quand même\nnous le retourner et nous le recyclerons.',
                  style: pw.TextStyle(
                    fontSize: 13.0 * PdfPageFormat.point,
                    font: fonts['helveticaNeueItalic'],
                    fontWeight: pw.FontWeight.bold,
                  ),
                  textAlign: pw.TextAlign.center,
                ),
              ),
              pw.SizedBox(height: 14.0 * PdfPageFormat.mm),
              pw.Container(
                padding: const EdgeInsets.only(left: 55.0 * PdfPageFormat.mm),
                child: pw.BarcodeWidget(
                  data: qrCodeUrl,
                  barcode: pw.Barcode.qrCode(),
                  width: 35.0 * PdfPageFormat.mm,
                  height: 35.0 * PdfPageFormat.mm,
                  color: PdfColor.fromHex('000000'),
                ),
              ),
              pw.SizedBox(height: 9.0 * PdfPageFormat.mm),
              pw.Container(
                padding: const EdgeInsets.only(left: 20.0 * PdfPageFormat.mm),
                child: pw.RichText(
                  text: pw.TextSpan(
                    children: [
                      TextSpan(
                        text: 'Pour plus d\'information, ',
                        style: pw.TextStyle(
                          fontSize: 13.0 * PdfPageFormat.point,
                          font: fonts['helveticaNeueLight'],
                        ),
                      ),
                      TextSpan(
                        text: 'veuillez scanner le QR code.',
                        style: pw.TextStyle(
                          fontSize: 13.0 * PdfPageFormat.point,
                          font: fonts['helveticaNeueBold'],
                          fontWeight: pw.FontWeight.normal,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
        pw.Positioned(
          right: -6.631 * PdfPageFormat.mm,
          top: 52.311 * PdfPageFormat.mm,
          child: pw.Container(
            child: pw.Transform.rotate(
              angle: math.pi / 2.0,
              child: label,
            ),
          ),
        ),
        pw.Positioned(
          right: 29.0 * PdfPageFormat.mm,
          bottom: 14.0 * PdfPageFormat.mm,
          child: pw.Text(
            'ETIQUETTE DE RETOUR',
            style: pw.TextStyle(
              fontSize: 18.0 * PdfPageFormat.point,
              font: fonts['helveticaNeueLight'],
            ),
            textAlign: pw.TextAlign.center,
          ),
        ),
      ],
    );
  }

  @override
  pw.Widget build(pw.Context context) {
    return pw.Container(
      width: 297 * PdfPageFormat.mm,
      height: 210.0 * PdfPageFormat.mm,
      child: _buildContent(),
    );
  }
}
