import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class LabelLaPoste extends pw.StatelessWidget {
  final String smartCodeLabel;
  final String base64DatamatrixImage;

  final Map<String, Font> fonts;
  final Map<String, Uint8List> images;

  LabelLaPoste({
    required this.smartCodeLabel,
    required this.base64DatamatrixImage,
    required this.fonts,
    required this.images,
  });

  pw.Widget _buildContent() {
    return pw.Stack(
      children: [
        images[AssetsFactory.laPosteLabelTemplate] != null
            ? pw.Image(
                pw.MemoryImage(
                  images[AssetsFactory.laPosteLabelTemplate]!,
                ),
                width: 140.0 * PdfPageFormat.mm,
                height: 90.0 * PdfPageFormat.mm,
              )
            : pw.SizedBox(),
        pw.Positioned(
          left: 12.325 * PdfPageFormat.mm,
          top: 46.5 * PdfPageFormat.mm,
          child: pw.Image(
            pw.MemoryImage(
              base64Decode(
                base64DatamatrixImage.replaceFirst(
                  'data:image/png;base64,',
                  '',
                ),
              ),
            ),
            width: 24.0 * PdfPageFormat.mm,
            height: 8.0 * PdfPageFormat.mm,
          ),
        ),
        pw.Positioned(
          left: 9.7 * PdfPageFormat.mm,
          top: 56.0 * PdfPageFormat.mm,
          child: pw.Text(
            smartCodeLabel,
            style: pw.TextStyle(
              fontSize: 7.0,
              font: fonts['robotoRegular'],
            ),
          ),
        ),
      ],
    );
  }

  @override
  pw.Widget build(pw.Context context) {
    return pw.Stack(
      children: [
        pw.Container(
          width: 140 * PdfPageFormat.mm,
          height: 90.0 * PdfPageFormat.mm,
          child: _buildContent(),
        ),
      ],
    );
  }
}
