import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class LabelGamifiedV1 extends pw.StatelessWidget {
  final String url;
  final String labelIdentifier;
  final Map<String, Font> fonts;

  LabelGamifiedV1({
    required this.url,
    required this.labelIdentifier,
    required this.fonts,
  });

  @override
  pw.Widget build(pw.Context context) {
    return pw.Container(
      width: 300.0,
      height: 150.0,
      padding: const pw.EdgeInsets.symmetric(horizontal: 24.0),
      child: pw.Column(children: [
        pw.SizedBox(height: 12.0),
        pw.Text(
          'TOP SECRET',
          style: pw.TextStyle(
            fontSize: 34.0,
            fontWeight: pw.FontWeight.bold,
            font: pw.Font.timesBold(),
          ),
        ),
        pw.SizedBox(height: 8.0),
        pw.Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            pw.Expanded(
              flex: 3,
              child: pw.Container(
                child: pw.Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    pw.BarcodeWidget(
                      data: url,
                      barcode: pw.Barcode.qrCode(),
                      width: 62,
                      height: 62,
                    ),
                    pw.SizedBox(height: 4.0),
                    Text(
                      labelIdentifier,
                      style: pw.TextStyle(
                        fontSize: 8.0,
                        font: fonts['helveticaNeueLight'],
                      ),
                      textAlign: pw.TextAlign.center,
                    ),
                  ],
                ),
              ),
            ),
            pw.SizedBox(width: 14.0),
            pw.Expanded(
              flex: 7,
              child: pw.Column(
                // mainAxisAlignment: pw.MainAxisAlignment.start,
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.Text(
                    'This packaging is our secret\nweapon to change the world.',
                    style: pw.TextStyle(
                      fontSize: 10.0,
                      font: fonts['helveticaNeueLight'],
                    ),
                    textAlign: pw.TextAlign.left,
                  ),
                  pw.SizedBox(height: 8.0),
                  pw.RichText(
                    textAlign: pw.TextAlign.left,
                    text: pw.TextSpan(
                      children: [
                        pw.TextSpan(
                          text:
                              'By scanning this code, you might unleash its sustainable super\npower. ',
                          style: pw.TextStyle(
                            fontSize: 10.0,
                            font: fonts['helveticaNeueLight'],
                          ),
                        ),
                        pw.TextSpan(
                          text: 'Wanna be our ally?',
                          style: pw.TextStyle(
                            fontSize: 10.0,
                            font: fonts['helveticaNeueBold'],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ]),
    );
  }
}
