import 'package:pdf/widgets.dart' as pw;

class Minimal extends pw.StatelessWidget {
  final String url;
  final String labelIdentifier;

  Minimal({
    required this.url,
    required this.labelIdentifier,
  });

  @override
  pw.Widget build(pw.Context context) {
    return pw.Container(
      width: 150,
      height: 150,
      child: pw.Column(
        children: [
          pw.SizedBox(height: 3.25),
          pw.BarcodeWidget(
            data: url,
            barcode: pw.Barcode.qrCode(),
            width: 72,
            height: 72,
          ),
          pw.SizedBox(height: 1.5),
          pw.Text(
            labelIdentifier,
            style: const pw.TextStyle(fontSize: 5.0, height: 5.0),
            textAlign: pw.TextAlign.center,
          ),
        ],
      ),
    );
  }
}
