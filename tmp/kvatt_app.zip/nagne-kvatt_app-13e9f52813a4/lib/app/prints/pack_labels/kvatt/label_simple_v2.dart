import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class LabelSimpleV2 extends pw.StatelessWidget {
  final String url;
  final String labelIdentifier;
  final Map<String, Font> fonts;

  LabelSimpleV2({
    required this.url,
    required this.labelIdentifier,
    // required this.productType,
    // required this.manufacturer,
    // required this.code,
    required this.fonts,
  });

  @override
  pw.Widget build(pw.Context context) {
    return pw.Container(
      width: 300.0,
      height: 150.0,
      child: pw.Row(
        children: [
          pw.Expanded(
            flex: 4,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              crossAxisAlignment: pw.CrossAxisAlignment.center,
              children: [
                pw.BarcodeWidget(
                  data: url,
                  barcode: pw.Barcode.qrCode(),
                  width: 85,
                  height: 85,
                ),
                pw.SizedBox(height: 4.0),
                pw.Text(
                  labelIdentifier,
                  style: pw.TextStyle(
                    fontSize: 9.5,
                    font: fonts['helveticaNeueLight'],
                  ),
                  textAlign: pw.TextAlign.center,
                ),
              ],
            ),
          ),
          pw.Expanded(
            flex: 6,
            child: pw.Padding(
              padding: const pw.EdgeInsets.fromLTRB(0.0, 20.0, 8.0, 30.0),
              child: pw.Column(
                crossAxisAlignment: pw.CrossAxisAlignment.start,
                children: [
                  pw.RichText(
                    textAlign: pw.TextAlign.left,
                    text: pw.TextSpan(
                      children: [
                        pw.TextSpan(
                          text: 'RETURN THIS PACK ',
                          style: pw.TextStyle(
                            fontSize: 19.0,
                            fontWeight: pw.FontWeight.normal,
                            font: fonts['helveticaNeueLight'],
                          ),
                        ),
                        pw.TextSpan(
                          text: 'FOR FREE',
                          style: pw.TextStyle(
                            fontSize: 19.0,
                            font: fonts['helveticaNeueBold'],
                          ),
                        ),
                      ],
                    ),
                  ),
                  pw.SizedBox(height: 16.0),
                  pw.Text(
                    'Scan and make sure your delivery experience is waste-less!',
                    style: pw.TextStyle(
                      fontSize: 11.0,
                      font: fonts['dinAlternateBold'],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
