import 'package:flutter/foundation.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/prints/widgets/horizontal_bleed_line.dart';
import 'package:kvatt_app/app/prints/widgets/vertical_bleed_line.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class LabelSimpleV3Large extends pw.StatelessWidget {
  final String url;
  final String labelIdentifier;
  final Map<String, Font> fonts;
  final Map<String, Uint8List> images;

  LabelSimpleV3Large({
    required this.url,
    required this.labelIdentifier,
    required this.fonts,
    required this.images,
  });

  pw.Widget _buildContent() {
    return pw.Container(
      color: PdfColor.fromHex('D3D3D3'),
      child: pw.Column(
        children: [
          pw.Padding(
            padding: const EdgeInsets.fromLTRB(
              4.5 * PdfPageFormat.mm,
              4.5 * PdfPageFormat.mm,
              0.0,
              0.0,
            ),
            child: pw.Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                pw.Text(
                  'Powered by',
                  style: pw.TextStyle(
                    fontSize: 8.0,
                    font: fonts['mavenProSemiBold'],
                  ),
                ),
                pw.SizedBox(width: 1 * PdfPageFormat.mm),
                images[AssetsFactory.kvattLogoBlack] != null
                    ? pw.Image(
                        pw.MemoryImage(
                          images[AssetsFactory.kvattLogoBlack]!,
                        ),
                        width: 7 * PdfPageFormat.mm,
                      )
                    : pw.SizedBox(),
              ],
            ),
          ),
          pw.SizedBox(height: 8 * PdfPageFormat.mm),
          pw.Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              pw.SizedBox(width: 11 * PdfPageFormat.mm),
              pw.Column(
                children: [
                  pw.BarcodeWidget(
                    data: url,
                    barcode: pw.Barcode.qrCode(),
                    width: 35 * PdfPageFormat.mm,
                    height: 35 * PdfPageFormat.mm,
                  ),
                  pw.SizedBox(height: 3 * PdfPageFormat.mm),
                  pw.Text(
                    labelIdentifier,
                    textAlign: pw.TextAlign.center,
                    style: pw.TextStyle(
                      font: fonts['mavenProRegular'],
                      fontSize: 11.0,
                      letterSpacing: 0.05,
                    ),
                  ),
                ],
              ),
              pw.SizedBox(width: 4 * PdfPageFormat.mm),
              pw.Column(
                mainAxisAlignment: MainAxisAlignment.start,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  pw.Padding(
                    padding: const EdgeInsets.only(left: 14 * PdfPageFormat.mm),
                    child: Text(
                      'BRING IT BACK, GET REWARDED!\nRETURN YOUR PACK FOR A\nSUSTAINABLE FUTURE.',
                      style: pw.TextStyle(
                        fontSize: 19.0,
                        font: fonts['permanentMarker'],
                      ),
                    ),
                  ),
                  pw.SizedBox(height: 1 * PdfPageFormat.mm),
                  pw.Row(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      images[AssetsFactory.labelLeftPointer] != null
                          ? pw.Image(
                              pw.MemoryImage(
                                images[AssetsFactory.labelLeftPointer]!,
                              ),
                              width: 20 * PdfPageFormat.mm,
                            )
                          : pw.SizedBox(),
                      pw.SizedBox(width: 4 * PdfPageFormat.mm),
                      Padding(
                        padding:
                            const EdgeInsets.only(top: 2 * PdfPageFormat.mm),
                        child: Text(
                          'SCAN HERE',
                          style: pw.TextStyle(
                            fontSize: 16,
                            font: fonts['permanentMarker'],
                          ),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  pw.Widget build(pw.Context context) {
    return pw.Stack(children: [
      pw.Positioned(
        top: 11 * PdfPageFormat.mm,
        child: HorizontalBleedLine(
          width: 207 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        bottom: 11 * PdfPageFormat.mm,
        child: HorizontalBleedLine(
          width: 207 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        left: 11 * PdfPageFormat.mm,
        child: VerticalBleedLine(
          height: 87 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        right: 11 * PdfPageFormat.mm,
        child: VerticalBleedLine(
          height: 87 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        left: 9.5 * PdfPageFormat.mm,
        top: 9 * PdfPageFormat.mm,
        child: pw.Container(
          width: 188 * PdfPageFormat.mm,
          height: 69 * PdfPageFormat.mm,
          child: _buildContent(),
        ),
      ),
    ]);
  }
}
