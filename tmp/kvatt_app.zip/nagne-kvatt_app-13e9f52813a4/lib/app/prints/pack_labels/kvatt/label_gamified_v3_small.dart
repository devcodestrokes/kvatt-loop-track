import 'package:flutter/foundation.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/prints/widgets/horizontal_bleed_line.dart';
import 'package:kvatt_app/app/prints/widgets/vertical_bleed_line.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class LabelGamifiedV3Small extends pw.StatelessWidget {
  final String url;
  final String labelIdentifier;
  final Map<String, Font> fonts;
  final Map<String, Uint8List> images;

  LabelGamifiedV3Small({
    required this.url,
    required this.labelIdentifier,
    required this.fonts,
    required this.images,
  });

  pw.Widget _buildContent() {
    return pw.Container(
      color: PdfColor.fromHex('D3D3D3'),
      child: pw.Column(
        children: [
          pw.Padding(
            padding: const EdgeInsets.fromLTRB(
              4.0 * PdfPageFormat.mm,
              4.0 * PdfPageFormat.mm,
              0.0,
              0.0,
            ),
            child: pw.Row(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                pw.Text(
                  'Powered by',
                  style: pw.TextStyle(
                    fontSize: 6.0,
                    font: fonts['mavenProSemiBold'],
                  ),
                ),
                pw.SizedBox(width: 0.75 * PdfPageFormat.mm),
                images[AssetsFactory.kvattLogoBlack] != null
                    ? pw.Image(
                        pw.MemoryImage(
                          images[AssetsFactory.kvattLogoBlack]!,
                        ),
                        width: 5 * PdfPageFormat.mm,
                      )
                    : pw.SizedBox(),
              ],
            ),
          ),
          pw.SizedBox(height: 5 * PdfPageFormat.mm),
          pw.Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              pw.SizedBox(width: 9 * PdfPageFormat.mm),
              pw.Column(children: [
                pw.BarcodeWidget(
                  data: url,
                  barcode: pw.Barcode.qrCode(),
                  width: 28 * PdfPageFormat.mm,
                  height: 28 * PdfPageFormat.mm,
                ),
                pw.SizedBox(height: 3 * PdfPageFormat.mm),
                pw.Text(
                  labelIdentifier,
                  style: pw.TextStyle(
                    font: fonts['mavenProRegular'],
                    fontSize: 9.0,
                    letterSpacing: 0.05,
                  ),
                  textAlign: pw.TextAlign.center,
                ),
              ]),
              pw.SizedBox(width: 5 * PdfPageFormat.mm),
              pw.Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.start,
                children: [
                  pw.SizedBox(height: 1 * PdfPageFormat.mm),
                  pw.Text(
                    'FREE PIZZA? <3',
                    style: pw.TextStyle(
                      fontSize: 18.0,
                      font: fonts['permanentMarker'],
                    ),
                  ),
                  pw.Text(
                    'UNLOCK THE POWER OF THE UNKNOWN.',
                    style: pw.TextStyle(
                      fontSize: 12.0,
                      font: fonts['permanentMarker'],
                    ),
                  ),
                  pw.SizedBox(height: 5 * PdfPageFormat.mm),
                  pw.Text(
                    '- SCAN THE QR CODE NOW!',
                    style: pw.TextStyle(
                      fontSize: 12.0,
                      font: fonts['permanentMarker'],
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }

  @override
  pw.Widget build(pw.Context context) {
    return pw.Stack(children: [
      pw.Positioned(
        top: 11 * PdfPageFormat.mm,
        child: HorizontalBleedLine(
          width: 152 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        bottom: 11 * PdfPageFormat.mm,
        child: HorizontalBleedLine(
          width: 152 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        left: 11 * PdfPageFormat.mm,
        child: VerticalBleedLine(
          height: 72 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        right: 11 * PdfPageFormat.mm,
        child: VerticalBleedLine(
          height: 72 * PdfPageFormat.mm,
        ),
      ),
      pw.Positioned(
        left: 9.5 * PdfPageFormat.mm,
        top: 9 * PdfPageFormat.mm,
        child: pw.Container(
          width: 133 * PdfPageFormat.mm,
          height: 53 * PdfPageFormat.mm,
          child: _buildContent(),
        ),
      ),
    ]);
  }
}
