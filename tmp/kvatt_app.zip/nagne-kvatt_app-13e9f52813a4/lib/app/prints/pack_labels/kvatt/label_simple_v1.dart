import 'package:pdf/widgets.dart' as pw;

class LabelSimpleV1 extends pw.StatelessWidget {
  final String url;
  final String labelIdentifier;

  LabelSimpleV1({
    required this.url,
    required this.labelIdentifier,
  });

  @override
  pw.Widget build(pw.Context context) {
    return pw.Container(
      width: 300.0,
      height: 150.0,
      child: pw.Row(
        children: [
          pw.Expanded(
            flex: 4,
            child: pw.Column(
              mainAxisAlignment: pw.MainAxisAlignment.center,
              crossAxisAlignment: pw.CrossAxisAlignment.center,
              children: [
                pw.BarcodeWidget(
                  data: url,
                  barcode: pw.Barcode.qrCode(),
                  width: 85,
                  height: 85,
                ),
                pw.SizedBox(height: 4.0),
                pw.Text(
                  labelIdentifier,
                  style: const pw.TextStyle(fontSize: 9.5),
                  textAlign: pw.TextAlign.center,
                ),
              ],
            ),
          ),
          pw.Expanded(
            flex: 6,
            child: pw.Padding(
              padding: const pw.EdgeInsets.fromLTRB(0.0, 24.0, 12.0, 30.0),
              child: pw.Column(
                mainAxisAlignment: pw.MainAxisAlignment.spaceBetween,
                crossAxisAlignment: pw.CrossAxisAlignment.center,
                children: [
                  pw.Text(
                    'IF FOUND, PLEASE RETURN TO KVATT LTD.',
                    style: const pw.TextStyle(
                      fontSize: 10.0,
                    ),
                    textAlign: pw.TextAlign.center,
                  ),
                  pw.Text(
                    'Scan QR Code',
                    style: pw.TextStyle(
                      fontSize: 11.0,
                      fontWeight: pw.FontWeight.bold,
                    ),
                    textAlign: pw.TextAlign.center,
                  ),
                  pw.RichText(
                    textAlign: pw.TextAlign.center,
                    text: pw.TextSpan(
                      children: [
                        pw.TextSpan(
                          text: 'We need YOU! ',
                          style: pw.TextStyle(
                            fontSize: 8.0,
                            fontWeight: pw.FontWeight.bold,
                          ),
                        ),
                        pw.TextSpan(
                          text: 'By returning this pack, you can ',
                          style: pw.TextStyle(
                            fontSize: 6.0,
                            fontStyle: pw.FontStyle.italic,
                          ),
                        ),
                        pw.TextSpan(
                          text: 'reduce its impact by 30%',
                          style: pw.TextStyle(
                            fontSize: 6.0,
                            fontWeight: pw.FontWeight.bold,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
