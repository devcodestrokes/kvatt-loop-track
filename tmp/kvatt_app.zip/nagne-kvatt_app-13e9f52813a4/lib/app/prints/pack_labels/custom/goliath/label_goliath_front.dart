import 'package:flutter/foundation.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/prints/widgets/horizontal_bleed_line.dart';
import 'package:kvatt_app/app/prints/widgets/vertical_bleed_line.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';
import 'dart:math' as math;

class LabelGoliathFront extends pw.StatelessWidget {
  final String qrCodeUrl;
  final String kvattCode;
  final String lang;

  final Map<String, Font> fonts;
  final Map<String, Uint8List> images;

  LabelGoliathFront({
    required this.qrCodeUrl,
    required this.kvattCode,
    required this.lang,
    required this.fonts,
    required this.images,
  }) : assert(lang == 'FR' || lang == 'EN');

  pw.Widget _getFRMainTextSection() {
    return pw.Stack(
      children: [
        pw.Container(
          width: 120 * PdfPageFormat.mm,
          margin: const EdgeInsets.only(top: -3.5 * PdfPageFormat.mm),
          child: pw.Text(
            'Mettez cette envelope vide',
            textAlign: pw.TextAlign.left,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 25.0 * PdfPageFormat.point,
              color: PdfColor.fromHex('000000'),
            ),
          ),
        ),
        pw.Positioned(
          top: 5.0 * PdfPageFormat.mm,
          child: pw.Container(
            child: pw.Text(
              'dans une boite aux lettres',
              textAlign: pw.TextAlign.left,
              style: pw.TextStyle(
                font: fonts['permanentMarker'],
                fontSize: 25.0 * PdfPageFormat.point,
                color: PdfColor.fromHex('000000'),
              ),
            ),
          ),
        ),
        pw.Positioned(
          top: 13.5 * PdfPageFormat.mm,
          child: pw.Container(
            child: pw.Text(
              'publique.',
              textAlign: pw.TextAlign.left,
              style: pw.TextStyle(
                font: fonts['permanentMarker'],
                fontSize: 25.0 * PdfPageFormat.point,
                color: PdfColor.fromHex('000000'),
              ),
            ),
          ),
        ),
        pw.Positioned(
          bottom: 6.0 * PdfPageFormat.mm,
          child: pw.Text(
            'il y a une etiquette de retour a l\'interieur,',
            textAlign: pw.TextAlign.left,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 15.0 * PdfPageFormat.point,
              color: PdfColor.fromHex('000000'),
            ),
          ),
        ),
        pw.Positioned(
          bottom: 0.5 * PdfPageFormat.mm,
          child: pw.Text(
            'pas besoin d\'ajouter un timbre.',
            textAlign: pw.TextAlign.left,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 15.0 * PdfPageFormat.point,
              color: PdfColor.fromHex('000000'),
            ),
          ),
        ),
      ],
    );
  }

  pw.Widget _getENMainTextSection() {
    return pw.Stack(
      children: [
        pw.Container(
          margin: const EdgeInsets.only(top: -3.5 * PdfPageFormat.mm),
          child: pw.Text(
            'Pop this empty envelope',
            textAlign: pw.TextAlign.left,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 28.0 * PdfPageFormat.point,
              color: PdfColor.fromHex('000000'),
            ),
          ),
        ),
        pw.Positioned(
          top: 7.0 * PdfPageFormat.mm,
          child: pw.Container(
            child: pw.Text(
              'in the post box.',
              textAlign: pw.TextAlign.left,
              style: pw.TextStyle(
                font: fonts['permanentMarker'],
                fontSize: 28.0 * PdfPageFormat.point,
                color: PdfColor.fromHex('000000'),
              ),
            ),
          ),
        ),
        pw.Positioned(
          bottom: 6.0 * PdfPageFormat.mm,
          child: pw.Text(
            'there is a return label inside,',
            textAlign: pw.TextAlign.left,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 17.0 * PdfPageFormat.point,
              color: PdfColor.fromHex('000000'),
            ),
          ),
        ),
        pw.Positioned(
          bottom: 0.0 * PdfPageFormat.mm,
          child: pw.Text(
            'no need to add a stamp.',
            textAlign: pw.TextAlign.left,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 17.0 * PdfPageFormat.point,
              color: PdfColor.fromHex('000000'),
            ),
          ),
        ),
      ],
    );
  }

  pw.Widget _getScanText() {
    if (lang == 'FR') {
      return pw.Column(
        children: [
          pw.Text(
            'scannez moi pour',
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 12.0,
              color: PdfColor.fromHex('000000'),
            ),
          ),
          pw.Container(
            margin: const EdgeInsets.only(top: -1.0 * PdfPageFormat.mm),
            child: pw.Text(
              'en savoir plus!',
              textAlign: pw.TextAlign.center,
              style: pw.TextStyle(
                font: fonts['permanentMarker'],
                fontSize: 12.0,
                color: PdfColor.fromHex('000000'),
              ),
            ),
          ),
        ],
      );
    } else {
      return pw.Column(
        children: [
          pw.Text(
            'scan to learn',
            textAlign: pw.TextAlign.center,
            style: pw.TextStyle(
              font: fonts['permanentMarker'],
              fontSize: 12.0 * PdfPageFormat.point,
              color: PdfColor.fromHex('000000'),
            ),
          ),
          pw.Container(
            margin: const EdgeInsets.only(top: -1.0 * PdfPageFormat.mm),
            child: pw.Text(
              'more!',
              textAlign: pw.TextAlign.center,
              style: pw.TextStyle(
                font: fonts['permanentMarker'],
                fontSize: 12.0 * PdfPageFormat.point,
                color: PdfColor.fromHex('000000'),
              ),
            ),
          ),
        ],
      );
    }
  }

  pw.Widget _buildContent() {
    return pw.Container(
      height: 130.0 * PdfPageFormat.mm,
      width: 200.0 * PdfPageFormat.mm,
      color: PdfColor.fromHex('BFBFBF'),
      child: pw.Stack(
        children: [
          pw.Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              pw.SizedBox(
                height: 22.0 * PdfPageFormat.mm,
              ),
              pw.Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  images[AssetsFactory.kvattLogoBlack] != null
                      ? pw.Image(
                          pw.MemoryImage(
                            images[AssetsFactory.amazonSmileLogo]!,
                          ),
                          width: 113.0 * PdfPageFormat.mm,
                          // height: 23.0 * PdfPageFormat.mm,
                        )
                      : pw.SizedBox(),
                ],
              ),
              pw.SizedBox(height: 23.0 * PdfPageFormat.mm),
              pw.Container(
                child: pw.Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    pw.SizedBox(width: 13 * PdfPageFormat.mm),
                    pw.BarcodeWidget(
                      data: qrCodeUrl,
                      barcode: pw.Barcode.qrCode(),
                      width: 41 * PdfPageFormat.mm,
                      height: 41 * PdfPageFormat.mm,
                      color: PdfColor.fromHex('000000'),
                    ),
                    pw.SizedBox(width: 13.0 * PdfPageFormat.mm),
                    pw.Container(
                      height: 41.0 * PdfPageFormat.mm,
                      child: lang == 'FR'
                          ? _getFRMainTextSection()
                          : _getENMainTextSection(),
                    ),
                  ],
                ),
              ),
              pw.SizedBox(height: 2.0 * PdfPageFormat.mm),
              pw.Container(
                width: 41 * PdfPageFormat.mm,
                margin: const pw.EdgeInsets.only(left: 13 * PdfPageFormat.mm),
                child: _getScanText(),
              ),
            ],
          ),
          pw.Positioned(
            bottom: 13.5 * PdfPageFormat.mm,
            right: -6.0 * PdfPageFormat.mm,
            child: pw.Transform.rotate(
              angle: math.pi / 2.0,
              child: pw.Text(
                kvattCode,
                style: pw.TextStyle(
                  font: fonts['helveticaNeueLight'],
                  fontSize: 8.0 * PdfPageFormat.point,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  pw.Widget build(pw.Context context) {
    return pw.Transform.rotate(
      angle: math.pi / 2.0,
      child: pw.Container(
        margin: const EdgeInsets.only(
          left: -70.0 * PdfPageFormat.mm,
        ),
        child: pw.Stack(
          children: [
            pw.Container(
              margin: const EdgeInsets.only(top: 5.0 * PdfPageFormat.mm),
              child: HorizontalBleedLine(width: 210.0 * PdfPageFormat.mm),
            ),
            pw.Container(
              margin: const EdgeInsets.only(top: 135.0 * PdfPageFormat.mm),
              child: HorizontalBleedLine(width: 210.0 * PdfPageFormat.mm),
            ),
            pw.Container(
              margin: const EdgeInsets.only(left: 5.0 * PdfPageFormat.mm),
              child: VerticalBleedLine(height: 140.0 * PdfPageFormat.mm),
            ),
            pw.Container(
              margin: const EdgeInsets.only(left: 205.0 * PdfPageFormat.mm),
              child: VerticalBleedLine(height: 140.0 * PdfPageFormat.mm),
            ),
            pw.Container(
              margin: const EdgeInsets.fromLTRB(
                3.0 * PdfPageFormat.mm,
                3.0 * PdfPageFormat.mm,
                0.0,
                0.0,
              ),
              color: PdfColor.fromHex('BFBFBF'),
              padding: const EdgeInsets.all(2.0 * PdfPageFormat.mm),
              height: 134.0 * PdfPageFormat.mm,
              width: 204.0 * PdfPageFormat.mm,
              child: _buildContent(),
            ),
          ],
        ),
      ),
    );
  }
}
