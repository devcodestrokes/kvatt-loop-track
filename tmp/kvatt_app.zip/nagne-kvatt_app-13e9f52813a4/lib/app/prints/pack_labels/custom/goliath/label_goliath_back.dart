import 'package:flutter/foundation.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/prints/widgets/horizontal_bleed_line.dart';
import 'package:kvatt_app/app/prints/widgets/vertical_bleed_line.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';
import 'dart:math' as math;

class LabelGoliathBack extends pw.StatelessWidget {
  final String customCode;
  final Map<String, Font> fonts;
  final Map<String, Uint8List> images;

  LabelGoliathBack({
    required this.customCode,
    required this.fonts,
    required this.images,
  });

  pw.Widget _buildContent() {
    return pw.Container(
      child: pw.Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          pw.Container(
            margin: const EdgeInsets.only(left: -10.0 * PdfPageFormat.mm),
            child: pw.Transform.rotate(
              angle: math.pi / 2.0,
              child: pw.Container(
                width: 32.0 * PdfPageFormat.mm,
                height: 12.5 * PdfPageFormat.mm,
                child: pw.Row(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    pw.Text(
                      'Powered by',
                      style: pw.TextStyle(
                        fontSize: 9.0,
                        font: fonts['helveticaNeueMedium'],
                      ),
                    ),
                    pw.SizedBox(width: 1.5 * PdfPageFormat.mm),
                    images[AssetsFactory.kvattLogoBlack] != null
                        ? pw.Image(
                            pw.MemoryImage(
                              images[AssetsFactory.kvattLogoBlack]!,
                            ),
                            width: 10.5 * PdfPageFormat.mm,
                          )
                        : pw.SizedBox(),
                  ],
                ),
              ),
            ),
          ),
          pw.Container(
            margin: const EdgeInsets.only(left: -16.5 * PdfPageFormat.mm),
            child: pw.Transform.rotate(
              angle: math.pi / 2.0,
              child: images[AssetsFactory.emballageReemployable] != null
                  ? pw.Container(
                      height: 9.0 * PdfPageFormat.mm,
                      child: pw.Image(
                        pw.MemoryImage(
                          images[AssetsFactory.emballageReemployable]!,
                        ),
                        height: 9.0 * PdfPageFormat.mm,
                      ))
                  : pw.SizedBox(),
            ),
          ),
          pw.Container(
            width: 76.2 * PdfPageFormat.mm,
            height: 42.0 * PdfPageFormat.mm,
            padding: const EdgeInsets.fromLTRB(
              4.6 * PdfPageFormat.mm,
              2.6 * PdfPageFormat.mm,
              4.6 * PdfPageFormat.mm,
              1.0 * PdfPageFormat.mm,
            ),
            decoration: BoxDecoration(
              color: PdfColor.fromHex('FFFFFF'),
              borderRadius: const BorderRadius.all(Radius.circular(12.0)),
            ),
            child: pw.Column(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                pw.BarcodeWidget(
                  data: customCode,
                  barcode: pw.Barcode.code128(useCode128B: true),
                  width: 67.0 * PdfPageFormat.mm,
                  height: 31.0 * PdfPageFormat.mm,
                  drawText: false,
                ),
                pw.Text(
                  customCode,
                  style: pw.TextStyle(
                    font: fonts['switzerlandBlack'],
                    fontSize: 18.0,
                  ),
                ),
              ],
            ),
          ),
          pw.Container(
            margin: const EdgeInsets.only(left: 2.5 * PdfPageFormat.mm),
            child: pw.Transform.rotate(
              angle: math.pi / 2.0,
              child: pw.Container(
                height: 13.0 * PdfPageFormat.mm,
                child: pw.Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    images[AssetsFactory.recyclingLogo] != null
                        ? pw.Image(
                            pw.MemoryImage(
                              images[AssetsFactory.recyclingLogo]!,
                            ),
                            height: 10.0 * PdfPageFormat.mm,
                          )
                        : pw.SizedBox(),
                    pw.SizedBox(width: 2.5 * PdfPageFormat.mm),
                    images[AssetsFactory.pvcLogo] != null
                        ? pw.Image(
                            pw.MemoryImage(
                              images[AssetsFactory.pvcLogo]!,
                            ),
                            height: 13.0 * PdfPageFormat.mm,
                          )
                        : pw.SizedBox(),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  @override
  pw.Widget build(pw.Context context) {
    return pw.Stack(
      children: [
        pw.Positioned(
          top: 5.0 * PdfPageFormat.mm,
          child: HorizontalBleedLine(
            width: 140.0 * PdfPageFormat.mm,
          ),
        ),
        pw.Positioned(
          bottom: 5.0 * PdfPageFormat.mm,
          child: HorizontalBleedLine(
            width: 140.0 * PdfPageFormat.mm,
          ),
        ),
        pw.Positioned(
          left: 5.0 * PdfPageFormat.mm,
          child: VerticalBleedLine(
            height: 55.0 * PdfPageFormat.mm,
          ),
        ),
        pw.Positioned(
          right: 5.0 * PdfPageFormat.mm,
          child: VerticalBleedLine(
            height: 55.0 * PdfPageFormat.mm,
          ),
        ),
        pw.Positioned(
          left: 3.0 * PdfPageFormat.mm,
          top: 3.0 * PdfPageFormat.mm,
          child: pw.Container(
            color: PdfColor.fromHex('BFBFBF'),
            padding: const EdgeInsets.all(2.0 * PdfPageFormat.mm),
            width: 134.0 * PdfPageFormat.mm,
            height: 49.0 * PdfPageFormat.mm,
            child: _buildContent(),
          ),
        ),
      ],
    );
  }
}
