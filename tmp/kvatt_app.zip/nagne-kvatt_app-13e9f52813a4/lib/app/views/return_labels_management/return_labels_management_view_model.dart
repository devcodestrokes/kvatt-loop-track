import 'package:flutter/foundation.dart';
import 'package:kvatt_app/app/services/label_generators/return_labels/return_label_generation_service.dart';
import 'package:kvatt_core/domain/return_labels/la_poste/la_poste_smart_data.dart';
import 'package:kvatt_core/domain/return_labels/return_labels_manager.dart';

class ReturnLabelsManagementViewModel extends ChangeNotifier {
  ReturnLabelsManager returnLabelsManager;
  ReturnLabelGenerationService returnLabelGenerationService;

  ReturnLabelsManagementViewModel({
    required this.returnLabelsManager,
    required this.returnLabelGenerationService,
  });

  String? errorMessage;

  Future<void> onGenerateLabelsPressed({
    required String labelType,
    required int numLabels,
  }) async {
    errorMessage = null;
    notifyListeners();
    try {
      List<LaPosteSmartData> smartDataResults =
          await returnLabelsManager.getLaPosteSmartData(
        quantity: numLabels,
      );

      await returnLabelGenerationService.buildAndDownloadGoliathReturnLabels(
        smartDataDefinitions: smartDataResults,
      );
    } catch (e) {
      errorMessage =
          'There was an issue generating and downloading the labels. Please try again later.';
      notifyListeners();
    }
  }
}
