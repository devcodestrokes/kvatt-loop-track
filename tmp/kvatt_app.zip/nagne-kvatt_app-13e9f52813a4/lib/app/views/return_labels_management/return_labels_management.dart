import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/return_labels_management/return_labels_management_view_model.dart';

class ReturnLabelsManagement extends StatefulWidget {
  final ReturnLabelsManagementViewModel viewModel;

  const ReturnLabelsManagement({
    super.key,
    required this.viewModel,
  });

  @override
  State<ReturnLabelsManagement> createState() => _ReturnLabelsManagementState();
}

class _ReturnLabelsManagementState extends State<ReturnLabelsManagement> {
  TextEditingController numLabelsController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  String? _selectedLabelType;

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.3,
            child: Column(
              children: [
                const SizedBox(height: 48.0),
                Text(
                  'Generate return labels',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        color:
                            Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                      ),
                ),
                const SizedBox(height: 24.0),
                DropDownFieldBlack(
                  validator: (String? value) => Validators.validateNotEmpty(
                      value, 'Please select the label type'),
                  label: 'Label type',
                  items: const ['La Poste'],
                  onItemSelected: (String item) {
                    _selectedLabelType = item;
                  },
                ),
                const SizedBox(height: 24.0),
                TextFieldBlack(
                  validator: (String? numPackagings) {
                    return Validators.validateNotEmpty(
                      numPackagings,
                      'Please enter the number of labels you want to create',
                    );
                  },
                  label: 'Number of labels',
                  keyboardType: TextInputType.number,
                  controller: numLabelsController,
                ),
                const SizedBox(height: 48.0),
                PrimaryButton(
                  label: 'Generate and download labels',
                  onPressed: () async {
                    bool isFormValid = _formKey.currentState!.validate();
                    if (isFormValid) {
                      LoadingDialog.show(
                        context,
                        'generating labels ...',
                        loadingDialogMode: LoadingDialogMode.onSurface,
                      );
                      await widget.viewModel.onGenerateLabelsPressed(
                        labelType: _selectedLabelType!,
                        numLabels: int.parse(numLabelsController.text),
                      );
                      if (!mounted) return;
                      Navigator.of(context).pop();
                    }
                  },
                ),
                widget.viewModel.errorMessage != null
                    ? Column(
                        children: [
                          const SizedBox(height: 24.0),
                          Container(
                            color:
                                Theme.of(context).colorScheme.trafficLightAmber,
                            padding:
                                const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                            child: Text(
                              widget.viewModel.errorMessage!,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onTrafficLightAmber,
                                  ),
                              textAlign: TextAlign.center,
                            ),
                          ),
                          const SizedBox(height: 24.0),
                        ],
                      )
                    : const SizedBox(),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
