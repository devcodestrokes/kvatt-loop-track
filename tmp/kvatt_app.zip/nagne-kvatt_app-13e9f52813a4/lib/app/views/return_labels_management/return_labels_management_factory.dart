import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/services/label_generators/return_labels/return_label_generation_service.dart';
import 'package:kvatt_app/app/views/return_labels_management/return_labels_management.dart';
import 'package:kvatt_app/app/views/return_labels_management/return_labels_management_view_model.dart';
import 'package:kvatt_core/domain/return_labels/return_labels_manager.dart';

import 'package:provider/provider.dart';

class ReturnLabelsManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<ReturnLabelsManagementViewModel>(
      create: (context) {
        return ReturnLabelsManagementViewModel(
          returnLabelsManager: Provider.of<ReturnLabelsManager>(
            context,
            listen: false,
          ),
          returnLabelGenerationService:
              Provider.of<ReturnLabelGenerationService>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<ReturnLabelsManagementViewModel>(
        builder: (context, model, child) => ReturnLabelsManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
