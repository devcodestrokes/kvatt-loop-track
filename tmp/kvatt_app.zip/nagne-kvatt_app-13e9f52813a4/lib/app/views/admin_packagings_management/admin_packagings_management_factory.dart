import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/admin_packagings_management.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/admin_packagings_management_view_model.dart';
import 'package:kvatt_app/domain/reporting/reporting_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:provider/provider.dart';

class AdminPackagingsManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<AdminPackagingsManagementViewModel>(
      create: (context) {
        return AdminPackagingsManagementViewModel(
          packagingsManager: Provider.of<PackagingsManager>(
            context,
            listen: false,
          ),
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          reportingManager: Provider.of<ReportingManager>(
            context,
            listen: false,
          ),
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<AdminPackagingsManagementViewModel>(
        builder: (context, model, child) => AdminPackagingsManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
