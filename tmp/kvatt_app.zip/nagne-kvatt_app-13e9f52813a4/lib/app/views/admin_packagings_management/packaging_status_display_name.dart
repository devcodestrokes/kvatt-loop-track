import 'package:kvatt_core/domain/packagings/packaging_status.dart';

extension PackagingStatusDisplayName on PackagingStatus {
  String get displayName {
    switch (this) {
      case PackagingStatus.inStoreNew:
        return 'In Store (New)';
      case PackagingStatus.inStoreReturned:
        return 'Returned';
      case PackagingStatus.enRouteToMerchant:
        return 'En Route to Merchant';
      case PackagingStatus.withMerchant:
        return 'With Merchant';
      case PackagingStatus.withMerchantReturned:
        return 'With Merchant (Returned)';
      case PackagingStatus.withCustomer:
        return 'With Customer';
      case PackagingStatus.inMaintenance:
        return 'In Maintenance';
      case PackagingStatus.inStoreReady:
        return 'In Store (Ready)';
    }
  }
}
