import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_core/domain/tracking/tracking_event.dart';
import 'package:kvatt_core/domain/tracking/tracking_history.dart';
import 'package:timelines/timelines.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class TrackingHistoryTimeline extends StatelessWidget {
  final List<TrackingHistory> trackingHistory;

  const TrackingHistoryTimeline({
    super.key,
    required this.trackingHistory,
  });

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 220.0,
      child: TimelineTheme(
        data: TimelineThemeData(
          color: Theme.of(context).primaryColor,
          indicatorTheme: IndicatorThemeData(
            color: Theme.of(context).colorScheme.secondaryColor,
          ),
        ),
        child: Timeline.tileBuilder(
          scrollDirection: Axis.horizontal,
          builder: TimelineTileBuilder.fromStyle(
            indicatorStyle: IndicatorStyle.outlined,
            contentsAlign: ContentsAlign.alternating,
            contentsBuilder: (context, index) => Padding(
              padding: const EdgeInsets.all(24.0),
              child: Text(
                _buildLabel(trackingHistory[index]),
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                    ),
                textAlign: TextAlign.center,
              ),
            ),
            itemCount: trackingHistory.length,
          ),
        ),
      ),
    );
  }

  String _buildLabel(TrackingHistory history) {
    String event = '';

    switch (history.event) {
      case TrackingEvent.shippedToMerchant:
        event = 'Shipped to merchant';
        break;
      case TrackingEvent.receivedByMerchant:
        event = 'Received by merchant';
        break;
      case TrackingEvent.shippedToCustomer:
        event = 'Shipped to customer';
        break;
      case TrackingEvent.returnedFromCustomer:
        event = 'Returned to merchant from customer';
        break;
      case TrackingEvent.returnedToKvatt:
        event = 'Returned to Kvatt';
        break;
      case TrackingEvent.sentToMaintenance:
        event = 'Sent to maintenance';
        break;
      case TrackingEvent.outOfMaintenance:
        event = 'Out of maintenance';
        break;
      //Legacy events
      case TrackingEvent.returnedToKvattNeedsMaintenance:
        event = 'Returned to Kvatt\n(Maintenance needed)';
        break;
      case TrackingEvent.returnedToKvattNoMaintenance:
        event = 'Returned to Kvatt';
        break;
    }

    String date = DateFormat('dd/MM/yyyy').format(history.date);
    String time = DateFormat('HH:mm').format(history.date);

    return '$event\n$date at $time';
  }
}
