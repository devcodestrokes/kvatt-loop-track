import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/packaging_details/widgets/tracking_history_timeline.dart';
import 'package:kvatt_core/domain/tracking/tracking_history.dart';

class PackagingDetails extends StatelessWidget {
  final bool isLoading;
  final List<TrackingHistory>? trackingHistory;

  const PackagingDetails({
    super.key,
    required this.isLoading,
    required this.trackingHistory,
  });

  @override
  Widget build(BuildContext context) {
    return isLoading
        ? const Padding(
            padding: EdgeInsets.symmetric(vertical: 16.0),
            child: LoadingSpinner(),
          )
        : trackingHistory == null || trackingHistory!.isEmpty
            ? Padding(
                padding: const EdgeInsets.symmetric(vertical: 48.0),
                child: Text(
                  'Tracking history is not available yet for this packaging.',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
              )
            : TrackingHistoryTimeline(
                trackingHistory: trackingHistory!,
              );
  }
}
