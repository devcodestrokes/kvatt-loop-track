import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/domain/reporting/reporting_manager.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:kvatt_core/domain/tracking/tracking_history.dart';

class PackagingsViewData {
  Packaging packaging;
  List<TrackingHistory>? history;
  bool isFetchingHistory;
  bool isEditing;

  PackagingsViewData({
    required this.packaging,
    required this.history,
    required this.isFetchingHistory,
    required this.isEditing,
  });
}

class AdminPackagingsManagementViewModel extends ChangeNotifier {
  PackagingsManager packagingsManager;
  UserManager userManager;
  ReportingManager reportingManager;
  AuthState authState;

  List<PackagingsViewData>? packagingsData;
  List<Merchant>? activeMerchants;

  PackagingStatus? _selectedStatus;
  String? _selectedType;
  Merchant? _selectedMerchant;
  int? _filterSearchPackagingCode;

  int displayPerPage = 20;
  int startPackagingCode = 1;
  int? lastPackagingCode;
  int? firstPackagingCode;

  AdminPackagingsManagementViewModel({
    required this.packagingsManager,
    required this.userManager,
    required this.reportingManager,
    required this.authState,
  });

  Future<void> init() async {
    activeMerchants = await userManager.retrieveActiveMerchants();
    _reloadPackagingsData();
  }

  bool get showNextButton =>
      packagingsData?.last.packaging.code != lastPackagingCode &&
      !isFilteringBySearch;

  bool get showPreviousButton =>
      packagingsData?.first.packaging.code != firstPackagingCode &&
      !isFilteringBySearch;

  onDisplayPerPageChanged(int? displayPerPage) {
    this.displayPerPage = displayPerPage ?? 20;
    _reloadPackagingsData();
  }

  onPreviousPageTapped() {
    int firstDisplayedCode = packagingsData?.first.packaging.code ?? 1;
    startPackagingCode = firstDisplayedCode - displayPerPage;
    _reloadPackagingsData();
  }

  onNextPageTapped() {
    int lastDisplayedCode = packagingsData?.last.packaging.code ?? 1;
    startPackagingCode = lastDisplayedCode + 1;
    _reloadPackagingsData();
  }

  onStatusSelected(PackagingStatus? status) {
    _selectedStatus = status;
    _resetPagination();

    _reloadPackagingsData();
  }

  onPackagingTypeSelected(String? type) {
    _selectedType = type;
    _resetPagination();
    _reloadPackagingsData();
  }

  onMerchantSelected(String merchantName) {
    if (activeMerchants == null) return;
    if (merchantName == 'All') {
      _selectedMerchant = null;
    } else {
      _selectedMerchant = activeMerchants!
          .where((Merchant merchant) => merchant.name == merchantName)
          .first;
    }
    _resetPagination();

    _reloadPackagingsData();
  }

  bool get isFilteringBySearch {
    return _filterSearchPackagingCode != null;
  }

  void onTextSearchChanged({
    required String searchText,
  }) {
    _resetPagination();
    if (searchText.isEmpty) {
      _filterSearchPackagingCode = null;
      _reloadPackagingsData();
      return;
    }

    packagingsData = [];
    notifyListeners();

    _filterSearchPackagingCode = _determinePackagingCode(
      searchString: searchText,
    );

    _reloadPackagingsData();
  }

  Future<void> onSaveTapped({
    required Packaging packaging,
    required PackagingStatus? newStatus,
  }) async {
    //TODO: Should handle case where errors happen during update
    if (newStatus != null && packaging.status != newStatus) {
      switch (newStatus) {
        case PackagingStatus.inStoreReturned:
          await packagingsManager.recordReturnedToKvattPackagings(
            userId: authState.activeUser!.uid!,
            packagings: [packaging],
          );
          break;
        default:
          break;
      }
    }
    notifyListeners();
  }

  onRowExpansionToggled({
    required PackagingsViewData data,
    required bool isExpanded,
  }) async {
    if (packagingsData == null) return;

    PackagingsViewData rowData = data;
    notifyListeners();

    if (isExpanded == true && rowData.history == null) {
      _fetchHistoryData(rowData);
    }
  }

  onEditRowTapped(PackagingsViewData data) {
    data.isEditing = true;
    notifyListeners();
  }

  onSaveRowTapped(PackagingsViewData data) {
    data.isEditing = false;
    notifyListeners();
  }

  Future<void> onExportToCsvTapped() async {
    await reportingManager.downloadPackagingsCsvData(
      status: _selectedStatus,
      type: _selectedType,
      merchantId: _selectedMerchant?.uid,
    );
  }

  Future<void> _reloadPackagingsData() async {
    if (!isFilteringBySearch) {
      lastPackagingCode = await packagingsManager.getLastPackagingCode(
        status: _selectedStatus,
        type: _selectedType,
        merchantId: _selectedMerchant?.uid,
      );
    }

    List<Packaging> packagings = await packagingsManager.getPackagings(
      status: _selectedStatus,
      type: _selectedType,
      code: _filterSearchPackagingCode,
      merchantId: _selectedMerchant?.uid,
      numPackagings: isFilteringBySearch ? null : displayPerPage,
      startAtPackagingCode: isFilteringBySearch ? null : startPackagingCode,
    );

    packagingsData = packagings.map((Packaging packaging) {
      return PackagingsViewData(
        packaging: packaging,
        history: null,
        isFetchingHistory: false,
        isEditing: false,
      );
    }).toList();

    if (packagingsData != null &&
        packagingsData!.isNotEmpty &&
        !isFilteringBySearch) {
      firstPackagingCode ??= packagingsData?.first.packaging.code;
    }

    notifyListeners();
  }

  _resetPagination() {
    displayPerPage = 20;
    startPackagingCode = 1;
    lastPackagingCode = null;
    firstPackagingCode = null;
  }

  Future<void> _fetchHistoryData(PackagingsViewData rowData) async {
    rowData.isFetchingHistory = true;
    notifyListeners();
    try {
      rowData.history = await packagingsManager.getPackagingTrackingHistory(
        packagingId: rowData.packaging.identifier,
      );
    } catch (e) {
      //Fail silently
    }
    rowData.isFetchingHistory = false;
    notifyListeners();
  }

  int _determinePackagingCode({
    required String searchString,
  }) {
    if (searchString.length != 5) {
      return 0;
    }
    int? value = int.tryParse(searchString);

    if (value == null) {
      return 0;
    }

    return value;
  }
}
