import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/admin_packagings_management_view_model.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/packaging_status_display_name.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/widgets/packagings_table/admin_packagings_table.dart';
import 'package:kvatt_app/domain/products/available_products.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';

class AdminPackagingsManagement extends StatefulWidget {
  final AdminPackagingsManagementViewModel viewModel;

  const AdminPackagingsManagement({
    super.key,
    required this.viewModel,
  });

  @override
  State<AdminPackagingsManagement> createState() =>
      _AdminPackagingsManagementState();
}

class _AdminPackagingsManagementState extends State<AdminPackagingsManagement> {
  TextEditingController serialNoController = TextEditingController();
  TextEditingController searchTextController = TextEditingController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      widget.viewModel.init();
    });

    searchTextController.addListener(() {
      EasyDebounce.debounce(
          'search-debouncer', const Duration(milliseconds: 500), () {
        widget.viewModel.onTextSearchChanged(
          searchText: searchTextController.text,
        );
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return widget.viewModel.packagingsData != null &&
            widget.viewModel.activeMerchants != null
        ? Scaffold(
            backgroundColor: Theme.of(context).colorScheme.surfaceColor,
            body: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24.0),
              child: Column(
                children: [
                  const SizedBox(height: 12.0),
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      Expanded(
                        child: _buildFilters(),
                      ),
                      const SizedBox(width: 16.0),
                      SizedBox(
                        width: 120.0,
                        child: SecondaryButton(
                          label: 'Export CSV',
                          onPressed: () async {
                            LoadingDialog.show(
                              context,
                              'exporting data ...',
                              loadingDialogMode: LoadingDialogMode.onSurface,
                            );
                            await widget.viewModel.onExportToCsvTapped();
                            if (!mounted) return;
                            Navigator.of(context).pop();
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 24.0),
                  widget.viewModel.packagingsData!.isEmpty
                      ? Column(
                          children: [
                            const SizedBox(height: 60.0),
                            Text(
                              'No packagings match your filter.',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceDisabled),
                            ),
                          ],
                        )
                      : Expanded(
                          child: SizedBox(
                            width: MediaQuery.of(context).size.width,
                            child: _buildTable(),
                          ),
                        ),
                ],
              ),
            ),
          )
        : const LoadingSpinner();
  }

  @override
  void dispose() {
    serialNoController.dispose();
    searchTextController.dispose();
    super.dispose();
  }

  Widget _buildTable() {
    return AdminPackagingsTable(
      packagingsData: widget.viewModel.packagingsData,
      onSaveTapped: (Packaging packaging, PackagingStatus? status) => widget
          .viewModel
          .onSaveTapped(packaging: packaging, newStatus: status),
      onRowExpansionToggled: (bool expanded, PackagingsViewData pack) =>
          widget.viewModel.onRowExpansionToggled(
        data: pack,
        isExpanded: expanded,
      ),
      isLoading: false,
      initialDisplayPerPage: widget.viewModel.displayPerPage,
      onDisplayPerPageChanged: widget.viewModel.isFilteringBySearch
          ? null
          : (int? value) => widget.viewModel.onDisplayPerPageChanged(value),
      onPreviousTapped: widget.viewModel.showPreviousButton
          ? () => widget.viewModel.onPreviousPageTapped()
          : null,
      onNextTapped: widget.viewModel.showNextButton
          ? () => widget.viewModel.onNextPageTapped()
          : null,
    );
  }

  Widget _buildFilters() {
    List<String> packagingStatusNames = PackagingStatus.values
        .map((PackagingStatus status) => status.displayName)
        .toList();
    packagingStatusNames = [
      ...packagingStatusNames,
      ...['All']
    ];
    List<String> merchantNames = [];
    if (widget.viewModel.activeMerchants != null) {
      merchantNames.addAll(
        widget.viewModel.activeMerchants!.map(
          ((Merchant merchant) => merchant.name),
        ),
      );
    }
    merchantNames.insert(0, 'All');

    return Container(
      padding: const EdgeInsets.fromLTRB(24.0, 24.0, 24.0, 24.0),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceColor,
        borderRadius: const BorderRadius.all(Radius.circular(8.0)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Expanded(
            child: Row(
              children: [
                Expanded(
                  child: DropDownFieldBlack(
                    label: 'Package Type',
                    items: const [
                      ...availableProducts,
                      ...['All']
                    ],
                    onItemSelected: (String type) {
                      if (type == 'All') {
                        widget.viewModel.onPackagingTypeSelected(null);
                      } else {
                        widget.viewModel.onPackagingTypeSelected(type);
                      }
                    },
                    initialValue: 'All',
                  ),
                ),
                const SizedBox(width: 24.0),
                Expanded(
                  child: DropDownFieldBlack(
                    label: 'Status',
                    items: packagingStatusNames,
                    onItemSelected: (String status) {
                      if (status == 'All') {
                        widget.viewModel.onStatusSelected(null);
                      } else {
                        widget.viewModel.onStatusSelected(
                          PackagingStatus
                              .values[packagingStatusNames.indexOf(status)],
                        );
                      }
                    },
                    initialValue: 'All',
                  ),
                ),
                const SizedBox(width: 24.0),
                Expanded(
                  child: DropDownFieldBlack(
                    label: 'Merchant',
                    items: merchantNames,
                    onItemSelected: (String merchantName) {
                      if (merchantName == 'All') {
                        widget.viewModel.onMerchantSelected('All');
                      } else {
                        widget.viewModel.onMerchantSelected(merchantName);
                      }
                    },
                    initialValue: 'All',
                  ),
                ),
                const SizedBox(width: 24.0),
                SizedBox(
                  width: 160.0,
                  child: TextFieldBlack(
                    validator: (String? text) {},
                    label: 'Search by Code',
                    keyboardType: TextInputType.text,
                    controller: searchTextController,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
