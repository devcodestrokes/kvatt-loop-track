enum LabelStyleOption {
  kvattOld,
  kvattNew,
  customGoliathFR,
  customGoliathEN,
  kvattMinimal,
}
