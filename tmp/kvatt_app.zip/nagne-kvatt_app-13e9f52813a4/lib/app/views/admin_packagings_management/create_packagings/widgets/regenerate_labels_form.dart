import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class RegenerateLabelsForm extends StatefulWidget {
  final Function(
    List<String> codes,
  ) onSubmitPressed;
  final String? errorMessage;

  const RegenerateLabelsForm({
    Key? key,
    required this.onSubmitPressed,
    this.errorMessage,
  }) : super(key: key);

  @override
  State<RegenerateLabelsForm> createState() => RegenerateLabelsFormState();
}

class RegenerateLabelsFormState extends State<RegenerateLabelsForm> {
  TextEditingController labelCodesController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Regenerate existing labels',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          widget.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Enter the codes of the packs for which labels should be regenerated according to the following format:\n- Enter each code on a separate line\n- Enter only the code number i.e. 00025 instead of KV-NC-RS-00025',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
            ),
          ),
          const SizedBox(height: 24.0),
          TextFieldBlack(
            validator: (String? codes) {
              return Validators.validateNotEmpty(
                codes,
                'Please enter the codes for which you want labels to be regenerated.',
              );
            },
            label: 'Pack codes',
            maxLines: null,
            keyboardType: TextInputType.multiline,
            controller: labelCodesController,
          ),
          const SizedBox(height: 48.0),
          PrimaryButton(
            label: 'Regenerate labels',
            onPressed: () async {
              bool isFormValid = _formKey.currentState!.validate();
              if (isFormValid) {
                await widget.onSubmitPressed(
                  labelCodesController.text.trim().split('\n'),
                );
              }
            },
          ),
          const SizedBox(height: 24.0),
        ],
      ),
    );
  }

  @override
  void dispose() {
    labelCodesController.dispose();
    super.dispose();
  }
}
