import 'package:flutter/material.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/pack_label_generation_service.dart';
import 'package:kvatt_app/app/services/label_generators/spreadsheets/label_spreadsheet_generator.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/label_style_option.dart';
import 'package:kvatt_core/domain/labels/kvatt/label_version.dart';
import 'package:kvatt_core/domain/labels/label_style.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';

class CreatePackagingsViewModel extends ChangeNotifier {
  PackagingsManager packagingsManager;
  PackLabelGenerationService packagingLabelGenerationService;
  LabelSpreadsheetGenerator labelSpreadsheetGenerator;

  bool isLoading = false;
  String? createPacksSuccessSubmissionMessage;
  String? regenerateLabelsSuccessSubmissionMessage;
  String? createPacksErrorMessage;
  String? regenerateLabelsErrorMessage;

  CreatePackagingsViewModel({
    required this.packagingsManager,
    required this.packagingLabelGenerationService,
    required this.labelSpreadsheetGenerator,
  });

  onRegenerateLabels({
    required List<String> codes,
  }) async {
    try {
      List<Future<List<Packaging>>> fetchPacksTasks = codes.map((String code) {
        return packagingsManager.getPackagings(
          code: int.parse(code),
        );
      }).toList();

      List<List<Packaging>> packLists = await Future.wait(fetchPacksTasks);

      List<Packaging> packs = packLists.map((List<Packaging> packs) {
        return packs[0];
      }).toList();

      await packagingLabelGenerationService.generateAndDownloadLabels(
        packagings: packs,
      );

      regenerateLabelsSuccessSubmissionMessage =
          'Labels have been successfully regenerated';
    } catch (e) {
      regenerateLabelsErrorMessage =
          'There was an issue regenerating the labels.';
    }
    notifyListeners();
  }

  Future<List<Packaging>> _createPackagings({
    required String numPackagings,
    required String packagingType,
    required String manufacturer,
    required LabelStyleOption? selectedLabelStyleOption,
  }) async {
    List<Packaging> createdPackagings = [];

    if (selectedLabelStyleOption == LabelStyleOption.kvattOld ||
        selectedLabelStyleOption == LabelStyleOption.kvattNew) {
      createdPackagings = await packagingsManager.createNewPackagings(
        numPackagings: int.parse(numPackagings),
        packagingType: packagingType,
        manufacturer: manufacturer,
        labelVersion: _determineSelectedLabelVersion(selectedLabelStyleOption!),
        customLabelStyle: null,
      );
    }
    if (selectedLabelStyleOption == LabelStyleOption.customGoliathFR ||
        selectedLabelStyleOption == LabelStyleOption.customGoliathEN) {
      createdPackagings = await packagingsManager.createNewGoliathPackagings(
        numPackagings: int.parse(numPackagings),
        packagingType: packagingType,
        manufacturer: manufacturer,
        labelStyle: selectedLabelStyleOption == LabelStyleOption.customGoliathFR
            ? LabelStyle.customGoliathFR
            : LabelStyle.customGoliathEN,
      );
    }
    if (selectedLabelStyleOption == LabelStyleOption.kvattMinimal) {
      createdPackagings = await packagingsManager.createNewPackagings(
        numPackagings: int.parse(numPackagings),
        packagingType: packagingType,
        manufacturer: manufacturer,
        labelVersion: null,
        customLabelStyle: LabelStyle.minimal,
      );
    }

    return createdPackagings;
  }

  onCreatePackagingsAndSpreadsheet({
    required String numPackagings,
    required String packagingType,
    required String manufacturer,
    required LabelStyleOption? selectedLabelStyleOption,
  }) async {
    try {
      List<Packaging> createdPackagings = await _createPackagings(
        numPackagings: numPackagings,
        packagingType: packagingType,
        manufacturer: manufacturer,
        selectedLabelStyleOption: selectedLabelStyleOption,
      );

      await labelSpreadsheetGenerator.generateLabelsSpreadsheet(
          packs: createdPackagings);

      createPacksSuccessSubmissionMessage =
          'The new packagings have been successfully created and a spreadsheet has been successfully generated.';
    } catch (e) {
      createPacksErrorMessage =
          'There was an issue creating new packagings and generating the spreadsheet.';
    }
    notifyListeners();
  }

  onCreatePackagingsAndLabels({
    required String numPackagings,
    required String packagingType,
    required String manufacturer,
    required LabelStyleOption? selectedLabelStyleOption,
  }) async {
    try {
      List<Packaging> createdPackagings = await _createPackagings(
        numPackagings: numPackagings,
        packagingType: packagingType,
        manufacturer: manufacturer,
        selectedLabelStyleOption: selectedLabelStyleOption,
      );

      await packagingLabelGenerationService.generateAndDownloadLabels(
        packagings: createdPackagings,
      );

      createPacksSuccessSubmissionMessage =
          'The new packagings have been successfully created and labels have been successfully generated for them.';
    } catch (e) {
      createPacksErrorMessage =
          'There was an issue creating new packagings and generating labels.';
    }
    notifyListeners();
  }

  onCreateMorePacksPressed() {
    createPacksSuccessSubmissionMessage = null;
    notifyListeners();
  }

  onRegenerateMoreLabelsPressed() {
    regenerateLabelsSuccessSubmissionMessage = null;
    notifyListeners();
  }

  LabelVersion? _determineSelectedLabelVersion(
      LabelStyleOption labelStyleOption) {
    switch (labelStyleOption) {
      case LabelStyleOption.kvattOld:
        return LabelVersion.v2;
      case LabelStyleOption.kvattNew:
        return LabelVersion.v3;
      default:
        return null;
    }
  }
}
