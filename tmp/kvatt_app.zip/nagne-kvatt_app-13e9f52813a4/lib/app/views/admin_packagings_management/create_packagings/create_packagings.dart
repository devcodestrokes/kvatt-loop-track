import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/create_packagings_view_model.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/label_style_option.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/widgets/create_packagings_form.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/widgets/regenerate_labels_form.dart';

class CreatePackagings extends StatefulWidget {
  final CreatePackagingsViewModel viewModel;

  const CreatePackagings({
    super.key,
    required this.viewModel,
  });

  @override
  State<CreatePackagings> createState() => _CreatePackagingsState();
}

class _CreatePackagingsState extends State<CreatePackagings> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.3,
            child: Column(
              children: [
                const SizedBox(height: 48.0),
                widget.viewModel.isLoading == true
                    ? const LoadingSpinner()
                    : Column(
                        children: [
                          widget.viewModel
                                      .createPacksSuccessSubmissionMessage !=
                                  null
                              ? _buildCreatePacksSuccessSubmission()
                              : CreatePackagingsForm(
                                  errorMessage:
                                      widget.viewModel.createPacksErrorMessage,
                                  onSubmitPressed: (
                                    String numPackagings,
                                    String packagingType,
                                    String manufacturer,
                                    LabelStyleOption? selectedLabelStyleOption,
                                    bool generateSpreadsheet,
                                  ) async {
                                    LoadingDialog.show(
                                      context,
                                      generateSpreadsheet
                                          ? 'creating packagings and generating spreadsheet'
                                          : 'creating packagings and generating labels ...',
                                      loadingDialogMode:
                                          LoadingDialogMode.onSurface,
                                    );
                                    if (generateSpreadsheet) {
                                      await widget.viewModel
                                          .onCreatePackagingsAndSpreadsheet(
                                        numPackagings: numPackagings,
                                        packagingType: packagingType,
                                        manufacturer: manufacturer,
                                        selectedLabelStyleOption:
                                            selectedLabelStyleOption,
                                      );
                                    } else {
                                      await widget.viewModel
                                          .onCreatePackagingsAndLabels(
                                        numPackagings: numPackagings,
                                        packagingType: packagingType,
                                        manufacturer: manufacturer,
                                        selectedLabelStyleOption:
                                            selectedLabelStyleOption,
                                      );
                                    }
                                    if (!mounted) return;
                                    Navigator.of(context).pop();
                                  },
                                ),
                          const Divider(
                            height: 48.0,
                          ),
                          widget.viewModel
                                      .regenerateLabelsSuccessSubmissionMessage !=
                                  null
                              ? _buildRegenerateLabelsSuccessSubmission()
                              : RegenerateLabelsForm(
                                  onSubmitPressed: (List<String> codes) async {
                                    LoadingDialog.show(
                                      context,
                                      'regenerating labels ...',
                                      loadingDialogMode:
                                          LoadingDialogMode.onSurface,
                                    );
                                    await widget.viewModel.onRegenerateLabels(
                                      codes: codes,
                                    );
                                    if (!mounted) return;
                                    Navigator.of(context).pop();
                                  },
                                  errorMessage: widget
                                      .viewModel.regenerateLabelsErrorMessage,
                                ),
                        ],
                      ),
                const SizedBox(height: 12.0),
              ],
            ),
          ),
        ],
      ),
    );
  }

  _buildCreatePacksSuccessSubmission() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          widget.viewModel.createPacksSuccessSubmissionMessage!,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              height: 1.4),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16.0),
        Text(
          'Click on Create More to create more packagings.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              height: 1.4),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24.0),
        SizedBox(
          width: 160.0,
          child: SecondaryButton(
            label: 'Create More',
            onPressed: () {
              setState(() {
                widget.viewModel.onCreateMorePacksPressed();
              });
            },
          ),
        ),
      ],
    );
  }

  _buildRegenerateLabelsSuccessSubmission() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          widget.viewModel.regenerateLabelsSuccessSubmissionMessage!,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              height: 1.4),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16.0),
        Text(
          'Click on Regenerate More to regenerate more labels.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              height: 1.4),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24.0),
        SizedBox(
          width: 160.0,
          child: SecondaryButton(
            label: 'Regenerate More',
            onPressed: () {
              setState(() {
                widget.viewModel.onRegenerateMoreLabelsPressed();
              });
            },
          ),
        ),
        const SizedBox(height: 24.0),
      ],
    );
  }
}
