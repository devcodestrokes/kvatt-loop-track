import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/domain/products/available_manufacturers.dart';
import 'package:kvatt_app/domain/products/available_products.dart';

import '../label_style_option.dart';

class CreatePackagingsForm extends StatefulWidget {
  final Function(
    String numPackagings,
    String packageType,
    String manufacturer,
    LabelStyleOption? selectedLabelStyleOption,
    bool generateSpreadsheet,
  ) onSubmitPressed;
  final String? errorMessage;

  const CreatePackagingsForm({
    Key? key,
    required this.onSubmitPressed,
    this.errorMessage,
  }) : super(key: key);

  @override
  State<CreatePackagingsForm> createState() => CreatePackagingsFormState();
}

class CreatePackagingsFormState extends State<CreatePackagingsForm> {
  TextEditingController numPackagingsController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  String? _selectedProduct;
  String? _selectedManufacturer;

  LabelStyleOption? _selectedLabelStyleOption;

  String _getLabelStyleDisplayName(LabelStyleOption option) {
    switch (option) {
      case LabelStyleOption.kvattOld:
        return 'Kvatt (old)';
      case LabelStyleOption.kvattNew:
        return 'Kvatt (new)';
      case LabelStyleOption.customGoliathFR:
        return '(Custom) Goliath FR';
      case LabelStyleOption.customGoliathEN:
        return '(Custom) Goliath EN';
      case LabelStyleOption.kvattMinimal:
        return 'Kvatt (Minimal)';
    }
  }

  LabelStyleOption? _getLabelStyleOptionFromName(String name) {
    switch (name) {
      case 'Kvatt (old)':
        return LabelStyleOption.kvattOld;
      case 'Kvatt (new)':
        return LabelStyleOption.kvattNew;
      case '(Custom) Goliath FR':
        return LabelStyleOption.customGoliathFR;
      case '(Custom) Goliath EN':
        return LabelStyleOption.customGoliathEN;
      case 'Kvatt (Minimal)':
        return LabelStyleOption.kvattMinimal;
      default:
        return null;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Create new packs and labels',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          widget.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          TextFieldBlack(
            validator: (String? numPackagings) {
              return Validators.validateNotEmpty(
                numPackagings,
                'Please enter the number of packagings you want to create',
              );
            },
            label: 'Number of packagings',
            keyboardType: TextInputType.number,
            controller: numPackagingsController,
          ),
          const SizedBox(height: 40.0),
          DropDownFieldBlack(
            validator: (String? value) => Validators.validateNotEmpty(
                value, 'Please select the packaging type'),
            label: 'Packaging type',
            items: availableProducts,
            onItemSelected: (String item) {
              _selectedProduct = item;
            },
          ),
          const SizedBox(height: 40.0),
          DropDownFieldBlack(
            validator: (String? value) => Validators.validateNotEmpty(
                value, 'Please select the manufacturer'),
            label: 'Manufacturer',
            items: availableManufacturers,
            onItemSelected: (String item) {
              _selectedManufacturer = item;
            },
          ),
          const SizedBox(height: 36.0),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Select the style of label',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
            ),
          ),
          const SizedBox(height: 24.0),
          DropDownFieldBlack(
            validator: (String? value) => Validators.validateNotEmpty(
                value, 'Please select the label style'),
            label: 'Label style',
            items: LabelStyleOption.values
                .map((LabelStyleOption option) =>
                    _getLabelStyleDisplayName(option))
                .toList(),
            onItemSelected: (String optionName) {
              _selectedLabelStyleOption =
                  _getLabelStyleOptionFromName(optionName);
            },
          ),
          const SizedBox(height: 48.0),
          PrimaryButton(
            label: 'Create packs and generate labels',
            onPressed: () async {
              bool isFormValid = _formKey.currentState!.validate();
              if (isFormValid) {
                await widget.onSubmitPressed(
                  numPackagingsController.text.trim(),
                  _selectedProduct!,
                  _selectedManufacturer!,
                  _selectedLabelStyleOption,
                  false,
                );
              }
            },
          ),
          const SizedBox(height: 24.0),
          SecondaryButton(
            label: 'Create packs and generate spreadsheet',
            onPressed: () async {
              bool isFormValid = _formKey.currentState!.validate();
              if (isFormValid) {
                await widget.onSubmitPressed(
                  numPackagingsController.text.trim(),
                  _selectedProduct!,
                  _selectedManufacturer!,
                  _selectedLabelStyleOption,
                  true,
                );
              }
            },
          ),
          const SizedBox(height: 24.0),
        ],
      ),
    );
  }

  @override
  void dispose() {
    numPackagingsController.dispose();
    super.dispose();
  }
}
