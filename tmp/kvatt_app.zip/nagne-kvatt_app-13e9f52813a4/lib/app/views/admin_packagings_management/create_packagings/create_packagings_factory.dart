import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/pack_label_generation_service.dart';
import 'package:kvatt_app/app/services/label_generators/spreadsheets/label_spreadsheet_generator.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/create_packagings.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/create_packagings_view_model.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:provider/provider.dart';

class CreatePackagingsFactory {
  static Widget build() {
    return ChangeNotifierProvider<CreatePackagingsViewModel>(
      create: (context) {
        return CreatePackagingsViewModel(
          packagingsManager: Provider.of<PackagingsManager>(
            context,
            listen: false,
          ),
          packagingLabelGenerationService:
              Provider.of<PackLabelGenerationService>(
            context,
            listen: false,
          ),
          labelSpreadsheetGenerator: Provider.of<LabelSpreadsheetGenerator>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<CreatePackagingsViewModel>(
        builder: (context, model, child) => CreatePackagings(
          viewModel: model,
        ),
      ),
    );
  }
}
