import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_header.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/pagination_config.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/admin_packagings_management_view_model.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';

import 'admin_packagings_table_row.dart';

class AdminPackagingsTable extends StatelessWidget {
  final List<PackagingsViewData>? packagingsData;
  final Function(Packaging, PackagingStatus?) onSaveTapped;
  final Function(bool, PackagingsViewData) onRowExpansionToggled;
  final bool isLoading;
  final int initialDisplayPerPage;
  final Function(int?)? onDisplayPerPageChanged;
  final Function()? onPreviousTapped;
  final Function()? onNextTapped;

  const AdminPackagingsTable({
    super.key,
    required this.packagingsData,
    required this.onSaveTapped,
    required this.onRowExpansionToggled,
    required this.isLoading,
    required this.initialDisplayPerPage,
    required this.onDisplayPerPageChanged,
    required this.onPreviousTapped,
    required this.onNextTapped,
  });

  @override
  Widget build(BuildContext context) {
    return CustomTable(
      isLoading: isLoading,
      emptyStateMessage: 'No packs match your current filters.',
      backgroundColor: Theme.of(context).colorScheme.backgroundColor,
      borderRadius: const BorderRadius.all(
        Radius.circular(20.0),
      ),
      tableRowsExpandable: true,
      headers: [
        HeaderConfig(
          label: 'Code',
          expandFlex: 1,
        ),
        HeaderConfig(
          label: 'Custom ID',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Product Type',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Manufacturer',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Merchant name',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Order number',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Status',
          expandFlex: 3,
        ),
        HeaderConfig(
          label: '',
          expandFlex: 1,
        ),
      ],
      rows: packagingsData?.map((PackagingsViewData packagingData) {
            return AdminPackagingsTableRow(
              code: packagingData.packaging.code,
              customId: packagingData.packaging.customId,
              type: packagingData.packaging.type,
              manufacturer: packagingData.packaging.manufacturer,
              merchantName: packagingData.packaging.merchantName,
              orderNumber: packagingData.packaging.orderNumber,
              status: packagingData.packaging.status,
              trackingHistories: packagingData.history,
              isFetchingHistory: packagingData.isFetchingHistory,
              onSaveTapped: (PackagingStatus? status) async {
                return await onSaveTapped(
                  packagingData.packaging,
                  status,
                );
              },
              onRowExpansionToggled: (bool expanded) =>
                  onRowExpansionToggled(expanded, packagingData),
            );
          }).toList() ??
          [],
      paginationConfig: PaginationConfig(
        initialDisplayPerPage: initialDisplayPerPage,
        onDisplayPerPageChanged: onDisplayPerPageChanged,
        onPreviousTapped: onPreviousTapped,
        onNextTapped: onNextTapped,
      ),
    );
  }
}
