import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_cell.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/packaging_details/packaging_details.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/packaging_status_display_name.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';
import 'package:kvatt_core/domain/tracking/tracking_history.dart';

class AdminPackagingsTableRow extends StatefulWidget {
  final int? code;
  final String? customId;
  final String? type;
  final String? manufacturer;
  final String? merchantName;
  final String? orderNumber;
  final PackagingStatus? status;
  final List<TrackingHistory>? trackingHistories;
  final bool isFetchingHistory;
  final Future<void> Function(PackagingStatus?) onSaveTapped;
  final Function(bool) onRowExpansionToggled;

  const AdminPackagingsTableRow({
    super.key,
    required this.code,
    required this.customId,
    required this.type,
    required this.manufacturer,
    required this.merchantName,
    required this.orderNumber,
    required this.status,
    required this.trackingHistories,
    required this.isFetchingHistory,
    required this.onSaveTapped,
    required this.onRowExpansionToggled,
  });

  @override
  State<AdminPackagingsTableRow> createState() =>
      _AdminPackagingsTableRowState();
}

class _AdminPackagingsTableRowState extends State<AdminPackagingsTableRow> {
  bool _isEditing = false;
  bool _isSaving = false;

  String? _selectedStatus;

  String _getDisplayNameFromStatus({
    required PackagingStatus? status,
  }) {
    if (status == null) {
      return 'n/a';
    } else {
      return status.displayName;
    }
  }

  PackagingStatus? _getPackagingStatusFromDisplayName({
    required String? name,
  }) {
    switch (name) {
      case 'In Store (New)':
        return PackagingStatus.inStoreNew;
      case 'Returned':
        return PackagingStatus.inStoreReturned;
      case 'En Route to Merchant':
        return PackagingStatus.enRouteToMerchant;
      case 'With Merchant':
        return PackagingStatus.withMerchant;
      case 'With Merchant (Returned)':
        return PackagingStatus.withMerchantReturned;
      case 'With Customer':
        return PackagingStatus.withCustomer;
      case 'In Maintenance':
        return PackagingStatus.inMaintenance;
      case 'In Store (Ready)':
        return PackagingStatus.inStoreReady;
      default:
        return null;
    }
  }

  Widget _buildSaveButton() {
    return TextButton(
      style: ButtonStyle(
        overlayColor: MaterialStateProperty.resolveWith<Color>(
          (Set<MaterialState> states) {
            return Colors.transparent;
          },
        ),
      ),
      onPressed: () async {
        setState(() {
          _isSaving = true;
        });
        await widget.onSaveTapped(
          _getPackagingStatusFromDisplayName(name: _selectedStatus),
        );
        setState(() {
          _isSaving = false;
          _isEditing = false;
        });
      },
      child: Text(
        'Save',
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
              color: Theme.of(context).colorScheme.secondaryColor,
            ),
      ),
    );
  }

  Widget _buildEditButton({
    required bool isEnabled,
  }) {
    return IconButton(
      onPressed: isEnabled == false
          ? null
          : () {
              setState(() {
                _isEditing = true;
              });
            },
      splashRadius: 24.0,
      icon: Icon(
        Icons.edit,
        size: 16.0,
        color: isEnabled
            ? Theme.of(context).colorScheme.onSurfaceMediumEmphasis
            : Theme.of(context).colorScheme.onSurfaceDisabled,
      ),
    );
  }

  Widget _buildAction() {
    if (_isSaving) {
      return const LoadingSpinner(
        width: 24.0,
        height: 24.0,
      );
    }
    if (_isEditing) {
      return _buildSaveButton();
    }
    return _buildEditButton(
      isEnabled: widget.status != PackagingStatus.inStoreReturned,
    );
  }

  CustomTableCell _buildStatusCell() {
    return CustomTableCell.dropdown(
      isEditing: _isEditing,
      items: ['Returned', _getDisplayNameFromStatus(status: widget.status)],
      value: _getDisplayNameFromStatus(status: widget.status),
      expandFlex: 3,
      onChanged: (String? status) {
        _selectedStatus = status;
      },
    );
  }

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
      data: Theme.of(context).copyWith(dividerColor: Colors.transparent),
      child: ExpansionTile(
        tilePadding: EdgeInsets.zero,
        onExpansionChanged: (bool expanded) =>
            widget.onRowExpansionToggled(expanded),
        title: Row(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            CustomTableCell.readonly(
              text: widget.code == null
                  ? 'n/a'
                  : widget.code.toString().padLeft(5, '0'),
              expandFlex: 1,
            ),
            CustomTableCell.readonly(
              text: widget.customId ?? 'n/a',
              expandFlex: 2,
            ),
            CustomTableCell.readonly(
              text: widget.type ?? 'n/a',
              expandFlex: 2,
            ),
            CustomTableCell.readonly(
              text: widget.manufacturer ?? 'n/a',
              expandFlex: 2,
            ),
            CustomTableCell.readonly(
              text: widget.merchantName ?? 'n/a',
              expandFlex: 2,
            ),
            CustomTableCell.readonly(
              text: widget.orderNumber ?? 'n/a',
              expandFlex: 2,
            ),
            _buildStatusCell(),
            Expanded(
              flex: 1,
              child: _buildAction(),
            ),
          ],
        ),
        children: [
          PackagingDetails(
            isLoading: widget.isFetchingHistory,
            trackingHistory: widget.trackingHistories,
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
  }
}
