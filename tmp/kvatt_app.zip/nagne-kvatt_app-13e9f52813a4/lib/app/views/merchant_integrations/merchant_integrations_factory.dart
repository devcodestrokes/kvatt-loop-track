import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/services/url_launcher/url_launcher_service.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/merchant_integrations/merchant_integrations.dart';
import 'package:kvatt_app/app/views/merchant_integrations/merchant_integrations_view_model.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_core/domain/shopify/shopify_manager.dart';
import 'package:provider/provider.dart';

class MerchantIntegrationsFactory {
  static Widget build({
    required Map<String, String> params,
  }) {
    return ChangeNotifierProvider<MerchantIntegrationsViewModel>(
      create: (context) {
        return MerchantIntegrationsViewModel(
          config: Provider.of<Config>(
            context,
            listen: false,
          ),
          urlLauncherService: Provider.of<UrlLauncherService>(
            context,
            listen: false,
          ),
          shopifyManager: Provider.of<ShopifyManager>(
            context,
            listen: false,
          ),
          communicationsManager: Provider.of<CommunicationsManager>(
            context,
            listen: false,
          ),
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
          params: params,
        );
      },
      child: Consumer<MerchantIntegrationsViewModel>(
        builder: (context, model, child) => MerchantIntegrations(
          viewModel: model,
        ),
      ),
    );
  }
}
