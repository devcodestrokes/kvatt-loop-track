import 'package:flutter/material.dart';
import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/services/url_launcher/url_launcher_service.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_core/domain/shopify/connection_status.dart';
import 'package:kvatt_core/domain/shopify/shopify_manager.dart';

enum ConnectActionResult {
  success,
  failure,
}

class MerchantIntegrationsViewModel extends ChangeNotifier {
  Config config;
  UrlLauncherService urlLauncherService;
  ShopifyManager shopifyManager;
  CommunicationsManager communicationsManager;
  UiState uiState;
  Map<String, String> params;

  final navigatorKey = GlobalKey<NavigatorState>();

  final String shippingMethodText = 'No Waste Experience';

  bool? isShopifyConnected;
  bool? isCheckoutShippingMethodAdded;
  bool? isConnectRequestedSuccessfully;
  bool? sendGenericReturnEmailNudge;
  bool isVerifyingCheckoutConnection = false;
  bool isUpdatingSendGenericReturnEmailNudge = false;

  MerchantIntegrationsViewModel({
    required this.config,
    required this.urlLauncherService,
    required this.shopifyManager,
    required this.communicationsManager,
    required this.uiState,
    required this.params,
  });

  Future<ConnectActionResult?> init() async {
    ConnectActionResult? result;
    if (params['connect'] == '1' && params['checkCode'] != null) {
      try {
        await shopifyManager.connectShopToMerchant(
          checkCode: params['checkCode']!,
          region: config.cloudFunctionRegion!,
        );
        result = ConnectActionResult.success;
      } catch (e) {
        result = ConnectActionResult.failure;
      }
    }
    try {
      ConnectionStatus status = await shopifyManager.getConnectionStatus(
        region: config.cloudFunctionRegion!,
      );
      isShopifyConnected = status.isConnected;
      sendGenericReturnEmailNudge = status.sendGenericReturnEmailNudge;
      isCheckoutShippingMethodAdded =
          await shopifyManager.getCheckoutAddedStatus(
        region: config.cloudFunctionRegion!,
        shippingMethodText: shippingMethodText,
      );
    } catch (e) {
      isShopifyConnected = false;
      isCheckoutShippingMethodAdded = false;
      sendGenericReturnEmailNudge = false;
    }
    notifyListeners();
    return result;
  }

  onVerifyCheckoutConnectionPressed() async {
    isVerifyingCheckoutConnection = true;
    notifyListeners();
    isCheckoutShippingMethodAdded = await shopifyManager.getCheckoutAddedStatus(
      region: config.cloudFunctionRegion!,
      shippingMethodText: shippingMethodText,
    );
    isVerifyingCheckoutConnection = false;
    notifyListeners();
  }

  onSendGenericReturnEmailNudgeToggled({
    required bool value,
  }) async {
    isUpdatingSendGenericReturnEmailNudge = true;
    notifyListeners();
    try {
      await shopifyManager.setGenericReturnEmailNudge(
        region: config.cloudFunctionRegion!,
        sendGenericReturnEmailNudge: value,
      );
      sendGenericReturnEmailNudge = value;
    } catch (e) {
      //Fail silently
    }
    isUpdatingSendGenericReturnEmailNudge = false;
    notifyListeners();
  }

  onGoToShippingAndDeliverySettingsPressed() {
    communicationsManager.launchShopifyShippingAndDeliverySettings();
  }

  onGoToShopifyAdminDashboardPressed() {
    communicationsManager.launchShopifyAdminDashboard();
  }

  onGoToShopifyShippingAndDeliveryDocsPressed() {
    communicationsManager.launchShopifyShippingAndDeliveryDocs();
  }

  onContactSupportPressed() {
    communicationsManager.launchSupportEmail();
  }

  onCloseConnectionSuccessModalPressed() {
    urlLauncherService.openLink(
      url: '/home?view=merchant-integrations',
      inSameTab: true,
    );
  }

  onCloseConnectionFailureModalPressed() {
    urlLauncherService.openLink(
      url: '/home?view=merchant-integrations',
      inSameTab: true,
    );
  }

  onInstallAndConnectPressed() {
    communicationsManager.launchKvattShopifyAppPage();
  }
}
