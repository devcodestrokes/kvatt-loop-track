import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/custom_checkbox.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/merchant_integrations/merchant_integrations_view_model.dart';
import 'package:kvatt_app/app/views/merchant_integrations/widgets/instructions_dialog.dart';

class MerchantIntegrations extends StatefulWidget {
  final MerchantIntegrationsViewModel viewModel;

  const MerchantIntegrations({
    super.key,
    required this.viewModel,
  });

  @override
  State<MerchantIntegrations> createState() => _MerchantIntegrationsState();
}

class _MerchantIntegrationsState extends State<MerchantIntegrations> {
  Widget _buildStoreNotConnected() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        Text(
          'Kvatt is currently not connected to your Shopify account.\n\nClick on the button below to install our Shopify App from the Shopify App Store and set up the connection.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
              ),
        ),
        const SizedBox(
          height: 36.0,
        ),
        SizedBox(
          width: 200.0,
          child: PrimaryButton(
            label: "Install & Connect",
            onPressed: () => widget.viewModel.onInstallAndConnectPressed(),
          ),
        ),
      ],
    );
  }

  Widget _buildStoreConnected() {
    return Column(
      children: [
        Text(
          'Kvatt is connected to your Shopify account!',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
              ),
        ),
      ],
    );
  }

  Widget _buildCheckoutNotConnected() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      children: [
        RichText(
          text: TextSpan(children: [
            TextSpan(
              text:
                  'Giving your customers the option to choose circularity at checkout allows you to test their interest without any financial risk for your brand. Our common objective will be to maximise pick-up rate (i.e. how many people choose the circular option). \n\nWe\'ve found that the actual message presented at checkout has an impact on whether customers choose that option or not. We recommend adding "${widget.viewModel.shippingMethodText}" in the shipping method name you\'ll add at checkout - copy/paste it below!\n\nClick on "View Instructions" below for more information.\n\nOnce you\'ve done this, we\'ll be able to start tracking your pick-up rate and provide you with valuable insights on how to improve it.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
            ),
          ]),
        ),
        const SizedBox(height: 24.0),
        Container(
          width: 300.0,
          padding: const EdgeInsets.symmetric(vertical: 8.0),
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.surfaceColor,
            borderRadius: const BorderRadius.all(Radius.circular(8.0)),
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(width: 8.0),
              SelectableText(
                widget.viewModel.shippingMethodText,
                textAlign: TextAlign.center,
              ),
              InkWell(
                onTap: () {
                  Clipboard.setData(
                    ClipboardData(text: widget.viewModel.shippingMethodText),
                  ).then((_) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        behavior: SnackBarBehavior.floating,
                        width: 300.0,
                        content: Text("Copied to clipboard."),
                      ),
                    );
                  });
                },
                child: const Icon(
                  Icons.copy,
                ),
              ),
              const SizedBox(width: 2.0),
            ],
          ),
        ),
        const SizedBox(height: 36.0),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              width: 200.0,
              child: SecondaryButton(
                label: "View instructions",
                onPressed: () {
                  _showInstructionsDialog();
                },
              ),
            ),
            const SizedBox(width: 24.0),
            SizedBox(
              width: 200.0,
              child: PrimaryButton(
                label: "Verify",
                onPressed: () =>
                    widget.viewModel.onVerifyCheckoutConnectionPressed(),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Widget _buildCheckoutConnected() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'You\'ve successfully added the "${widget.viewModel.shippingMethodText}" shipping method at checkout.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
              ),
        ),
        Text(
          '\nWe\'ll be tracking your pick-up rate, return rate, carbon emissions and provide you with insights on how to improve them. Check your Home Dashboard to visualise all your data!',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
              ),
        ),
        widget.viewModel.isCheckoutShippingMethodAdded == true &&
                widget.viewModel.sendGenericReturnEmailNudge != null
            ? Column(
                children: [
                  const SizedBox(height: 24.0),
                  Container(
                    padding: const EdgeInsets.all(16.0),
                    decoration: BoxDecoration(
                      color: Theme.of(context).colorScheme.surfaceColor,
                      borderRadius:
                          const BorderRadius.all(Radius.circular(4.0)),
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Return reminder email',
                          style:
                              Theme.of(context).textTheme.titleSmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceMediumEmphasis,
                                  ),
                        ),
                        const SizedBox(height: 8.0),
                        Text(
                          'When you check the box below, we\'ll send an email to your customer a few days after they\'ve placed an order and selected the ${widget.viewModel.shippingMethodText} shipping method to remind them to return the pack. This has shown to improve return rate.',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceMediumEmphasis,
                                  ),
                        ),
                        const SizedBox(height: 24.0),
                        Row(
                          children: [
                            Text(
                              'Send return reminder email',
                              style: Theme.of(context)
                                  .textTheme
                                  .titleSmall
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceMediumEmphasis,
                                  ),
                            ),
                            const SizedBox(width: 14.0),
                            widget.viewModel
                                        .isUpdatingSendGenericReturnEmailNudge ==
                                    false
                                ? CustomCheckbox(
                                    value: widget
                                        .viewModel.sendGenericReturnEmailNudge!,
                                    onChanged: (bool value) => widget.viewModel
                                        .onSendGenericReturnEmailNudgeToggled(
                                            value: value),
                                  )
                                : const LoadingSpinner(
                                    height: 40.0,
                                    width: 40.0,
                                  ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ],
              )
            : const SizedBox(),
      ],
    );
  }

  Widget _buildConnectionDisplay({
    required BuildContext context,
    required bool isConnected,
    required bool isCheckout,
  }) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Image.asset(
          AssetsFactory.kvattLogoBlack,
          width: 60.0,
        ),
        const SizedBox(width: 24.0),
        Icon(
          Icons.arrow_back_rounded,
          color: isConnected
              ? Theme.of(context).colorScheme.onTrafficLightGreen
              : Theme.of(context).colorScheme.onTrafficLightRed,
        ),
        const SizedBox(width: 12.0),
        isConnected == true
            ? Icon(
                Icons.check,
                size: 48.0,
                color: Theme.of(context).colorScheme.onTrafficLightGreen,
              )
            : Icon(
                Icons.close,
                size: 48.0,
                color: Theme.of(context).colorScheme.onTrafficLightRed,
              ),
        const SizedBox(width: 12.0),
        Icon(
          Icons.arrow_forward_rounded,
          color: isConnected
              ? Theme.of(context).colorScheme.onTrafficLightGreen
              : Theme.of(context).colorScheme.onTrafficLightRed,
        ),
        const SizedBox(width: 16.0),
        isCheckout == true
            ? Icon(
                Icons.shopping_cart_checkout,
                size: 40.0,
                color: isConnected
                    ? Theme.of(context).colorScheme.onTrafficLightGreen
                    : Theme.of(context).colorScheme.onTrafficLightRed,
              )
            : Image.asset(
                AssetsFactory.shopifyLogo,
                width: 80.0,
              ),
      ],
    );
  }

  _showConnectionFailureDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Oops! Something went wrong.',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          content: SizedBox(
            width: 500.0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  'There was an issue with your request. Please try again.\n\nIf the problem persists, please contact our support team at the following email address: team@kvatt.com.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
              ],
            ),
          ),
          actions: [
            SizedBox(
              width: 100.0,
              child: PrimaryButton(
                label: 'OK',
                onPressed: () {
                  Navigator.of(context).pop();
                  widget.viewModel.onCloseConnectionFailureModalPressed();
                },
              ),
            ),
          ],
        );
      },
    );
  }

  _showConnectionSuccessDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: Text(
            'Connection successful!',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          content: SizedBox(
            width: 500.0,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(
                  Icons.check_circle_outline,
                  size: 120.0,
                  color: Theme.of(context).colorScheme.onTrafficLightGreen,
                ),
                const SizedBox(height: 24.0),
                Text(
                  'Well done!\nYou\'ve successfully connected your Shopify account to Kvatt.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                  textAlign: TextAlign.center,
                ),
              ],
            ),
          ),
          actions: [
            SizedBox(
              width: 100.0,
              child: PrimaryButton(
                label: 'OK',
                onPressed: () {
                  Navigator.of(context).pop();
                  widget.viewModel.onCloseConnectionSuccessModalPressed();
                },
              ),
            ),
          ],
        );
      },
    );
  }

  _showInstructionsDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return InstructionsDialog(
          shippingMethodText: widget.viewModel.shippingMethodText,
          onGoToShopifyAdminDashboardPressed: () =>
              widget.viewModel.onGoToShopifyAdminDashboardPressed(),
          onContactSupportPressed: () =>
              widget.viewModel.onContactSupportPressed(),
          onGoToShopifyShippingAndDeliveryDocsPressed: () =>
              widget.viewModel.onGoToShopifyShippingAndDeliveryDocsPressed(),
          onClosePressed: () {
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  Widget _buildStoreConnectionSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Connect your Shopify account to Kvatt',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 36.0),
        Padding(
          padding: const EdgeInsets.fromLTRB(16.0, 24.0, 16.0, 24.0),
          child: Column(
            children: [
              _buildConnectionDisplay(
                context: context,
                isConnected: widget.viewModel.isShopifyConnected!,
                isCheckout: false,
              ),
              const SizedBox(height: 40.0),
              widget.viewModel.isShopifyConnected == true
                  ? _buildStoreConnected()
                  : _buildStoreNotConnected(),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildCheckoutConnectionSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Add Kvatt at checkout',
          style: Theme.of(context).textTheme.titleSmall,
        ),
        const SizedBox(height: 36.0),
        IntrinsicHeight(
          child: Stack(
            fit: StackFit.expand,
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(16.0, 24.0, 16.0, 24.0),
                child: Column(
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    widget.viewModel.isVerifyingCheckoutConnection
                        ? const LoadingSpinner(
                            width: 45.0,
                            height: 45.0,
                          )
                        : _buildConnectionDisplay(
                            context: context,
                            isConnected:
                                widget.viewModel.isCheckoutShippingMethodAdded!,
                            isCheckout: true,
                          ),
                    const SizedBox(height: 40.0),
                    widget.viewModel.isCheckoutShippingMethodAdded == true
                        ? _buildCheckoutConnected()
                        : _buildCheckoutNotConnected(),
                  ],
                ),
              ),
              widget.viewModel.isShopifyConnected == false
                  ? Container(
                      color: Theme.of(context)
                          .colorScheme
                          .surfaceColor
                          .withOpacity(0.95),
                      child: Center(
                        child: Text(
                          'Please connect your Shopify\naccount to Kvatt first.',
                          style: Theme.of(context).textTheme.headlineSmall,
                          textAlign: TextAlign.center,
                        ),
                      ),
                    )
                  : const SizedBox(),
            ],
          ),
        ),
      ],
    );
  }

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      widget.viewModel.init().then((ConnectActionResult? result) {
        if (result == ConnectActionResult.failure) {
          _showConnectionFailureDialog();
        }
        if (result == ConnectActionResult.success) {
          _showConnectionSuccessDialog();
        }
      });
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceColor,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 60.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 24.0),
              Text(
                'Integrations',
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    ),
              ),
              const SizedBox(height: 48.0),
              Container(
                padding: const EdgeInsets.fromLTRB(24.0, 16.0, 24.0, 40.0),
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: Theme.of(context).colorScheme.backgroundColor,
                  borderRadius: const BorderRadius.all(Radius.circular(20.0)),
                  border: Border.all(
                    color: Theme.of(context).colorScheme.surfaceDarkColor,
                  ),
                ),
                width: MediaQuery.of(context).size.width,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Shopify',
                      style:
                          Theme.of(context).textTheme.headlineSmall?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceHighEmphasis,
                              ),
                    ),
                    const Divider(),
                    const SizedBox(height: 32.0),
                    widget.viewModel.isShopifyConnected == null ||
                            widget.viewModel.isCheckoutShippingMethodAdded ==
                                null
                        ? Column(
                            children: [
                              const LoadingSpinner(
                                width: 40.0,
                                height: 40.0,
                              ),
                              const SizedBox(height: 8.0),
                              Text(
                                'Verifying connection...',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceDisabled,
                                    ),
                              ),
                            ],
                          )
                        : Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                flex: 1,
                                child: _buildStoreConnectionSection(),
                              ),
                              const SizedBox(width: 60.0),
                              Expanded(
                                flex: 1,
                                child: _buildCheckoutConnectionSection(),
                              ),
                            ],
                          ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
