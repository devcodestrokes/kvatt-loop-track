import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class InstructionsDialog extends StatelessWidget {
  final String shippingMethodText;
  final Function onGoToShopifyAdminDashboardPressed;
  final Function onContactSupportPressed;
  final Function onGoToShopifyShippingAndDeliveryDocsPressed;
  final Function onClosePressed;

  const InstructionsDialog({
    super.key,
    required this.shippingMethodText,
    required this.onGoToShopifyAdminDashboardPressed,
    required this.onContactSupportPressed,
    required this.onGoToShopifyShippingAndDeliveryDocsPressed,
    required this.onClosePressed,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(
        'Instructions: Add Kvatt at checkout',
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
            ),
      ),
      content: Container(
        width: 650.0,
        padding: const EdgeInsets.symmetric(horizontal: 8.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            RichText(
              text: TextSpan(children: [
                TextSpan(
                  text: '1. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text: 'Login to your ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: 'Shopify Admin dashboard',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.blue,
                      ),
                  recognizer: TapGestureRecognizer()
                    ..onTap = () => onGoToShopifyAdminDashboardPressed(),
                ),
                TextSpan(
                  text: '.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: '\n2. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text: 'In the bottom left corner, click on Settings.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: '\n3. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text:
                      'In the list on the left, select Shipping and delivery.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: '\n4. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text:
                      'Select the shipping profile you want to add the "$shippingMethodText" shipping option to.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: '\n5. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text:
                      'Find the shipping zone you want to add the shipping option to.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: '\n6. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text: 'Click on Add rate.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: '\n7. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text:
                      'Make sure the custom rate name field includes the words "$shippingMethodText".',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text: '\n8. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text: 'Set the price to £1.99.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: '\n9. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text: 'Click on Done to save your changes.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text:
                      '\n\nNote: If you have multiple shipping profiles, and want to add the "$shippingMethodText" shipping method to multiple profiles, you\'ll need to perform steps 4 to 7 for each profile.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontStyle: FontStyle.italic,
                      ),
                ),
                TextSpan(
                  text:
                      '\n\nOnce you\'re done, come back here, close the instructions pop-up, and click on the ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: 'Verify',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                        fontWeight: FontWeight.bold,
                      ),
                ),
                TextSpan(
                  text:
                      ' button to know whether we are able to pick up the shipping methods you\'ve added. ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text:
                      '\n\nIf it does not turn green, please go through the steps above again to make sure you haven\'t missed anything. If you are still having issues, please don\'t hesitate to email our support team at ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: 'team@kvatt.com',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.blue,
                      ),
                  recognizer: TapGestureRecognizer()
                    ..onTap = () => onContactSupportPressed(),
                ),
                TextSpan(
                  text: '.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text:
                      '\n\nFor more detailed instructions, or to know more about how to manage Shipping and delivery in Shopify, please visit the official Shopify documentation ',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
                TextSpan(
                  text: 'here',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Colors.blue,
                      ),
                  recognizer: TapGestureRecognizer()
                    ..onTap =
                        () => onGoToShopifyShippingAndDeliveryDocsPressed(),
                ),
                TextSpan(
                  text: '.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                ),
              ]),
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          width: 100.0,
          child: SecondaryButton(
            label: 'Close',
            onPressed: () => onClosePressed(),
          ),
        ),
      ],
    );
  }
}
