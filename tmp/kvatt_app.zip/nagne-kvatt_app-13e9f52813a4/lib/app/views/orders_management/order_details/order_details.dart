import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/domain/orders/order.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class OrderDetails extends StatelessWidget {
  final Order order;

  const OrderDetails({
    super.key,
    required this.order,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 24.0),
      child: Column(
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                flex: 1,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    _buildField(
                      context,
                      'Contact email',
                      order.contactEmail ?? 'N/A',
                    ),
                    const SizedBox(height: 12.0),
                    _buildField(
                      context,
                      'Shipping details',
                      order.shippingDetails ?? 'N/A',
                    ),
                    const SizedBox(height: 12.0),
                    _buildField(
                      context,
                      'Expected Delivery Date',
                      order.expectedDeliveryDate != null
                          ? DateFormat('dd/MM/yyyy')
                              .format(order.expectedDeliveryDate!)
                          : 'N/A',
                    ),
                    const SizedBox(height: 12.0),
                    _buildField(
                      context,
                      'Invoiced',
                      order.hasInvoiced == true ? 'Yes' : 'No',
                    ),
                    const SizedBox(height: 12.0),
                    _buildField(
                      context,
                      'Probability',
                      order.probability != null
                          ? '${order.probability}%'
                          : 'N/A',
                    ),
                  ],
                ),
              ),
              Expanded(
                flex: 1,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisAlignment: MainAxisAlignment.start,
                  children: [
                    _buildField(
                      context,
                      'Unit price (£)',
                      order.unitPriceInGBP != null
                          ? order.unitPriceInGBP.toString()
                          : 'N/A',
                    ),
                    const SizedBox(height: 12.0),
                    _buildField(
                      context,
                      'Tracking',
                      order.tracking ?? 'N/A',
                    ),
                    const SizedBox(height: 12.0),
                    _buildField(
                      context,
                      'Delivery Date',
                      order.deliveryDate != null
                          ? DateFormat('dd/MM/yyyy')
                              .format(order.expectedDeliveryDate!)
                          : 'N/A',
                    ),
                    const SizedBox(height: 12.0),
                    _buildField(
                      context,
                      'Invoice link',
                      order.invoiceLink ?? 'N/A',
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 32.0),
        ],
      ),
    );
  }

  Widget _buildField(
    BuildContext context,
    String label,
    String value,
  ) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis),
        ),
        const SizedBox(height: 4.0),
        Text(
          value,
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis),
        ),
      ],
    );
  }
}
