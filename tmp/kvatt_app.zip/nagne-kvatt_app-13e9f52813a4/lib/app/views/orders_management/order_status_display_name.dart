import 'package:kvatt_app/domain/orders/order_status.dart';

Map<OrderStatus, String> orderStatusDisplayNameMap = {
  OrderStatus.open: 'Open',
  OrderStatus.acknowledged: 'Acknowledged',
  OrderStatus.ready: 'Ready',
  OrderStatus.onHold: 'On-hold',
  OrderStatus.inTransit: 'In transit',
  OrderStatus.delivered: 'Delivered',
};

Map<String, OrderStatus> displayNameOrderStatusMap = {
  'Open': OrderStatus.open,
  'Acknowledged': OrderStatus.acknowledged,
  'Ready': OrderStatus.ready,
  'On-hold': OrderStatus.onHold,
  'In transit': OrderStatus.inTransit,
  'Delivered': OrderStatus.delivered,
};
