import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/orders_management/orders_management.dart';
import 'package:kvatt_app/app/views/orders_management/orders_management_view_model.dart';
import 'package:kvatt_app/domain/orders/order_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class OrdersManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<OrdersManagementViewModel>(
      create: (context) {
        return OrdersManagementViewModel(
          orderManager: Provider.of<OrderManager>(
            context,
            listen: false,
          ),
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<OrdersManagementViewModel>(
        builder: (context, model, child) => OrdersManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
