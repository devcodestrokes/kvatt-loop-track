import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/views/orders_management/create_order/create_order.dart';
import 'package:kvatt_app/app/views/orders_management/create_order/create_order_view_model.dart';
import 'package:kvatt_app/domain/orders/order_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class CreateOrderFactory {
  static Widget build() {
    return ChangeNotifierProvider<CreateOrderViewModel>(
      create: (context) {
        return CreateOrderViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          orderManager: Provider.of<OrderManager>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<CreateOrderViewModel>(
        builder: (context, model, child) => CreateOrder(
          viewModel: model,
        ),
      ),
    );
  }
}
