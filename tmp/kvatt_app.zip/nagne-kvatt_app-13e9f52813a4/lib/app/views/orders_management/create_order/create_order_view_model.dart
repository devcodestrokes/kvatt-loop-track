import 'package:flutter/material.dart';
import 'package:kvatt_app/domain/orders/order_manager.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

class CreateOrderViewModel extends ChangeNotifier {
  UserManager userManager;
  OrderManager orderManager;

  List<Merchant> merchants = [];

  bool isLoading = false;
  String? errorMessage;

  CreateOrderViewModel({
    required this.userManager,
    required this.orderManager,
  });

  Future<void> init() async {
    isLoading = true;
    notifyListeners();
    merchants = await userManager.retrieveActiveMerchants();
    isLoading = false;
    notifyListeners();
  }

  Future<bool> onCreateOrder({
    required Merchant? selectedMerchant,
    required String? enteredMerchantName,
    required OrderType orderType,
    required String? contactEmail,
    required String? shippingDetails,
    required String product,
    required String quantity,
    required String? unitPrice,
    required String? probability,
  }) async {
    try {
      await orderManager.createNewOrder(
        orderType: orderType,
        product: product,
        quantity: int.parse(quantity),
        merchantId: selectedMerchant?.uid,
        merchantName: selectedMerchant == null ? enteredMerchantName : null,
        contactEmail: contactEmail,
        shippingDetails: shippingDetails,
        unitPriceInGBP: unitPrice != null && unitPrice.isNotEmpty
            ? double.parse(unitPrice)
            : null,
        probability: probability != null && probability.isNotEmpty
            ? double.parse(probability)
            : null,
      );
      return true;
    } catch (e) {
      errorMessage = 'There was an issue creating the order.';
      notifyListeners();
      return false;
    }
  }
}
