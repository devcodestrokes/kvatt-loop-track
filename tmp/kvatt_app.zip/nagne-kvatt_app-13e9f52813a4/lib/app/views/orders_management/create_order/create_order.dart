import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/orders_management/create_order/create_order_view_model.dart';
import 'package:kvatt_app/app/views/orders_management/widgets/order_form.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:provider/provider.dart';

class CreateOrder extends StatefulWidget {
  final CreateOrderViewModel viewModel;

  const CreateOrder({
    super.key,
    required this.viewModel,
  });

  @override
  State<CreateOrder> createState() => _CreateOrderState();
}

class _CreateOrderState extends State<CreateOrder> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.init();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.3,
            child: Column(
              children: [
                const SizedBox(height: 48.0),
                widget.viewModel.isLoading ? _buildLoading() : _buildForm(),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildLoading() {
    return const LoadingSpinner();
  }

  Widget _buildForm() {
    return OrderForm(
        merchants: widget.viewModel.merchants,
        errorMessage: widget.viewModel.errorMessage,
        onSubmitPressed: (
          Merchant? selectedMerchant,
          String? enteredMerchantName,
          OrderStatus? orderStatus,
          OrderType orderType,
          String? contactEmail,
          String? shippingDetails,
          String product,
          String quantity,
          String? unitPrice,
          String? probability,
          String? tracking,
          String? invoiceLink,
          String? comments,
          DateTime? expectedDeliveryDate,
          DateTime? deliveryDate,
          bool? hasInvoiced,
        ) async {
          LoadingDialog.show(context, 'creating order...');

          bool res = await widget.viewModel.onCreateOrder(
            selectedMerchant: selectedMerchant,
            enteredMerchantName: enteredMerchantName,
            orderType: orderType,
            contactEmail: contactEmail,
            shippingDetails: shippingDetails,
            product: product,
            quantity: quantity,
            unitPrice: unitPrice,
            probability: probability,
          );
          if (!mounted) return;
          Navigator.of(context).pop();
          if (res == true) {
            Provider.of<UiState>(context, listen: false).updateView(ViewConfig(
              appView: AppView.homeOrdersManagement,
              params: {},
            ));
          }
        });
  }
}
