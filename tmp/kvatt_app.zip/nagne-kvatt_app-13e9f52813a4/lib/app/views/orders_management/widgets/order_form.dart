import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/checkbox_field.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/custom_datepicker.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/domain/orders/order.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';
import 'package:kvatt_app/domain/products/available_products.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/app/views/orders_management/order_type_display_name.dart';

import '../order_status_display_name.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class OrderForm extends StatefulWidget {
  final Function(
    Merchant? selectedMerchant,
    String? enteredMerchantName,
    OrderStatus? selectedOrderStatus,
    OrderType orderType,
    String? contactEmail,
    String? shippingDetails,
    String product,
    String quantity,
    String? unitPrice,
    String? probability,
    String? tracking,
    String? invoiceLink,
    String? comments,
    DateTime? expectedDeliveryDate,
    DateTime? deliveryDate,
    bool? selectedHasInvoiced,
  ) onSubmitPressed;
  final List<Merchant> merchants;
  final String? errorMessage;
  final Order? existingOrder;
  final Function? onDeleteOrderPressed;

  const OrderForm({
    super.key,
    required this.onSubmitPressed,
    required this.merchants,
    this.onDeleteOrderPressed,
    this.errorMessage,
    this.existingOrder,
  });

  @override
  State<OrderForm> createState() => _OrderFormState();
}

class _OrderFormState extends State<OrderForm> {
  TextEditingController enteredMerchantNameController = TextEditingController();
  TextEditingController contactEmailController = TextEditingController();
  TextEditingController shippingDetailsController = TextEditingController();
  TextEditingController quantityController = TextEditingController();
  TextEditingController unitPriceController = TextEditingController();
  TextEditingController probabilityController = TextEditingController();
  TextEditingController trackingController = TextEditingController();
  TextEditingController invoiceLinkController = TextEditingController();
  TextEditingController commentsController = TextEditingController();
  TextEditingController expectedDeliveryDateController =
      TextEditingController();
  TextEditingController deliveryDateController = TextEditingController();

  Merchant? _selectedMerchant;
  OrderType? _selectedOrderType;
  String? _selectedProduct;
  OrderStatus? _selectedOrderStatus;
  DateTime? _selectedExpectedDeliveryDate;
  DateTime? _selectedDeliveryDate;
  bool? _selectedHasInvoiced = false;

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    super.initState();
    if (widget.existingOrder != null) {
      if (widget.existingOrder!.merchantId != null) {
        _selectedMerchant = widget.merchants
            .where((Merchant merchant) =>
                merchant.uid == widget.existingOrder!.merchantId)
            .first;
      }

      if (widget.existingOrder!.expectedDeliveryDate != null) {
        _selectedExpectedDeliveryDate =
            widget.existingOrder!.expectedDeliveryDate;
        expectedDeliveryDateController.text =
            DateFormat('dd/MM/yyyy').format(_selectedExpectedDeliveryDate!);
      }

      if (widget.existingOrder!.deliveryDate != null) {
        _selectedDeliveryDate = widget.existingOrder!.deliveryDate;
        deliveryDateController.text =
            DateFormat('dd/MM/yyyy').format(_selectedDeliveryDate!);
      }

      _selectedOrderType = widget.existingOrder!.orderType;
      _selectedProduct = widget.existingOrder!.productType;
      _selectedOrderStatus = widget.existingOrder!.status;

      enteredMerchantNameController.text =
          widget.existingOrder!.merchantName ?? '';
      contactEmailController.text = widget.existingOrder!.contactEmail ?? '';
      shippingDetailsController.text =
          widget.existingOrder!.shippingDetails ?? '';
      quantityController.text = widget.existingOrder!.quantity.toString();
      unitPriceController.text = widget.existingOrder!.unitPriceInGBP != null
          ? widget.existingOrder!.unitPriceInGBP.toString()
          : '';
      probabilityController.text = widget.existingOrder!.probability != null
          ? widget.existingOrder!.probability.toString()
          : '';
      trackingController.text = widget.existingOrder!.tracking ?? '';
      invoiceLinkController.text = widget.existingOrder!.invoiceLink ?? '';
      commentsController.text = widget.existingOrder!.comment ?? '';

      _selectedHasInvoiced = widget.existingOrder!.hasInvoiced ?? false;
    }
  }

  @override
  Widget build(BuildContext context) {
    List<String> merchantsDropdownItems =
        widget.merchants.map((Merchant merchant) => merchant.name).toList();
    merchantsDropdownItems.insert(0, 'None');
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            widget.existingOrder != null ? 'Edit order' : 'Create order',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 36.0),
          widget.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          Text(
            'Merchant details',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 16.0),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Select an existing merchant from the dropdown',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
            ),
          ),
          const SizedBox(height: 16.0),
          DropDownFieldBlack(
            validator: (String? value) {
              if (enteredMerchantNameController.text.trim().isEmpty) {
                String? validMessage = Validators.validateNotEmpty(
                    value, 'Please select a merchant');
                if (validMessage != null) {
                  return validMessage;
                }
                if (_selectedMerchant == null) {
                  return 'Please select a merchant';
                }
                return null;
              }
              return null;
            },
            label: 'Select existing merchant',
            items: merchantsDropdownItems,
            onItemSelected: (String item) {
              if (item == 'None') {
                _selectedMerchant = null;
              } else {
                _selectedMerchant = widget.merchants
                    .where((Merchant merchant) => merchant.name == item)
                    .first;
                if (contactEmailController.text.trim().isEmpty) {
                  contactEmailController.text = _selectedMerchant?.email ?? '';
                }
              }
            },
            initialValue:
                _selectedMerchant != null ? _selectedMerchant!.name : null,
          ),
          const SizedBox(height: 16.0),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              '...or manually enter the merchant name below',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
            ),
          ),
          const SizedBox(height: 16.0),
          TextFieldBlack(
            validator: (String? name) {
              if (_selectedMerchant == null) {
                return Validators.validateNotEmpty(
                    name, 'Please enter the merchant name');
              }
              return null;
            },
            label: 'Merchant name',
            keyboardType: TextInputType.text,
            controller: enteredMerchantNameController,
          ),
          const SizedBox(height: 36.0),
          Text(
            'Order details',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          widget.existingOrder != null
              ? Column(
                  children: [
                    DropDownFieldBlack(
                      validator: (String? value) => Validators.validateNotEmpty(
                          value, 'Please select the order status.'),
                      label: 'Select order status',
                      items: OrderStatus.values.map((OrderStatus status) {
                        return orderStatusDisplayNameMap[status]!;
                      }).toList(),
                      onItemSelected: (String item) {
                        _selectedOrderStatus = displayNameOrderStatusMap[item];
                      },
                      initialValue:
                          orderStatusDisplayNameMap[_selectedOrderStatus],
                    ),
                    const SizedBox(height: 16.0),
                  ],
                )
              : const SizedBox(),
          DropDownFieldBlack(
            validator: (String? value) => Validators.validateNotEmpty(
                value, 'Please select an order type.'),
            label: 'Select order type',
            items: OrderType.values.map((OrderType type) {
              return orderTypeDisplayNameMap[type]!;
            }).toList(),
            onItemSelected: (String item) {
              _selectedOrderType = displayNameOrderTypeMap[item];
            },
            initialValue: widget.existingOrder != null
                ? orderTypeDisplayNameMap[_selectedOrderType]
                : null,
          ),
          const SizedBox(height: 16.0),
          DropDownFieldBlack(
            validator: (String? value) =>
                Validators.validateNotEmpty(value, 'Please select a product.'),
            label: 'Select product',
            items: availableProducts,
            onItemSelected: (String item) {
              _selectedProduct = item;
            },
            initialValue:
                widget.existingOrder != null ? _selectedProduct : null,
          ),
          const SizedBox(height: 16.0),
          TextFieldBlack(
            validator: (String? quantity) => Validators.validateNotEmpty(
                quantity, 'Please enter the quantity.'),
            label: 'Quantity',
            keyboardType: TextInputType.number,
            controller: quantityController,
          ),
          const SizedBox(height: 16.0),
          TextFieldBlack(
            validator: (String? unitPrice) => Validators.validateIsNumeric(
                unitPrice, 'The unit price needs to be a valid number.'),
            label: 'Unit price (£)',
            keyboardType: TextInputType.text,
            controller: unitPriceController,
          ),
          const SizedBox(height: 36.0),
          Text(
            'Contact and shipping details',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          TextFieldBlack(
            validator: (String? email) {
              if (email != null && email.isEmpty) return null;
              return Validators.validateEmail(email);
            },
            label: 'Contact email',
            keyboardType: TextInputType.emailAddress,
            controller: contactEmailController,
          ),
          const SizedBox(height: 16.0),
          TextFieldBlack(
            validator: (String? details) => null,
            label: 'Shipping details',
            keyboardType: TextInputType.text,
            controller: shippingDetailsController,
          ),
          widget.existingOrder != null
              ? Column(
                  children: [
                    const SizedBox(height: 16.0),
                    TextFieldBlack(
                      validator: (String? tracking) => null,
                      label: 'Tracking',
                      keyboardType: TextInputType.text,
                      controller: trackingController,
                    ),
                  ],
                )
              : const SizedBox(),
          widget.existingOrder != null
              ? Column(
                  children: [
                    const SizedBox(height: 16.0),
                    CustomDatePicker(
                      textController: expectedDeliveryDateController,
                      label: 'Expected delivery date',
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.parse('2050-01-01'),
                      onDateSelected: (DateTime date) {
                        expectedDeliveryDateController.text =
                            DateFormat('dd/MM/yyyy').format(date);
                        _selectedExpectedDeliveryDate = date;
                      },
                      isEnabled: true,
                    ),
                    const SizedBox(height: 16.0),
                    CustomDatePicker(
                      textController: deliveryDateController,
                      label: 'Delivery date',
                      initialDate: DateTime.now(),
                      firstDate: DateTime.now(),
                      lastDate: DateTime.parse('2050-01-01'),
                      onDateSelected: (DateTime date) {
                        deliveryDateController.text =
                            DateFormat('dd/MM/yyyy').format(date);
                        _selectedDeliveryDate = date;
                      },
                      isEnabled: true,
                    ),
                  ],
                )
              : const SizedBox(),
          widget.existingOrder != null
              ? Column(
                  children: [
                    const SizedBox(height: 36.0),
                    Text(
                      'Payment details',
                      style: Theme.of(context).textTheme.titleSmall?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceHighEmphasis,
                          ),
                    ),
                    const SizedBox(height: 24.0),
                    CheckboxField(
                      label: 'Has invoiced?',
                      value: _selectedHasInvoiced ?? false,
                      onChanged: (bool value) {
                        _selectedHasInvoiced = value;
                      },
                    ),
                    const SizedBox(height: 16.0),
                    TextFieldBlack(
                      validator: (String? invoiceLink) => null,
                      label: 'Invoice link',
                      keyboardType: TextInputType.text,
                      controller: invoiceLinkController,
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 36.0),
          Text(
            'Miscellaneous',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          TextFieldBlack(
            validator: (String? probability) => Validators.validateIsProbability(
                probability,
                'The probability value should be a number equal to or less than 100'),
            label: 'Probability (%)',
            keyboardType: TextInputType.number,
            controller: probabilityController,
          ),
          widget.existingOrder != null
              ? Column(
                  children: [
                    const SizedBox(height: 24.0),
                    TextFieldBlack(
                      validator: (String? probability) => null,
                      label: 'Comments',
                      keyboardType: TextInputType.text,
                      controller: commentsController,
                      maxLines: 5,
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 48.0),
          PrimaryButton(
            label: widget.existingOrder != null ? 'Save' : 'Create order',
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                await widget.onSubmitPressed(
                  _selectedMerchant,
                  enteredMerchantNameController.text.trim() == ''
                      ? null
                      : enteredMerchantNameController.text.trim(),
                  _selectedOrderStatus,
                  _selectedOrderType!,
                  contactEmailController.text.trim() == ''
                      ? null
                      : contactEmailController.text.trim(),
                  shippingDetailsController.text.trim() == ''
                      ? null
                      : shippingDetailsController.text.trim(),
                  _selectedProduct!,
                  quantityController.text.trim(),
                  unitPriceController.text.trim() == ''
                      ? null
                      : unitPriceController.text.trim(),
                  probabilityController.text.trim() == ''
                      ? null
                      : probabilityController.text.trim(),
                  trackingController.text.trim() == ''
                      ? null
                      : trackingController.text.trim(),
                  invoiceLinkController.text.trim() == ''
                      ? null
                      : invoiceLinkController.text.trim(),
                  commentsController.text.trim() == ''
                      ? null
                      : commentsController.text.trim(),
                  _selectedExpectedDeliveryDate,
                  _selectedDeliveryDate,
                  _selectedHasInvoiced,
                );
              }
            },
          ),
          widget.existingOrder != null && widget.onDeleteOrderPressed != null
              ? Column(
                  children: [
                    const SizedBox(height: 48.0),
                    PromptTextButton(
                      promptText: '',
                      actionLabel: 'Delete Order',
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text(
                                'Are you sure you want to delete this order?',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(
                                      fontSize: 20.0,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceHighEmphasis,
                                    ),
                              ),
                              content: Text(
                                'By deleting this order you will lose all information associated with that order.',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Text(
                                    'No, go back.',
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelLarge
                                        ?.copyWith(
                                            color:
                                                Theme.of(context).primaryColor),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () =>
                                      widget.onDeleteOrderPressed!(),
                                  child: Text(
                                    'Yes, delete order.',
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelLarge
                                        ?.copyWith(
                                            color: Theme.of(context)
                                                .colorScheme
                                                .secondaryColor),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 24.0),
        ],
      ),
    );
  }

  @override
  void dispose() {
    enteredMerchantNameController.dispose();
    contactEmailController.dispose();
    shippingDetailsController.dispose();
    quantityController.dispose();
    unitPriceController.dispose();
    probabilityController.dispose();
    trackingController.dispose();
    invoiceLinkController.dispose();
    expectedDeliveryDateController.dispose();
    deliveryDateController.dispose();
    super.dispose();
  }
}
