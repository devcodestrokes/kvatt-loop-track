import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/orders/order.dart';
import 'package:kvatt_app/domain/orders/order_manager.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

class OrderViewData {
  Order order;
  String? merchantName;
  bool isExpanded;

  OrderViewData({
    required this.order,
    required this.isExpanded,
    required this.merchantName,
  });
}

class OrdersManagementViewModel extends ChangeNotifier {
  OrderManager orderManager;
  UserManager userManager;
  UiState uiState;

  List<OrderViewData>? ordersData;

  int displayPerPage = 20;
  int startOrderNumber = 1;
  int? lastOrderNumber;
  int? firstOrderNumber;

  OrderStatus? _selectedStatus;

  OrdersManagementViewModel({
    required this.orderManager,
    required this.userManager,
    required this.uiState,
  });

  Future<void> init() async {
    _reloadOrdersData();
  }

  bool get showNextButton => ordersData?.last.order.number != lastOrderNumber;

  bool get showPreviousButton =>
      ordersData?.first.order.number != firstOrderNumber;

  onDisplayPerPageChanged(int? displayPerPage) {
    this.displayPerPage = displayPerPage ?? 20;
    _reloadOrdersData();
  }

  onPreviousPageTapped() {
    int firstDisplayedOrderNumber = ordersData?.first.order.number ?? 1;
    startOrderNumber = firstDisplayedOrderNumber - displayPerPage;
    _reloadOrdersData();
  }

  onNextPageTapped() {
    int lastDisplayedOrderNumber = ordersData?.last.order.number ?? 1;
    startOrderNumber = lastDisplayedOrderNumber + 1;
    _reloadOrdersData();
  }

  onRowExpansionToggled({
    required int rowIndex,
    required bool isExpanded,
  }) async {
    if (ordersData == null) return;

    OrderViewData rowData = ordersData![rowIndex];
    rowData.isExpanded = !isExpanded;
    notifyListeners();
  }

  onOrderStatusSelected(OrderStatus? status) {
    _selectedStatus = status;
    _resetPagination();
    _reloadOrdersData();
  }

  onEditOrderTapped({
    required Order order,
  }) {
    uiState.updateView(ViewConfig(
      appView: AppView.editOrder,
      params: {
        'orderId': order.id,
      },
    ));
  }

  Future<void> _reloadOrdersData() async {
    lastOrderNumber = await orderManager.getLastOrderNumber();
    List<Order> orders = await orderManager.getOrders(
      status: _selectedStatus,
      numOrders: displayPerPage,
      startAtOrderNumber: startOrderNumber,
    );

    ordersData = orders.map((Order order) {
      return OrderViewData(
        order: order,
        isExpanded: false,
        merchantName: _determineMerchantName(order),
      );
    }).toList();

    if (ordersData != null && ordersData!.isNotEmpty) {
      firstOrderNumber ??= ordersData?.first.order.number;
    }

    notifyListeners();
  }

  String? _determineMerchantName(Order order) {
    if (order.merchantId == null && order.merchantName == null) {
      return 'N/A';
    } else if (order.merchantId == null) {
      return order.merchantName;
    } else {
      _fetchMerchantName(order);
      return null;
    }
  }

  _fetchMerchantName(Order order) async {
    try {
      Merchant merchant =
          await userManager.findUser(userId: order.merchantId!) as Merchant;
      OrderViewData? data = ordersData?.firstWhere(
          (OrderViewData data) => data.order.number == order.number);
      if (data != null) {
        data.merchantName = merchant.name;
        notifyListeners();
      }
      // ignore: empty_catches
    } catch (e) {}
  }

  _resetPagination() {
    displayPerPage = 20;
    startOrderNumber = 1;
    lastOrderNumber = null;
    firstOrderNumber = null;
  }
}
