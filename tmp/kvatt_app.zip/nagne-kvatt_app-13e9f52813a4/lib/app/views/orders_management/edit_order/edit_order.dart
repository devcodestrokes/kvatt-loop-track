import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';

import 'package:kvatt_app/app/views/orders_management/edit_order/edit_order_view_model.dart';
import 'package:kvatt_app/app/views/orders_management/widgets/order_form.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:provider/provider.dart';

import '../../../states/ui_state.dart';

class EditOrder extends StatefulWidget {
  final EditOrderViewModel viewModel;

  const EditOrder({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  State<EditOrder> createState() => _EditOrderState();
}

class _EditOrderState extends State<EditOrder> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.init();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 48.0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 0.3,
              child: _buildContent(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContent() {
    if (widget.viewModel.isLoading == true) {
      return _buildLoading();
    }
    if (widget.viewModel.order == null) {
      return _buildInvalid();
    }
    return _buildForm();
  }

  Widget _buildLoading() {
    return const LoadingSpinner();
  }

  Widget _buildInvalid() {
    return Center(
      child: Text(
        'This order is not valid.',
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
            color: Theme.of(context).colorScheme.onSurfaceHighEmphasis),
      ),
    );
  }

  Widget _buildForm() {
    return OrderForm(
      onSubmitPressed: (
        Merchant? selectedMerchant,
        String? enteredMerchantName,
        OrderStatus? orderStatus,
        OrderType orderType,
        String? contactEmail,
        String? shippingDetails,
        String product,
        String quantity,
        String? unitPrice,
        String? probability,
        String? tracking,
        String? invoiceLink,
        String? comments,
        DateTime? expectedDeliveryDate,
        DateTime? deliveryDate,
        bool? hasInvoiced,
      ) async {
        LoadingDialog.show(context, 'saving order...');

        bool res = await widget.viewModel.onEditOrder(
          selectedMerchant: selectedMerchant,
          enteredMerchantName: enteredMerchantName,
          orderStatus: orderStatus,
          orderType: orderType,
          contactEmail: contactEmail,
          shippingDetails: shippingDetails,
          product: product,
          quantity: quantity,
          unitPrice: unitPrice,
          probability: probability,
          tracking: tracking,
          invoiceLink: invoiceLink,
          comments: comments,
          expectedDeliveryDate: expectedDeliveryDate,
          deliveryDate: deliveryDate,
          hasInvoiced: hasInvoiced,
        );
        if (!mounted) return;
        Navigator.of(context).pop();
        if (res == true) {
          Provider.of<UiState>(context, listen: false).updateView(ViewConfig(
            appView: AppView.homeOrdersManagement,
            params: {},
          ));
        }
      },
      onDeleteOrderPressed: () async {
        LoadingDialog.show(context, 'deleting order...');
        bool res = await widget.viewModel.onDeleteOrderPressed();
        if (!mounted) return;
        Navigator.of(context).pop();
        Navigator.of(context).pop();
        if (res == true) {
          Provider.of<UiState>(context, listen: false).updateView(ViewConfig(
            appView: AppView.homeOrdersManagement,
            params: {},
          ));
        }
      },
      merchants: widget.viewModel.merchants,
      errorMessage: widget.viewModel.errorMessage,
      existingOrder: widget.viewModel.order,
    );
  }
}
