import 'package:flutter/material.dart';
import 'package:kvatt_app/domain/orders/order.dart';
import 'package:kvatt_app/domain/orders/order_manager.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

class EditOrderViewModel extends ChangeNotifier {
  OrderManager orderManager;
  UserManager userManager;

  String? orderId;

  List<Merchant> merchants = [];
  Order? order;

  String? errorMessage;

  bool isLoading = true;

  EditOrderViewModel({
    required this.orderManager,
    required this.userManager,
    required this.orderId,
  });

  Future<void> init() async {
    if (orderId == null) {
      isLoading = false;
      notifyListeners();
      return;
    }

    order = await orderManager.getOrderById(id: orderId!);

    merchants = await userManager.retrieveActiveMerchants();

    isLoading = false;
    notifyListeners();
  }

  Future<bool> onEditOrder({
    required Merchant? selectedMerchant,
    required String? enteredMerchantName,
    required OrderStatus? orderStatus,
    required OrderType orderType,
    required String? contactEmail,
    required String? shippingDetails,
    required String product,
    required String quantity,
    required String? unitPrice,
    required String? probability,
    required String? tracking,
    required String? invoiceLink,
    required String? comments,
    required DateTime? expectedDeliveryDate,
    required DateTime? deliveryDate,
    required bool? hasInvoiced,
  }) async {
    try {
      await orderManager.updateOrder(
        previousOrder: order!,
        orderType: orderType,
        orderStatus: orderStatus ?? order!.status,
        product: product,
        quantity: int.parse(quantity),
        merchantId: selectedMerchant?.uid,
        merchantName: selectedMerchant == null ? enteredMerchantName : null,
        contactEmail: contactEmail,
        shippingDetails: shippingDetails,
        unitPriceInGBP: unitPrice != null && unitPrice.isNotEmpty
            ? double.parse(unitPrice)
            : null,
        probability: probability != null && probability.isNotEmpty
            ? double.parse(probability)
            : null,
        tracking: tracking,
        invoiceLink: invoiceLink,
        comments: comments,
        expectedDeliveryDate: expectedDeliveryDate,
        deliveryDate: deliveryDate,
        hasInvoiced: hasInvoiced,
      );
      return true;
    } catch (e) {
      errorMessage = 'There was an issue saving the order';
      notifyListeners();
      return false;
    }
  }

  Future<bool> onDeleteOrderPressed() async {
    try {
      await orderManager.deleteOrder(orderId: order!.id);
      return true;
    } catch (e) {
      errorMessage = 'There was an issue deleting this order.';
      notifyListeners();
      return false;
    }
  }
}
