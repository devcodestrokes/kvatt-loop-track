import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/views/orders_management/edit_order/edit_order.dart';
import 'package:kvatt_app/app/views/orders_management/edit_order/edit_order_view_model.dart';
import 'package:kvatt_app/domain/orders/order_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class EditOrderFactory {
  static Widget build({
    required String orderId,
  }) {
    return ChangeNotifierProvider<EditOrderViewModel>(
      create: (context) {
        return EditOrderViewModel(
          orderManager: Provider.of<OrderManager>(
            context,
            listen: false,
          ),
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          orderId: orderId,
        );
      },
      child: Consumer<EditOrderViewModel>(
        builder: (context, model, child) => EditOrder(
          viewModel: model,
        ),
      ),
    );
  }
}
