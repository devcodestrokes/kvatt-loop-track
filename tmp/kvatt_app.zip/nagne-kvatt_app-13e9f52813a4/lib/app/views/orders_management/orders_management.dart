import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/common/widgets/tables/paginator.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/orders_management/order_details/order_details.dart';
import 'package:kvatt_app/app/views/orders_management/order_status_display_name.dart';
import 'package:kvatt_app/app/views/orders_management/order_type_display_name.dart';
import 'package:kvatt_app/app/views/orders_management/orders_management_view_model.dart';
import 'package:kvatt_app/domain/orders/order.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';

import '../../common/widgets/form_fields/drop_down_field_black.dart';

class OrdersManagement extends StatefulWidget {
  final OrdersManagementViewModel viewModel;

  const OrdersManagement({
    super.key,
    required this.viewModel,
  });

  @override
  State<OrdersManagement> createState() => _OrdersManagementState();
}

class _OrdersManagementState extends State<OrdersManagement> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      widget.viewModel.init();
    });
  }

  @override
  Widget build(BuildContext context) {
    return widget.viewModel.ordersData == null
        ? const LoadingSpinner()
        : SingleChildScrollView(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 24.0),
              child: Column(children: [
                _buildFilters(),
                const SizedBox(height: 16.0),
                widget.viewModel.ordersData!.isEmpty
                    ? Column(
                        children: [
                          const SizedBox(height: 60.0),
                          Text(
                            'No orders have been created yet.',
                            style: Theme.of(context)
                                .textTheme
                                .bodyMedium
                                ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceDisabled),
                          ),
                        ],
                      )
                    : SizedBox(
                        width: MediaQuery.of(context).size.width,
                        child: _buildTable(),
                      ),
              ]),
            ),
          );
  }

  Widget _buildFilters() {
    List<String> orderStatusNames = OrderStatus.values
        .map((OrderStatus status) => orderStatusDisplayNameMap[status]!)
        .toList();
    orderStatusNames = [
      ...['All'],
      ...orderStatusNames,
    ];

    return Container(
      padding: const EdgeInsets.fromLTRB(24.0, 24.0, 24.0, 24.0),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceColor,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.max,
        mainAxisAlignment: MainAxisAlignment.end,
        children: [
          SizedBox(
            width: 300.0,
            child: DropDownFieldBlack(
              label: 'Status',
              items: orderStatusNames,
              onItemSelected: (String status) {
                if (status == 'All') {
                  widget.viewModel.onOrderStatusSelected(null);
                } else {
                  widget.viewModel
                      .onOrderStatusSelected(displayNameOrderStatusMap[status]);
                }
              },
              initialValue: 'All',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTable() {
    return Column(
      children: [
        _buildTableHeader(),
        ExpansionPanelList(
          expansionCallback: (int index, bool isExpanded) =>
              widget.viewModel.onRowExpansionToggled(
            rowIndex: index,
            isExpanded: isExpanded,
          ),
          children: widget.viewModel.ordersData!.map((OrderViewData data) {
            return ExpansionPanel(
              headerBuilder: (BuildContext context, bool isExpanded) {
                return _buildContentHeader(data);
              },
              body: _buildContentBody(data.order),
              isExpanded: data.isExpanded,
            );
          }).toList(),
        ),
        Paginator(
          initialDisplayPerPage: widget.viewModel.displayPerPage,
          onDisplayPerPageChanged: (int? value) =>
              widget.viewModel.onDisplayPerPageChanged(value),
          onPreviousPageTapped: widget.viewModel.showPreviousButton
              ? () => widget.viewModel.onPreviousPageTapped()
              : null,
          onNextPageTapped: widget.viewModel.showNextButton
              ? () => widget.viewModel.onNextPageTapped()
              : null,
        ),
      ],
    );
  }

  Widget _buildTableHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16.0, 16.0, 80.0, 16.0),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineColor,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text(
              'Order no.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              'Merchant',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              'Order Type',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              'Product',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              'Quantity',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              'Status',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          const Expanded(
            flex: 1,
            child: Text(
              '',
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContentHeader(OrderViewData data) {
    return Padding(
      padding: const EdgeInsets.all(16.0),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text(
              data.order.number.toString().padLeft(5, '0'),
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: data.merchantName == null
                ? Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.only(left: 8.0),
                        width: 12.0,
                        height: 12.0,
                        child: const LoadingSpinner(),
                      ),
                    ],
                  )
                : Text(
                    data.merchantName!,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              orderTypeDisplayNameMap[data.order.orderType] ?? '',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              data.order.productType,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              data.order.quantity.toString(),
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              orderStatusDisplayNameMap[data.order.status] ?? '',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 1,
            child: IconButton(
              onPressed: () =>
                  widget.viewModel.onEditOrderTapped(order: data.order),
              icon: Icon(
                Icons.edit,
                size: 16.0,
                color: Theme.of(context).colorScheme.onSurfaceDisabled,
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildContentBody(Order order) {
    return OrderDetails(
      order: order,
    );
  }
}
