import 'package:kvatt_app/domain/orders/order_type.dart';

Map<OrderType, String> orderTypeDisplayNameMap = {
  OrderType.other: 'Other',
  OrderType.pilot: 'Pilot',
  OrderType.samples: 'Samples',
  OrderType.subscription: 'Subscription',
  OrderType.wholesale: 'Wholesale',
};

Map<String, OrderType> displayNameOrderTypeMap = {
  'Other': OrderType.other,
  'Pilot': OrderType.pilot,
  'Samples': OrderType.samples,
  'Subscription': OrderType.subscription,
  'Wholesale': OrderType.wholesale,
};
