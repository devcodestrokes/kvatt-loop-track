import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/views/merchant_packagings_management/widgets/packagings_table/packagings_table_filters.dart';
import 'package:kvatt_app/domain/contracts/packaging_info.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:kvatt_core/domain/stocks/stock.dart';
import 'package:kvatt_core/domain/stocks/stocks_manager.dart';

class MerchantPackagingsManagementViewModel extends ChangeNotifier {
  PackagingsManager packagingsManager;
  StocksManager stocksManager;

  AuthState authState;

  MerchantPackagingsManagementViewModel({
    required this.packagingsManager,
    required this.stocksManager,
    required this.authState,
  });

  List<Packaging> packagings = [];
  Stock? merchantStock;

  //Filters
  int? _filterSearchPackagingCode;
  String? _filterSearchOrderNumber;
  String? _filterSelectedProduct;
  DateTime? _filterLastTrackedPeriod;

  //Pagination
  int displayPerPage = 20;
  int startPackagingCode = 1;
  int? lastPackagingCode;
  int? firstPackagingCode;

  bool isLoadingTableData = false;

  init() async {
    _reloadPackagings();
    _reloadStocks();
  }

  List<String> get merchantAvailableProducts {
    Set<String> uniqueProductTypes = {};
    List<PackagingInfo> packagings =
        (authState.activeUser as Merchant).contractInfo.packagings;

    for (var packaging in packagings) {
      uniqueProductTypes.add(packaging.packagingType);
    }

    return uniqueProductTypes.toList();
  }

  Future<void> onSaveTapped({
    required Packaging packaging,
    required PackagingStatus? newStatus,
    required String? newOrderNumber,
    required String? newCustomerName,
  }) async {
    //TODO: Should handle case where errors happen during update
    if (newOrderNumber != null && newOrderNumber != packaging.orderNumber) {
      await packagingsManager.updatePackagingOrderNumber(
        packaging: packaging,
        newOrderNumber: newOrderNumber,
      );
      packaging.orderNumber = newOrderNumber;
    }

    if (newCustomerName != null && newCustomerName != packaging.customerName) {
      await packagingsManager.updatePackagingCustomerName(
        packaging: packaging,
        newCustomerName: newCustomerName,
      );
      packaging.customerName = newCustomerName;
    }
    if (newStatus != null && packaging.status != newStatus) {
      switch (newStatus) {
        case PackagingStatus.withMerchantReturned:
          await packagingsManager.recordInboundFromCustomerPackagings(
            merchantId: authState.activeUser!.uid!,
            packagings: [packaging],
          );
          break;
        case PackagingStatus.withCustomer:
          await packagingsManager.recordOutboundToCustomerPackagings(
            merchantId: authState.activeUser!.uid!,
            packagings: [packaging],
            customerName: packaging.customerName ?? '',
            orderNumber: packaging.orderNumber ?? '',
          );
          break;
        default:
          break;
      }
      await _reloadStocks();
    }
    notifyListeners();
  }

  void onTextSearchChanged({
    required String searchText,
  }) {
    _resetPagination();
    if (searchText.isEmpty) {
      if (_filterSearchPackagingCode != null ||
          _filterSearchOrderNumber != null) {
        _filterSearchPackagingCode = null;
        _filterSearchOrderNumber = null;
        _reloadPackagings();
      }
      return;
    }

    packagings = [];
    notifyListeners();

    _filterSearchOrderNumber = searchText;

    _filterSearchPackagingCode = _determinePackagingCode(
      searchString: searchText,
    );

    _reloadPackagings();
  }

  void onProductFilterChanged({
    required String? product,
  }) {
    _filterSelectedProduct = product;
    _resetPagination();
    _reloadPackagings();
  }

  void onLastTrackedFilterChanged({
    required FilterTimePeriod period,
  }) {
    _filterLastTrackedPeriod = _getDateTimeFromTimePeriod(period);
    _resetPagination();
    _reloadPackagings();
  }

  bool get isFilteringBySearch {
    return _filterSearchPackagingCode != null ||
        _filterSearchOrderNumber != null;
  }

  bool get isFilteringByLastTracked {
    return _filterLastTrackedPeriod != null;
  }

  bool get showNextButton =>
      packagings.isNotEmpty &&
      (packagings.last.code != lastPackagingCode) &&
      !isFilteringBySearch &&
      !isFilteringByLastTracked;

  bool get showPreviousButton =>
      packagings.isNotEmpty &&
      (packagings.first.code != firstPackagingCode) &&
      !isFilteringBySearch &&
      !isFilteringByLastTracked;

  onDisplayPerPageChanged({
    required int? value,
  }) {
    displayPerPage = value ?? 20;
    _reloadPackagings();
  }

  onPreviousTapped() {
    int firstDisplayedCode = packagings.first.code;
    startPackagingCode = firstDisplayedCode - displayPerPage;
    _reloadPackagings();
  }

  onNextTapped() {
    int lastDisplayedCode = packagings.last.code;

    startPackagingCode = lastDisplayedCode;
    _reloadPackagings();
  }

  onRefreshTapped() {
    _reloadPackagings();
  }

  _reloadStocks() async {
    merchantStock = await stocksManager.computeMerchantStock(
      merchantId: authState.activeUser!.uid ?? '',
    );
    notifyListeners();
  }

  _reloadPackagings() async {
    _showTableLoading();
    if (!isFilteringBySearch && !isFilteringByLastTracked) {
      lastPackagingCode = await packagingsManager.getLastPackagingCode(
        type: _filterSelectedProduct,
        merchantId: (authState.activeUser as Merchant).uid,
        earliestLastTrackedDate: _filterLastTrackedPeriod,
      );
    }

    if (_filterSearchPackagingCode != null &&
        _filterSearchOrderNumber != null) {
      packagings = await _fetchPackagingsWithBothCodeAndOrderNumberSearch();
    } else {
      packagings = await _fetchPackagingsWithSingleOrNoSearch();
    }

    if (!isFilteringBySearch &&
        !isFilteringByLastTracked &&
        packagings.isNotEmpty) {
      firstPackagingCode ??= packagings.first.code;
    }
    _hideTableLoading();
    notifyListeners();
  }

  Future<List<Packaging>> _fetchPackagingsWithSingleOrNoSearch() async {
    return await packagingsManager.getPackagings(
      type: _filterSelectedProduct,
      earliestLastTrackedDate: _filterLastTrackedPeriod,
      code: _filterSearchPackagingCode,
      orderNumber: _filterSearchOrderNumber,
      merchantId: (authState.activeUser as Merchant).uid,
      numPackagings: isFilteringBySearch || isFilteringByLastTracked
          ? null
          : displayPerPage,
      startAtPackagingCode: isFilteringBySearch || isFilteringByLastTracked
          ? null
          : startPackagingCode,
    );
  }

  Future<List<Packaging>>
      _fetchPackagingsWithBothCodeAndOrderNumberSearch() async {
    //If we have both a valid code and order number to search by
    //we need to make two separate queries
    List<Future<List<Packaging>>> fetchTasks = [];
    fetchTasks.add(
      packagingsManager.getPackagings(
        type: _filterSelectedProduct,
        earliestLastTrackedDate: _filterLastTrackedPeriod,
        code: _filterSearchPackagingCode,
        orderNumber: null,
        merchantId: (authState.activeUser as Merchant).uid,
        numPackagings: isFilteringBySearch || isFilteringByLastTracked
            ? null
            : displayPerPage,
        startAtPackagingCode: isFilteringBySearch || isFilteringByLastTracked
            ? null
            : startPackagingCode,
      ),
    );
    fetchTasks.add(
      packagingsManager.getPackagings(
        type: _filterSelectedProduct,
        earliestLastTrackedDate: _filterLastTrackedPeriod,
        code: null,
        orderNumber: _filterSearchOrderNumber,
        merchantId: (authState.activeUser as Merchant).uid,
        numPackagings: isFilteringBySearch || isFilteringByLastTracked
            ? null
            : displayPerPage,
        startAtPackagingCode: isFilteringBySearch || isFilteringByLastTracked
            ? null
            : startPackagingCode,
      ),
    );
    List<List<Packaging>> results = await Future.wait(fetchTasks);
    return results.expand((element) => element).toList();
  }

  int? _determinePackagingCode({
    required String searchString,
  }) {
    if (searchString.length != 5) {
      return null;
    }
    int? value = int.tryParse(searchString);

    if (value == 0) {
      return null;
    }

    return value;
  }

  _resetPagination() {
    displayPerPage = 20;
    startPackagingCode = 1;
    lastPackagingCode = null;
    firstPackagingCode = null;
  }

  void _showTableLoading() {
    isLoadingTableData = true;
    notifyListeners();
  }

  void _hideTableLoading() {
    isLoadingTableData = false;
    notifyListeners();
  }

  DateTime? _getDateTimeFromTimePeriod(FilterTimePeriod? period) {
    if (period == FilterTimePeriod.allTime || period == null) {
      return null;
    }

    if (period == FilterTimePeriod.pastMonth) {
      DateTime now = DateTime.now().toUtc();
      return DateTime(now.year, now.month - 1, now.day);
    }

    int daysToSubtract;

    if (period == FilterTimePeriod.pastWeek) {
      daysToSubtract = 7;
    } else {
      daysToSubtract = 14;
    }

    return DateTime.now().toUtc().subtract(
          Duration(days: daysToSubtract),
        );
  }
}
