import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_header.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/pagination_config.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';

import 'packagings_table_row.dart';

class PackagingsTable extends StatelessWidget {
  final List<Packaging> packagings;
  final Function(Packaging, PackagingStatus?, String?, String?) onSaveTapped;
  final bool isLoading;
  final int initialDisplayPerPage;
  final Function(int?)? onDisplayPerPageChanged;
  final Function()? onPreviousTapped;
  final Function()? onNextTapped;

  const PackagingsTable({
    super.key,
    required this.packagings,
    required this.onSaveTapped,
    required this.isLoading,
    required this.initialDisplayPerPage,
    required this.onDisplayPerPageChanged,
    required this.onPreviousTapped,
    required this.onNextTapped,
  });

  @override
  Widget build(BuildContext context) {
    return CustomTable(
      isLoading: isLoading,
      emptyStateMessage: 'No packs match your current filters.',
      backgroundColor: Theme.of(context).colorScheme.backgroundColor,
      borderRadius: const BorderRadius.all(
        Radius.circular(20.0),
      ),
      headers: [
        HeaderConfig(
          label: 'ID',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Product Type',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Last Tracked',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Status',
          expandFlex: 3,
        ),
        HeaderConfig(
          label: 'Order ID',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: 'Customer Name',
          expandFlex: 2,
        ),
        HeaderConfig(
          label: '',
          expandFlex: 2,
        ),
      ],
      rows: packagings.map((Packaging packaging) {
        return PackagingsTableRow(
          code: packaging.code,
          type: packaging.type,
          lastTracked: packaging.lastTracked,
          status: packaging.status,
          orderNumber: packaging.orderNumber,
          customerName: packaging.customerName,
          onSaveTapped: (PackagingStatus? status, String? orderNumber,
              String? customerName) async {
            return await onSaveTapped(
              packaging,
              status,
              orderNumber,
              customerName,
            );
          },
        );
      }).toList(),
      paginationConfig: PaginationConfig(
        initialDisplayPerPage: initialDisplayPerPage,
        onDisplayPerPageChanged: onDisplayPerPageChanged,
        onPreviousTapped: onPreviousTapped,
        onNextTapped: onNextTapped,
      ),
    );
  }
}
