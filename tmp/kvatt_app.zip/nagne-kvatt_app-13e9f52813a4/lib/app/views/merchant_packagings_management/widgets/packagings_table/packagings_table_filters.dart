import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';

enum FilterTimePeriod {
  allTime,
  pastWeek,
  pastTwoWeeks,
  pastMonth,
}

class PackagingsTableFilters extends StatelessWidget {
  final TextEditingController controller;
  final List<String> availableProductsSelection;
  final Function(String?) onProductSelected;
  final Function(FilterTimePeriod) onLastTrackedSelected;

  const PackagingsTableFilters({
    super.key,
    required this.controller,
    required this.availableProductsSelection,
    required this.onProductSelected,
    required this.onLastTrackedSelected,
  });

  String _filterTimePeriodToString(FilterTimePeriod period) {
    switch (period) {
      case FilterTimePeriod.allTime:
        return 'All time';
      case FilterTimePeriod.pastWeek:
        return 'Past week';
      case FilterTimePeriod.pastTwoWeeks:
        return 'Past two weeks';
      case FilterTimePeriod.pastMonth:
        return 'Past month';
    }
  }

  FilterTimePeriod _stringToFilterTimePeriod(String period) {
    switch (period) {
      case 'All time':
        return FilterTimePeriod.allTime;
      case 'Past week':
        return FilterTimePeriod.pastWeek;
      case 'Past two weeks':
        return FilterTimePeriod.pastTwoWeeks;
      case 'Past month':
        return FilterTimePeriod.pastMonth;
      default:
        return FilterTimePeriod.allTime;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        SizedBox(
          width: 300.0,
          child: DropDownFieldBlack(
            label: 'Product',
            items: [
              ...['All'],
              ...availableProductsSelection,
            ],
            onItemSelected: (String item) {
              if (item == 'All') {
                onProductSelected(null);
              } else {
                onProductSelected(item);
              }
            },
            initialValue: 'All',
          ),
        ),
        const SizedBox(width: 16.0),
        SizedBox(
          width: 300.0,
          child: DropDownFieldBlack(
            label: 'Last Tracked',
            items: [
              _filterTimePeriodToString(FilterTimePeriod.allTime),
              _filterTimePeriodToString(FilterTimePeriod.pastWeek),
              _filterTimePeriodToString(FilterTimePeriod.pastTwoWeeks),
              _filterTimePeriodToString(FilterTimePeriod.pastMonth),
            ],
            onItemSelected: (String item) {
              onLastTrackedSelected(
                _stringToFilterTimePeriod(item),
              );
            },
            initialValue: _filterTimePeriodToString(FilterTimePeriod.allTime),
          ),
        ),
        const SizedBox(width: 32.0),
        SizedBox(
          width: 300.0,
          child: TextFieldBlack(
            validator: (String? text) {},
            label: 'Search by ID or Order ID',
            keyboardType: TextInputType.text,
            controller: controller,
          ),
        ),
      ],
    );
  }
}
