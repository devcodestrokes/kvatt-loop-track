import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class StockDetails extends StatelessWidget {
  final Map<String, int> stockLevels;
  final double? width;
  final double? height;

  const StockDetails({
    super.key,
    required this.stockLevels,
    this.width,
    this.height,
  });

  Widget _buildStockRow(
    BuildContext context, {
    required String name,
    required int? value,
  }) {
    return Container(
      width: 200.0,
      padding: const EdgeInsets.only(bottom: 4.0),
      decoration: BoxDecoration(
        border: Border(
          bottom: BorderSide(
            color: Theme.of(context).colorScheme.outlineColor,
          ),
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Text(
              NumberFormat('#,###,###.#').format(
                value,
              ),
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
              textAlign: TextAlign.right,
            ),
          ),
          Expanded(
            flex: 1,
            child: Text(
              name,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
              textAlign: TextAlign.right,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStockDetails(BuildContext context) {
    List<Widget> items = [];
    for (int i = 0; i < stockLevels.keys.length; i++) {
      items.add(
        _buildStockRow(
          context,
          name: stockLevels.keys.toList()[i],
          value: stockLevels[stockLevels.keys.toList()[i]],
        ),
      );
    }

    return Wrap(
      direction: Axis.vertical,
      spacing: 4.0,
      runSpacing: 32.0,
      children: items,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      padding: const EdgeInsets.fromLTRB(32.0, 16.0, 32.0, 16.0),
      color: Theme.of(context).colorScheme.backgroundColor,
      child: _buildStockDetails(context),
    );
  }
}
