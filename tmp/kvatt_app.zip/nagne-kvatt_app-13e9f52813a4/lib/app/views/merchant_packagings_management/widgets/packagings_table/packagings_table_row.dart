import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/common/widgets/tables/custom_table/custom_table_cell.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';

class PackagingsTableRow extends StatefulWidget {
  final int? code;
  final String? type;
  final DateTime? lastTracked;
  final PackagingStatus? status;
  final String? orderNumber;
  final String? customerName;
  final Future<void> Function(PackagingStatus?, String?, String?) onSaveTapped;

  const PackagingsTableRow({
    super.key,
    required this.code,
    required this.type,
    required this.lastTracked,
    required this.status,
    required this.orderNumber,
    required this.customerName,
    required this.onSaveTapped,
  });

  @override
  State<PackagingsTableRow> createState() => _PackagingsTableRowState();
}

class _PackagingsTableRowState extends State<PackagingsTableRow> {
  bool _isEditing = false;
  bool _isSaving = false;

  TextEditingController orderNumberTextController = TextEditingController();
  TextEditingController customerNameTextController = TextEditingController();
  String? _selectedStatus;

  String _getDisplayNameFromStatus({
    required PackagingStatus? status,
  }) {
    switch (status) {
      case PackagingStatus.enRouteToMerchant:
        return 'En route';
      case PackagingStatus.withMerchant:
        return 'In Stock';
      case PackagingStatus.withMerchantReturned:
        return 'Returned';
      case PackagingStatus.withCustomer:
        return 'With Customer';

      default:
        return 'n/a';
    }
  }

  PackagingStatus? _getPackagingStatusFromDisplayName({
    required String? name,
  }) {
    switch (name) {
      case 'In Stock':
        return PackagingStatus.withMerchant;
      case 'Returned':
        return PackagingStatus.withMerchantReturned;
      case 'With Customer':
        return PackagingStatus.withCustomer;
      default:
        return null;
    }
  }

  Widget _buildSaveButton() {
    return TextButton(
      style: ButtonStyle(
        overlayColor: MaterialStateProperty.resolveWith<Color>(
          (Set<MaterialState> states) {
            return Colors.transparent;
          },
        ),
      ),
      onPressed: () async {
        setState(() {
          _isSaving = true;
        });
        await widget.onSaveTapped(
          _getPackagingStatusFromDisplayName(name: _selectedStatus),
          orderNumberTextController.text.trim(),
          customerNameTextController.text.trim(),
        );
        setState(() {
          _isSaving = false;
          _isEditing = false;
        });
      },
      child: Text(
        'Save',
        style: Theme.of(context).textTheme.labelLarge?.copyWith(
              color: Theme.of(context).colorScheme.secondaryColor,
            ),
      ),
    );
  }

  Widget _buildEditButton({
    required bool isEnabled,
  }) {
    return IconButton(
      onPressed: isEnabled == false
          ? null
          : () {
              setState(() {
                _isEditing = true;
              });
            },
      splashRadius: 24.0,
      icon: Icon(
        Icons.edit,
        size: 16.0,
        color: isEnabled
            ? Theme.of(context).colorScheme.onSurfaceMediumEmphasis
            : Theme.of(context).colorScheme.onSurfaceDisabled,
      ),
    );
  }

  Widget _buildAction() {
    if (_isSaving) {
      return const LoadingSpinner(
        width: 24.0,
        height: 24.0,
      );
    }
    if (_isEditing) {
      return _buildSaveButton();
    }
    return _buildEditButton(
      isEnabled: widget.status != PackagingStatus.enRouteToMerchant,
    );
  }

  CustomTableCell _buildStatusCell() {
    switch (widget.status) {
      case PackagingStatus.enRouteToMerchant:
        return CustomTableCell.readonly(
          text: _getDisplayNameFromStatus(status: widget.status),
          expandFlex: 3,
          isEnabled: false,
        );
      case PackagingStatus.withMerchant:
        return CustomTableCell.dropdown(
          isEditing: _isEditing,
          items: const [
            'In Stock',
            'With Customer',
          ],
          value: _getDisplayNameFromStatus(status: widget.status),
          onChanged: (String? status) {
            _selectedStatus = status;
          },
          expandFlex: 3,
        );
      case PackagingStatus.withCustomer:
        return CustomTableCell.dropdown(
          isEditing: _isEditing,
          items: const [
            'With Customer',
            'Returned',
          ],
          value: _getDisplayNameFromStatus(status: widget.status),
          onChanged: (String? status) {
            _selectedStatus = status;
          },
          expandFlex: 3,
        );
      case PackagingStatus.withMerchantReturned:
        return CustomTableCell.readonly(
          text: _getDisplayNameFromStatus(status: widget.status),
          expandFlex: 3,
          isEnabled: true,
        );
      default:
        return CustomTableCell.readonly(
          text: 'n/a',
          expandFlex: 3,
          isEnabled: false,
        );
    }
  }

  @override
  void initState() {
    super.initState();
    if (widget.orderNumber != null) {
      orderNumberTextController.text = widget.orderNumber!;
    }
    if (widget.customerName != null) {
      customerNameTextController.text = widget.customerName!;
    }
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 40.0,
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          CustomTableCell.readonly(
            text: widget.code == null
                ? 'n/a'
                : widget.code.toString().padLeft(5, '0'),
            expandFlex: 2,
            isEnabled: widget.status == PackagingStatus.enRouteToMerchant
                ? false
                : true,
          ),
          CustomTableCell.readonly(
            text: widget.type ?? 'n/a',
            expandFlex: 2,
            isEnabled: widget.status == PackagingStatus.enRouteToMerchant
                ? false
                : true,
          ),
          CustomTableCell.readonly(
            text: widget.lastTracked == null
                ? 'n/a'
                : DateFormat('dd.MM.yy').format(widget.lastTracked!),
            expandFlex: 2,
            isEnabled: widget.status == PackagingStatus.enRouteToMerchant
                ? false
                : true,
          ),
          _buildStatusCell(),
          CustomTableCell.editable(
            isEditing: _isEditing,
            controller: orderNumberTextController,
            expandFlex: 2,
          ),
          CustomTableCell.editable(
            isEditing: _isEditing,
            controller: customerNameTextController,
            expandFlex: 2,
          ),
          Expanded(
            flex: 2,
            child: _buildAction(),
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    orderNumberTextController.dispose();
    customerNameTextController.dispose();
    super.dispose();
  }
}
