import 'package:easy_debounce/easy_debounce.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/stat_cards/data_card.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/merchant_packagings_management/merchant_packagings_management_view_model.dart';
import 'package:kvatt_app/app/views/merchant_packagings_management/widgets/packagings_table/packagings_table.dart';
import 'package:kvatt_app/app/views/merchant_packagings_management/widgets/packagings_table/packagings_table_filters.dart';
import 'package:kvatt_app/app/views/merchant_packagings_management/widgets/stock_details.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packaging_status.dart';

class MerchantPackagingsManagement extends StatefulWidget {
  final MerchantPackagingsManagementViewModel viewModel;

  const MerchantPackagingsManagement({
    super.key,
    required this.viewModel,
  });

  @override
  State<MerchantPackagingsManagement> createState() =>
      _MerchantPackagingsManagementState();
}

class _MerchantPackagingsManagementState
    extends State<MerchantPackagingsManagement> {
  TextEditingController searchTextController = TextEditingController();

  bool _showStockDetails = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.init();
    });

    searchTextController.addListener(() {
      EasyDebounce.debounce(
          'search-debouncer', const Duration(milliseconds: 500), () {
        widget.viewModel.onTextSearchChanged(
          searchText: searchTextController.text,
        );
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 60.0),
        child: Column(
          children: [
            const SizedBox(height: 24.0),
            Row(
              children: [
                SizedBox(
                  width: 350.0,
                  child: DataCard(
                    value:
                        widget.viewModel.merchantStock?.totalUnits.toDouble(),
                    unit: null,
                    label: 'Units in Stock',
                    height: 180.0,
                    elementsSpacing: 8.0,
                    valueTextStyle:
                        Theme.of(context).textTheme.displaySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceHighEmphasis,
                              fontSize: 40.0,
                            ),
                    onDetailsToggled: () {
                      setState(() {
                        _showStockDetails = !_showStockDetails;
                      });
                    },
                  ),
                ),
                widget.viewModel.merchantStock != null
                    ? AnimatedOpacity(
                        opacity: _showStockDetails ? 1.0 : 0.0,
                        duration: const Duration(milliseconds: 200),
                        curve: Curves.fastOutSlowIn,
                        child: StockDetails(
                          height: 140.0,
                          stockLevels: widget.viewModel.merchantStock!.levels,
                        ),
                      )
                    : const SizedBox(),
              ],
            ),
            const SizedBox(height: 40.0),
            Row(
              children: [
                Expanded(
                  child: PackagingsTableFilters(
                    controller: searchTextController,
                    availableProductsSelection:
                        widget.viewModel.merchantAvailableProducts,
                    onProductSelected: (String? product) =>
                        widget.viewModel.onProductFilterChanged(
                      product: product,
                    ),
                    onLastTrackedSelected: (FilterTimePeriod period) =>
                        widget.viewModel.onLastTrackedFilterChanged(
                      period: period,
                    ),
                  ),
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 32.0),
                  child: IconButton(
                    onPressed: () => widget.viewModel.onRefreshTapped(),
                    tooltip: 'Refresh',
                    icon: Icon(
                      Icons.refresh,
                      size: 28.0,
                      color:
                          Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16.0),
            Expanded(
              child: PackagingsTable(
                isLoading: widget.viewModel.isLoadingTableData,
                packagings: widget.viewModel.packagings,
                onSaveTapped: (
                  Packaging packaging,
                  PackagingStatus? status,
                  String? orderNumber,
                  String? customerName,
                ) async {
                  await widget.viewModel.onSaveTapped(
                    packaging: packaging,
                    newStatus: status,
                    newOrderNumber: orderNumber,
                    newCustomerName: customerName,
                  );
                },
                initialDisplayPerPage: widget.viewModel.displayPerPage,
                onDisplayPerPageChanged: widget.viewModel.isFilteringBySearch ||
                        widget.viewModel.isFilteringByLastTracked
                    ? null
                    : (int? value) => widget.viewModel.onDisplayPerPageChanged(
                          value: value,
                        ),
                onPreviousTapped: widget.viewModel.showPreviousButton
                    ? () => widget.viewModel.onPreviousTapped()
                    : null,
                onNextTapped: widget.viewModel.showNextButton
                    ? () => widget.viewModel.onNextTapped()
                    : null,
              ),
            ),
            const SizedBox(height: 8.0),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    super.dispose();
    searchTextController.dispose();
  }
}
