import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:kvatt_core/domain/stocks/stocks_manager.dart';
import 'package:provider/provider.dart';

import 'merchant_packagings_management.dart';
import 'merchant_packagings_management_view_model.dart';

class MerchantPackagingsManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<MerchantPackagingsManagementViewModel>(
      create: (context) {
        return MerchantPackagingsManagementViewModel(
          packagingsManager: Provider.of<PackagingsManager>(
            context,
            listen: false,
          ),
          stocksManager: Provider.of<StocksManager>(
            context,
            listen: false,
          ),
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<MerchantPackagingsManagementViewModel>(
        builder: (context, model, child) => MerchantPackagingsManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
