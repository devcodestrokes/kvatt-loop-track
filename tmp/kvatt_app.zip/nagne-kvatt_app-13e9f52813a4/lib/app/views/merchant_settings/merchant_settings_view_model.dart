import 'package:flutter/material.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/domain/merchant_settings/merchant_settings_manager.dart';
import 'package:kvatt_app/domain/merchant_settings/stock_level_reminder_setting.dart';

import '../../../domain/merchant_settings/merchant_settings.dart';

class MerchantSettingsViewModel extends ChangeNotifier {
  MerchantSettingsManager settingsManager;
  AuthState authState;

  MerchantSettingsViewModel({
    required this.settingsManager,
    required this.authState,
  });

  MerchantSettings? merchantSettings;

  String? stockLevelReminderErrorMessage;

  bool isLoading = true;

  Future<void> init() async {
    merchantSettings = await settingsManager.getSettingsForMerchant(
      merchantId: authState.activeUser!.uid!,
    );
    isLoading = false;
    notifyListeners();
  }

  Future<void> onReminderSettingsSaved(
    List<StockLevelReminderSetting> settings,
  ) async {
    stockLevelReminderErrorMessage = null;
    try {
      if (merchantSettings == null) {
        merchantSettings = MerchantSettings(
          stockLevelReminderSettings: settings,
        );
      } else {
        merchantSettings?.stockLevelReminderSettings = settings;
      }
      await settingsManager.updateSettingsForMerchant(
        merchantId: authState.activeUser!.uid!,
        merchantSettings: merchantSettings!,
      );
    } catch (e) {
      stockLevelReminderErrorMessage =
          'There was an issue saving your reminders. Please try again later.';
    }
    notifyListeners();
  }
}
