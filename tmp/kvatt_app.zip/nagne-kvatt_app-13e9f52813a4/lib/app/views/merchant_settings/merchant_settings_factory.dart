import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/views/merchant_settings/merchant_settings_view_model.dart';
import 'package:kvatt_app/domain/merchant_settings/merchant_settings_manager.dart';
import 'package:provider/provider.dart';

import 'merchant_settings.dart';

class MerchantSettingsFactory {
  static Widget build() {
    return ChangeNotifierProvider<MerchantSettingsViewModel>(
      create: (context) {
        return MerchantSettingsViewModel(
          settingsManager: Provider.of<MerchantSettingsManager>(
            context,
            listen: false,
          ),
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<MerchantSettingsViewModel>(
        builder: (context, model, child) => MerchantSettings(
          viewModel: model,
        ),
      ),
    );
  }
}
