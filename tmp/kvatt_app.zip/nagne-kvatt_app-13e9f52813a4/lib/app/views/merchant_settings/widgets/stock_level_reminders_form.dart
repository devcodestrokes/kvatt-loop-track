import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/packaging_selector.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/domain/merchant_settings/stock_level_reminder_setting.dart';

class StockLevelRemindersForm extends StatefulWidget {
  final List<StockLevelReminderSetting> settings;
  final Function(List<StockLevelReminderSetting>) onSave;
  final String? errorMessage;

  const StockLevelRemindersForm({
    super.key,
    required this.settings,
    required this.onSave,
    this.errorMessage,
  });

  @override
  State<StockLevelRemindersForm> createState() =>
      _StockLevelRemindersFormState();
}

class _StockLevelRemindersFormState extends State<StockLevelRemindersForm> {
  final _formKey = GlobalKey<FormState>();

  List<Map<String, String>> settingItems = [];

  @override
  void initState() {
    super.initState();
    settingItems = widget.settings.map((StockLevelReminderSetting setting) {
      return {
        'type': setting.product,
        'numUnits': setting.minLevel.toString(),
      };
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Stock Level Reminders',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          const SizedBox(height: 12.0),
          Text(
            'By setting stock level reminders, you\'ll be notified by email each time the quantity of a product in stock drops below the level you\'ve specified.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                ),
          ),
          widget.errorMessage != null
              ? Column(
                  children: [
                    const SizedBox(height: 8.0),
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                      ),
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 32.0),
          PackagingSelector(
            mainLabel: 'Add reminders',
            quantityLabel: 'Stock level',
            productLabel: 'Product',
            initialItems: settingItems,
            onItemAdded: (List<Map<String, String>> itemsAdded) {
              setState(() {
                settingItems = itemsAdded;
              });
            },
          ),
          settingItems.isEmpty
              ? Column(
                  children: [
                    const SizedBox(height: 16.0),
                    Text(
                      'You currently don\'t have any reminders set.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceMediumEmphasis,
                          ),
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 32.0),
          Align(
            alignment: Alignment.centerRight,
            child: SizedBox(
              width: 120.0,
              child: PrimaryButton(
                label: 'Save',
                onPressed: () {
                  if (_formKey.currentState!.validate()) {
                    List<StockLevelReminderSetting> updatedSettings =
                        settingItems.map((Map<String, String> setting) {
                      return StockLevelReminderSetting(
                        product: setting['type']!,
                        minLevel: int.parse(setting['numUnits'] ?? ''),
                      );
                    }).toList();
                    widget.onSave(updatedSettings);
                  }
                },
              ),
            ),
          ),
        ],
      ),
    );
  }
}
