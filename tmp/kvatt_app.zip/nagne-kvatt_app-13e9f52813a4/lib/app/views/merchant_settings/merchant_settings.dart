import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/merchant_settings/merchant_settings_view_model.dart';
import 'package:kvatt_app/app/views/merchant_settings/widgets/stock_level_reminders_form.dart';
import 'package:kvatt_app/domain/merchant_settings/stock_level_reminder_setting.dart';

class MerchantSettings extends StatefulWidget {
  final MerchantSettingsViewModel viewModel;

  const MerchantSettings({
    super.key,
    required this.viewModel,
  });

  @override
  State<MerchantSettings> createState() => _MerchantSettingsState();
}

class _MerchantSettingsState extends State<MerchantSettings> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      widget.viewModel.init();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceColor,
      body: SingleChildScrollView(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 60.0),
          child: widget.viewModel.isLoading
              ? const Column(
                  children: [
                    SizedBox(height: 24.0),
                    LoadingSpinner(),
                  ],
                )
              : Column(
                  children: [
                    const SizedBox(height: 24.0),
                    SizedBox(
                      width: MediaQuery.of(context).size.width * 0.3,
                      child: StockLevelRemindersForm(
                          settings: widget.viewModel.merchantSettings
                                  ?.stockLevelReminderSettings ??
                              [],
                          errorMessage:
                              widget.viewModel.stockLevelReminderErrorMessage,
                          onSave:
                              (List<StockLevelReminderSetting> settings) async {
                            LoadingDialog.show(context, 'saving...');
                            await widget.viewModel
                                .onReminderSettingsSaved(settings);
                            if (!mounted) return;
                            Navigator.of(context).pop();
                          }),
                    ),
                  ],
                ),
        ),
      ),
    );
  }
}
