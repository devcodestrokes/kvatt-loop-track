import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/user_management/invite_user/invite_user_view_model.dart';
import 'package:kvatt_app/app/views/user_management/widgets/admin_invite_form.dart';
import 'package:kvatt_app/app/views/user_management/widgets/merchant_invite_form.dart';
import 'package:kvatt_app/app/views/user_management/widgets/partner_invite_form.dart';
import 'package:kvatt_app/domain/users/user_type.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';
import 'package:provider/provider.dart';

class InviteUser extends StatefulWidget {
  final InviteUserViewModel viewModel;

  const InviteUser({Key? key, required this.viewModel}) : super(key: key);

  @override
  State<InviteUser> createState() => _InviteUserState();
}

class _InviteUserState extends State<InviteUser> {
  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.3,
            child: Column(
              children: [
                const SizedBox(height: 48.0),
                Text(
                  'Type of User',
                  style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                        color:
                            Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                      ),
                ),
                const SizedBox(height: 12.0),
                Text(
                  'First, select the type of user which you want to invite.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                  textAlign: TextAlign.center,
                ),
                const SizedBox(height: 24.0),
                DropDownFieldBlack(
                  label: 'User Type',
                  items: const ['Admin', 'Partner', 'Merchant'],
                  onItemSelected: (String type) =>
                      widget.viewModel.onUserTypeSelected(type),
                ),
                const SizedBox(height: 24.0),
                _buildForm(context),
                const SizedBox(height: 12.0),
                SecondaryButton(
                  label: 'Cancel',
                  onPressed: () => Provider.of<UiState>(context, listen: false)
                      .updateView(ViewConfig(
                    appView: AppView.homeUsers,
                    params: {},
                  )),
                ),
                const SizedBox(height: 36.0),
                PromptTextButton(
                  promptText: 'Having issues?',
                  actionLabel: 'Contact Support',
                  onPressed: () => widget.viewModel.onContactSupportTapped(),
                  fontColor:
                      Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
                const SizedBox(height: 48.0),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildForm(BuildContext context) {
    switch (widget.viewModel.userType) {
      case UserType.admin:
        return AdminInviteForm(
            emailValidator: (String? email) => Validators.validateEmail(email),
            errorMessage: widget.viewModel.errorMessage,
            onSubmitPressed: (String email, String name) async {
              LoadingDialog.show(context, 'sending invite...');
              bool res = await widget.viewModel.onInviteAdminPressed(
                email: email,
                name: name,
              );
              if (!mounted) return;
              Navigator.of(context).pop();
              if (res == true) {
                Provider.of<UiState>(context, listen: false)
                    .updateView(ViewConfig(
                  appView: AppView.homeUsers,
                  params: {},
                ));
              }
            });
      case UserType.partner:
        return PartnerInviteForm(
          allMerchants: widget.viewModel.allMerchants,
          errorMessage: widget.viewModel.errorMessage,
          emailValidator: (String? email) => Validators.validateEmail(email),
          onSubmitPressed: (
            String email,
            String name,
            List<String> selectedMerchantIds,
          ) async {
            LoadingDialog.show(context, 'sending invite...');
            bool res = await widget.viewModel.onInvitePartnerPressed(
              email: email,
              name: name,
              assignedMerchantIds: selectedMerchantIds,
            );
            if (!mounted) return;
            Navigator.of(context).pop();
            if (res == true) {
              Provider.of<UiState>(context, listen: false)
                  .updateView(ViewConfig(
                appView: AppView.homeUsers,
                params: {},
              ));
            }
          },
        );
      case UserType.merchant:
        return MerchantInviteForm(
          errorMessage: widget.viewModel.errorMessage,
          emailValidator: (String? email) => Validators.validateEmail(email),
          onSubmitPressed: (
            String email,
            String name,
            String deliveryAddress,
            String contractType,
            TrackingSource? trackingType,
            List<Map<String, String>> packagingItems,
            bool packagingLossCompensation,
            bool packagingMaintenance,
            LandingPageConfig? landingPageConfig,
          ) async {
            LoadingDialog.show(context, 'sending invite...');
            bool res = await widget.viewModel.onInviteMerchantPressed(
              email: email,
              name: name,
              deliveryAddress: deliveryAddress,
              trackingType: trackingType,
              contractType: contractType,
              packagingItems: packagingItems,
              packagingLossCompensation: packagingLossCompensation,
              packagingMaintenance: packagingMaintenance,
              landingPageConfig: landingPageConfig,
            );
            if (!mounted) return;
            Navigator.of(context).pop();
            if (res == true) {
              Provider.of<UiState>(context, listen: false)
                  .updateView(ViewConfig(
                appView: AppView.homeUsers,
                params: {},
              ));
            }
          },
        );
      default:
        return const SizedBox();
    }
  }
}
