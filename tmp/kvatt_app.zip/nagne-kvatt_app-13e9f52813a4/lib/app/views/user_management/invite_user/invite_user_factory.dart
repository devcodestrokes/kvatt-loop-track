import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/views/user_management/invite_user/invite_user.dart';
import 'package:kvatt_app/app/views/user_management/invite_user/invite_user_view_model.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class InviteUserFactory {
  static Widget build() {
    return ChangeNotifierProvider<InviteUserViewModel>(
      create: (context) {
        return InviteUserViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          communicationsManager: Provider.of<CommunicationsManager>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<InviteUserViewModel>(
        builder: (context, model, child) => InviteUser(
          viewModel: model,
        ),
      ),
    );
  }
}
