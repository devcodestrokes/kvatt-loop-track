import 'package:flutter/material.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_app/domain/contracts/packaging_info.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_app/domain/users/user_type.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';

class InviteUserViewModel extends ChangeNotifier {
  UserManager userManager;
  CommunicationsManager communicationsManager;

  InviteUserViewModel({
    required this.userManager,
    required this.communicationsManager,
  });

  UserType? userType;

  String? errorMessage;

  List<Merchant>? allMerchants;

  onUserTypeSelected(String type) {
    switch (type) {
      case 'Admin':
        userType = UserType.admin;
        break;
      case 'Partner':
        userType = UserType.partner;
        if (allMerchants == null) {
          _retrieveMerchants();
        }
        break;
      case 'Merchant':
        userType = UserType.merchant;
        break;
      default:
        break;
    }
    notifyListeners();
  }

  Future<bool> onInviteAdminPressed({
    required String email,
    required String name,
  }) async {
    bool isUserAlreadyInvited =
        await userManager.isUserAlreadyInvited(email: email);
    if (isUserAlreadyInvited) {
      errorMessage = 'This user has already been invited.';
      notifyListeners();
      return false;
    } else {
      await userManager.inviteAdmin(
        email: email,
        name: name,
      );
      return true;
    }
  }

  Future<bool> onInvitePartnerPressed({
    required String email,
    required String name,
    required List<String> assignedMerchantIds,
  }) async {
    bool isUserAlreadyInvited =
        await userManager.isUserAlreadyInvited(email: email);
    if (isUserAlreadyInvited) {
      errorMessage = 'This user has already been invited.';
      notifyListeners();
      return false;
    } else {
      await userManager.invitePartner(
        email: email,
        name: name,
        assignedMerchantIds: assignedMerchantIds,
      );
      return true;
    }
  }

  Future<bool> onInviteMerchantPressed({
    required String email,
    required String name,
    required String deliveryAddress,
    required String contractType,
    required TrackingSource? trackingType,
    required List<Map<String, String>> packagingItems,
    required bool packagingLossCompensation,
    required bool packagingMaintenance,
    required LandingPageConfig? landingPageConfig,
  }) async {
    bool isUserAlreadyInvited =
        await userManager.isUserAlreadyInvited(email: email);
    if (isUserAlreadyInvited) {
      errorMessage = 'This user has already been invited.';
      notifyListeners();
      return false;
    } else {
      await userManager.inviteMerchant(
        email: email,
        name: name,
        deliveryAddress: deliveryAddress,
        contractType: contractType,
        packagingItems: packagingItems
            .map(
              (Map<String, String> item) => PackagingInfo(
                packagingType: item['type']!,
                numberOfUnits: int.parse(item['numUnits']!),
              ),
            )
            .toList(),
        packagingLossCompensation: packagingLossCompensation,
        packagingMaintenance: packagingMaintenance,
        trackingType: trackingType,
      );

      return true;
    }
  }

  onCancelPressed() {}

  onContactSupportTapped() {
    communicationsManager.launchSupportEmail();
  }

  Future<void> _retrieveMerchants() async {
    allMerchants = await userManager.retrieveActiveMerchants();
    notifyListeners();
  }
}
