import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/user_management/partner_management/partner_management.dart';
import 'package:kvatt_app/app/views/user_management/partner_management/partner_management_view_model.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class PartnerManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<PartnerManagementViewModel>(
      create: (context) {
        return PartnerManagementViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<PartnerManagementViewModel>(
        builder: (context, model, child) => PartnerManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
