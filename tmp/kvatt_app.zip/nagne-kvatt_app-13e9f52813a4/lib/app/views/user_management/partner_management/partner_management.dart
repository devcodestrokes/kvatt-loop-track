import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/common/widgets/tables/traditional_table.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/user_management/partner_management/partner_management_view_model.dart';
import 'package:kvatt_app/app/views/user_management/widgets/account_status_pill.dart';
import 'package:kvatt_app/domain/users/partner.dart';
import 'package:kvatt_app/domain/users/user_account_status.dart';

class PartnerManagement extends StatefulWidget {
  final PartnerManagementViewModel viewModel;

  const PartnerManagement({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  State<PartnerManagement> createState() => _PartnerManagementState();
}

class _PartnerManagementState extends State<PartnerManagement> {
  @override
  Widget build(BuildContext context) {
    return widget.viewModel.partners != null
        ? widget.viewModel.partners!.isEmpty
            ? Center(
                child: Text(
                  'No partner has been invited yet.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceDisabled),
                ),
              )
            : SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 24.0),
                  child: TraditionalTable(
                    tableConfig: TableConfig(
                      headers: ['Email', 'Name', 'Account Status', ''],
                      data: widget.viewModel.partners!.map((Partner partner) {
                        return [
                          partner.email,
                          partner.name,
                          Row(
                            children: [
                              AccountStatusPill(
                                  accountStatus: partner.accountStatus),
                              partner.accountStatus == UserAccountStatus.pending
                                  ? _buildResendInvite(
                                      context: context, email: partner.email)
                                  : const SizedBox(),
                            ],
                          ),
                          IconButton(
                            onPressed: () => widget.viewModel
                                .onEditPartnerTapped(partner.uid),
                            icon: Icon(
                              Icons.edit,
                              size: 16.0,
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceDisabled,
                            ),
                          ),
                        ];
                      }).toList(),
                    ),
                  ),
                ),
              )
        : const LoadingSpinner();
  }

  Widget _buildResendInvite({
    required BuildContext context,
    required String email,
  }) {
    return Row(
      children: [
        const SizedBox(width: 4.0),
        PromptTextButton(
          promptText: '',
          actionLabel: 'resend invite',
          onPressed: () async {
            LoadingDialog.show(context, 'resending invite...');
            await widget.viewModel.onResendInviteTapped(email);
            if (!mounted) return;
            Navigator.of(context).pop();
          },
        ),
      ],
    );
  }
}
