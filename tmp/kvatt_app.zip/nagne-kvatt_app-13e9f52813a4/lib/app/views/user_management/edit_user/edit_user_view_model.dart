import 'package:flutter/material.dart';
import 'package:kvatt_app/domain/contracts/packaging_info.dart';
import 'package:kvatt_app/domain/users/admin.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/partner.dart';
import 'package:kvatt_app/domain/users/user.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_manager.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';

class EditUserViewModel extends ChangeNotifier {
  UserManager userManager;
  LandingPageManager landingPageManager;

  String userId;

  User? user;

  LandingPageConfig? landingPageConfig;

  String? errorMessage;

  List<Merchant> allMerchants = [];

  EditUserViewModel({
    required this.userManager,
    required this.landingPageManager,
    required this.userId,
  });

  Future<void> load() async {
    user = await userManager.findUser(userId: userId);
    if (user is Partner) {
      allMerchants = await userManager.retrieveActiveMerchants();
    }
    if (user is Merchant) {
      landingPageConfig = await landingPageManager.getCustomConfigsForMerchant(
        merchantId: user?.uid ?? '',
      );
    }
    notifyListeners();
  }

  Future<bool> onSubmitAdminPressed({
    required String name,
  }) async {
    try {
      Admin admin = user as Admin;
      admin.name = name;
      await userManager.updateUserDetails(user: admin);
      return true;
    } catch (e) {
      errorMessage = 'There was an issue updating admin details';
      notifyListeners();
      return false;
    }
  }

  Future<bool> onSubmitPartnerPressed({
    required String name,
    required List<String> assignedMerchantIds,
  }) async {
    try {
      Partner partner = user as Partner;
      partner.name = name;
      partner.assignedMerchantIds = assignedMerchantIds;
      await userManager.updateUserDetails(user: partner);
      return true;
    } catch (e) {
      errorMessage = 'There was an issue updating partner details';
      notifyListeners();
      return false;
    }
  }

  Future<bool> onSubmitMerchantPressed({
    required String email,
    required String name,
    required String deliveryAddress,
    required String contractType,
    required TrackingSource? trackingType,
    required List<Map<String, String>> packagingItems,
    required bool packagingLossCompensation,
    required bool packagingMaintenance,
    required LandingPageConfig? landingPageConfig,
  }) async {
    try {
      Merchant merchant = user as Merchant;

      if (merchant.email != email) {
        await userManager.updateUserEmail(
          userId: merchant.uid!,
          email: email,
        );
      }

      merchant.email = email;
      merchant.name = name;
      merchant.contractInfo.deliveryAddress = deliveryAddress;
      merchant.contractInfo.contractType = contractType;
      merchant.contractInfo.packagings = packagingItems
          .map(
            (Map<String, String> item) => PackagingInfo(
              packagingType: item['type']!,
              numberOfUnits: int.parse(item['numUnits']!),
            ),
          )
          .toList();
      merchant.contractInfo.packagingLossCompensationIncluded =
          packagingLossCompensation;
      merchant.contractInfo.packagingMaintenanceIncluded = packagingMaintenance;
      merchant.trackingSource = trackingType;
      await userManager.updateUserDetails(user: merchant);
      await landingPageManager.setCustomConfigsForMerchant(
        merchantId: merchant.uid!,
        landingPageConfig: landingPageConfig,
      );

      return true;
    } catch (e) {
      errorMessage = 'There was an issue updating merchant details';
      notifyListeners();
      return false;
    }
  }

  Future<bool> onDeleteMerchantPressed() async {
    try {
      Merchant merchant = user as Merchant;
      await userManager.removeMerchant(merchant: merchant);
      return true;
    } catch (e) {
      errorMessage = 'There was an issue deleting this user.';
      notifyListeners();
      return false;
    }
  }
}
