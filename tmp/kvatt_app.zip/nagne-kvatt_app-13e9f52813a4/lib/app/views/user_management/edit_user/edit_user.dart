import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/user_management/edit_user/edit_user_view_model.dart';
import 'package:kvatt_app/app/views/user_management/widgets/admin_invite_form.dart';
import 'package:kvatt_app/app/views/user_management/widgets/form_action.dart';
import 'package:kvatt_app/app/views/user_management/widgets/merchant_invite_form.dart';
import 'package:kvatt_app/app/views/user_management/widgets/partner_invite_form.dart';
import 'package:kvatt_app/domain/contracts/packaging_info.dart';
import 'package:kvatt_app/domain/users/admin.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/partner.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';
import 'package:provider/provider.dart';

class EditUser extends StatefulWidget {
  final EditUserViewModel viewModel;

  const EditUser({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  State<EditUser> createState() => _EditUserState();
}

class _EditUserState extends State<EditUser> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.load();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(vertical: 48.0),
            child: SizedBox(
              width: MediaQuery.of(context).size.width * 0.3,
              child: widget.viewModel.user == null
                  ? const LoadingSpinner()
                  : _buildForm(),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildForm() {
    if (widget.viewModel.user is Admin) {
      return _buildAdminForm();
    }
    if (widget.viewModel.user is Merchant) {
      return _buildMerchantForm();
    }

    if (widget.viewModel.user is Partner) {
      return _buildPartnerForm();
    }
    return const SizedBox();
  }

  Widget _buildAdminForm() {
    Admin admin = widget.viewModel.user as Admin;
    return AdminInviteForm(
        errorMessage: widget.viewModel.errorMessage,
        action: FormAction.edit,
        email: admin.email,
        name: admin.name,
        emailValidator: (String? email) => () {},
        onSubmitPressed: (String email, String name) async {
          LoadingDialog.show(context, 'updating user...');
          bool res = await widget.viewModel.onSubmitAdminPressed(name: name);
          if (!mounted) return;
          Navigator.of(context).pop();
          if (res == true) {
            Provider.of<UiState>(context, listen: false).updateView(ViewConfig(
              appView: AppView.homeUsers,
              params: {},
            ));
          }
        });
  }

  Widget _buildPartnerForm() {
    Partner partner = widget.viewModel.user as Partner;
    return PartnerInviteForm(
        allMerchants: widget.viewModel.allMerchants,
        errorMessage: widget.viewModel.errorMessage,
        action: FormAction.edit,
        email: partner.email,
        name: partner.name,
        merchantIds: partner.assignedMerchantIds,
        emailValidator: (String? email) => () {},
        onSubmitPressed: (
          String email,
          String name,
          List<String> selectedMerchantIds,
        ) async {
          LoadingDialog.show(context, 'updating user...');
          bool res = await widget.viewModel.onSubmitPartnerPressed(
            name: name,
            assignedMerchantIds: selectedMerchantIds,
          );
          if (!mounted) return;
          Navigator.of(context).pop();
          if (res == true) {
            Provider.of<UiState>(context, listen: false).updateView(ViewConfig(
              appView: AppView.homeUsers,
              params: {},
            ));
          }
        });
  }

  Widget _buildMerchantForm() {
    Merchant merchant = widget.viewModel.user as Merchant;
    return MerchantInviteForm(
        errorMessage: widget.viewModel.errorMessage,
        action: FormAction.edit,
        email: merchant.email,
        name: merchant.name,
        deliveryAddress: merchant.contractInfo.deliveryAddress,
        trackingType: merchant.trackingSource,
        contractType: merchant.contractInfo.contractType,
        packagingItems: merchant.contractInfo.packagings
            .map((PackagingInfo info) => {
                  'type': info.packagingType,
                  'numUnits': info.numberOfUnits.toString(),
                })
            .toList(),
        packagingLossCompensation:
            merchant.contractInfo.packagingLossCompensationIncluded,
        packagingMaintenance:
            merchant.contractInfo.packagingMaintenanceIncluded,
        emailValidator: (String? email) => Validators.validateEmail(email),
        landingPageConfig: widget.viewModel.landingPageConfig,
        onDeleteMerchantPressed: () async {
          LoadingDialog.show(context, 'deleting user...');
          bool res = await widget.viewModel.onDeleteMerchantPressed();
          if (!mounted) return;
          Navigator.of(context).pop();
          Navigator.of(context).pop();
          if (res == true) {
            Provider.of<UiState>(context, listen: false).updateView(ViewConfig(
              appView: AppView.homeUsers,
              params: {},
            ));
          }
        },
        onSubmitPressed: (
          String email,
          String name,
          String deliveryAddress,
          String contractType,
          TrackingSource? trackingType,
          List<Map<String, String>> packagingItems,
          bool packagingLossCompensation,
          bool packagingMaintenance,
          LandingPageConfig? landingPageConfig,
        ) async {
          LoadingDialog.show(context, 'updating user...');
          bool res = await widget.viewModel.onSubmitMerchantPressed(
            email: email,
            name: name,
            deliveryAddress: deliveryAddress,
            contractType: contractType,
            trackingType: trackingType,
            packagingItems: packagingItems,
            packagingLossCompensation: packagingLossCompensation,
            packagingMaintenance: packagingMaintenance,
            landingPageConfig: landingPageConfig,
          );
          if (!mounted) return;
          Navigator.of(context).pop();
          if (res == true) {
            Provider.of<UiState>(context, listen: false).updateView(ViewConfig(
              appView: AppView.homeUsers,
              params: {},
            ));
          }
        });
  }
}
