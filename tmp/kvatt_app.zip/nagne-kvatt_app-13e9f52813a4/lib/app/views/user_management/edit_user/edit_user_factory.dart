import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/views/user_management/edit_user/edit_user.dart';
import 'package:kvatt_app/app/views/user_management/edit_user/edit_user_view_model.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_manager.dart';
import 'package:provider/provider.dart';

class EditUserFactory {
  static Widget build({
    required String userId,
  }) {
    return ChangeNotifierProvider<EditUserViewModel>(
      create: (context) {
        return EditUserViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          landingPageManager: Provider.of<LandingPageManager>(
            context,
            listen: false,
          ),
          userId: userId,
        );
      },
      child: Consumer<EditUserViewModel>(
        builder: (context, model, child) => EditUser(
          viewModel: model,
        ),
      ),
    );
  }
}
