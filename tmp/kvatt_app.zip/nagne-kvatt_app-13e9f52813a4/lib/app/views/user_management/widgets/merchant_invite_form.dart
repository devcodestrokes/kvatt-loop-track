import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/checkbox_field.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/packaging_selector.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/user_management/widgets/form_action.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';

class MerchantInviteForm extends StatefulWidget {
  final FormAction? action;
  final Function(String?) emailValidator;
  final Function(
    String email,
    String name,
    String deliveryAddress,
    String contractType,
    TrackingSource? trackingType,
    List<Map<String, String>> packagingItems,
    bool packagingLossCompensation,
    bool packagingMaintenance,
    LandingPageConfig? landingPageConfig,
  ) onSubmitPressed;
  final Function? onDeleteMerchantPressed;
  final String? errorMessage;
  final String? email;
  final String? name;
  final String? deliveryAddress;
  final String? contractType;
  final TrackingSource? trackingType;
  final List<Map<String, String>>? packagingItems;
  final bool? packagingLossCompensation;
  final bool? packagingMaintenance;
  final LandingPageConfig? landingPageConfig;

  const MerchantInviteForm({
    Key? key,
    this.action = FormAction.create,
    required this.emailValidator,
    required this.onSubmitPressed,
    this.onDeleteMerchantPressed,
    this.errorMessage,
    this.email,
    this.name,
    this.deliveryAddress,
    this.contractType,
    this.trackingType,
    this.packagingItems,
    this.packagingLossCompensation,
    this.packagingMaintenance,
    this.landingPageConfig,
  }) : super(key: key);

  @override
  State<MerchantInviteForm> createState() => MerchantInviteFormState();
}

class MerchantInviteFormState extends State<MerchantInviteForm> {
  TextEditingController emailTextController = TextEditingController();
  TextEditingController nameTextController = TextEditingController();
  TextEditingController deliveryAddressTextController = TextEditingController();
  TextEditingController returnLocationUrlTextController =
      TextEditingController();
  TextEditingController returnLocationLabelTextController =
      TextEditingController();

  final _formKey = GlobalKey<FormState>();

  String? _contractType;
  String? _trackingType;
  bool _packagingLossCompensation = false;
  bool _packagingMaintenance = false;
  List<Map<String, String>> _packagingItems = [];

  TrackingSource? _trackingTypeToSource(String type) {
    switch (type) {
      case 'Admin Kvatt App':
        return null;
      case 'Merchant Kvatt App':
        return TrackingSource.kvattApp;
      case 'Shopify':
        return TrackingSource.shopify;
      default:
        return null;
    }
  }

  String? _trackingSourceToType(TrackingSource? source) {
    switch (source) {
      case TrackingSource.kvattApp:
        return 'Merchant Kvatt App';
      case TrackingSource.shopify:
        return 'Shopify';
      default:
        return 'Admin Kvatt App';
    }
  }

  @override
  void initState() {
    if (widget.action == FormAction.edit) {
      emailTextController.text = widget.email ?? '';
      nameTextController.text = widget.name ?? '';
      deliveryAddressTextController.text = widget.deliveryAddress ?? '';
      returnLocationUrlTextController.text =
          widget.landingPageConfig?.returnLocationUrl ?? '';
      returnLocationLabelTextController.text =
          widget.landingPageConfig?.returnLocationLabel ?? '';
      _contractType = widget.contractType;
      _trackingType = _trackingSourceToType(widget.trackingType);
      _packagingItems = widget.packagingItems ?? [];
      _packagingLossCompensation = widget.packagingLossCompensation ?? false;
      _packagingMaintenance = widget.packagingMaintenance ?? false;
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            widget.action == FormAction.create
                ? 'Fill in Merchant details'
                : 'Edit Merchant details',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 12.0),
          widget.action == FormAction.create
              ? Text(
                  widget.action == FormAction.create
                      ? 'Next, fill in the details of the new Merchant.'
                      : 'Edit merchant details',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                  textAlign: TextAlign.center,
                )
              : const SizedBox(),
          const SizedBox(height: 16.0),
          widget.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          TextFieldBlack(
            validator: (String? email) {
              return widget.emailValidator(email);
            },
            label: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            controller: emailTextController,
          ),
          const SizedBox(height: 28.0),
          TextFieldBlack(
            validator: (String? name) => Validators.validateNotEmpty(
              name,
              'Please enter the Merchant Name',
            ),
            label: 'Merchant Name',
            keyboardType: TextInputType.text,
            controller: nameTextController,
          ),
          const SizedBox(height: 36.0),
          Text(
            'Contract information',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 28.0),
          TextFieldBlack(
            validator: (String? address) => Validators.validateNotEmpty(
              address,
              'Please enter the delivery address',
            ),
            label: 'Delivery Address',
            keyboardType: TextInputType.text,
            controller: deliveryAddressTextController,
          ),
          const SizedBox(height: 28.0),
          DropDownFieldBlack(
            initialValue: _contractType,
            validator: (String? type) => Validators.validateNotEmpty(
                type, 'Please select a Contract Type'),
            label: 'Contract Type',
            items: const [
              'Rental Large Loop',
              'Rental Small Loop',
              'Wholesale'
            ],
            onItemSelected: (String type) => _contractType = type,
          ),
          const SizedBox(height: 36.0),
          PackagingSelector(
            initialItems: _packagingItems,
            onItemAdded: (List<Map<String, String>> itemsAdded) {
              _packagingItems = itemsAdded;
            },
          ),
          const SizedBox(height: 48.0),
          CheckboxField(
            label: 'Includes Packaging Loss Compensation',
            value: _packagingLossCompensation,
            onChanged: (bool value) {
              _packagingLossCompensation = value;
            },
          ),
          const SizedBox(height: 28.0),
          CheckboxField(
            label: 'Includes Packaging Maintenance',
            value: _packagingMaintenance,
            onChanged: (bool value) {
              _packagingMaintenance = value;
            },
          ),
          const SizedBox(height: 36.0),
          Text(
            'Tracking information',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 28.0),
          DropDownFieldBlack(
            initialValue: _trackingType,
            validator: (String? type) => Validators.validateNotEmpty(
                type, 'Please select a Tracking Type'),
            label: 'Tracking Type',
            items: const [
              'Admin Kvatt App',
              'Merchant Kvatt App',
              'Shopify',
            ],
            onItemSelected: (String type) => _trackingType = type,
          ),
          const SizedBox(height: 36.0),
          Text(
            'Landing page customisation',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 28.0),
          TextFieldBlack(
            validator: (String? url) => Validators.validateHttpLink(url),
            label: 'Return location URL',
            keyboardType: TextInputType.url,
            controller: returnLocationUrlTextController,
          ),
          const SizedBox(height: 28.0),
          TextFieldBlack(
            validator: (String? label) {},
            label: 'Return location button label',
            keyboardType: TextInputType.text,
            controller: returnLocationLabelTextController,
          ),
          const SizedBox(height: 36.0),
          PrimaryButton(
            label: widget.action == FormAction.create
                ? 'Invite Merchant'
                : 'Update Merchant details',
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                widget.onSubmitPressed(
                  emailTextController.text.trim(),
                  nameTextController.text.trim(),
                  deliveryAddressTextController.text.trim(),
                  _contractType!,
                  _trackingTypeToSource(_trackingType!),
                  _packagingItems,
                  _packagingLossCompensation,
                  _packagingMaintenance,
                  LandingPageConfig(
                    returnLocationUrl:
                        returnLocationUrlTextController.text.trim(),
                    returnLocationLabel:
                        returnLocationLabelTextController.text.trim(),
                  ),
                );
              }
            },
          ),
          widget.action == FormAction.edit &&
                  widget.onDeleteMerchantPressed != null
              ? Column(
                  children: [
                    const SizedBox(height: 48.0),
                    PromptTextButton(
                      promptText: '',
                      actionLabel: 'Delete Merchant',
                      onPressed: () {
                        showDialog(
                          context: context,
                          builder: (BuildContext context) {
                            return AlertDialog(
                              title: Text(
                                'Are you sure you want to delete this merchant?',
                                style: Theme.of(context)
                                    .textTheme
                                    .headlineSmall
                                    ?.copyWith(
                                      fontSize: 20.0,
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceHighEmphasis,
                                    ),
                              ),
                              content: Text(
                                'Deleting this merchant would remove all data associated with them\nand they wouldn\'t be able to access the platform anymore.',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              actions: [
                                TextButton(
                                  onPressed: () {
                                    Navigator.of(context).pop();
                                  },
                                  child: Text(
                                    'No, go back.',
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelLarge
                                        ?.copyWith(
                                            color:
                                                Theme.of(context).primaryColor),
                                  ),
                                ),
                                TextButton(
                                  onPressed: () =>
                                      widget.onDeleteMerchantPressed!(),
                                  child: Text(
                                    'Yes, delete merchant.',
                                    style: Theme.of(context)
                                        .textTheme
                                        .labelLarge
                                        ?.copyWith(
                                            color: Theme.of(context)
                                                .colorScheme
                                                .secondaryColor),
                                  ),
                                ),
                              ],
                            );
                          },
                        );
                      },
                    ),
                  ],
                )
              : const SizedBox(),
        ],
      ),
    );
  }

  @override
  void dispose() {
    emailTextController.dispose();
    nameTextController.dispose();
    deliveryAddressTextController.dispose();
    returnLocationUrlTextController.dispose();
    returnLocationLabelTextController.dispose();
    super.dispose();
  }
}
