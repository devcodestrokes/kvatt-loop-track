import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/pills/traffic_light_pill.dart';
import 'package:kvatt_app/domain/users/user_account_status.dart';

class AccountStatusPill extends StatelessWidget {
  final UserAccountStatus accountStatus;

  const AccountStatusPill({
    Key? key,
    required this.accountStatus,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TrafficLightPill(
      status: accountStatus == UserAccountStatus.pending
          ? TrafficLightStatus.amber
          : TrafficLightStatus.green,
      label: accountStatus == UserAccountStatus.pending ? 'PENDING' : 'ACTIVE',
    );
  }
}
