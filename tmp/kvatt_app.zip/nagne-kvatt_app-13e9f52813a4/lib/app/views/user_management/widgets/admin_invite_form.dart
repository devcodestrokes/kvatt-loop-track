import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/user_management/widgets/form_action.dart';

class AdminInviteForm extends StatefulWidget {
  final FormAction? action;
  final Function(String?) emailValidator;
  final Function(String email, String name) onSubmitPressed;
  final String? errorMessage;
  final String? email;
  final String? name;

  const AdminInviteForm({
    Key? key,
    this.action = FormAction.create,
    required this.emailValidator,
    required this.onSubmitPressed,
    this.errorMessage,
    this.email,
    this.name,
  }) : super(key: key);

  @override
  State<AdminInviteForm> createState() => AdminInviteFormState();
}

class AdminInviteFormState extends State<AdminInviteForm> {
  TextEditingController emailTextController = TextEditingController();
  TextEditingController nameTextController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  @override
  void initState() {
    if (widget.action == FormAction.edit) {
      emailTextController.text = widget.email ?? '';
      nameTextController.text = widget.name ?? '';
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            widget.action == FormAction.create
                ? 'Fill in Admin details'
                : 'Update Admin details',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 12.0),
          widget.action == FormAction.create
              ? Text(
                  'Next, fill in the details of the new Admin.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                  textAlign: TextAlign.center,
                )
              : const SizedBox(),
          const SizedBox(height: 24.0),
          widget.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          TextFieldBlack(
            readOnly: widget.action == FormAction.edit,
            validator: (String? email) {
              if (widget.action == FormAction.create) {
                widget.emailValidator(email);
              } else {
                return null;
              }
            },
            label: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            controller: emailTextController,
          ),
          const SizedBox(height: 28.0),
          TextFieldBlack(
            validator: (String? name) => Validators.validateNotEmpty(
              name,
              'Please enter a name',
            ),
            label: 'Name',
            keyboardType: TextInputType.text,
            controller: nameTextController,
          ),
          const SizedBox(height: 36.0),
          PrimaryButton(
            label: widget.action == FormAction.create
                ? 'Invite Admin'
                : 'Update Admin details',
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                widget.onSubmitPressed(
                  emailTextController.text.trim(),
                  nameTextController.text.trim(),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    emailTextController.dispose();
    nameTextController.dispose();
    super.dispose();
  }
}
