import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/checkbox_field.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/user_management/widgets/form_action.dart';
import 'package:kvatt_app/domain/users/merchant.dart';

class PartnerInviteForm extends StatefulWidget {
  final FormAction? action;
  final List<Merchant>? allMerchants;
  final Function(String?) emailValidator;
  final Function(
    String email,
    String name,
    List<String> selectedMerchantIds,
  ) onSubmitPressed;
  final String? errorMessage;
  final String? email;
  final String? name;
  final List<String>? merchantIds;

  const PartnerInviteForm({
    Key? key,
    this.action = FormAction.create,
    required this.allMerchants,
    required this.emailValidator,
    required this.onSubmitPressed,
    this.email,
    this.name,
    this.merchantIds,
    this.errorMessage,
  }) : super(key: key);

  @override
  State<PartnerInviteForm> createState() => PartnerInviteFormState();
}

class PartnerInviteFormState extends State<PartnerInviteForm> {
  TextEditingController emailTextController = TextEditingController();
  TextEditingController nameTextController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  List<String> _selectedMerchantIds = [];

  @override
  void initState() {
    if (widget.action == FormAction.edit) {
      emailTextController.text = widget.email ?? '';
      nameTextController.text = widget.name ?? '';
      _selectedMerchantIds = widget.merchantIds ?? [];
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            widget.action == FormAction.create
                ? 'Fill in Partner details'
                : 'Update Partner details',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 12.0),
          widget.action == FormAction.create
              ? Text(
                  'Next, fill in the details of the new Partner.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onSurfaceMediumEmphasis,
                      ),
                  textAlign: TextAlign.center,
                )
              : const SizedBox(),
          const SizedBox(height: 16.0),
          widget.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          TextFieldBlack(
            readOnly: widget.action == FormAction.edit,
            validator: (String? email) => Validators.validateEmail(email),
            label: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            controller: emailTextController,
          ),
          const SizedBox(height: 28.0),
          TextFieldBlack(
            validator: (String? name) =>
                Validators.validateNotEmpty(name, 'Please enter a name'),
            label: 'Name',
            keyboardType: TextInputType.text,
            controller: nameTextController,
          ),
          const SizedBox(height: 28.0),
          Align(
            alignment: Alignment.centerLeft,
            child: Text(
              'Assign Merchants',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          const SizedBox(height: 8.0),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 8.0),
            decoration: BoxDecoration(
              border: Border.all(
                  color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis),
              borderRadius: const BorderRadius.all(Radius.circular(4.0)),
            ),
            child: Column(
              children: [
                widget.allMerchants != null
                    ? _buildMerchantsList()
                    : const LoadingSpinner(),
              ],
            ),
          ),
          const SizedBox(height: 28.0),
          const SizedBox(height: 36.0),
          PrimaryButton(
            label: widget.action == FormAction.create
                ? 'Invite Partner'
                : 'Update Partner details',
            onPressed: () {
              if (_formKey.currentState!.validate()) {
                widget.onSubmitPressed(
                  emailTextController.text.trim(),
                  nameTextController.text.trim(),
                  _selectedMerchantIds,
                );
              }
            },
          ),
        ],
      ),
    );
  }

  Widget _buildMerchantsList() {
    return ListView.builder(
      physics: const NeverScrollableScrollPhysics(),
      shrinkWrap: true,
      itemBuilder: (
        BuildContext context,
        int index,
      ) {
        return CheckboxField(
          label: widget.allMerchants![index].name,
          value: widget.merchantIds == null
              ? false
              : widget.merchantIds!.contains(widget.allMerchants![index].uid),
          onChanged: (bool value) {
            if (value == true) {
              _selectedMerchantIds.add(widget.allMerchants![index].uid!);
            } else {
              _selectedMerchantIds.remove(widget.allMerchants![index].uid!);
            }
          },
        );
      },
      itemCount: widget.allMerchants!.length,
    );
  }

  @override
  void dispose() {
    emailTextController.dispose();
    nameTextController.dispose();
    super.dispose();
  }
}
