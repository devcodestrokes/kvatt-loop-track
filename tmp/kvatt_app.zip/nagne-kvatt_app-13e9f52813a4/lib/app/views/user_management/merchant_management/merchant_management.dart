import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/common/widgets/tables/traditional_table.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/user_management/merchant_management/merchant_management_view_model.dart';
import 'package:kvatt_app/app/views/user_management/widgets/account_status_pill.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_account_status.dart';

class MerchantManagement extends StatefulWidget {
  final MerchantManagementViewModel viewModel;

  const MerchantManagement({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  State<MerchantManagement> createState() => _MerchantManagementState();
}

class _MerchantManagementState extends State<MerchantManagement> {
  @override
  Widget build(BuildContext context) {
    return widget.viewModel.merchants != null
        ? widget.viewModel.merchants!.isEmpty
            ? Center(
                child: Text(
                  'No merchant has been invited yet.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceDisabled),
                ),
              )
            : SingleChildScrollView(
                child: Padding(
                  padding: const EdgeInsets.symmetric(vertical: 24.0),
                  child: TraditionalTable(
                    tableConfig: TableConfig(
                      headers: ['Email', 'Name', 'Account Status', ''],
                      data:
                          widget.viewModel.merchants!.map((Merchant merchant) {
                        return [
                          merchant.email,
                          merchant.name,
                          Row(
                            children: [
                              AccountStatusPill(
                                  accountStatus: merchant.accountStatus),
                              merchant.accountStatus ==
                                      UserAccountStatus.pending
                                  ? _buildResendInvite(
                                      context: context, email: merchant.email)
                                  : const SizedBox(),
                            ],
                          ),
                          IconButton(
                            onPressed: () => widget.viewModel
                                .onEditMerchantTapped(merchant.uid),
                            icon: Icon(
                              Icons.edit,
                              size: 16.0,
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceDisabled,
                            ),
                          ),
                        ];
                      }).toList(),
                    ),
                  ),
                ),
              )
        : const LoadingSpinner();
  }

  Widget _buildResendInvite({
    required BuildContext context,
    required String email,
  }) {
    return Row(
      children: [
        const SizedBox(width: 4.0),
        PromptTextButton(
          promptText: '',
          actionLabel: 'resend invite',
          onPressed: () async {
            LoadingDialog.show(context, 'resending invite...');
            await widget.viewModel.onResendInviteTapped(email);
            if (!mounted) return;
            Navigator.of(context).pop();
          },
        ),
      ],
    );
  }
}
