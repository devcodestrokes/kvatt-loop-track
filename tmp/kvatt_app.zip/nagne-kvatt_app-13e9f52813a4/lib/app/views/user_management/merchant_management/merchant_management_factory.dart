import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/user_management/merchant_management/merchant_management.dart';
import 'package:kvatt_app/app/views/user_management/merchant_management/merchant_management_view_model.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class MerchantManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<MerchantManagementViewModel>(
      create: (context) {
        return MerchantManagementViewModel(
            userManager: Provider.of<UserManager>(
              context,
              listen: false,
            ),
            uiState: Provider.of<UiState>(
              context,
              listen: false,
            ));
      },
      child: Consumer<MerchantManagementViewModel>(
        builder: (context, model, child) => MerchantManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
