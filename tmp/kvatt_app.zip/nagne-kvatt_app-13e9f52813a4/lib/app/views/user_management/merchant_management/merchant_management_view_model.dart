import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

class MerchantManagementViewModel extends ChangeNotifier {
  UserManager userManager;
  UiState uiState;

  List<List<dynamic>>? tableData;

  StreamSubscription<List<Merchant>>? merchantsSubscription;

  List<Merchant>? merchants;

  MerchantManagementViewModel({
    required this.userManager,
    required this.uiState,
  }) {
    merchantsSubscription =
        userManager.merchants().listen((List<Merchant> merchants) {
      this.merchants = merchants;
      notifyListeners();
    });
  }

  Future<void> onResendInviteTapped(String email) async {
    try {
      await userManager.resendInvite(email: email);
    } catch (e) {
      //TODO: Handle error when sending invite fails
    }
  }

  onEditMerchantTapped(String? uid) {
    uiState.updateView(ViewConfig(
      appView: AppView.editUser,
      params: {
        'userId': uid ?? '',
      },
    ));
  }

  @override
  void dispose() {
    merchantsSubscription?.cancel();
    super.dispose();
  }
}
