import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/app/views/user_management/admin_management/admin_management.dart';
import 'package:kvatt_app/app/views/user_management/admin_management/admin_management_view_model.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class AdminManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<AdminManagementViewModel>(
      create: (context) {
        return AdminManagementViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<AdminManagementViewModel>(
        builder: (context, model, child) => AdminManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
