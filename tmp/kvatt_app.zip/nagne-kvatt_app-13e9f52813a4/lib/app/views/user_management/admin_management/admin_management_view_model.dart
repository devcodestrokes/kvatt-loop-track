import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/users/admin.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

class AdminManagementViewModel extends ChangeNotifier {
  UserManager userManager;
  UiState uiState;

  List<List<dynamic>>? tableData;

  StreamSubscription<List<Admin>>? adminsSubscription;

  List<Admin>? admins;

  AdminManagementViewModel({
    required this.userManager,
    required this.uiState,
  }) {
    adminsSubscription = userManager.admins().listen((List<Admin> admins) {
      this.admins = admins;
      notifyListeners();
    });
  }

  Future<void> onResendInviteTapped(String email) async {
    try {
      await userManager.resendInvite(email: email);
    } catch (e) {
      //TODO: Handle error when sending invite fails
    }
  }

  onEditAdminTapped(String? uid) {
    uiState.updateView(ViewConfig(
      appView: AppView.editUser,
      params: {
        'userId': uid ?? '',
      },
    ));
  }

  @override
  void dispose() {
    adminsSubscription?.cancel();
    super.dispose();
  }
}
