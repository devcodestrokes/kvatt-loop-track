import 'package:flutter/material.dart';
import 'package:kvatt_app/domain/products/available_products.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';

enum StockStatus {
  availableForUse,
  returned,
  inMaintenance,
  enRouteToMerchant,
  withMerchant,
  withMerchantReturned,
  withCustomer,
}

class StockLevelsViewModel extends ChangeNotifier {
  PackagingsManager packagingsManager;

  StockLevelsViewModel({
    required this.packagingsManager,
  });

  Map<StockStatus, Map<String, int>> stockLevelMap = {
    StockStatus.availableForUse: {},
    StockStatus.returned: {},
    StockStatus.inMaintenance: {},
    StockStatus.enRouteToMerchant: {},
    StockStatus.withMerchant: {},
    StockStatus.withMerchantReturned: {},
    StockStatus.withCustomer: {},
  };

  bool isLoading = true;

  Future<void> loadData() async {
    List<int> counts = await _fetchCounts();
    _populateStockLevels(counts);
    isLoading = false;
    notifyListeners();
  }

  int get totalAvailableForUse {
    if (stockLevelMap[StockStatus.availableForUse] == null) {
      return 0;
    }
    return stockLevelMap[StockStatus.availableForUse]!.values.fold(0,
        (previousValue, int value) {
      return previousValue + value;
    });
  }

  int get totalReturned {
    if (stockLevelMap[StockStatus.returned] == null) {
      return 0;
    }
    return stockLevelMap[StockStatus.returned]!.values.fold(0,
        (previousValue, int value) {
      return previousValue + value;
    });
  }

  int get totalInMaintenance {
    if (stockLevelMap[StockStatus.inMaintenance] == null) {
      return 0;
    }
    return stockLevelMap[StockStatus.inMaintenance]!.values.fold(0,
        (previousValue, int value) {
      return previousValue + value;
    });
  }

  int get totalEnRouteToMerchant {
    if (stockLevelMap[StockStatus.enRouteToMerchant] == null) {
      return 0;
    }
    return stockLevelMap[StockStatus.enRouteToMerchant]!.values.fold(0,
        (previousValue, int value) {
      return previousValue + value;
    });
  }

  int get totalWithMerchant {
    if (stockLevelMap[StockStatus.withMerchant] == null) {
      return 0;
    }
    return stockLevelMap[StockStatus.withMerchant]!.values.fold(0,
        (previousValue, int value) {
      return previousValue + value;
    });
  }

  int get totalWithMerchantReturned {
    if (stockLevelMap[StockStatus.withMerchantReturned] == null) {
      return 0;
    }
    return stockLevelMap[StockStatus.withMerchantReturned]!.values.fold(0,
        (previousValue, int value) {
      return previousValue + value;
    });
  }

  int get totalWithCustomer {
    if (stockLevelMap[StockStatus.withCustomer] == null) {
      return 0;
    }
    return stockLevelMap[StockStatus.withCustomer]!.values.fold(0,
        (previousValue, int value) {
      return previousValue + value;
    });
  }

  void _populateStockLevels(List<int> counts) {
    int index = 0;

    for (var product in availableProducts) {
      stockLevelMap[StockStatus.availableForUse]?[product] = counts[index];
      index++;
      stockLevelMap[StockStatus.returned]?[product] = counts[index];
      index++;
      stockLevelMap[StockStatus.inMaintenance]?[product] = counts[index];
      index++;
      stockLevelMap[StockStatus.enRouteToMerchant]?[product] = counts[index];
      index++;
      stockLevelMap[StockStatus.withMerchant]?[product] = counts[index];
      index++;
      stockLevelMap[StockStatus.withMerchantReturned]?[product] = counts[index];
      index++;
      stockLevelMap[StockStatus.withCustomer]?[product] = counts[index];
      index++;
    }
  }

  Future<List<int>> _fetchCounts() async {
    List<Future<int>> fetchTasks = [];
    for (var product in availableProducts) {
      fetchTasks.addAll(
        [
          packagingsManager.getNumPacksAvailableForUse(
            type: product,
          ),
          packagingsManager.getNumPacksReturned(
            type: product,
          ),
          packagingsManager.getNumPacksInMaintenance(
            type: product,
          ),
          packagingsManager.getNumPacksEnRouteToMerchants(
            type: product,
          ),
          packagingsManager.getNumPacksWithMerchants(
            type: product,
          ),
          packagingsManager.getNumPacksWithMerchantsReturned(
            type: product,
          ),
          packagingsManager.getNumPacksWithCustomers(
            type: product,
          ),
        ],
      );
    }

    List<int> results = await Future.wait(fetchTasks);
    return results;
  }
}
