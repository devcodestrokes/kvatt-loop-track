import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/common/widgets/stat_cards/stat_card.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/stock_management/stock_levels/stock_levels_view_model.dart';
import 'package:kvatt_app/domain/products/available_products.dart';

class StockLevels extends StatefulWidget {
  final StockLevelsViewModel viewModel;

  const StockLevels({
    super.key,
    required this.viewModel,
  });

  @override
  State<StockLevels> createState() => _StockLevelsState();
}

class _StockLevelsState extends State<StockLevels> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.loadData();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: widget.viewModel.isLoading == true
          ? const Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                SizedBox(height: 80.0),
                LoadingSpinner(),
              ],
            )
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const SizedBox(height: 24.0),
                _buildAvailableForUseSection(),
                _buildReturnedSection(),
                _buildInMaintenanceSection(),
                _buildEnRouteToMerchantSection(),
                _buildWithMerchantSection(),
                _buildWithMerchantReturnedSection(),
                _buildWithCustomerSection(),
                const SizedBox(height: 24.0),
              ],
            ),
    );
  }

  Widget _buildAvailableForUseSection() {
    return _buildSection(
      context: context,
      title:
          'In Store (Ready for use)  (total = ${widget.viewModel.totalAvailableForUse})',
      widgets: availableProducts.map((String product) {
        return StatCard(
          width: 200.0,
          height: 100.0,
          value: widget
              .viewModel.stockLevelMap[StockStatus.availableForUse]![product]
              .toString(),
          label: product,
        );
      }).toList(),
    );
  }

  Widget _buildReturnedSection() {
    return _buildSection(
      context: context,
      title: 'Returned  (total = ${widget.viewModel.totalReturned})',
      widgets: availableProducts.map((String product) {
        return StatCard(
          width: 200.0,
          height: 100.0,
          value: widget.viewModel.stockLevelMap[StockStatus.returned]![product]
              .toString(),
          label: product,
        );
      }).toList(),
    );
  }

  Widget _buildInMaintenanceSection() {
    return _buildSection(
      context: context,
      title:
          'Undergoing maintenance  (total = ${widget.viewModel.totalInMaintenance})',
      widgets: availableProducts.map((String product) {
        return StatCard(
          width: 200.0,
          height: 100.0,
          value: widget
              .viewModel.stockLevelMap[StockStatus.inMaintenance]![product]
              .toString(),
          label: product,
        );
      }).toList(),
    );
  }

  Widget _buildEnRouteToMerchantSection() {
    return _buildSection(
      context: context,
      title:
          'En route to merchants  (total = ${widget.viewModel.totalEnRouteToMerchant})',
      widgets: availableProducts.map((String product) {
        return StatCard(
          width: 200.0,
          height: 100.0,
          value: widget
              .viewModel.stockLevelMap[StockStatus.enRouteToMerchant]![product]
              .toString(),
          label: product,
        );
      }).toList(),
    );
  }

  Widget _buildWithMerchantSection() {
    return _buildSection(
      context: context,
      title: 'With merchants  (total = ${widget.viewModel.totalWithMerchant})',
      widgets: availableProducts.map((String product) {
        return StatCard(
          width: 200.0,
          height: 100.0,
          value: widget
              .viewModel.stockLevelMap[StockStatus.withMerchant]![product]
              .toString(),
          label: product,
        );
      }).toList(),
    );
  }

  Widget _buildWithMerchantReturnedSection() {
    return _buildSection(
      context: context,
      title:
          'With merchants (Returned) (total = ${widget.viewModel.totalWithMerchantReturned})',
      widgets: availableProducts.map((String product) {
        return StatCard(
          width: 200.0,
          height: 100.0,
          value: widget.viewModel
              .stockLevelMap[StockStatus.withMerchantReturned]![product]
              .toString(),
          label: product,
        );
      }).toList(),
    );
  }

  Widget _buildWithCustomerSection() {
    return _buildSection(
      context: context,
      title: 'With customers  (total = ${widget.viewModel.totalWithCustomer})',
      widgets: availableProducts.map((String product) {
        return StatCard(
          width: 200.0,
          height: 100.0,
          value: widget
              .viewModel.stockLevelMap[StockStatus.withCustomer]![product]
              .toString(),
          label: product,
        );
      }).toList(),
    );
  }

  Widget _buildSection({
    required BuildContext context,
    required String title,
    required List<Widget> widgets,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const SizedBox(height: 16.0),
        Text(
          title,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
        ),
        const SizedBox(height: 16.0),
        Wrap(
          spacing: 8.0,
          runSpacing: 8.0,
          children: widgets,
        ),
      ],
    );
  }
}
