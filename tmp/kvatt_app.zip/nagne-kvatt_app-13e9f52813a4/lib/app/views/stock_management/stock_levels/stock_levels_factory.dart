import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/views/stock_management/stock_levels/stock_levels.dart';
import 'package:kvatt_app/app/views/stock_management/stock_levels/stock_levels_view_model.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';

import 'package:provider/provider.dart';

class StockLevelsFactory {
  static Widget build() {
    return ChangeNotifierProvider<StockLevelsViewModel>(
      create: (context) {
        return StockLevelsViewModel(
          packagingsManager:
              Provider.of<PackagingsManager>(context, listen: false),
        );
      },
      child: Consumer<StockLevelsViewModel>(
        builder: (context, model, child) => StockLevels(
          viewModel: model,
        ),
      ),
    );
  }
}
