import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/stock_management/shipment_management/shipment_management_view_model.dart';
import 'package:kvatt_app/app/views/stock_management/shipment_management/widgets/shipment_input_form.dart';
import 'package:kvatt_app/domain/users/merchant.dart';

class ShipmentManagement extends StatefulWidget {
  final ShipmentManagementViewModel viewModel;

  const ShipmentManagement({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  State<ShipmentManagement> createState() => _ShipmentManagementState();
}

class _ShipmentManagementState extends State<ShipmentManagement> {
  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.loadData();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.3,
            child: Column(
              children: [
                const SizedBox(height: 48.0),
                widget.viewModel.isLoading == true
                    ? const LoadingSpinner()
                    : widget.viewModel.successSubmissionMessage != null
                        ? _buildSuccessSubmission()
                        : ShipmentInputForm(
                            merchants: widget.viewModel.merchants,
                            errorMessage:
                                widget.viewModel.returnInputErrorMessage,
                            onSubmitPressed: (
                              Merchant merchant,
                              List<Map<String, String>> productQuantities,
                              DateTime date,
                              String? shippingService,
                              String? trackingNumber,
                            ) async {
                              LoadingDialog.show(
                                context,
                                'recording shipment ...',
                                loadingDialogMode: LoadingDialogMode.onSurface,
                              );
                              await widget.viewModel.onShipmentSubmitted(
                                merchant: merchant,
                                productQuantities: productQuantities,
                                date: date,
                                shippingService: shippingService,
                                trackingNumber: trackingNumber,
                              );
                              if (!mounted) return;
                              Navigator.of(context).pop();
                            },
                          ),
                const SizedBox(height: 12.0),
              ],
            ),
          ),
        ],
      ),
    );
  }

  _buildSuccessSubmission() {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text(
          widget.viewModel.successSubmissionMessage!,
          style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              height: 1.4),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 16.0),
        Text(
          'Click on Submit More to record another shipment.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              height: 1.4),
          textAlign: TextAlign.center,
        ),
        const SizedBox(height: 24.0),
        SizedBox(
          width: 160.0,
          child: SecondaryButton(
            label: 'Submit More',
            onPressed: () {
              setState(() {
                widget.viewModel.onSubmitMorePressed();
              });
            },
          ),
        ),
      ],
    );
  }
}
