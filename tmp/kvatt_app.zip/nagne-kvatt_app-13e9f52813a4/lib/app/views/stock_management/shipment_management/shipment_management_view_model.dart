import 'package:flutter/material.dart';
import 'package:kvatt_app/domain/shipments/shipment.dart';
import 'package:kvatt_app/domain/shipments/shipment_manager.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

class ShipmentManagementViewModel extends ChangeNotifier {
  UserManager userManager;
  ShipmentManager shipmentManager;

  List<Merchant> merchants = [];

  String? successSubmissionMessage;
  String? returnInputErrorMessage;
  bool isLoading = false;

  ShipmentManagementViewModel({
    required this.userManager,
    required this.shipmentManager,
  });

  Future<void> loadData() async {
    isLoading = true;
    notifyListeners();
    merchants = await userManager.retrieveActiveMerchants();
    isLoading = false;
    notifyListeners();
  }

  Future<void> onShipmentSubmitted({
    required Merchant merchant,
    required List<Map<String, String>> productQuantities,
    required DateTime date,
    required String? shippingService,
    required String? trackingNumber,
  }) async {
    try {
      await shipmentManager.recordShipment(
        shipment: Shipment(
          productQuantities: productQuantities,
          date: date,
          shippingService: shippingService,
          trackingNumber: trackingNumber,
        ),
        merchantId: merchant.uid!,
      );
      successSubmissionMessage =
          'Shipment information was successfully recorded. The merchant will receive an email with the shipment information.';
    } catch (e) {
      returnInputErrorMessage =
          'There was an issue submitting the shipment information.';
    }
    notifyListeners();
  }

  onSubmitMorePressed() {
    successSubmissionMessage = null;
    notifyListeners();
  }
}
