import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/views/stock_management/shipment_management/shipment_management.dart';
import 'package:kvatt_app/app/views/stock_management/shipment_management/shipment_management_view_model.dart';
import 'package:kvatt_app/domain/shipments/shipment_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class ShipmentManagementFactory {
  static Widget build() {
    return ChangeNotifierProvider<ShipmentManagementViewModel>(
      create: (context) {
        return ShipmentManagementViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          shipmentManager: Provider.of<ShipmentManager>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<ShipmentManagementViewModel>(
        builder: (context, model, child) => ShipmentManagement(
          viewModel: model,
        ),
      ),
    );
  }
}
