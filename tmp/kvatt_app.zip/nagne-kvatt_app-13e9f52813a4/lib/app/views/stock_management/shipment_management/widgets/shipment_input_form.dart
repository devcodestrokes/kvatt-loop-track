import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/custom_datepicker.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/packaging_selector.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'package:kvatt_app/domain/shipments/available_shipping_services.dart';
import 'package:kvatt_app/domain/users/merchant.dart';

class ShipmentInputForm extends StatefulWidget {
  final Function(
    Merchant merchant,
    List<Map<String, String>> productQuantities,
    DateTime date,
    String? shippingService,
    String? trackingNumber,
  ) onSubmitPressed;
  final List<Merchant> merchants;
  final String? errorMessage;

  const ShipmentInputForm({
    Key? key,
    required this.onSubmitPressed,
    required this.merchants,
    this.errorMessage,
  }) : super(key: key);

  @override
  State<ShipmentInputForm> createState() => ShipmentInputFormState();
}

class ShipmentInputFormState extends State<ShipmentInputForm> {
  TextEditingController dateTextController = TextEditingController();
  TextEditingController trackingNumberTextController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  Merchant? _selectedMerchant;
  DateTime? _date;
  String? _selectedShippingService;
  List<Map<String, String>> _productQuantities = [];

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Record shipment',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          widget.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        widget.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          DropDownFieldBlack(
            validator: (String? value) => Validators.validateNotEmpty(
              value,
              'Select merchant',
            ),
            label: 'Merchant',
            items: widget.merchants
                .map((Merchant merchant) => merchant.name)
                .toList(),
            onItemSelected: (String item) {
              _selectedMerchant = widget.merchants
                  .where((Merchant merchant) => merchant.name == item)
                  .first;
            },
          ),
          const SizedBox(height: 28.0),
          PackagingSelector(
            onItemAdded: (List<Map<String, String>> itemsAdded) {
              _productQuantities = itemsAdded;
            },
            initialItems: const [],
          ),
          const SizedBox(height: 28.0),
          Row(
            children: [
              Expanded(
                flex: 1,
                child: CustomDatePicker(
                  textController: dateTextController,
                  isEnabled: true,
                  validatorMessage: 'Enter date',
                  label: 'Date',
                  initialDate: DateTime.now(),
                  firstDate: DateTime.parse('2020-01-01'),
                  lastDate: DateTime.now(),
                  onDateSelected: (DateTime date) {
                    setState(() {
                      _date = date;
                      dateTextController.text =
                          DateFormat('dd/MM/yyyy').format(_date!);
                    });
                  },
                ),
              ),
            ],
          ),
          const SizedBox(height: 28.0),
          DropDownFieldBlack(
            label: 'Shipping service',
            items: availableShippingServices,
            onItemSelected: (String item) {
              _selectedShippingService = item;
            },
          ),
          const SizedBox(height: 28.0),
          TextFieldBlack(
            validator: (String? numShipped) {
              return null;
            },
            label: 'Tracking code',
            keyboardType: TextInputType.text,
            controller: trackingNumberTextController,
          ),
          const SizedBox(height: 36.0),
          Text(
            'Once you click on Submit, the shipment information will be saved and the merchant will receive an email with the shipment information and a reminder for them to update their stock levels in the Kvatt Platform.',
            style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 16.0),
          PrimaryButton(
            label: 'Submit',
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                await widget.onSubmitPressed(
                  _selectedMerchant!,
                  _productQuantities,
                  _date!,
                  _selectedShippingService,
                  trackingNumberTextController.text.trim(),
                );
              }
            },
          ),
          const SizedBox(height: 24.0),
        ],
      ),
    );
  }

  @override
  void dispose() {
    dateTextController.dispose();
    trackingNumberTextController.dispose();
    super.dispose();
  }
}
