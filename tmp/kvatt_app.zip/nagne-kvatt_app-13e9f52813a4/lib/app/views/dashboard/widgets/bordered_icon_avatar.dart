import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class BorderedIconAvatar extends StatelessWidget {
  final double radius;
  final IconData icon;

  const BorderedIconAvatar({
    Key? key,
    required this.radius,
    required this.icon,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      backgroundColor: Theme.of(context).colorScheme.onSurfaceDisabled,
      radius: radius + 1.0,
      child: CircleAvatar(
        radius: radius,
        backgroundColor: Colors.white,
        child: Icon(
          icon,
          color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
          size: radius - 1.0,
        ),
      ),
    );
  }
}
