import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/filters/date_filter/date_filter.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/merchant_dashboard_view_model.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/widgets/data_card_coming_soon.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/widgets/packaging_shipment_card.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/widgets/pick_up_info_card.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/widgets/pick_up_info_tip_dialog.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/widgets/return_info_card.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/widgets/return_info_tip_dialog.dart';

class MerchantDashboard extends StatefulWidget {
  final MerchantDashboardViewModel viewModel;

  const MerchantDashboard({
    super.key,
    required this.viewModel,
  });

  @override
  State<MerchantDashboard> createState() => _MerchantDashboardState();
}

class _MerchantDashboardState extends State<MerchantDashboard> {
  _showReturnInfoTipDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return ReturnInfoTipDialog(
          onClosePressed: () {
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  _showCheckoutPickUpInfoTipDialog() {
    showDialog(
      barrierDismissible: false,
      context: context,
      builder: (BuildContext context) {
        return PickUpInfoTipDialog(
          onClosePressed: () {
            Navigator.of(context).pop();
          },
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.init();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceColor,
      body: widget.viewModel.isLoadingPackagingReceiptsData &&
              widget.viewModel.isLoadingInsightsData
          ? const LoadingSpinner()
          : Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Column(
                    children: [
                      widget.viewModel.isLoadingPackagingReceiptsData
                          ? const LoadingSpinner()
                          : ListView.builder(
                              itemCount: widget
                                  .viewModel.awaitingPackagingShipments.length,
                              itemBuilder: (BuildContext context, int index) {
                                return Column(
                                  children: [
                                    SizedBox(
                                      width: MediaQuery.of(context).size.width,
                                      child: PackagingShipmentCard(
                                        onAcknowledgeReceiptTapped: () async {
                                          await widget.viewModel
                                              .onAcknowledgeReceiptTapped(
                                            packagingShipment: widget.viewModel
                                                    .awaitingPackagingShipments[
                                                index],
                                          );
                                        },
                                        packagingShipment: widget.viewModel
                                            .awaitingPackagingShipments[index],
                                      ),
                                    ),
                                    const SizedBox(height: 8.0),
                                  ],
                                );
                              },
                              shrinkWrap: true,
                            ),
                    ],
                  ),
                ),
                const SizedBox(height: 16.0),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Padding(
                      padding: const EdgeInsets.only(left: 24.0),
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: DateFilter(
                          earliestStartDate: DateTime.parse('2022-01-01'),
                          latestEndDate: DateTime.now(),
                          onRangeSelected: (DateTimeRange? range) =>
                              widget.viewModel.onDateRangeSelected(range),
                        ),
                      ),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(right: 24.0),
                      child: TextButton(
                        onPressed: () => widget.viewModel.onRefreshTapped(),
                        child: Row(
                          children: [
                            Text(
                              'Refresh',
                              style: Theme.of(context).textTheme.labelLarge,
                            ),
                            const SizedBox(width: 8.0),
                            Icon(
                              Icons.refresh,
                              size: 28.0,
                              color: Theme.of(context)
                                  .colorScheme
                                  .onSurfaceHighEmphasis,
                            ),
                          ],
                        ),
                      ),
                    ),
                  ],
                ),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 24.0),
                  child: Column(
                    children: [
                      const SizedBox(height: 24.0),
                      Row(
                        children: [
                          Expanded(
                            flex: 1,
                            child: ReturnInfoCard(
                              onTooltipTapped: () {
                                _showReturnInfoTipDialog();
                              },
                              numReturned:
                                  widget.viewModel.returnInfo?.numReturned,
                              numPending:
                                  widget.viewModel.returnInfo?.numPending,
                              numLost: widget.viewModel.returnInfo?.numLost,
                              returnRatePercentage:
                                  widget.viewModel.returnRatePercentage,
                              minReturnDays:
                                  widget.viewModel.returnInfo?.minReturnDays,
                              maxReturnDays:
                                  widget.viewModel.returnInfo?.maxReturnDays,
                              averageReturnDays: widget
                                  .viewModel.returnInfo?.averageReturnDays,
                              isLoading: widget.viewModel.isLoadingInsightsData,
                            ),
                          ),
                          const SizedBox(width: 48.0),
                          Expanded(
                            flex: 1,
                            child: PickUpInfoCard(
                              onTooltipTapped: () {
                                _showCheckoutPickUpInfoTipDialog();
                              },
                              totalOrders: widget
                                  .viewModel.checkoutPickUpInfo?.totalOrders,
                              numOrdersWithKvattPack: widget.viewModel
                                  .checkoutPickUpInfo?.numOrdersWithKvattPack,
                              pickUpRate: (widget
                                  .viewModel.checkoutPickUpInfo?.pickUpRate),
                              isLoading: widget.viewModel.isLoadingInsightsData,
                              isShopifyConnected:
                                  widget.viewModel.checkoutPickUpInfo != null,
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 32.0),
                      Row(
                        children: [
                          const Expanded(
                            flex: 1,
                            child: DataCardComingSoon(
                              height: 250.0,
                              label: 'GHG Emissions Savings',
                            ),
                          ),
                          const SizedBox(width: 48.0),
                          Expanded(
                            flex: 1,
                            child: Container(),
                          ),
                        ],
                      )
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}
