import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/merchant_dashboard_view_model.dart';
import 'package:kvatt_core/domain/insights/insights_manager.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_manager.dart';
import 'package:provider/provider.dart';

import 'merchant_dashboard.dart';

class MerchantDashboardFactory {
  static Widget build() {
    return ChangeNotifierProvider<MerchantDashboardViewModel>(
      create: (context) {
        return MerchantDashboardViewModel(
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
          insightsManager: Provider.of<InsightsManager>(
            context,
            listen: false,
          ),
          packagingShipmentsManager: Provider.of<PackagingShipmentsManager>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<MerchantDashboardViewModel>(
        builder: (context, model, child) => MerchantDashboard(
          viewModel: model,
        ),
      ),
    );
  }
}
