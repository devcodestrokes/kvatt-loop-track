import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipment.dart';

class PackagingShipmentCard extends StatefulWidget {
  final PackagingShipment packagingShipment;
  final Function onAcknowledgeReceiptTapped;

  const PackagingShipmentCard({
    super.key,
    required this.packagingShipment,
    required this.onAcknowledgeReceiptTapped,
  });

  @override
  State<PackagingShipmentCard> createState() => _PackagingShipmentCardState();
}

class _PackagingShipmentCardState extends State<PackagingShipmentCard> {
  bool _isProcessing = false;

  Widget _buildProductQuantities(BuildContext context) {
    List<Row> children = [];

    List<String> products = widget.packagingShipment.products;

    for (var product in products) {
      children.add(
        Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            const SizedBox(width: 12.0),
            Text(
              '${widget.packagingShipment.productQuantities[product]}',
              style: Theme.of(context).textTheme.titleSmall?.copyWith(
                    color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                    fontSize: 18.0,
                  ),
            ),
            const SizedBox(width: 4.0),
            Text(
              product,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                  ),
            ),
            Text(
              ',',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                  ),
            ),
          ],
        ),
      );
    }

    children.last.children.removeLast();

    return SizedBox(
      width: 500.0,
      child: Wrap(
        runSpacing: 6.0,
        children: children,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 4.0,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.zero,
      ),
      color: Theme.of(context).colorScheme.secondaryColor,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(24.0, 12.0, 24.0, 12.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              children: [
                ImageIcon(
                  const AssetImage(AssetsFactory.packagingsIcon),
                  color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                ),
                const SizedBox(width: 12.0),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Text(
                          'Kvatt has shipped the following packs to you on ',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onPrimaryHighEmphasis,
                                  ),
                        ),
                        Text(
                          DateFormat('dd/MM/yyyy')
                              .format(widget.packagingShipment.sentDate),
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onPrimaryHighEmphasis,
                                    fontWeight: FontWeight.bold,
                                  ),
                        ),
                        Text(
                          ' and they should be with you soon.',
                          style:
                              Theme.of(context).textTheme.bodyMedium?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onPrimaryHighEmphasis,
                                  ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 8.0),
                    _buildProductQuantities(context),
                    const SizedBox(height: 8.0),
                    Row(
                      children: [
                        Row(
                          children: [
                            Text(
                              'Click on ',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onPrimaryHighEmphasis,
                                  ),
                            ),
                            Text(
                              'Acknowledge Receipt',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onPrimaryHighEmphasis,
                                    fontWeight: FontWeight.bold,
                                  ),
                            ),
                            Text(
                              ' to confirm that you\'ve received the packs.',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium
                                  ?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onPrimaryHighEmphasis,
                                  ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ],
                ),
              ],
            ),
            SizedBox(
              width: 200.0,
              child: _isProcessing == true
                  ? const LoadingSpinner(
                      height: 36.0,
                      width: 36.0,
                    )
                  : PrimaryButton(
                      onPressed: () async {
                        setState(() {
                          _isProcessing = true;
                        });
                        await widget.onAcknowledgeReceiptTapped();
                        setState(() {
                          _isProcessing = false;
                        });
                      },
                      label: 'Acknowledge Receipt',
                      backgroundColor: Theme.of(context).primaryColor,
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
