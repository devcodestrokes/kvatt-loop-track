import 'package:flutter/material.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/insights/checkout_pick_up_info.dart';
import 'package:kvatt_core/domain/insights/insights_manager.dart';
import 'package:kvatt_core/domain/insights/return_info.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipment.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_manager.dart';

class MerchantDashboardViewModel extends ChangeNotifier {
  AuthState authState;
  InsightsManager insightsManager;
  PackagingShipmentsManager packagingShipmentsManager;

  MerchantDashboardViewModel({
    required this.authState,
    required this.insightsManager,
    required this.packagingShipmentsManager,
  });

  bool isLoadingPackagingReceiptsData = false;

  bool isLoadingInsightsData = false;

  List<PackagingShipment> awaitingPackagingShipments = [];

  Period? _selectedDateRangeFilter;

  ReturnInfo? returnInfo;

  CheckoutPickUpInfo? checkoutPickUpInfo;

  init() async {
    _reloadPackagingReceiptsData();
    _reloadInsightsData();
  }

  double? get returnRatePercentage {
    if (returnInfo?.returnRate == null) {
      return null;
    }
    return returnInfo!.returnRate! * 100;
  }

  onAcknowledgeReceiptTapped({
    required PackagingShipment packagingShipment,
  }) async {
    await packagingShipmentsManager.markPackagingShipmentAsReceived(
      packagingShipment: packagingShipment,
    );
    awaitingPackagingShipments.remove(packagingShipment);
    notifyListeners();
  }

  onRefreshTapped() {
    _selectedDateRangeFilter = null;
    _reloadPackagingReceiptsData();
    _reloadInsightsData();
  }

  onDateRangeSelected(DateTimeRange? range) {
    if (range == null) {
      _selectedDateRangeFilter = null;
    } else {
      _selectedDateRangeFilter = Period(
        start: range.start,
        end: range.end,
      );
    }

    _reloadInsightsData();
  }

  _reloadInsightsData() async {
    isLoadingInsightsData = true;
    notifyListeners();

    returnInfo = await insightsManager.getMerchantReturnInfo(
      merchantId: authState.activeUser!.uid!,
      period: _selectedDateRangeFilter,
    );

    checkoutPickUpInfo = await insightsManager.getMerchantCheckoutPickUpInfo(
      merchantId: authState.activeUser!.uid!,
      period: _selectedDateRangeFilter,
    );

    isLoadingInsightsData = false;
    notifyListeners();
  }

  _reloadPackagingReceiptsData() async {
    isLoadingPackagingReceiptsData = true;
    notifyListeners();
    awaitingPackagingShipments =
        await packagingShipmentsManager.retrieveAwaitingConfirmationShipments(
      merchantId: authState.activeUser!.uid ?? '',
    );

    isLoadingPackagingReceiptsData = false;
    notifyListeners();
  }
}
