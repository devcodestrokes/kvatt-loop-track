import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/common/widgets/buttons/tooltip_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class PickUpInfoCard extends StatefulWidget {
  final Function onTooltipTapped;
  final int? totalOrders;
  final int? numOrdersWithKvattPack;
  final double? pickUpRate;
  final bool? isLoading;
  final bool? isShopifyConnected;

  const PickUpInfoCard({
    super.key,
    required this.onTooltipTapped,
    required this.totalOrders,
    required this.numOrdersWithKvattPack,
    required this.pickUpRate,
    required this.isShopifyConnected,
    this.isLoading,
  });

  @override
  State<PickUpInfoCard> createState() => _PickUpInfoCardState();
}

class _PickUpInfoCardState extends State<PickUpInfoCard> {
  Widget _buildCheckoutInfoNoData() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.center,
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(height: 24.0),
        Padding(
          padding: const EdgeInsets.only(left: 24.0),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              Text(
                'Checkout pick-up\ninformation',
                style: Theme.of(context).textTheme.titleSmall?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                      fontWeight: FontWeight.bold,
                    ),
              ),
              const SizedBox(width: 12.0),
              ToolTipButton(
                onTapped: () => widget.onTooltipTapped(),
              ),
            ],
          ),
        ),
        const SizedBox(height: 32.0),
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              AssetsFactory.kvattLogoBlack,
              width: 60.0,
            ),
            const SizedBox(width: 24.0),
            Icon(
              Icons.arrow_back_rounded,
              color: Theme.of(context).colorScheme.onTrafficLightRed,
            ),
            const SizedBox(width: 12.0),
            Icon(
              Icons.close,
              size: 48.0,
              color: Theme.of(context).colorScheme.onTrafficLightRed,
            ),
            const SizedBox(width: 12.0),
            Icon(
              Icons.arrow_forward_rounded,
              color: Theme.of(context).colorScheme.onTrafficLightRed,
            ),
            const SizedBox(width: 16.0),
            Icon(
              Icons.shopping_cart_checkout,
              size: 40.0,
              color: Theme.of(context).colorScheme.onTrafficLightRed,
            )
          ],
        ),
        const SizedBox(height: 16.0),
        Text(
          'Add Kvatt at checkout to get your pick up rate.',
          style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceDisabled,
              ),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 240.0,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.backgroundColor,
        borderRadius: const BorderRadius.all(Radius.circular(20.0)),
        border: Border.all(
          color: Theme.of(context).colorScheme.surfaceDarkColor,
        ),
      ),
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              widget.isLoading == true
                  ? Column(
                      children: [
                        const SizedBox(height: 80.0),
                        const LoadingSpinner(
                          width: 50.0,
                          height: 50.0,
                        ),
                        const SizedBox(height: 12.0),
                        Text(
                          'Loading checkout pick-up information...',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceDisabled,
                                  ),
                        ),
                      ],
                    )
                  : widget.isShopifyConnected == false
                      ? _buildCheckoutInfoNoData()
                      : Row(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Expanded(
                              flex: 2,
                              child: Padding(
                                padding: const EdgeInsets.only(left: 24.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    const SizedBox(height: 24.0),
                                    Row(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.center,
                                      children: [
                                        Text(
                                          'Checkout pick-up\ninformation',
                                          style: Theme.of(context)
                                              .textTheme
                                              .titleSmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceHighEmphasis,
                                                fontWeight: FontWeight.bold,
                                              ),
                                        ),
                                        const SizedBox(width: 12.0),
                                        ToolTipButton(
                                          onTapped: () =>
                                              widget.onTooltipTapped(),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 24.0),
                                    Column(
                                      children: [
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Container(
                                                  width: 12.0,
                                                  height: 12.0,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .surfaceDarkColor,
                                                  ),
                                                ),
                                                const SizedBox(width: 4.0),
                                                Text(
                                                  'Total orders',
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodyMedium
                                                      ?.copyWith(
                                                        color: Theme.of(context)
                                                            .colorScheme
                                                            .onSurfaceHighEmphasis,
                                                      ),
                                                ),
                                              ],
                                            ),
                                            Text(
                                              widget.totalOrders.toString(),
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.copyWith(
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .onSurfaceMediumEmphasis,
                                                  ),
                                            ),
                                          ],
                                        ),
                                        const SizedBox(height: 6.0),
                                        Row(
                                          mainAxisAlignment:
                                              MainAxisAlignment.spaceBetween,
                                          children: [
                                            Row(
                                              children: [
                                                Container(
                                                  width: 12.0,
                                                  height: 12.0,
                                                  decoration: BoxDecoration(
                                                    shape: BoxShape.circle,
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .kvattNewGreen,
                                                  ),
                                                ),
                                                const SizedBox(width: 4.0),
                                                Text(
                                                  '"No Waste Experience"\norders',
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .bodyMedium
                                                      ?.copyWith(
                                                        color: Theme.of(context)
                                                            .colorScheme
                                                            .onSurfaceHighEmphasis,
                                                      ),
                                                ),
                                              ],
                                            ),
                                            Text(
                                              widget.numOrdersWithKvattPack
                                                  .toString(),
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.copyWith(
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .onSurfaceMediumEmphasis,
                                                  ),
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                            Expanded(
                              flex: 2,
                              child: Padding(
                                padding: const EdgeInsets.only(right: 28.0),
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.end,
                                  children: [
                                    const SizedBox(height: 40.0),
                                    Stack(
                                      alignment: Alignment.center,
                                      children: [
                                        SizedBox(
                                          width: 164.0,
                                          height: 164.0,
                                          child: PieChart(
                                            PieChartData(
                                              sectionsSpace: 4.0,
                                              sections: [
                                                PieChartSectionData(
                                                  value: widget.totalOrders !=
                                                              null &&
                                                          widget.numOrdersWithKvattPack !=
                                                              null
                                                      ? widget.totalOrders!
                                                              .toDouble() -
                                                          widget
                                                              .numOrdersWithKvattPack!
                                                              .toDouble()
                                                      : 0.0,
                                                  color: Theme.of(context)
                                                      .colorScheme
                                                      .surfaceDarkColor,
                                                  radius: 12.0,
                                                  showTitle: false,
                                                ),
                                                PieChartSectionData(
                                                  value: widget
                                                          .numOrdersWithKvattPack
                                                          ?.toDouble() ??
                                                      0.0,
                                                  color: Theme.of(context)
                                                      .colorScheme
                                                      .kvattNewGreen,
                                                  radius: 12.0,
                                                  showTitle: false,
                                                ),
                                              ],
                                            ),
                                          ),
                                        ),
                                        Column(
                                          children: [
                                            RichText(
                                              text: TextSpan(
                                                children: [
                                                  TextSpan(
                                                    text: widget.pickUpRate ==
                                                            null
                                                        ? 'n/a'
                                                        : NumberFormat(
                                                                '#,###,###.#')
                                                            .format(widget
                                                                    .pickUpRate! *
                                                                100),
                                                    style: Theme.of(context)
                                                        .textTheme
                                                        .headlineMedium
                                                        ?.copyWith(
                                                          color: Theme.of(
                                                                  context)
                                                              .colorScheme
                                                              .onSurfaceHighEmphasis,
                                                        ),
                                                  ),
                                                  TextSpan(
                                                      text: widget.pickUpRate !=
                                                              null
                                                          ? '%'
                                                          : '',
                                                      style: Theme.of(context)
                                                          .textTheme
                                                          .headlineSmall
                                                          ?.copyWith(
                                                            color: Theme.of(
                                                                    context)
                                                                .colorScheme
                                                                .onSurfaceHighEmphasis,
                                                          )),
                                                ],
                                              ),
                                            ),
                                            Text(
                                              'Pick-up rate\nat checkout',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodySmall
                                                  ?.copyWith(
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .onSurfaceMediumEmphasis,
                                                  ),
                                              textAlign: TextAlign.center,
                                            ),
                                          ],
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          ],
                        ),
              const SizedBox(height: 24.0),
            ],
          );
        },
      ),
    );
  }
}
