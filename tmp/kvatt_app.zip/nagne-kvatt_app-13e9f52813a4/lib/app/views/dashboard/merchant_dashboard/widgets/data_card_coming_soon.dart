import 'package:flutter/material.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class DataCardComingSoon extends StatelessWidget {
  final String label;
  final double? height;

  const DataCardComingSoon({
    super.key,
    required this.label,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.backgroundColor,
        borderRadius: const BorderRadius.all(Radius.circular(20.0)),
        border: Border.all(
          color: Theme.of(context).colorScheme.surfaceDarkColor,
        ),
      ),
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    'Coming soon',
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                ],
              ),
              const SizedBox(height: 24.0),
              Text(
                label,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                    ),
              ),
              const SizedBox(height: 8.0),
              SizedBox(
                width: constraints.maxWidth * 0.5,
                child: Divider(
                  color: Theme.of(context).colorScheme.onSurfaceDisabled,
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}
