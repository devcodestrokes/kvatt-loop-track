import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class ReturnInfoTipDialog extends StatelessWidget {
  final Function onClosePressed;

  const ReturnInfoTipDialog({
    super.key,
    required this.onClosePressed,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      scrollable: true,
      title: Text(
        'Return information',
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
            ),
      ),
      content: SizedBox(
        width: 750.0,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Why is return rate important?',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 2.0),
            Text(
              'Your return rate is the percentage of reusable packs which have been returned by your customers. When reusable packs are returned, they are cleaned and reused. This reduces the impact on the environment; instead of the pack ending up in landfills, it is reintroduced into the cycle. A higher return rate therefore means more carbon emission savings. The average return rate across merchants is approximately 40%.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
            ),
            const SizedBox(height: 24.0),
            Text(
              'How we calculate return information.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Returned: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'This is the number of packs which have been returned by your customers.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Pending: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'The return process generally involves a normal delay (i.e. the time between when the pack is shipped and when the pack gets back to us). To avoid skewing the information due to that delay (i.e. considering packs as lost too early), we only consider a pack as lost if it has not been returned for more than 14 days. During this period, packs are considered as Pending.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Lost: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'This is the number of packs which haven\'t been returned. See "Pending" above to know more about how we account for the normal return delay process.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Max cycle time: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'We look at all packs which have been returned by your customers to determine the longest time it took for a pack to be returned.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Min cycle time: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'We look at all packs which have been returned by your customers to determine the shortest time it took for a pack to be returned.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Avg. cycle time: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'We look at all packs which have been returned by your customers and determine the average time it takes for packs to be returned by your customers.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 16.0),
            Text(
              'Caveats',
              style: Theme.of(context).textTheme.labelLarge?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    fontWeight: FontWeight.bold,
                    fontStyle: FontStyle.italic,
                  ),
            ),
            const SizedBox(height: 2.0),
            Text(
              '- Return information is updated as we track packs. Because of logistic loads, we do not always track a pack as soon as it is returned to us. As such, return information is not in real-time.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                    fontStyle: FontStyle.italic,
                  ),
            ),
            Text(
              '- When considering times, if you use the Kvatt App to scan packs, we consider a pack as shipped when you ship the pack to your customer. If you don\'t use the Kvatt App to scan packs, we consider a pack as shipped when we send the pack to you.',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                    fontStyle: FontStyle.italic,
                  ),
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          width: 100.0,
          child: SecondaryButton(
            label: 'Close',
            onPressed: () => onClosePressed(),
          ),
        ),
      ],
    );
  }
}
