import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/tooltip_button.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';

class ReturnInfoCard extends StatefulWidget {
  final Function onTooltipTapped;
  final int? numReturned;
  final int? numPending;
  final int? numLost;
  final double? returnRatePercentage;
  final int? maxReturnDays;
  final int? minReturnDays;
  final double? averageReturnDays;
  final bool? isLoading;

  const ReturnInfoCard({
    super.key,
    required this.onTooltipTapped,
    required this.numReturned,
    required this.numPending,
    required this.numLost,
    required this.returnRatePercentage,
    required this.maxReturnDays,
    required this.minReturnDays,
    required this.averageReturnDays,
    this.isLoading = false,
  });

  @override
  State<ReturnInfoCard> createState() => _ReturnInfoCardState();
}

class _ReturnInfoCardState extends State<ReturnInfoCard> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 240.0,
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.backgroundColor,
        borderRadius: const BorderRadius.all(Radius.circular(20.0)),
        border: Border.all(
          color: Theme.of(context).colorScheme.surfaceDarkColor,
        ),
      ),
      child: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          return Column(
            mainAxisAlignment: MainAxisAlignment.start,
            children: [
              widget.isLoading == true
                  ? Column(
                      children: [
                        const SizedBox(height: 80.0),
                        const LoadingSpinner(
                          width: 50.0,
                          height: 50.0,
                        ),
                        const SizedBox(height: 12.0),
                        Text(
                          'Loading return information...',
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onSurfaceDisabled,
                                  ),
                        ),
                      ],
                    )
                  : Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Expanded(
                          flex: 2,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 24.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                const SizedBox(height: 24.0),
                                Row(
                                  crossAxisAlignment: CrossAxisAlignment.center,
                                  children: [
                                    Text(
                                      'Return information',
                                      style: Theme.of(context)
                                          .textTheme
                                          .titleSmall
                                          ?.copyWith(
                                            color: Theme.of(context)
                                                .colorScheme
                                                .onSurfaceHighEmphasis,
                                            fontWeight: FontWeight.bold,
                                          ),
                                    ),
                                    const SizedBox(width: 12.0),
                                    ToolTipButton(
                                      onTapped: () => widget.onTooltipTapped(),
                                    ),
                                  ],
                                ),
                                const SizedBox(height: 24.0),
                                Column(
                                  children: [
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              width: 12.0,
                                              height: 12.0,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .kvattNewGreen,
                                              ),
                                            ),
                                            const SizedBox(width: 4.0),
                                            Text(
                                              'Returned',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.copyWith(
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .onSurfaceHighEmphasis,
                                                  ),
                                            ),
                                          ],
                                        ),
                                        Text(
                                          widget.numReturned.toString(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyMedium
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceMediumEmphasis,
                                              ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 6.0),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              width: 12.0,
                                              height: 12.0,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .kvattNewBlue,
                                              ),
                                            ),
                                            const SizedBox(width: 4.0),
                                            Text(
                                              'Pending',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.copyWith(
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .onSurfaceHighEmphasis,
                                                  ),
                                            ),
                                          ],
                                        ),
                                        Text(
                                          widget.numPending.toString(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyMedium
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceMediumEmphasis,
                                              ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 6.0),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Row(
                                          children: [
                                            Container(
                                              width: 12.0,
                                              height: 12.0,
                                              decoration: BoxDecoration(
                                                shape: BoxShape.circle,
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .kvattNewPink,
                                              ),
                                            ),
                                            const SizedBox(width: 4.0),
                                            Text(
                                              'Lost',
                                              style: Theme.of(context)
                                                  .textTheme
                                                  .bodyMedium
                                                  ?.copyWith(
                                                    color: Theme.of(context)
                                                        .colorScheme
                                                        .onSurfaceHighEmphasis,
                                                  ),
                                            ),
                                          ],
                                        ),
                                        Text(
                                          widget.numLost.toString(),
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodyMedium
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceMediumEmphasis,
                                              ),
                                        ),
                                      ],
                                    ),
                                    const Divider(
                                      height: 24.0,
                                    ),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Max cycle time',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceHighEmphasis,
                                              ),
                                        ),
                                        Text(
                                          widget.maxReturnDays == null
                                              ? 'n/a'
                                              : '${widget.maxReturnDays.toString()} days',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceMediumEmphasis,
                                              ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 2.0),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Min cycle time',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceHighEmphasis,
                                              ),
                                        ),
                                        Text(
                                          widget.minReturnDays == null
                                              ? 'n/a'
                                              : '${widget.minReturnDays.toString()} days',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceMediumEmphasis,
                                              ),
                                        ),
                                      ],
                                    ),
                                    const SizedBox(height: 2.0),
                                    Row(
                                      mainAxisAlignment:
                                          MainAxisAlignment.spaceBetween,
                                      children: [
                                        Text(
                                          'Avg. cycle time',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceHighEmphasis,
                                              ),
                                        ),
                                        Text(
                                          widget.averageReturnDays == null
                                              ? 'n/a'
                                              : '${widget.averageReturnDays!.toStringAsFixed(0)} days',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceMediumEmphasis,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                        Expanded(
                          flex: 2,
                          child: Padding(
                            padding: const EdgeInsets.only(right: 28.0),
                            child: Column(
                              crossAxisAlignment: CrossAxisAlignment.end,
                              children: [
                                const SizedBox(height: 40.0),
                                Stack(
                                  alignment: Alignment.center,
                                  children: [
                                    SizedBox(
                                      width: 164.0,
                                      height: 164.0,
                                      child: PieChart(
                                        PieChartData(
                                          sectionsSpace: 4.0,
                                          sections: [
                                            PieChartSectionData(
                                              value: widget.numReturned == null
                                                  ? 0.0
                                                  : widget.numReturned
                                                      ?.toDouble(),
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .kvattNewGreen,
                                              radius: 12.0,
                                              showTitle: false,
                                            ),
                                            PieChartSectionData(
                                              value: widget.numPending == null
                                                  ? 0.0
                                                  : widget.numPending
                                                      ?.toDouble(),
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .kvattNewBlue,
                                              radius: 12.0,
                                              showTitle: false,
                                            ),
                                            PieChartSectionData(
                                              value: widget.numLost == null
                                                  ? 0.0
                                                  : widget.numLost?.toDouble(),
                                              color: Theme.of(context)
                                                  .colorScheme
                                                  .kvattNewPink,
                                              radius: 12.0,
                                              showTitle: false,
                                            ),
                                          ],
                                          pieTouchData: PieTouchData(
                                            enabled: true,
                                          ),
                                        ),
                                      ),
                                    ),
                                    Column(
                                      children: [
                                        RichText(
                                          text: TextSpan(
                                            children: [
                                              TextSpan(
                                                text: widget.returnRatePercentage ==
                                                        null
                                                    ? 'n/a'
                                                    : NumberFormat(
                                                            '#,###,###.#')
                                                        .format(widget
                                                            .returnRatePercentage),
                                                style: Theme.of(context)
                                                    .textTheme
                                                    .headlineMedium
                                                    ?.copyWith(
                                                      color: Theme.of(context)
                                                          .colorScheme
                                                          .onSurfaceHighEmphasis,
                                                    ),
                                              ),
                                              TextSpan(
                                                  text:
                                                      widget.returnRatePercentage !=
                                                              null
                                                          ? '%'
                                                          : '',
                                                  style: Theme.of(context)
                                                      .textTheme
                                                      .headlineSmall
                                                      ?.copyWith(
                                                        color: Theme.of(context)
                                                            .colorScheme
                                                            .onSurfaceHighEmphasis,
                                                      )),
                                            ],
                                          ),
                                        ),
                                        Text(
                                          'Return rate',
                                          style: Theme.of(context)
                                              .textTheme
                                              .bodySmall
                                              ?.copyWith(
                                                color: Theme.of(context)
                                                    .colorScheme
                                                    .onSurfaceMediumEmphasis,
                                              ),
                                        ),
                                      ],
                                    ),
                                  ],
                                ),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
              const SizedBox(height: 24.0),
            ],
          );
        },
      ),
    );
  }
}
