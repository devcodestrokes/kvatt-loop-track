import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class PickUpInfoTipDialog extends StatelessWidget {
  final Function onClosePressed;

  const PickUpInfoTipDialog({
    super.key,
    required this.onClosePressed,
  });

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      scrollable: true,
      title: Text(
        'Checkout pick-up information',
        style: Theme.of(context).textTheme.headlineSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
            ),
      ),
      content: SizedBox(
        width: 750.0,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'Why is pick-up rate important?',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 2.0),
            Text(
              'Giving your customers the option to choose circularity at checkout allows you to test their interest without any financial risk for your brand. Our common objective will be to maximise pick-up rate (i.e. how many people choose the circular option). A higher pick-up rate means that more customers are adopting reusable packaging which is better for the environment.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color:
                        Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                  ),
            ),
            const SizedBox(height: 24.0),
            Text(
              'How we calculate checkout pick-up information.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    fontWeight: FontWeight.bold,
                  ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: 'Total orders: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'This is the total number of orders where the "No Waste Experience" option was presented at checkout.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 12.0),
            RichText(
              text: TextSpan(
                children: [
                  TextSpan(
                    text: '"No Waste Experience" orders: ',
                    style: Theme.of(context).textTheme.labelLarge?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  TextSpan(
                    text:
                        'This is the number of orders where customers have actually chosen the "No Waste Experience" option.',
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis,
                        ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      actions: [
        SizedBox(
          width: 100.0,
          child: SecondaryButton(
            label: 'Close',
            onPressed: () => onClosePressed(),
          ),
        ),
      ],
    );
  }
}
