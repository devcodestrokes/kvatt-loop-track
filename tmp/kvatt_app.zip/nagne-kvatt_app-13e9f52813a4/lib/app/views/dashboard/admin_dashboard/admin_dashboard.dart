import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/filters/date_filter/date_filter.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/custom_checkbox.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/common/widgets/menu/more_dropdown_menu.dart';
import 'package:kvatt_app/app/common/widgets/stat_cards/data_card.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/views/dashboard/admin_dashboard/admin_dashboard_view_model.dart';
import 'package:kvatt_app/app/views/dashboard/admin_dashboard/widgets/add_comment_dialog.dart';
import 'package:kvatt_core/domain/stocks/stock.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';

class AdminDashboard extends StatefulWidget {
  final AdminDashboardViewModel viewModel;

  const AdminDashboard({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  State<AdminDashboard> createState() => _AdminDashboardState();
}

class _AdminDashboardState extends State<AdminDashboard> {
  _showCommentDialog({
    required BuildContext context,
    required String merchantId,
    required String merchantName,
  }) {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (BuildContext context) {
        return AlertDialog(
          scrollable: true,
          title: Text(
            'Download circularity report',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                ),
          ),
          content: AddCommentDialog(
            from: widget.viewModel.selectedDateRangeFilter?.start ??
                widget.viewModel.platformStartDate,
            to: widget.viewModel.selectedDateRangeFilter?.end ?? DateTime.now(),
            merchantName: merchantName,
            onSaveTapped: (String comment) async {
              Navigator.of(context).pop();
              await widget.viewModel.onDownloadCircularityReportTapped(
                merchantId: merchantId,
                comment: comment,
              );
            },
          ),
        );
      },
    );
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      widget.viewModel.init();
    });
  }

  @override
  Widget build(BuildContext context) {
    return SingleChildScrollView(
      child: widget.viewModel.merchantsData.isEmpty
          ? Column(
              children: [
                const SizedBox(height: 60.0),
                Text(
                  'No merchant insights are available.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceDisabled),
                ),
              ],
            )
          : Padding(
              padding: const EdgeInsets.symmetric(vertical: 24.0),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Column(
                        children: [
                          Text(
                            'Merchant average statistics',
                            style: Theme.of(context)
                                .textTheme
                                .headlineSmall
                                ?.copyWith(
                                  color: Theme.of(context)
                                      .colorScheme
                                      .onSurfaceHighEmphasis,
                                ),
                          ),
                          const SizedBox(height: 16.0),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.25,
                            child: DataCard(
                              height: 220.0,
                              value:
                                  widget.viewModel.averageMerchantsReturnRate,
                              unit: '%',
                              label: 'Average return rate',
                              isLoading:
                                  !widget.viewModel.isAllReturnInfoLoaded(),
                            ),
                          ),
                        ],
                      ),
                      DateFilter(
                        earliestStartDate: widget.viewModel.platformStartDate,
                        latestEndDate: DateTime.now(),
                        onRangeSelected: (DateTimeRange? range) =>
                            widget.viewModel.onDateRangeSelected(range),
                      ),
                    ],
                  ),
                  const SizedBox(height: 40.0),
                  Text(
                    'Merchants data table',
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                  ),
                  const SizedBox(height: 16.0),
                  SizedBox(
                    width: MediaQuery.of(context).size.width,
                    child: widget.viewModel.isLoadingData
                        ? const Column(
                            children: [
                              SizedBox(height: 24.0),
                              LoadingSpinner(),
                            ],
                          )
                        : _buildTable(),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildTable() {
    return Column(
      children: [
        _buildTableHeader(),
        ListView.builder(
          shrinkWrap: true,
          itemCount: widget.viewModel.merchantsData.length,
          itemBuilder: (BuildContext context, int index) {
            String returnRate = '';
            if (widget.viewModel.merchantsData[index].returnRate == null) {
              returnRate = 'N/A';
            } else {
              returnRate =
                  '${((widget.viewModel.merchantsData[index].returnRate ?? 0.0) * 100).toStringAsFixed(0)}%';
            }
            String numShipped = '';
            if (widget.viewModel.merchantsData[index].numShipped == null) {
              numShipped = 'N/A';
            } else {
              numShipped =
                  widget.viewModel.merchantsData[index].numShipped.toString();
            }

            String numReturned = '';
            if (widget.viewModel.merchantsData[index].numReturned == null) {
              numReturned = 'N/A';
            } else {
              numReturned =
                  widget.viewModel.merchantsData[index].numReturned.toString();
            }

            String numPending = '';
            if (widget.viewModel.merchantsData[index].numPending == null) {
              numPending = 'N/A';
            } else {
              numPending =
                  widget.viewModel.merchantsData[index].numPending.toString();
            }

            String numLost = '';
            if (widget.viewModel.merchantsData[index].numLost == null) {
              numLost = 'N/A';
            } else {
              numLost =
                  widget.viewModel.merchantsData[index].numLost.toString();
            }

            String maxReturnDays = '';
            if (widget.viewModel.merchantsData[index].maxReturnDays == null) {
              maxReturnDays = 'N/A';
            } else {
              maxReturnDays = widget
                  .viewModel.merchantsData[index].maxReturnDays
                  .toString();
            }

            String minReturnDays = '';
            if (widget.viewModel.merchantsData[index].minReturnDays == null) {
              minReturnDays = 'N/A';
            } else {
              minReturnDays = widget
                  .viewModel.merchantsData[index].minReturnDays
                  .toString();
            }

            String averageReturnDays = '';
            if (widget.viewModel.merchantsData[index].averageReturnDays ==
                null) {
              averageReturnDays = 'N/A';
            } else {
              averageReturnDays = widget
                      .viewModel.merchantsData[index].averageReturnDays
                      ?.toStringAsFixed(0) ??
                  'N/A';
            }

            return Container(
              padding: const EdgeInsets.fromLTRB(16.0, 16.0, 80.0, 16.0),
              decoration: BoxDecoration(
                border: Border.all(
                  color: Theme.of(context).colorScheme.outlineColor,
                ),
              ),
              child: Row(
                children: [
                  Expanded(
                    flex: 3,
                    child: CustomCheckbox(
                      value: widget.viewModel.merchantsData[index]
                          .isSelectedForAggregation,
                      onChanged: (bool value) =>
                          widget.viewModel.selectUnselectMerchantForAggregation(
                        viewData: widget.viewModel.merchantsData[index],
                      ),
                    ),
                  ),
                  Expanded(
                    flex: 8,
                    child: Text(
                      widget.viewModel.merchantsData[index].merchant.name,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceHighEmphasis,
                          ),
                    ),
                  ),
                  Expanded(
                    flex: 8,
                    child: widget.viewModel.merchantsData[index]
                                .isReturnInfoLoaded ==
                            false
                        ? const Row(
                            children: [
                              LoadingSpinner(
                                width: 30.0,
                                height: 30.0,
                              ),
                            ],
                          )
                        : Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                returnRate,
                                style: Theme.of(context)
                                    .textTheme
                                    .bodyMedium
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceHighEmphasis,
                                    ),
                              ),
                              Text(
                                'Shipped: $numShipped',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              Text(
                                'Returned: $numReturned',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              Text(
                                'Pending: $numPending',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              Text(
                                'Lost: $numLost',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              Text(
                                'Max cycle time: $maxReturnDays days',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              Text(
                                'Min cycle time: $minReturnDays days',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                              Text(
                                'Avg. cycle time: $averageReturnDays days',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onSurfaceMediumEmphasis,
                                    ),
                              ),
                            ],
                          ),
                  ),
                  Expanded(
                    flex: 8,
                    child: widget.viewModel.merchantsData[index]
                                .isStockInfoLoaded ==
                            false
                        ? const Row(
                            children: [
                              LoadingSpinner(
                                width: 30.0,
                                height: 30.0,
                              ),
                            ],
                          )
                        : _buildStockLevelsTextDisplay(
                            widget.viewModel.merchantsData[index].stocks),
                  ),
                  Expanded(
                    flex: 8,
                    child: Text(
                      _trackingSourceDisplayName(widget.viewModel
                              .merchantsData[index].merchant.trackingSource) ??
                          'n/a',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onSurfaceHighEmphasis,
                          ),
                    ),
                  ),
                  Expanded(
                    flex: 4,
                    child: widget.viewModel.merchantsData[index]
                            .isDownloadingImpactData
                        ? const LoadingSpinner(
                            width: 30.0,
                            height: 30.0,
                          )
                        : MoreDropdownMenu(
                            menuItems: [
                              MenuItemConfig(
                                label: 'Download impact data',
                                onSelected: () =>
                                    widget.viewModel.onDownloadImpactData(
                                  merchantId: widget.viewModel
                                      .merchantsData[index].merchant.uid,
                                ),
                              ),
                              //TODO: Commented out for now - readd when circularity report ready
                              // MenuItemConfig(
                              //   label: 'Download circularity report',
                              //   onSelected: () {
                              //     Navigator.of(context).pop();
                              //     _showCommentDialog(
                              //       context: context,
                              //       merchantName: widget.viewModel
                              //           .merchantsData[index].merchant.name,
                              //       merchantId: widget.viewModel
                              //           .merchantsData[index].merchant.uid!,
                              //     );
                              //   },
                              // ),
                            ],
                          ),
                  ),
                ],
              ),
            );
          },
        ),
      ],
    );
  }

  Widget _buildStockLevelsTextDisplay(Stock? stock) {
    if (stock == null) {
      return const SizedBox();
    }
    return Column(
      children: stock.levels.keys.map((String item) {
        return Row(
          children: [
            SizedBox(
              width: 80.0,
              child: Text(
                item,
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ),
            const SizedBox(width: 12.0),
            SizedBox(
              width: 50.0,
              child: Text(
                stock.levels[item].toString(),
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.right,
              ),
            ),
          ],
        );
      }).toList(),
    );
  }

  Widget _buildTableHeader() {
    return Container(
      padding: const EdgeInsets.fromLTRB(16.0, 16.0, 80.0, 16.0),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.outlineColor,
        ),
      ),
      child: Row(
        children: [
          Expanded(
            flex: 3,
            child: Text(
              'Include in\naverages',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
              textAlign: TextAlign.center,
            ),
          ),
          Expanded(
            flex: 8,
            child: Text(
              'Merchant',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 8,
            child: Text(
              'Return rate',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 8,
            child: Text(
              'Stock levels',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          Expanded(
            flex: 8,
            child: Text(
              'Tracking source',
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                    color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  ),
            ),
          ),
          const Expanded(
            flex: 4,
            child: Text(
              '',
            ),
          ),
        ],
      ),
    );
  }

  String? _trackingSourceDisplayName(TrackingSource? source) {
    switch (source) {
      case TrackingSource.kvattApp:
        return 'Merchant Kvatt App';
      case TrackingSource.shopify:
        return 'Shopify';
      default:
        return 'Admin Kvatt App';
    }
  }
}
