import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_black.dart';

// ignore: depend_on_referenced_packages
import 'package:intl/intl.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class AddCommentDialog extends StatefulWidget {
  final DateTime from;
  final DateTime to;
  final String merchantName;
  final Function(String) onSaveTapped;

  const AddCommentDialog({
    super.key,
    required this.from,
    required this.to,
    required this.merchantName,
    required this.onSaveTapped,
  });

  @override
  State<AddCommentDialog> createState() => _AddCommentDialogState();
}

class _AddCommentDialogState extends State<AddCommentDialog> {
  TextEditingController controller = TextEditingController();

  @override
  void dispose() {
    super.dispose();
    controller.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: 700.0,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(
            'You are about to download the circularity report for ${widget.merchantName}.\n\nIf you want to add some comments for the merchant to be added to the report, please add the comments in the textbox below.\n\nReport period:',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                ),
          ),
          const SizedBox(height: 4.0),
          Text(
            '${DateFormat('dd MMM yyyy').format(widget.from)} to ${DateFormat('dd MMM yyyy').format(widget.to)}',
            style: Theme.of(context).textTheme.labelLarge?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          TextFieldBlack(
            validator: (s) {},
            label: 'Comment',
            keyboardType: TextInputType.multiline,
            controller: controller,
            maxLines: 20,
          ),
          const SizedBox(height: 24.0),
          Row(
            mainAxisAlignment: MainAxisAlignment.end,
            children: [
              Row(
                children: [
                  SizedBox(
                    width: 100.0,
                    height: 40.0,
                    child: SecondaryButton(
                      label: 'Cancel',
                      onPressed: () {
                        Navigator.pop(context);
                      },
                    ),
                  ),
                  const SizedBox(width: 12.0),
                  SizedBox(
                    width: 100.0,
                    height: 40.0,
                    child: PrimaryButton(
                      label: 'Download',
                      onPressed: () {
                        widget.onSaveTapped(controller.text);
                      },
                    ),
                  ),
                ],
              ),
            ],
          ),
        ],
      ),
    );
  }
}
