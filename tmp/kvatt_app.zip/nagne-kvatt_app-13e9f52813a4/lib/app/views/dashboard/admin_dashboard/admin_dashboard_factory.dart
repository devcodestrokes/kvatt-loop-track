import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/views/dashboard/admin_dashboard/admin_dashboard.dart';
import 'package:kvatt_app/app/views/dashboard/admin_dashboard/admin_dashboard_view_model.dart';
import 'package:kvatt_app/domain/reporting/reporting_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_core/domain/insights/insights_manager.dart';
import 'package:kvatt_core/domain/reporting/circularity_manager.dart';
import 'package:kvatt_core/domain/stocks/stocks_manager.dart';
import 'package:provider/provider.dart';

class AdminDashboardFactory {
  static Widget build() {
    return ChangeNotifierProvider<AdminDashboardViewModel>(
      create: (context) {
        return AdminDashboardViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          insightsManager: Provider.of<InsightsManager>(
            context,
            listen: false,
          ),
          stocksManager: Provider.of<StocksManager>(
            context,
            listen: false,
          ),
          reportingManager: Provider.of<ReportingManager>(
            context,
            listen: false,
          ),
          circularityManager: Provider.of<CircularityManager>(
            context,
            listen: false,
          ),
          platformStartDate: Provider.of<Config>(
            context,
            listen: false,
          ).platformStartDate!,
        );
      },
      child: Consumer<AdminDashboardViewModel>(
        builder: (context, model, child) => AdminDashboard(
          viewModel: model,
        ),
      ),
    );
  }
}
