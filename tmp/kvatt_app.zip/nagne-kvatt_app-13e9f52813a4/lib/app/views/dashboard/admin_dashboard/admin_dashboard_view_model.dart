import 'package:flutter/material.dart';
import 'package:kvatt_app/app/services/downloads/downloader_service.dart';
import 'package:kvatt_app/app/services/report_generators/circularity_report_generator.dart';
import 'package:kvatt_app/domain/reporting/reporting_manager.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_core/domain/common/period.dart';
import 'package:kvatt_core/domain/insights/insights_manager.dart';
import 'package:kvatt_core/domain/insights/return_info.dart';
import 'package:kvatt_core/domain/reporting/circularity_manager.dart';
import 'package:kvatt_core/domain/stocks/stock.dart';
import 'package:kvatt_core/domain/stocks/stocks_manager.dart';

class MerchantsViewData {
  Merchant merchant;
  int? numShipped;
  int? numReturned;
  int? numPending;
  int? numLost;
  int? maxReturnDays;
  int? minReturnDays;
  double? averageReturnDays;
  double? returnRate;
  Stock? stocks;
  bool isSelectedForAggregation;
  bool isDownloadingImpactData;

  MerchantsViewData({
    required this.merchant,
    required this.numShipped,
    required this.numReturned,
    required this.numPending,
    required this.numLost,
    required this.maxReturnDays,
    required this.minReturnDays,
    required this.averageReturnDays,
    required this.returnRate,
    required this.stocks,
    required this.isSelectedForAggregation,
    required this.isDownloadingImpactData,
  });

  bool get isReturnInfoLoaded =>
      numShipped != null &&
      numReturned != null &&
      numPending != null &&
      numLost != null;

  bool get isStockInfoLoaded => stocks != null;
}

class AdminDashboardViewModel extends ChangeNotifier {
  UserManager userManager;
  InsightsManager insightsManager;
  StocksManager stocksManager;
  ReportingManager reportingManager;
  CircularityManager circularityManager;
  DateTime platformStartDate;

  List<MerchantsViewData> merchantsData = [];

  List<Merchant> _merchants = [];

  Period? selectedDateRangeFilter;

  bool isLoadingData = false;

  bool isAllReturnInfoLoaded() {
    for (var merchantData in merchantsData) {
      if (merchantData.isReturnInfoLoaded == false) {
        return false;
      }
    }
    return true;
  }

  AdminDashboardViewModel({
    required this.userManager,
    required this.insightsManager,
    required this.stocksManager,
    required this.reportingManager,
    required this.circularityManager,
    required this.platformStartDate,
  });

  Future<void> _updateMerchantReturnInfo({
    required Merchant merchant,
  }) async {
    ReturnInfo? returnInfo = await insightsManager.getMerchantReturnInfo(
      merchantId: merchant.uid!,
      period: selectedDateRangeFilter,
    );
    try {
      MerchantsViewData viewData = merchantsData
          .where((MerchantsViewData viewData) =>
              viewData.merchant.uid == merchant.uid)
          .first;
      viewData.numShipped = returnInfo?.numShipped;
      viewData.numPending = returnInfo?.numPending;
      viewData.numLost = returnInfo?.numLost;
      viewData.numReturned = returnInfo?.numReturned;
      viewData.returnRate = returnInfo?.returnRate;
      viewData.maxReturnDays = returnInfo?.maxReturnDays;
      viewData.minReturnDays = returnInfo?.minReturnDays;
      viewData.averageReturnDays = returnInfo?.averageReturnDays;
      notifyListeners();
    } catch (e) {
      return;
    }
  }

  Future<void> _updateMerchantStockInfo({
    required Merchant merchant,
  }) async {
    Stock stock = await stocksManager.computeMerchantStock(
      merchantId: merchant.uid!,
    );

    try {
      MerchantsViewData viewData = merchantsData
          .where((MerchantsViewData viewData) =>
              viewData.merchant.uid == merchant.uid)
          .first;
      viewData.stocks = stock;
      notifyListeners();
    } catch (e) {
      return;
    }
  }

  Future<void> init() async {
    await _loadInitialMerchantsData();
  }

  double? get averageMerchantsReturnRate {
    double total = 0;
    int count = 0;

    for (int i = 0; i < merchantsData.length; i++) {
      if (merchantsData[i].isSelectedForAggregation) {
        if (merchantsData[i].returnRate != null) {
          count++;
          total += merchantsData[i].returnRate!;
        }
      }
    }

    if (count == 0) {
      return null;
    }

    return total * 100 / count;
  }

  selectUnselectMerchantForAggregation({
    required MerchantsViewData viewData,
  }) {
    viewData.isSelectedForAggregation = !viewData.isSelectedForAggregation;
    notifyListeners();
  }

  onDateRangeSelected(DateTimeRange? range) {
    if (range == null) {
      selectedDateRangeFilter = null;
    } else {
      selectedDateRangeFilter = Period(
        start: range.start,
        end: range.end,
      );
    }
    _reloadMerchantReturnRates();
  }

  onDownloadImpactData({
    required String? merchantId,
  }) async {
    if (merchantId == null) return;
    try {
      MerchantsViewData viewData = merchantsData
          .where((MerchantsViewData viewData) =>
              viewData.merchant.uid == merchantId)
          .first;
      viewData.isDownloadingImpactData = true;
      notifyListeners();
      await reportingManager.downloadMerchantPackagingDataForImpactReport(
        merchantId: merchantId,
      );
      viewData.isDownloadingImpactData = false;
      notifyListeners();
    } catch (_) {
      //Fail silently
      //TODO: Capture error in Sentry?
    }
  }

  Future<void> onDownloadCircularityReportTapped({
    required String? merchantId,
    required String comment,
  }) async {
    MerchantsViewData viewData = merchantsData
        .where(
            (MerchantsViewData viewData) => viewData.merchant.uid == merchantId)
        .first;
    viewData.isDownloadingImpactData = true;
    notifyListeners();
    try {
      if (comment.isNotEmpty) {
        await circularityManager.addCommentForMerchant(
          merchantId: merchantId!,
          comment: comment,
          from: selectedDateRangeFilter?.start ?? platformStartDate,
          to: selectedDateRangeFilter?.end ?? DateTime.now(),
        );
      }

      await CircularityReportGenerator(
        downloaderService: DownloaderService(),
      ).generateAndDownloadCircularityReport(
        comment: comment,
      );
    } catch (e) {
      //TODO: Send to Sentry?
    }
    viewData.isDownloadingImpactData = false;
    notifyListeners();
  }

  Future<void> _reloadMerchantReturnRates() async {
    isLoadingData = true;
    notifyListeners();

    for (var merchant in _merchants) {
      try {
        MerchantsViewData viewData = merchantsData
            .where((MerchantsViewData viewData) =>
                viewData.merchant.uid == merchant.uid)
            .first;
        viewData.numShipped = null;
        viewData.numReturned = null;
        viewData.numPending = null;
        viewData.numLost = null;
        viewData.returnRate = null;
        _updateMerchantReturnInfo(merchant: merchant);
      } catch (e) {
        //Fail silently
        //TODO: Capture error in Sentry?
      }
    }

    isLoadingData = false;
    notifyListeners();
  }

  Future<void> _loadInitialMerchantsData() async {
    isLoadingData = true;
    notifyListeners();
    _merchants = await userManager.retrieveActiveMerchants();

    merchantsData = [];

    for (var merchant in _merchants) {
      merchantsData.add(
        MerchantsViewData(
          numShipped: null,
          numReturned: null,
          numPending: null,
          numLost: null,
          returnRate: null,
          maxReturnDays: null,
          minReturnDays: null,
          averageReturnDays: null,
          stocks: null,
          merchant: merchant,
          isSelectedForAggregation: true,
          isDownloadingImpactData: false,
        ),
      );
      _updateMerchantReturnInfo(merchant: merchant);
      _updateMerchantStockInfo(merchant: merchant);
    }

    isLoadingData = false;
    notifyListeners();
  }
}
