import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/views/dashboard/partner_dashboard/partner_dashboard.dart';
import 'package:kvatt_app/app/views/dashboard/partner_dashboard/partner_dashboard_view_model.dart';
import 'package:provider/provider.dart';

class PartnerDashboardFactory {
  static Widget build() {
    return ChangeNotifierProvider<PartnerDashboardViewModel>(
      create: (context) {
        return PartnerDashboardViewModel();
      },
      child: Consumer<PartnerDashboardViewModel>(
        builder: (context, model, child) => PartnerDashboard(
          viewModel: model,
        ),
      ),
    );
  }
}
