import 'package:flutter/material.dart';

class PartnerDashboardViewModel extends ChangeNotifier {}
