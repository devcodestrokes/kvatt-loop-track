import 'package:flutter/material.dart';
import 'package:kvatt_app/app/views/dashboard/partner_dashboard/partner_dashboard_view_model.dart';

class PartnerDashboard extends StatelessWidget {
  final PartnerDashboardViewModel viewModel;

  const PartnerDashboard({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Text(
          'Partner dashboard comes here',
          style: Theme.of(context).textTheme.headlineSmall,
        ),
      ),
    );
  }
}
