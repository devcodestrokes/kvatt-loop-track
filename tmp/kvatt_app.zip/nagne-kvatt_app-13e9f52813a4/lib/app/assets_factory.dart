class AssetsFactory {
  static const String _logosFolder = 'assets/logos';
  static const String _iconsFolder = 'assets/icons';
  static const String _imagesFolder = 'assets/images';

  //Kvatt Logos
  static const String kvattLogoWhite = '$_logosFolder/kvatt_logo_white.png';
  static const String kvattLogoBlack = '$_logosFolder/kvatt_logo_black.png';
  static const String kvattLogoNewWhite =
      '$_logosFolder/kvatt_logo_new_white.png';
  static const String kvattLogoNewRed = '$_logosFolder/kvatt_logo_new_red.png';

  //Other Logos
  static const String shopifyLogo = '$_imagesFolder/shopify_logo.png';

  //Icons
  static const String eyeIcon = '$_iconsFolder/eye_icon.png';
  static const String peopleIcon = '$_iconsFolder/people.png';
  static const String homeIcon = '$_iconsFolder/home.png';
  static const String arrowBackIcon = '$_iconsFolder/arrow_back.png';
  static const String moreIcon = '$_iconsFolder/more.png';
  static const String stockIcon = '$_iconsFolder/stock.png';
  static const String packagingsIcon = '$_iconsFolder/packagings.png';
  static const String ordersIcon = '$_iconsFolder/orders.png';

  //Images
  static const String packSealingArea = '$_imagesFolder/pack_sealing_area.webp';
  static const String packSeal = '$_imagesFolder/pack_seal.webp';
  static const String postBox = '$_imagesFolder/post_box.webp';
  static const String charlie = '$_imagesFolder/charlie.webp';
  static const String ray = '$_imagesFolder/ray.webp';
  static const String harry = '$_imagesFolder/harry.webp';
  static const String alfred = '$_imagesFolder/alfred.webp';

  static const String charlieMPackFront =
      '$_imagesFolder/charlie_m_pack_front.jpg';
  static const String charlieMPackBack =
      '$_imagesFolder/charlie_m_pack_back.png';
  static const String charlieMPackWithLabel =
      '$_imagesFolder/charlie_m_pack_with_label.jpg';
  static const String postBoxNew = '$_imagesFolder/post_box_new.png';

  //Label images
  static const String labelLeftPointer =
      '$_imagesFolder/label_left_pointer.png';
  static const String labelRightPointer =
      '$_imagesFolder/label_right_pointer.png';
  static const String amazonSmileLogo = '$_imagesFolder/amazon_smile_logo.png';
  static const String emballageReemployable =
      '$_imagesFolder/emballage_reemployable.png';
  static const String pvcLogo = '$_imagesFolder/pvc_logo.png';
  static const String recyclingLogo = '$_imagesFolder/recycling_logo.png';
  static const String laPosteLabelTemplate =
      '$_imagesFolder/la_poste_label_template.png';
}
