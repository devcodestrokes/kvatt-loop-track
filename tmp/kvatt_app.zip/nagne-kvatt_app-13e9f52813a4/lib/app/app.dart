import 'package:flutter/material.dart';
import 'package:kvatt_app/app/app_theme.dart';
import 'package:kvatt_app/app/routing/app_route_information_parser.dart';
import 'package:kvatt_app/app/routing/app_router_delegate.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

class App extends StatefulWidget {
  final AuthState authState;
  final UiState uiState;

  const App({
    Key? key,
    required this.authState,
    required this.uiState,
  }) : super(key: key);

  @override
  AppState createState() => AppState();
}

class AppState extends State<App> {
  late AppRouterDelegate _appRouterDelegate;
  late AppRouteInformationParser _appRouteInformationParser;

  @override
  void initState() {
    super.initState();

    _appRouteInformationParser = AppRouteInformationParser();
    _appRouterDelegate = AppRouterDelegate(
      authState: widget.authState,
      uiState: widget.uiState,
    );
  }

  @override
  Widget build(BuildContext context) {
    // return MaterialApp(
    //   title: 'Kvatt',
    //   theme: appTheme,
    //   home: CreateAccountFactory.build(),
    // );

    return MaterialApp.router(
      title: 'Kvatt',
      localizationsDelegates: GlobalMaterialLocalizations.delegates,
      supportedLocales: const [
        Locale('en', 'US'),
        Locale('en', 'GB'),
      ],
      theme: appTheme,
      routerDelegate: _appRouterDelegate,
      routeInformationParser: _appRouteInformationParser,
    );
  }
}
