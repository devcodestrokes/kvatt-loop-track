import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/services/auth/auth_service.dart';
import 'package:kvatt_app/domain/users/user.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

enum AuthStatus {
  loggedIn,
  loggedOut,
  unknown,
}

class AuthState extends ChangeNotifier {
  AuthService authService;
  UserManager userManager;

  User? activeUser;

  late Stream<Future<User?>> onAuthStateChanged;

  AuthState({
    required this.authService,
    required this.userManager,
  }) {
    onAuthStateChanged =
        authService.authStateChanges().map((String? uid) async {
      if (uid == null) {
        activeUser = null;
        return activeUser;
      } else {
        await _updateActiveUser(uid: uid);
        return activeUser;
      }
    });
  }

  _updateActiveUser({
    required String uid,
  }) async {
    activeUser = await userManager.findUser(userId: uid);
  }
}
