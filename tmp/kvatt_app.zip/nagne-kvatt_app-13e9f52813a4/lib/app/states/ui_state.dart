import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';

class UiState extends ChangeNotifier {
  ViewConfig currentView =
      ViewConfig(appView: AppView.homeDashboard, params: {});

  StreamController<ViewConfig> appViewController =
      StreamController<ViewConfig>();

  late Stream<ViewConfig> onUiStateChanged;

  UiState() {
    onUiStateChanged = appViewController.stream;
  }

  updateView(ViewConfig viewConfig) {
    currentView = viewConfig;
    appViewController.add(viewConfig);
  }
}
