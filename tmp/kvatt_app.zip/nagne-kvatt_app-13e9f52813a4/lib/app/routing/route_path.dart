class RoutePath {
  static const String unknown = '/404';
  static const String home = '/home';
  static const String authAction = '/auth-action';
  static const String signIn = '/sign-in';
  static const String inviteUser = '/invite-user';
  static const String resetPassword = '/reset-password';
  static const String emailSent = '/email-sent';
  static const String setNewPassword = '/set-new-password';
  static const String createAccount = '/create-account';
  static const String editUser = '/edit-user';
  static const String createPackagings = '/create-packagings';
  static const String packagingInfo = '/packaging-info';
  static const String createOrder = '/create-order';
  static const String editOrder = '/edit-order';
}
