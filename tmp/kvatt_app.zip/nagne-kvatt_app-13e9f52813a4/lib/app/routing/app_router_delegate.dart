import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/create_account/create_account_page.dart';
import 'package:kvatt_app/app/pages/create_order/create_order_page.dart';
import 'package:kvatt_app/app/pages/create_packagings/create_packagings_page.dart';
import 'package:kvatt_app/app/pages/edit_order/edit_order_page.dart';
import 'package:kvatt_app/app/pages/edit_user/edit_user_page.dart';
import 'package:kvatt_app/app/pages/home/home_page.dart';
import 'package:kvatt_app/app/pages/invite_user/invite_user_page.dart';
import 'package:kvatt_app/app/pages/not_found/not_found_page.dart';
import 'package:kvatt_app/app/pages/packaging_info/packaging_info_page.dart';
import 'package:kvatt_app/app/pages/password_reset/email_sent/email_sent_page.dart';
import 'package:kvatt_app/app/pages/password_reset/reset_password/reset_password_page.dart';
import 'package:kvatt_app/app/pages/password_reset/set_new_password/set_new_password_page.dart';
import 'package:kvatt_app/app/pages/sign_in/sign_in_page.dart';
import 'package:kvatt_app/app/pages/splash/splash_page.dart';
import 'package:kvatt_app/app/routing/app_configuration.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/users/user.dart';

class AppRouterDelegate extends RouterDelegate<AppConfiguration>
    with ChangeNotifier, PopNavigatorRouterDelegateMixin<AppConfiguration> {
  final GlobalKey<NavigatorState> _navigatorKey;

  AuthState authState;
  UiState uiState;
  StreamSubscription? authStatusStreamSubscription;
  StreamSubscription? uiStateStreamSubscription;

  Map<String, String>? queryParams;

  bool show404 = false;

  bool? _isLoggedIn;
  ViewConfig? _currentViewConfig;

  bool? get isLoggedIn => _isLoggedIn;

  set isLoggedIn(bool? value) {
    _isLoggedIn = value;
    notifyListeners();
  }

  ViewConfig? get currentViewConfig => _currentViewConfig;

  set currentViewConfig(ViewConfig? viewConfig) {
    _currentViewConfig = viewConfig;
    notifyListeners();
  }

  @override
  GlobalKey<NavigatorState> get navigatorKey => _navigatorKey;

  AppRouterDelegate({
    required this.authState,
    required this.uiState,
  }) : _navigatorKey = GlobalKey<NavigatorState>() {
    _handleAuthStateChanges();
    _handleUiStateChanges();
  }

  @override
  Widget build(BuildContext context) {
    List<Page> stack;
    if (show404 == true) {
      stack = _unknownStack;
    } else if (isLoggedIn == null) {
      stack = _splashStack;
    } else if (isLoggedIn == false) {
      stack = _loggedOutStack;
    } else {
      stack = _loggedInStack;
    }
    return Navigator(
      key: navigatorKey,
      pages: stack,
      onPopPage: (route, result) {
        if (!route.didPop(result)) {
          return false;
        }
        return true;
      },
    );
  }

  @override
  AppConfiguration? get currentConfiguration {
    if (show404 == true) {
      return AppConfiguration.unknown();
    } else if (isLoggedIn == null) {
      return AppConfiguration.splash();
    } else if (isLoggedIn == false) {
      switch (currentViewConfig?.appView) {
        case AppView.signIn:
          return AppConfiguration.signIn(
              queryParams: currentViewConfig?.params ?? {});
        case AppView.resetPassword:
          return AppConfiguration.resetPassword();
        case AppView.emailSent:
          return AppConfiguration.emailSent();
        case AppView.setNewPassword:
          return AppConfiguration.setNewPassword(
            queryParams: currentViewConfig?.params ?? {},
          );
        case AppView.createAccount:
          return AppConfiguration.createAccount(
            queryParams: currentViewConfig?.params ?? {},
          );
        case AppView.packagingInfo:
          return AppConfiguration.packagingInfo(
            queryParams: currentViewConfig?.params ?? {},
          );
        default:
          return AppConfiguration.signIn(
              queryParams: currentViewConfig?.params ?? {});
      }
    } else {
      switch (_currentViewConfig?.appView) {
        case AppView.homeDashboard:
          return AppConfiguration.homeDashboard();
        case AppView.homeUsers:
          return AppConfiguration.homeUsers();
        case AppView.homeStockManagement:
          return AppConfiguration.homeStockManagement();
        case AppView.homeAdminPackagingsManagement:
          return AppConfiguration.homeAdminPackagingsManagement();
        case AppView.homeMerchantPackagingsManagement:
          return AppConfiguration.homeMerchantPackagingsManagement();
        case AppView.homeMerchantSettings:
          return AppConfiguration.homeMerchantSettings();
        case AppView.homeMerchantIntegrations:
          return AppConfiguration.homeMerchantIntegrations(
            queryParams: currentViewConfig?.params ?? {},
          );
        case AppView.homeOrdersManagement:
          return AppConfiguration.homeOrdersManagement();
        case AppView.homeReturnLabelsManagement:
          return AppConfiguration.homeReturnLabelsManagement();
        case AppView.inviteUser:
          return AppConfiguration.inviteUser();
        case AppView.editUser:
          return AppConfiguration.editUser(
            queryParams: currentViewConfig?.params ?? {},
          );
        case AppView.createPackagings:
          return AppConfiguration.createPackagings();
        case AppView.createOrder:
          return AppConfiguration.createOrder();
        case AppView.editOrder:
          return AppConfiguration.editOrder(
            queryParams: currentViewConfig?.params ?? {},
          );
        default:
          return AppConfiguration.signIn(
              queryParams: currentViewConfig?.params ?? {});
      }
    }
  }

  @override
  Future<void> setNewRoutePath(AppConfiguration configuration) async {
    if (configuration.isUnknown) {
      show404 = true;
    } else {
      show404 = false;
    }

    if (configuration.isHomeDashboard) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeDashboard,
        params: {},
      );
      // uiState.updateView(ViewConfig(
      //   appView: AppView.homeDashboard,
      //   params: {},
      // ));
    }

    if (configuration.isHomeUsers) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeUsers,
        params: {},
      );
      // uiState.updateView(ViewConfig(
      //   appView: AppView.homeUsers,
      //   params: {},
      // ));
    }

    if (configuration.isHomeStockManagement) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeStockManagement,
        params: {},
      );
    }

    if (configuration.isHomeAdminPackagingsManagement) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeAdminPackagingsManagement,
        params: {},
      );
    }

    if (configuration.isHomeMerchantPackagingsManagement) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeMerchantPackagingsManagement,
        params: {},
      );
    }

    if (configuration.isHomeMerchantSettings) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeMerchantSettings,
        params: {},
      );
    }

    if (configuration.isHomeMerchantIntegrations) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeMerchantIntegrations,
        params: {},
      );
    }

    if (configuration.isHomeOrdersManagement) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeOrdersManagement,
        params: {},
      );
    }

    if (configuration.isHomeReturnLabelsManagement) {
      currentViewConfig = ViewConfig(
        appView: AppView.homeReturnLabelsManagement,
        params: {},
      );
    }

    if (configuration.isInviteUser) {
      currentViewConfig = ViewConfig(
        appView: AppView.inviteUser,
        params: {},
      );
    }

    if (configuration.isEditUser) {
      currentViewConfig = ViewConfig(
        appView: AppView.editUser,
        params: configuration.queryParams,
      );
    }

    if (configuration.isSignIn) {
      currentViewConfig = ViewConfig(
        appView: AppView.signIn,
        params: {},
      );
    }

    if (configuration.isResetPassword) {
      currentViewConfig = ViewConfig(
        appView: AppView.resetPassword,
        params: {},
      );
    }

    if (configuration.isEmailSent) {
      currentViewConfig = ViewConfig(
        appView: AppView.emailSent,
        params: {},
      );
    }

    if (configuration.isSetNewPassword) {
      currentViewConfig = ViewConfig(
        appView: AppView.setNewPassword,
        params: {},
      );
    }

    if (configuration.isCreateAccount) {
      currentViewConfig = ViewConfig(
        appView: AppView.createAccount,
        params: {},
      );
    }

    if (configuration.isPackagingInfo) {
      currentViewConfig = ViewConfig(
        appView: AppView.packagingInfo,
        params: {},
      );
    }

    if (configuration.isCreatePackagings) {
      currentViewConfig = ViewConfig(
        appView: AppView.createPackagings,
        params: {},
      );
    }

    if (configuration.isCreateOrder) {
      currentViewConfig = ViewConfig(
        appView: AppView.createOrder,
        params: {},
      );
    }

    if (configuration.isEditOrder) {
      currentViewConfig = ViewConfig(
        appView: AppView.editOrder,
        params: configuration.queryParams,
      );
    }

    currentViewConfig?.params = configuration.queryParams;
  }

  @override
  void dispose() {
    authStatusStreamSubscription?.cancel();
    uiStateStreamSubscription?.cancel();
    super.dispose();
  }

  void _handleAuthStateChanges() {
    authStatusStreamSubscription =
        authState.onAuthStateChanged.listen((Future<User?> user) async {
      if (await user == null) {
        isLoggedIn = false;
      } else {
        isLoggedIn = true;
      }
    });
  }

  void _handleUiStateChanges() {
    uiStateStreamSubscription =
        uiState.onUiStateChanged.listen((ViewConfig viewConfig) {
      currentViewConfig = viewConfig;
    });
  }

  List<Page> get _unknownStack => [const NotFoundPage()];

  List<Page> get _splashStack => [const SplashPage()];

  List<Page> get _loggedOutStack => [
        SignInPage(params: currentViewConfig?.params ?? {}),
        if (currentViewConfig?.appView == AppView.resetPassword)
          const ResetPasswordPage(),
        if (currentViewConfig?.appView == AppView.emailSent)
          const EmailSentPage(),
        if (currentViewConfig?.appView == AppView.setNewPassword)
          SetNewPasswordPage(params: currentViewConfig?.params ?? {}),
        if (currentViewConfig?.appView == AppView.createAccount)
          CreateAccountPage(params: currentViewConfig?.params ?? {}),
        if (currentViewConfig?.appView == AppView.packagingInfo)
          PackagingInfoPage(params: currentViewConfig?.params ?? {}),
      ];

  List<Page> get _loggedInStack => [
        HomePage(params: currentViewConfig?.params ?? {}),
        if (currentViewConfig?.appView == AppView.inviteUser)
          const InviteUserPage(),
        if (currentViewConfig?.appView == AppView.editUser)
          EditUserPage(params: currentViewConfig?.params ?? {}),
        if (currentViewConfig?.appView == AppView.createPackagings)
          const CreatePackagingsPage(),
        if (currentViewConfig?.appView == AppView.createOrder)
          const CreateOrderPage(),
        if (currentViewConfig?.appView == AppView.editOrder)
          EditOrderPage(params: currentViewConfig?.params ?? {}),
      ];
}
