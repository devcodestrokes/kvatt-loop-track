import 'package:kvatt_app/app/routing/app_view.dart';

class ViewConfig {
  AppView appView;
  Map<String, String> params;

  ViewConfig({
    required this.appView,
    required this.params,
  });
}
