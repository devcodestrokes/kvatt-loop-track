import 'package:kvatt_app/app/routing/app_view.dart';

class AppConfiguration {
  final bool unknown;
  final bool? loggedIn;
  final AppView? loggedInView;
  final AppView? loggedOutView;

  Map<String, String> queryParams = {};

  AppConfiguration.unknown()
      : unknown = true,
        loggedIn = null,
        loggedInView = null,
        loggedOutView = null;

  AppConfiguration.splash()
      : unknown = false,
        loggedIn = null,
        loggedInView = null,
        loggedOutView = null;

  AppConfiguration.signIn({
    required this.queryParams,
  })  : unknown = false,
        loggedIn = false,
        loggedInView = null,
        loggedOutView = AppView.signIn;

  AppConfiguration.resetPassword()
      : unknown = false,
        loggedIn = false,
        loggedInView = null,
        loggedOutView = AppView.resetPassword;

  AppConfiguration.emailSent()
      : unknown = false,
        loggedIn = false,
        loggedInView = null,
        loggedOutView = AppView.emailSent;

  AppConfiguration.setNewPassword({
    required this.queryParams,
  })  : unknown = false,
        loggedIn = false,
        loggedInView = null,
        loggedOutView = AppView.setNewPassword;

  AppConfiguration.createAccount({
    required this.queryParams,
  })  : unknown = false,
        loggedIn = false,
        loggedInView = null,
        loggedOutView = AppView.createAccount;

  AppConfiguration.packagingInfo({
    required this.queryParams,
  })  : unknown = false,
        loggedIn = false,
        loggedInView = null,
        loggedOutView = AppView.packagingInfo;

  AppConfiguration.homeDashboard()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeDashboard,
        loggedOutView = null;

  AppConfiguration.homeUsers()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeUsers,
        loggedOutView = null;

  AppConfiguration.homeStockManagement()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeStockManagement,
        loggedOutView = null;

  AppConfiguration.homeAdminPackagingsManagement()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeAdminPackagingsManagement,
        loggedOutView = null;

  AppConfiguration.homeMerchantPackagingsManagement()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeMerchantPackagingsManagement,
        loggedOutView = null;

  AppConfiguration.homeMerchantSettings()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeMerchantSettings,
        loggedOutView = null;

  AppConfiguration.homeMerchantIntegrations({
    required this.queryParams,
  })  : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeMerchantIntegrations,
        loggedOutView = null;

  AppConfiguration.homeOrdersManagement()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeOrdersManagement,
        loggedOutView = null;

  AppConfiguration.homeReturnLabelsManagement()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.homeReturnLabelsManagement,
        loggedOutView = null;

  AppConfiguration.inviteUser()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.inviteUser,
        loggedOutView = null;

  AppConfiguration.editUser({
    required this.queryParams,
  })  : unknown = false,
        loggedIn = true,
        loggedInView = AppView.editUser,
        loggedOutView = null;

  AppConfiguration.createPackagings()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.createPackagings,
        loggedOutView = null;

  AppConfiguration.createOrder()
      : unknown = false,
        loggedIn = true,
        loggedInView = AppView.createOrder,
        loggedOutView = null;

  AppConfiguration.editOrder({
    required this.queryParams,
  })  : unknown = false,
        loggedIn = true,
        loggedInView = AppView.editOrder,
        loggedOutView = null;

  bool get isUnknown => unknown == true;

  bool get isSplash =>
      loggedIn == null &&
      unknown == false &&
      loggedInView == null &&
      loggedOutView == null;

  bool get isSignIn =>
      loggedIn == false &&
      unknown == false &&
      loggedInView == null &&
      loggedOutView == AppView.signIn;

  bool get isResetPassword =>
      loggedIn == false &&
      unknown == false &&
      loggedInView == null &&
      loggedOutView == AppView.resetPassword;

  bool get isEmailSent =>
      loggedIn == false &&
      unknown == false &&
      loggedInView == null &&
      loggedOutView == AppView.emailSent;

  bool get isSetNewPassword =>
      loggedIn == false &&
      unknown == false &&
      loggedInView == null &&
      loggedOutView == AppView.setNewPassword;

  bool get isCreateAccount =>
      loggedIn == false &&
      unknown == false &&
      loggedInView == null &&
      loggedOutView == AppView.createAccount;

  bool get isPackagingInfo =>
      loggedIn == false &&
      unknown == false &&
      loggedInView == null &&
      loggedOutView == AppView.packagingInfo;

  bool get isHomeDashboard =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeDashboard &&
      loggedOutView == null;

  bool get isHomeUsers =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeUsers &&
      loggedOutView == null;

  bool get isHomeStockManagement =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeStockManagement &&
      loggedOutView == null;

  bool get isHomeAdminPackagingsManagement =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeAdminPackagingsManagement &&
      loggedOutView == null;

  bool get isHomeMerchantPackagingsManagement =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeMerchantPackagingsManagement &&
      loggedOutView == null;

  bool get isHomeMerchantSettings =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeMerchantSettings &&
      loggedOutView == null;

  bool get isHomeMerchantIntegrations =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeMerchantIntegrations &&
      loggedOutView == null;

  bool get isHomeOrdersManagement =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeOrdersManagement &&
      loggedOutView == null;

  bool get isHomeReturnLabelsManagement =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.homeReturnLabelsManagement &&
      loggedOutView == null;

  bool get isInviteUser =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.inviteUser &&
      loggedOutView == null;

  bool get isEditUser =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.editUser &&
      loggedOutView == null;

  bool get isCreatePackagings =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.createPackagings &&
      loggedOutView == null;

  bool get isCreateOrder =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.createOrder &&
      loggedOutView == null;

  bool get isEditOrder =>
      unknown == false &&
      loggedIn == true &&
      loggedInView == AppView.editOrder &&
      loggedOutView == null;
}
