import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_configuration.dart';
import 'package:kvatt_app/app/routing/route_path.dart';

class AppRouteInformationParser
    extends RouteInformationParser<AppConfiguration> {
  @override
  Future<AppConfiguration> parseRouteInformation(
      RouteInformation routeInformation) async {
    final uri = routeInformation.uri;
    Map<String, String> queryParams = uri.queryParameters;

    // If '/' we set it to the home route
    if (uri.pathSegments.isEmpty) {
      return AppConfiguration.homeDashboard();
    }
    if (uri.pathSegments.length == 1) {
      final String path = '/${uri.pathSegments[0].toLowerCase()}';
      switch (path) {
        case RoutePath.home:
          return _handleHome(queryParams);
        case RoutePath.authAction:
          return _handleAuthAction(queryParams);
        case RoutePath.signIn:
          return AppConfiguration.signIn(
            queryParams: queryParams,
          );
        case RoutePath.inviteUser:
          return AppConfiguration.inviteUser();
        case RoutePath.editUser:
          return AppConfiguration.editUser(queryParams: queryParams);
        case RoutePath.resetPassword:
          return AppConfiguration.resetPassword();
        case RoutePath.emailSent:
          return AppConfiguration.emailSent();
        case RoutePath.setNewPassword:
          return AppConfiguration.setNewPassword(queryParams: queryParams);
        case RoutePath.createAccount:
          return AppConfiguration.createAccount(queryParams: queryParams);
        case RoutePath.packagingInfo:
          return AppConfiguration.packagingInfo(queryParams: queryParams);
        case RoutePath.createPackagings:
          return AppConfiguration.createPackagings();
        case RoutePath.createOrder:
          return AppConfiguration.createOrder();
        case RoutePath.editOrder:
          return AppConfiguration.editOrder(queryParams: queryParams);
        default:
          return AppConfiguration.unknown();
      }
    }

    return AppConfiguration.unknown();
  }

  @override
  RouteInformation? restoreRouteInformation(AppConfiguration configuration) {
    String queryParamsString = Uri(
      queryParameters: configuration.queryParams.map(
        (key, value) => MapEntry(key, value),
      ),
    ).query;

    if (configuration.isUnknown) {
      return RouteInformation(uri: Uri.parse(RoutePath.unknown));
    } else if (configuration.isSplash) {
      return null;
    } else if (configuration.isHomeDashboard) {
      return RouteInformation(
          uri: Uri.parse('${RoutePath.home}?view=dashboard'));
    } else if (configuration.isHomeUsers) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.home}?view=users'),
      );
    } else if (configuration.isHomeStockManagement) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.home}?view=stock-management'),
      );
    } else if (configuration.isHomeAdminPackagingsManagement) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.home}?view=kvatt-packagings-management'),
      );
    } else if (configuration.isHomeMerchantPackagingsManagement) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.home}?view=packagings-management'),
      );
    } else if (configuration.isHomeMerchantSettings) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.home}?view=merchant-settings'),
      );
    } else if (configuration.isHomeMerchantIntegrations) {
      if (queryParamsString.contains('view=merchant-integrations')) {
        return RouteInformation(
          uri: Uri.parse('${RoutePath.home}?$queryParamsString'),
        );
      } else {
        return RouteInformation(
          uri: Uri.parse(
              '${RoutePath.home}?view=merchant-integrations$queryParamsString'),
        );
      }
    } else if (configuration.isHomeOrdersManagement) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.home}?view=orders-management'),
      );
    } else if (configuration.isHomeReturnLabelsManagement) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.home}?view=return-labels-management'),
      );
    } else if (configuration.isInviteUser) {
      return RouteInformation(
        uri: Uri.parse(RoutePath.inviteUser),
      );
    } else if (configuration.isEditUser) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.editUser}?$queryParamsString'),
      );
    } else if (configuration.isResetPassword) {
      return RouteInformation(
        uri: Uri.parse(RoutePath.resetPassword),
      );
    } else if (configuration.isEmailSent) {
      return RouteInformation(
        uri: Uri.parse(RoutePath.emailSent),
      );
    } else if (configuration.isSetNewPassword) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.setNewPassword}?$queryParamsString'),
      );
    } else if (configuration.isCreateAccount) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.createAccount}?$queryParamsString'),
      );
    } else if (configuration.isSignIn) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.signIn}?$queryParamsString'),
      );
    } else if (configuration.isPackagingInfo) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.packagingInfo}?$queryParamsString'),
      );
    } else if (configuration.isCreatePackagings) {
      return RouteInformation(
        uri: Uri.parse(RoutePath.createPackagings),
      );
    } else if (configuration.isCreateOrder) {
      return RouteInformation(
        uri: Uri.parse(RoutePath.createOrder),
      );
    } else if (configuration.isEditOrder) {
      return RouteInformation(
        uri: Uri.parse('${RoutePath.editOrder}?$queryParamsString'),
      );
    } else {
      return null;
    }
  }

  AppConfiguration _handleAuthAction(Map<String, String> params) {
    switch (params['mode']) {
      case 'resetPassword':
        return AppConfiguration.setNewPassword(queryParams: params);
      default:
        return AppConfiguration.unknown();
    }
  }

  AppConfiguration _handleHome(Map<String, String> params) {
    switch (params['view']) {
      case 'users':
        return AppConfiguration.homeUsers();
      case 'kvatt-packagings-management':
        return AppConfiguration.homeAdminPackagingsManagement();
      case 'packagings-management':
        return AppConfiguration.homeMerchantPackagingsManagement();
      case 'merchant-settings':
        return AppConfiguration.homeMerchantSettings();
      case 'merchant-integrations':
        return AppConfiguration.homeMerchantIntegrations(
          queryParams: params,
        );
      case 'orders-management':
        return AppConfiguration.homeOrdersManagement();
      case 'stock-management':
        return AppConfiguration.homeStockManagement();
      case 'return-labels-management':
        return AppConfiguration.homeReturnLabelsManagement();
      default:
        return AppConfiguration.homeDashboard();
    }
  }
}
