enum AppView {
  //logged out views
  signIn,
  resetPassword,
  emailSent,
  setNewPassword,
  packagingInfo,

  //logged in views
  homeDashboard,
  homeUsers,
  homeStockManagement,
  homeAdminPackagingsManagement,
  homeMerchantPackagingsManagement,
  homeMerchantSettings,
  homeMerchantIntegrations,
  homeOrdersManagement,
  homeReturnLabelsManagement,
  inviteUser,
  createAccount,
  editUser,
  createPackagings,
  createOrder,
  editOrder,
}
