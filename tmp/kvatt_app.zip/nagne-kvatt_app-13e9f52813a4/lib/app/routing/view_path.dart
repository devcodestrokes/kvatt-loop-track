class ViewPath {
  static const String merchantIntegrations = 'merchant-integrations';
}
