import 'package:flutter/material.dart';

extension ExtendedColorScheme on ColorScheme {
  Color get primaryAlternateColor => const Color(0xFF49546E);
  Color get secondaryColor => const Color(0xFFFF5664);
  Color get surfaceColor => const Color(0xFFF4F4F4);
  Color get surfaceDarkColor => const Color(0xFFE3E3E3);

  Color get backgroundColor => const Color(0xFFFFFFFF);

  Color get onPrimaryHighEmphasis => const Color(0xFFFFFFFF);
  Color get onPrimaryMediumEmphasis =>
      const Color(0xFFFFFFFF).withOpacity(0.74);

  Color get onSurfaceHighEmphasis => const Color(0xFF000000);
  Color get onSurfaceMediumEmphasis => const Color(0xFF000000).withOpacity(0.6);

  Color get onSurfaceDisabled => const Color(0xFF000000).withOpacity(0.38);

  Color get outlineColor => const Color(0xFF27233D).withOpacity(0.15);

  Color get trafficLightAmber => const Color(0xFFFEFFCB);
  Color get trafficLightGreen => const Color(0xFFABF4D0);
  Color get trafficLightRed => const Color(0xFFFFC7C7);

  Color get onTrafficLightAmber => const Color(0xFF7C7E02);
  Color get onTrafficLightGreen => const Color(0xFF297650);
  Color get onTrafficLightRed => const Color(0xFFAE0303);

  Color get kvattNewGreen => const Color(0xFF05B19A);
  Color get kvattNewBlue => const Color(0xFF005493);
  Color get kvattNewPink => const Color(0xFFFF5664);

  Color get kvattGreyBrown => const Color(0xFFE6E3DB);
  Color get kvattBeige => const Color(0xFFF9F5ED);
  Color get kvattBrightRed => const Color(0xFFFF655d);
  Color get kvattBrown => const Color(0xFFADA79A);
}
