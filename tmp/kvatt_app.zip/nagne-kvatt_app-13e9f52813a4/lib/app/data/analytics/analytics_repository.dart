import 'package:kvatt_app/app/services/firestore/firestore_service.dart';
import 'package:kvatt_app/domain/analytics/analytics_event.dart';
import 'package:kvatt_app/domain/analytics/analytics_repository_interface.dart';
import 'package:kvatt_app/domain/analytics/landing_page_view_event.dart';

class AnalyticsRepository implements AnalyticsRepositoryInterface {
  static const String analyticsCollection = 'analytics';

  FirestoreService firestoreService;

  AnalyticsRepository({
    required this.firestoreService,
  });

  @override
  Future<void> recordAnalyticsEvent({
    required AnalyticsEvent event,
  }) async {
    await firestoreService.createDocument(
      collectionPath: analyticsCollection,
      data: _serialiseAnalyticsEvent(event: event),
    );
  }

  Map<String, dynamic> _serialiseAnalyticsEvent({
    required AnalyticsEvent event,
  }) {
    if (event is LandingPageViewEvent) {
      return {
        'date': event.date,
        'event': 'qr_landing_page_view',
        'packagingId': event.packagingId,
        'labelStyle': event.labelStyle,
        'source': event.source,
        'merchantId': event.merchantId,
      };
    }

    return {
      'date': event.date,
    };
  }
}
