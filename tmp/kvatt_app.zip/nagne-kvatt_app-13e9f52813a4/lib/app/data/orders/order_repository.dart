import 'package:kvatt_app/app/services/firestore/firestore_service.dart';
import 'package:kvatt_app/domain/orders/order.dart';
import 'package:kvatt_app/domain/orders/order_repository_interface.dart';
import 'package:kvatt_app/domain/orders/order_source.dart';
import 'package:kvatt_app/domain/orders/order_status.dart';
import 'package:kvatt_app/domain/orders/order_type.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';

class OrderRepository implements OrderRepositoryInterface {
  final String ordersCollection = 'orders';

  FirestoreService firestoreService;

  OrderRepository({
    required this.firestoreService,
  });

  @override
  Future<String> createOrder({
    required Order order,
  }) async {
    String docId = await firestoreService.createDocument(
      collectionPath: ordersCollection,
      data: _serialiseOrder(
        order: order,
      ),
    );
    return docId;
  }

  @override
  Future<void> updateOrder({
    required Order order,
  }) async {
    await firestoreService.updateDocument(
      documentPath: '$ordersCollection/${order.id}',
      data: _serialiseOrder(
        order: order,
      ),
    );
  }

  @override
  Future<List<Order>> retrieveOrders({
    OrderStatus? orderStatus,
    int? limit,
    int? startAt,
  }) async {
    List<String> fieldNames = [];
    List<String> targetValues = [];

    if (orderStatus != null) {
      fieldNames.add('status');
      targetValues.add(_serialiseOrderStatus(orderStatus));
    }

    List<DocumentData> docs = await firestoreService.retrieveDocuments(
      collectionPath: ordersCollection,
      fieldNamesEqual: fieldNames,
      targetValuesEqual: targetValues,
      limit: limit,
      startAt: startAt,
      orderByField: 'orderNumber',
    );
    return docs.map((DocumentData doc) {
      return _deserialiseOrder(id: doc.id, data: doc.data);
    }).toList();
  }

  @override
  Future<int?> retrieveLastOrderNumber() async {
    List<DocumentData> docs = await firestoreService.retrieveDocuments(
      collectionPath: ordersCollection,
      orderByField: 'orderNumber',
      orderDescending: true,
      limit: 1,
    );
    if (docs.isEmpty) return null;
    Order order = _deserialiseOrder(
      id: docs[0].id,
      data: docs[0].data,
    );
    return order.number;
  }

  @override
  Future<Order?> retrieveOrderById({
    required String id,
  }) async {
    DocumentData? doc = await firestoreService.retrieveDocument(
        documentPath: '$ordersCollection/$id');
    if (doc == null) return null;
    return _deserialiseOrder(id: doc.id, data: doc.data);
  }

  @override
  Future<void> deleteOrder({
    required String id,
  }) async {
    await firestoreService.deleteDocument(
      documentPath: '$ordersCollection/$id',
    );
  }

  Map<String, dynamic> _serialiseOrder({
    required Order order,
  }) {
    return {
      'orderNumber': order.number,
      'source': _serialiseOrderSource(order.source),
      'orderType': _serialiseOrderType(order.orderType),
      'productType': order.productType,
      'quantity': order.quantity,
      'status': _serialiseOrderStatus(order.status),
      'hasInvoiced': order.hasInvoiced,
      'merchantId': order.merchantId,
      'merchantName': order.merchantName,
      'comment': order.comment,
      'contactEmail': order.contactEmail,
      'shippingDetails': order.shippingDetails,
      'unitPriceInGBP': order.unitPriceInGBP,
      'probability': order.probability,
      'tracking': order.tracking,
      'expectedDeliveryDate': order.expectedDeliveryDate,
      'deliveryDate': order.deliveryDate,
      'invoiceLink': order.invoiceLink,
    };
  }

  Order _deserialiseOrder({
    required String id,
    required Map<String, dynamic> data,
  }) {
    return Order(
      id: id,
      number: data['orderNumber'],
      source: _deserialiseOrderSource(data['source']),
      orderType: _deserialiseOrderType(data['orderType']),
      productType: data['productType'],
      quantity: data['quantity'],
      status: _deserialiseOrderStatus(data['status']),
      hasInvoiced: data['hasInvoiced'] ?? false,
      merchantId: data['merchantId'],
      merchantName: data['merchantName'],
      comment: data['comment'],
      contactEmail: data['contactEmail'],
      shippingDetails: data['shippingDetails'],
      unitPriceInGBP: data['unitPriceInGBP'],
      probability: data['probability'],
      tracking: data['tracking'],
      expectedDeliveryDate: data['expectedDeliveryDate']?.toDate(),
      deliveryDate: data['deliveryDate']?.toDate(),
      invoiceLink: data['invoiceLink'],
    );
  }

  String _serialiseOrderSource(OrderSource source) {
    switch (source) {
      case OrderSource.customer:
        return 'customer';
      case OrderSource.internal:
        return 'internal';
    }
  }

  OrderSource _deserialiseOrderSource(String? source) {
    switch (source) {
      case 'customer':
        return OrderSource.customer;
      case 'internal':
        return OrderSource.internal;
      default:
        return OrderSource.customer;
    }
  }

  String _serialiseOrderType(OrderType type) {
    switch (type) {
      case OrderType.subscription:
        return 'subscription';
      case OrderType.samples:
        return 'samples';
      case OrderType.pilot:
        return 'pilot';
      case OrderType.wholesale:
        return 'wholesale';
      case OrderType.other:
        return 'other';
    }
  }

  OrderType _deserialiseOrderType(String? type) {
    switch (type) {
      case 'subscription':
        return OrderType.subscription;
      case 'samples':
        return OrderType.samples;
      case 'pilot':
        return OrderType.pilot;
      case 'wholesale':
        return OrderType.wholesale;
      case 'other':
        return OrderType.other;
      default:
        return OrderType.other;
    }
  }

  String _serialiseOrderStatus(OrderStatus status) {
    switch (status) {
      case OrderStatus.open:
        return 'open';
      case OrderStatus.acknowledged:
        return 'acknowledged';
      case OrderStatus.ready:
        return 'ready';
      case OrderStatus.inTransit:
        return 'in-transit';
      case OrderStatus.delivered:
        return 'delivered';
      case OrderStatus.onHold:
        return 'on-hold';
    }
  }

  OrderStatus _deserialiseOrderStatus(String? status) {
    switch (status) {
      case 'open':
        return OrderStatus.open;
      case 'acknowledged':
        return OrderStatus.acknowledged;
      case 'ready':
        return OrderStatus.ready;
      case 'in-transit':
        return OrderStatus.inTransit;
      case 'delivered':
        return OrderStatus.delivered;
      case 'on-hold':
        return OrderStatus.onHold;
      default:
        return OrderStatus.open;
    }
  }
}
