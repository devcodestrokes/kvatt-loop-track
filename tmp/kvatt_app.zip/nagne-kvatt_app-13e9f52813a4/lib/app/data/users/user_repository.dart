import 'package:kvatt_app/app/services/firestore/firestore_service.dart';
import 'package:kvatt_app/domain/contracts/contract_type.dart';
import 'package:kvatt_app/domain/contracts/merchant_contract_info.dart';
import 'package:kvatt_app/domain/contracts/packaging_info.dart';
import 'package:kvatt_app/domain/users/admin.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/partner.dart';
import 'package:kvatt_app/domain/users/user.dart';
import 'package:kvatt_app/domain/users/user_account_status.dart';
import 'package:kvatt_app/domain/users/user_repository_interface.dart';
import 'package:kvatt_app/domain/users/user_type.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_core/domain/tracking/tracking_source.dart';

class UserTypeSerialisationException implements Exception {
  String? message;
  UserTypeSerialisationException(message);
}

class UserObjectSerialisationException implements Exception {
  String? message;
  UserObjectSerialisationException(message);
}

class UserAccountStatusDeserialisationException implements Exception {
  String? message;
  UserAccountStatusDeserialisationException(message);
}

class UserTypeDeserialisationException implements Exception {
  String? message;
  UserTypeDeserialisationException(message);
}

class UserRepository implements UserRepositoryInterface {
  final String usersCollection = 'users';

  FirestoreService firestoreService;

  UserRepository({
    required this.firestoreService,
  });

  @override
  Future<void> createUser({
    required User user,
  }) async {
    await firestoreService.createDocument(
      collectionPath: usersCollection,
      data: _serialiseUser(user),
    );
  }

  @override
  Future<void> updateUser({
    required User user,
  }) async {
    await firestoreService.updateDocument(
      documentPath: '$usersCollection/${user.uid}',
      data: _serialiseUser(user),
    );
  }

  @override
  Future<User?> findUserByEmail({
    required String email,
  }) async {
    List<DocumentData> docs = await firestoreService.retrieveDocuments(
      collectionPath: usersCollection,
      fieldNamesEqual: ['email'],
      targetValuesEqual: [email],
    );
    if (docs.isEmpty) return null;
    return _deserialiseUser(docs[0].id, docs[0].data);
  }

  @override
  Future<User?> findUserById({
    required String userId,
  }) async {
    DocumentData? doc = await firestoreService.retrieveDocument(
      documentPath: '$usersCollection/$userId',
    );
    if (doc == null) return null;
    return _deserialiseUser(doc.id, doc.data);
  }

  @override
  Future<List<User>> findUsers({
    required UserType userType,
    required UserAccountStatus accountStatus,
    ContractType? contractType,
  }) async {
    List<String> fieldNames = ['type', 'accountStatus'];
    List<String> targetValues = [
      _serialiseUserType(userType),
      accountStatus == UserAccountStatus.active ? 'active' : 'pending',
    ];
    if (contractType != null) {
      fieldNames.add('contractType');
      targetValues.add(_serialiseContractType(contractType) ?? '');
    }
    List<DocumentData> docs = await firestoreService.retrieveDocuments(
      collectionPath: usersCollection,
      fieldNamesEqual: fieldNames,
      targetValuesEqual: targetValues,
    );
    return docs
        .map((DocumentData doc) => _deserialiseUser(doc.id, doc.data))
        .toList();
  }

  @override
  Stream<List<User>> users({
    required UserType userType,
  }) {
    return firestoreService.documents(
        collectionPath: usersCollection,
        fieldNames: [
          'type'
        ],
        targetValues: [
          _serialiseUserType(userType)
        ]).map((List<DocumentData> docs) {
      return docs.map((DocumentData doc) {
        return _deserialiseUser(doc.id, doc.data);
      }).toList();
    });
  }

  Map<String, dynamic> _serialiseUser(User user) {
    Map<String, dynamic> serialisedUser = {
      'email': user.email,
      'accountStatus': _serialiseUserAccountStatus(user.accountStatus),
      'type': _serialiseUserType(_getUserTypeFromObject(user)),
    };

    Map<String, dynamic> details = {};

    if (user is Merchant) {
      details = _serialiseMerchantDetails(user);
    }

    if (user is Admin) {
      details = _serialiseAdminDetails(user);
    }

    if (user is Partner) {
      details = _serialisePartnerDetails(user);
    }

    return {
      ...serialisedUser,
      ...details,
    };
  }

  User _deserialiseUser(String id, Map<String, dynamic> data) {
    String email = data['email'];
    UserAccountStatus accountStatus =
        _deserialiseUserAccountStatus(data['accountStatus']);
    switch (data['type']) {
      case 'admin':
        return Admin(
          uid: id,
          email: email,
          accountStatus: accountStatus,
          name: data['name'] ?? '',
        );
      case 'partner':
        return Partner(
          uid: id,
          email: email,
          accountStatus: accountStatus,
          name: data['name'],
          assignedMerchantIds: (data['assignedMerchantIds'] as List<dynamic>)
              .map((dynamic e) => e.toString())
              .toList(),
        );
      case 'merchant':
        return Merchant(
          uid: id,
          email: email,
          accountStatus: accountStatus,
          name: data['name'],
          contractInfo: MerchantContractInfo(
            deliveryAddress: data['deliveryAddress'],
            contractType: data['contractType'],
            packagings:
                (data['packagings'] as List<dynamic>).map((dynamic packaging) {
              return PackagingInfo(
                packagingType: packaging['type'],
                numberOfUnits: packaging['numUnits'],
              );
            }).toList(),
            packagingLossCompensationIncluded:
                data['packagingLossCompensationIncluded'],
            packagingMaintenanceIncluded: data['packagingMaintenanceIncluded'],
          ),
          trackingSource: _deserialiseTrackingSource(data['trackingSource']),
        );
      default:
        throw UserTypeDeserialisationException(
            '${data['type']} is not a valid user type');
    }
  }

  String _serialiseUserAccountStatus(UserAccountStatus status) {
    switch (status) {
      case UserAccountStatus.active:
        return 'active';
      case UserAccountStatus.pending:
        return 'pending';
    }
  }

  UserAccountStatus _deserialiseUserAccountStatus(String status) {
    switch (status) {
      case 'active':
        return UserAccountStatus.active;
      case 'pending':
        return UserAccountStatus.pending;
      default:
        throw UserAccountStatusDeserialisationException(
            '$status is not a valid account status');
    }
  }

  UserType _getUserTypeFromObject(User user) {
    if (user is Admin) return UserType.admin;
    if (user is Partner) return UserType.partner;
    if (user is Merchant) return UserType.merchant;
    throw UserObjectSerialisationException('Invalid user object');
  }

  String _serialiseUserType(UserType type) {
    switch (type) {
      case UserType.admin:
        return 'admin';
      case UserType.partner:
        return 'partner';
      case UserType.merchant:
        return 'merchant';
    }
  }

  Map<String, dynamic> _serialiseMerchantDetails(Merchant merchant) {
    return {
      'name': merchant.name,
      'deliveryAddress': merchant.contractInfo.deliveryAddress,
      'contractType': merchant.contractInfo.contractType,
      'packagings': merchant.contractInfo.packagings
          .map((PackagingInfo info) => {
                'type': info.packagingType,
                'numUnits': info.numberOfUnits,
              })
          .toList(),
      'packagingLossCompensationIncluded':
          merchant.contractInfo.packagingLossCompensationIncluded,
      'packagingMaintenanceIncluded':
          merchant.contractInfo.packagingMaintenanceIncluded,
      'trackingSource': _serialiseTrackingSource(merchant.trackingSource),
    };
  }

  Map<String, dynamic> _serialiseAdminDetails(Admin admin) {
    return {
      'name': admin.name,
    };
  }

  Map<String, dynamic> _serialisePartnerDetails(Partner partner) {
    return {
      'name': partner.name,
      'assignedMerchantIds': partner.assignedMerchantIds,
    };
  }

  String? _serialiseContractType(ContractType contractType) {
    switch (contractType) {
      case ContractType.rentalLargeLoop:
        return 'Rental Large Loop';
      case ContractType.rentalSmallLoop:
        return 'Rental Small Loop';
      default:
        return null;
    }
  }

  String? _serialiseTrackingSource(TrackingSource? trackingSource) {
    switch (trackingSource) {
      case TrackingSource.kvattApp:
        return 'kvatt_app';
      case TrackingSource.shopify:
        return 'shopify';
      default:
        return null;
    }
  }

  TrackingSource? _deserialiseTrackingSource(String? source) {
    switch (source) {
      case 'kvatt_app':
        return TrackingSource.kvattApp;
      case 'shopify':
        return TrackingSource.shopify;
      default:
        return null;
    }
  }
}
