import 'package:kvatt_app/app/services/firestore/firestore_service.dart';
import 'package:kvatt_app/domain/shipments/shipment.dart';
import 'package:kvatt_app/domain/shipments/shipment_repository_interface.dart';

class ShipmentRepository implements ShipmentRepositoryInterface {
  final String shipmentsCollection = 'shipments';

  FirestoreService firestoreService;

  ShipmentRepository({
    required this.firestoreService,
  });

  @override
  Future<void> createShipment({
    required Shipment shipment,
    required String merchantId,
  }) async {
    await firestoreService.createDocument(
      collectionPath: shipmentsCollection,
      data: _serialiseShipment(
        shipment: shipment,
        merchantId: merchantId,
      ),
    );
  }

  Map<String, dynamic> _serialiseShipment({
    required Shipment shipment,
    required String merchantId,
  }) {
    return {
      'productQuantities': shipment.productQuantities,
      'date': shipment.date,
      'shippingService': shipment.shippingService,
      'trackingNumber': shipment.trackingNumber,
      'merchantId': merchantId,
    };
  }
}
