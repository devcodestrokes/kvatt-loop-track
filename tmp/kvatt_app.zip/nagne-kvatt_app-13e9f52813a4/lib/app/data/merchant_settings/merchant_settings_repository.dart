import 'package:kvatt_app/domain/merchant_settings/merchant_settings.dart';
import 'package:kvatt_app/domain/merchant_settings/merchant_settings_repository_interface.dart';
import 'package:kvatt_app/domain/merchant_settings/stock_level_reminder_setting.dart';
import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';

class MerchantSettingsRepository
    implements MerchantSettingsRepositoryInterface {
  final String merchantSettingsCollection = 'merchant_settings';

  DbInterface db;

  MerchantSettingsRepository({
    required this.db,
  });

  @override
  Future<MerchantSettings?> retrieveMerchantSettings({
    required String merchantId,
  }) async {
    DocumentData? doc = await db.retrieveDocument(
        documentPath: '$merchantSettingsCollection/$merchantId');

    if (doc == null) {
      return null;
    }

    return _deserialiseMerchantSettings(doc.data);
  }

  @override
  Future<void> updateMerchantSettings({
    required String merchantId,
    required MerchantSettings merchantSettings,
  }) async {
    await db.updateDocument(
      documentPath: '$merchantSettingsCollection/$merchantId',
      data: _serialiseMerchantSettings(merchantSettings),
    );
  }

  Map<String, dynamic> _serialiseMerchantSettings(MerchantSettings settings) {
    return {
      'stockLevelReminderSettings': settings.stockLevelReminderSettings
          .map((StockLevelReminderSetting setting) {
        return _serialiseStockLevelReminderSetting(setting);
      }).toList(),
    };
  }

  MerchantSettings _deserialiseMerchantSettings(Map<String, dynamic> data) {
    List<StockLevelReminderSetting> stockLevelReminderSettings =
        (data['stockLevelReminderSettings'] as List<dynamic>)
            .map((dynamic setting) {
      return _deserialiseStockLevelReminderSetting(setting);
    }).toList();

    return MerchantSettings(
      stockLevelReminderSettings: stockLevelReminderSettings,
    );
  }

  Map<String, dynamic> _serialiseStockLevelReminderSetting(
    StockLevelReminderSetting setting,
  ) {
    return {
      'product': setting.product,
      'minLevel': setting.minLevel,
    };
  }

  StockLevelReminderSetting _deserialiseStockLevelReminderSetting(
    Map<String, dynamic> data,
  ) {
    return StockLevelReminderSetting(
      product: data['product'],
      minLevel: data['minLevel'],
    );
  }
}
