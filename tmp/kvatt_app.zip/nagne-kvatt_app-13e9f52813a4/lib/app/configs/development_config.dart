import 'package:firebase_core/firebase_core.dart';

import 'config.dart';

class DevelopmentConfig implements Config {
  @override
  String? environmentName = 'development';

  @override
  FirebaseOptions? firebaseConfigs = const FirebaseOptions(
    apiKey: 'AIzaSyBRP3eNM5lVCXONFSgpvTq3YsZ_N9LVlJw',
    appId: '1:862603377306:web:a90201f4f015652afe3d23',
    messagingSenderId: '862603377306',
    projectId: 'kvatt-platform-dev',
    authDomain: 'kvatt-platform-dev.firebaseapp.com',
  );

  @override
  String? cloudFunctionRegion = 'europe-west2';

  @override
  String? baseUrl = 'http://localhost:45555';

  @override
  DateTime? platformStartDate = DateTime.parse('2022-10-01');

  @override
  String? shopifyAuthUrl =
      'https://europe-west2-kvatt-platform-dev.cloudfunctions.net/shopifyAuthEndpoint';
}
