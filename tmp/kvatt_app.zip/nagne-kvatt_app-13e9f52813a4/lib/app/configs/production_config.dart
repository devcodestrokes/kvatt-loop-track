import 'package:firebase_core/firebase_core.dart';

import 'config.dart';

class ProductionConfig implements Config {
  @override
  String? environmentName = 'production';

  @override
  FirebaseOptions? firebaseConfigs = const FirebaseOptions(
    apiKey: 'AIzaSyAQ98ZzM_hfJ43wWzkc7A7fyZHVpql7bxw',
    appId: '1:1048899297323:web:e344ea9602f00a615dca6e',
    messagingSenderId: '1048899297323',
    projectId: 'kvatt-platform-live',
    authDomain: 'kvatt-platform-live.firebaseapp.com',
  );

  @override
  String? cloudFunctionRegion = 'europe-west2';

  @override
  String? baseUrl = 'https://app.kvatt.com';

  @override
  DateTime? platformStartDate = DateTime.parse('2022-10-01');

  @override
  String? shopifyAuthUrl =
      'https://europe-west2-kvatt-platform-live.cloudfunctions.net/shopifyAuthEndpoint';
}
