import 'package:firebase_core/firebase_core.dart';

abstract class Config {
  String? environmentName;
  FirebaseOptions? firebaseConfigs;
  String? cloudFunctionRegion;
  String? baseUrl;
  DateTime? platformStartDate;
  String? shopifyAuthUrl;
}
