import 'package:firebase_core/firebase_core.dart';

import 'config.dart';

class StagingConfig implements Config {
  @override
  String? environmentName = 'staging';

  @override
  FirebaseOptions? firebaseConfigs = const FirebaseOptions(
    apiKey: 'AIzaSyBv6ySzSS1l_ACVdy237PTohDkeiycEtDI',
    appId: '1:450635617658:web:c616e02d2ef832889772c3',
    messagingSenderId: '450635617658',
    projectId: 'kvatt-platform-staging',
    authDomain: 'kvatt-platform-staging.firebaseapp.com',
  );

  @override
  String? cloudFunctionRegion = 'europe-west2';

  @override
  String? baseUrl = 'https://kvatt-platform-staging.web.app';

  @override
  DateTime? platformStartDate = DateTime.parse('2022-10-01');

  @override
  String? shopifyAuthUrl =
      'https://europe-west2-kvatt-platform-staging.cloudfunctions.net/shopifyAuthEndpoint';
}
