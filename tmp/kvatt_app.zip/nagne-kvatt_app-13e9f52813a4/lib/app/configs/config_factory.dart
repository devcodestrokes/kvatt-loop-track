import 'package:kvatt_app/app/configs/production_config.dart';
import 'package:kvatt_app/app/configs/staging_config.dart';

import 'config.dart';
import 'development_config.dart';

class ConfigFactory {
  static Config getConfig(String environment) {
    switch (environment) {
      case 'development':
        return DevelopmentConfig();
      case 'staging':
        return StagingConfig();
      case 'production':
        return ProductionConfig();
      default:
        return DevelopmentConfig();
    }
  }
}
