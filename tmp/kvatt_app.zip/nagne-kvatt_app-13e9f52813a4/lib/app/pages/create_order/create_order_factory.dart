import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/create_order/create_order.dart';
import 'package:kvatt_app/app/pages/create_order/create_order_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class CreateOrderFactory {
  static Widget build() {
    return ChangeNotifierProvider<CreateOrderViewModel>(
      create: (context) {
        return CreateOrderViewModel(
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<CreateOrderViewModel>(
        builder: (context, model, child) => CreateOrder(
          viewModel: model,
        ),
      ),
    );
  }
}
