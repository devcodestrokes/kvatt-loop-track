import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/create_order/create_order_factory.dart';

class CreateOrderPage extends Page {
  const CreateOrderPage() : super(key: const ValueKey('CreateOrderPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => CreateOrderFactory.build(),
    );
  }
}
