import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/layouts/tabs_layout.dart';
import 'package:kvatt_app/app/pages/create_order/create_order_view_model.dart';
import 'package:kvatt_app/app/views/orders_management/create_order/create_order_factory.dart';

class CreateOrder extends StatelessWidget {
  final CreateOrderViewModel viewModel;

  const CreateOrder({
    super.key,
    required this.viewModel,
  });

  @override
  Widget build(BuildContext context) {
    return TabsLayout(
      title: 'Create new order',
      onBackButtonTapped: () => viewModel.onBackButtonTapped(),
      tabConfigs: [
        TabConfig(
          label: 'Create new order',
          widget: CreateOrderFactory.build(),
        ),
      ],
    );
  }
}
