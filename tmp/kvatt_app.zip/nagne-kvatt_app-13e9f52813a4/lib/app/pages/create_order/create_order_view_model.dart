import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';

class CreateOrderViewModel extends ChangeNotifier {
  UiState uiState;

  CreateOrderViewModel({
    required this.uiState,
  });

  onBackButtonTapped() {
    uiState.updateView(
      ViewConfig(appView: AppView.homeOrdersManagement, params: {}),
    );
  }
}
