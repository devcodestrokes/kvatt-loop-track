import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/create_packagings/create_packagings.dart';
import 'package:kvatt_app/app/pages/create_packagings/create_packagings_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class CreatePackagingsFactory {
  static Widget build() {
    return ChangeNotifierProvider<CreatePackagingsViewModel>(
      create: (context) {
        return CreatePackagingsViewModel(
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<CreatePackagingsViewModel>(
        builder: (context, model, child) => CreatePackagings(
          viewModel: model,
        ),
      ),
    );
  }
}
