import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/create_packagings/create_packagings_factory.dart';

class CreatePackagingsPage extends Page {
  const CreatePackagingsPage()
      : super(key: const ValueKey('CreatePackagingsPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => CreatePackagingsFactory.build(),
    );
  }
}
