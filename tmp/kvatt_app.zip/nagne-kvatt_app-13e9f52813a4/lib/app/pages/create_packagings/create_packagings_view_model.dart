import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/states/ui_state.dart';

import '../../routing/view_config.dart';

class CreatePackagingsViewModel extends ChangeNotifier {
  UiState uiState;

  CreatePackagingsViewModel({
    required this.uiState,
  });

  onBackButtonTapped() {
    uiState.updateView(
      ViewConfig(appView: AppView.homeAdminPackagingsManagement, params: {}),
    );
  }
}
