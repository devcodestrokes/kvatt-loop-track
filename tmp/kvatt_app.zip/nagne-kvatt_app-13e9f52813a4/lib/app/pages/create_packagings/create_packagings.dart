import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/layouts/tabs_layout.dart';
import 'package:kvatt_app/app/pages/create_packagings/create_packagings_view_model.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/create_packagings/create_packagings_factory.dart';

class CreatePackagings extends StatelessWidget {
  final CreatePackagingsViewModel viewModel;

  const CreatePackagings({
    super.key,
    required this.viewModel,
  });

  @override
  Widget build(BuildContext context) {
    return TabsLayout(
      title: 'Generate packs and labels',
      onBackButtonTapped: () => viewModel.onBackButtonTapped(),
      tabConfigs: [
        TabConfig(
          label: 'Generate packs and labels',
          widget: CreatePackagingsFactory.build(),
        ),
      ],
    );
  }
}
