import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_white.dart';
import 'package:kvatt_app/app/common/widgets/layouts/ride_side_layout.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/pages/create_account/create_account_view_model.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class CreateAccount extends StatelessWidget {
  final CreateAccountViewModel viewModel;

  const CreateAccount({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RightSideLayout(
      widget: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Complete account creation.',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                ),
          ),
          const SizedBox(height: 24.0),
          viewModel.isValidLink
              ? Column(
                  children: [
                    Text(
                      'You\'ve been invited to join the Kvatt Platform as ${_getUserTypeLabel()} with the following email address:',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryMediumEmphasis,
                          ),
                      textAlign: TextAlign.center,
                    ),
                    Text(
                      viewModel.invitedEmail!,
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryMediumEmphasis,
                            fontWeight: FontWeight.bold,
                          ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 12.0),
                    Text(
                      'Please set a password to complete your account creation.',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                            color: Theme.of(context)
                                .colorScheme
                                .onPrimaryMediumEmphasis,
                          ),
                      textAlign: TextAlign.center,
                    ),
                    const SizedBox(height: 60.0),
                    _CreateAccountForm(
                      passwordValidator: (String? password) =>
                          Validators.validatePassword(password),
                      onCreateAccountPressed: (String password) =>
                          viewModel.onCreateAccountPressed(
                        password: password,
                      ),
                    ),
                  ],
                )
              : Text(
                  'There seems to be an issue with this link. Please get in touch with an Administrator to get a new invitation.',
                  style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        color: Theme.of(context)
                            .colorScheme
                            .onPrimaryMediumEmphasis,
                      ),
                  textAlign: TextAlign.center,
                ),
          const SizedBox(height: 60.0),
          PromptTextButton(
            promptText: 'Having issues?',
            actionLabel: 'Contact Support',
            onPressed: () => viewModel.onContactSupportPressed(),
            fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
          ),
        ],
      ),
    );
  }

  String _getUserTypeLabel() {
    switch (viewModel.userType) {
      case 'admin':
        return 'an Administrator';
      case 'partner':
        return 'a Partner';
      case 'merchant':
        return 'a Merchant';
      default:
        return 'a User';
    }
  }
}

class _CreateAccountForm extends StatefulWidget {
  final Function(String?) passwordValidator;
  final Function(String password) onCreateAccountPressed;

  const _CreateAccountForm({
    required this.passwordValidator,
    required this.onCreateAccountPressed,
  });

  @override
  State<_CreateAccountForm> createState() => _CreateAccountFormState();
}

class _CreateAccountFormState extends State<_CreateAccountForm> {
  TextEditingController passwordTextController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextFieldWhite(
            validator: (String? password) => widget.passwordValidator(password),
            label: 'Set Password',
            keyboardType: TextInputType.text,
            controller: passwordTextController,
            obscureText: true,
          ),
          const SizedBox(height: 36.0),
          PrimaryButton(
            label: 'Complete Account Creation',
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                LoadingDialog.show(context, 'creating your account...');
                bool res = await widget.onCreateAccountPressed(
                  passwordTextController.text.trim(),
                );
                if (!mounted) return;
                Navigator.of(context).pop();
                if (res == true) {
                  Provider.of<UiState>(
                    context,
                    listen: false,
                  ).updateView(ViewConfig(
                    appView: AppView.signIn,
                    params: {},
                  ));
                }
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    passwordTextController.dispose();
    super.dispose();
  }
}
