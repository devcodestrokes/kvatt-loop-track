import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/create_account/create_account.dart';
import 'package:kvatt_app/app/pages/create_account/create_account_view_model.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:provider/provider.dart';

class CreateAccountFactory {
  static Widget build({
    required Map<String, dynamic> params,
  }) {
    return ChangeNotifierProvider<CreateAccountViewModel>(
      create: (context) {
        return CreateAccountViewModel(
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          communicationsManager: Provider.of<CommunicationsManager>(
            context,
            listen: false,
          ),
          invitedEmail: params['email'],
          userType: params['type'],
          code: params['code'],
        );
      },
      child: Consumer<CreateAccountViewModel>(
        builder: (context, model, child) => CreateAccount(
          viewModel: model,
        ),
      ),
    );
  }
}
