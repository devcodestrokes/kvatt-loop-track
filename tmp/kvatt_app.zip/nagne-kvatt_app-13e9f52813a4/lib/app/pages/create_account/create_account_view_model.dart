import 'package:flutter/material.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';

class CreateAccountViewModel extends ChangeNotifier {
  UserManager userManager;
  CommunicationsManager communicationsManager;

  String? invitedEmail;
  String? userType;
  String? code;

  CreateAccountViewModel({
    required this.userManager,
    required this.communicationsManager,
    required this.invitedEmail,
    required this.userType,
    required this.code,
  });

  bool get isValidLink =>
      invitedEmail != null && userType != null && code != null;

  Future<bool> onCreateAccountPressed({
    required String password,
  }) async {
    try {
      await userManager.createAccount(
        password: password,
        code: code ?? '',
      );
      return true;
    } catch (e) {
      code = null;
      notifyListeners();
      return false;
    }
  }

  onContactSupportPressed() {
    communicationsManager.launchSupportEmail();
  }
}
