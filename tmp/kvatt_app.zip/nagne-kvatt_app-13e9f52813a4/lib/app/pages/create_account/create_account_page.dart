import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/create_account/create_account_factory.dart';

class CreateAccountPage extends Page {
  final Map<String, String> params;

  const CreateAccountPage({
    required this.params,
  }) : super(key: const ValueKey('CreateAccountPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => CreateAccountFactory.build(
        params: params,
      ),
    );
  }
}
