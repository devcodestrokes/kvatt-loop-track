import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/password_reset/email_sent/email_sent.dart';
import 'package:kvatt_app/app/pages/password_reset/email_sent/email_sent_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class EmailSentFactory {
  static Widget build() {
    return ChangeNotifierProvider<EmailSentViewModel>(
      create: (context) {
        return EmailSentViewModel(
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<EmailSentViewModel>(
        builder: (context, model, child) => EmailSent(
          viewModel: model,
        ),
      ),
    );
  }
}
