import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/layouts/ride_side_layout.dart';
import 'package:kvatt_app/app/pages/password_reset/email_sent/email_sent_view_model.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class EmailSent extends StatelessWidget {
  final EmailSentViewModel viewModel;

  const EmailSent({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RightSideLayout(
      widget: Column(
        crossAxisAlignment: CrossAxisAlignment.center,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'We\'ve sent you an email.',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                ),
          ),
          const SizedBox(height: 6.0),
          Text(
            'Please click on the link we\'ve sent you\nby email to reset your password.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onPrimaryMediumEmphasis,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 48.0),
          PromptTextButton(
            promptText: 'Didn\'t get the email?',
            actionLabel: 'Try again',
            onPressed: () => viewModel.onTryAgainPressed(),
            fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
          ),
          const SizedBox(height: 16.0),
          PromptTextButton(
            promptText: 'Having issues?',
            actionLabel: 'Contact Support',
            onPressed: () => viewModel.onContactSupportPressed(),
            fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
          ),
        ],
      ),
    );
  }
}
