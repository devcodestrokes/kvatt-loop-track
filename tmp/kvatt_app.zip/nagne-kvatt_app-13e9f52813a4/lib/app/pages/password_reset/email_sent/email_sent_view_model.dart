import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';

class EmailSentViewModel extends ChangeNotifier {
  UiState uiState;

  EmailSentViewModel({
    required this.uiState,
  });

  onContactSupportPressed() {}

  onTryAgainPressed() {
    uiState.updateView(
      ViewConfig(appView: AppView.resetPassword, params: {}),
    );
  }
}
