import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/password_reset/email_sent/email_sent_factory.dart';

class EmailSentPage extends Page {
  const EmailSentPage() : super(key: const ValueKey('EmailSentPage'));
  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => EmailSentFactory.build(),
    );
  }
}
