import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';

class ResetPasswordViewModel extends ChangeNotifier {
  UiState uiState;
  AuthManager authManager;
  CommunicationsManager communicationsManager;

  String? errorMessage;

  ResetPasswordViewModel({
    required this.uiState,
    required this.authManager,
    required this.communicationsManager,
  });

  Future<bool> onSendResetLinkPressed({
    required String email,
  }) async {
    try {
      await authManager.sendPasswordResetEmail(email: email);
      return true;
    } catch (e) {
      errorMessage = 'There was an issue sending you the link.';
      notifyListeners();
      return false;
    }
  }

  onSignInPressed() {
    uiState.updateView(ViewConfig(
      appView: AppView.signIn,
      params: {},
    ));
  }

  onContactSupportPressed() {
    communicationsManager.launchSupportEmail();
  }
}
