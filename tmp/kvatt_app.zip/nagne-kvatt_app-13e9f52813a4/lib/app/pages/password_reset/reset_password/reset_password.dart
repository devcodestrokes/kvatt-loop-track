import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_white.dart';
import 'package:kvatt_app/app/common/widgets/layouts/ride_side_layout.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/pages/password_reset/reset_password/reset_password_view_model.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class ResetPassword extends StatelessWidget {
  final ResetPasswordViewModel viewModel;

  const ResetPassword({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RightSideLayout(
      widget: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Reset Password.',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                ),
          ),
          const SizedBox(height: 6.0),
          Text(
            'Please enter your email address and\nwe\'ll send you a link to reset your password.',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                  color: Theme.of(context).colorScheme.onPrimaryMediumEmphasis,
                ),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 48.0),
          viewModel.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        viewModel.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          _ResetPasswordForm(
            emailValidator: (String? email) => Validators.validateEmail(email),
            onSendResetLinkPressed: (String email) =>
                viewModel.onSendResetLinkPressed(
              email: email,
            ),
          ),
          const SizedBox(height: 60.0),
          PromptTextButton(
            promptText: 'Remembered your password?',
            actionLabel: 'Sign in',
            onPressed: () => viewModel.onSignInPressed(),
            fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
          ),
          const SizedBox(height: 16.0),
          PromptTextButton(
            promptText: 'Having issues?',
            actionLabel: 'Contact Support',
            onPressed: () => viewModel.onContactSupportPressed(),
            fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
          ),
        ],
      ),
    );
  }
}

class _ResetPasswordForm extends StatefulWidget {
  final Function(String?) emailValidator;
  final Function(String email) onSendResetLinkPressed;

  const _ResetPasswordForm({
    required this.emailValidator,
    required this.onSendResetLinkPressed,
  });

  @override
  State<_ResetPasswordForm> createState() => _ResetPasswordFormState();
}

class _ResetPasswordFormState extends State<_ResetPasswordForm> {
  TextEditingController emailTextController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextFieldWhite(
            validator: (String? email) => widget.emailValidator(email),
            label: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            controller: emailTextController,
          ),
          const SizedBox(height: 36.0),
          PrimaryButton(
            label: 'Send a reset password link',
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                LoadingDialog.show(context, 'sending the link...');
                bool res = await widget.onSendResetLinkPressed(
                  emailTextController.text.trim(),
                );
                if (!mounted) return;
                Navigator.of(context).pop();
                if (res == true) {
                  Provider.of<UiState>(context, listen: false)
                      .updateView(ViewConfig(
                    appView: AppView.emailSent,
                    params: {},
                  ));
                }
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    emailTextController.dispose();
    super.dispose();
  }
}
