import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/password_reset/reset_password/reset_password_factory.dart';

class ResetPasswordPage extends Page {
  const ResetPasswordPage() : super(key: const ValueKey('ResetPasswordPage'));
  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => ResetPasswordFactory.build(),
    );
  }
}
