import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/password_reset/reset_password/reset_password.dart';
import 'package:kvatt_app/app/pages/password_reset/reset_password/reset_password_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:provider/provider.dart';

class ResetPasswordFactory {
  static Widget build() {
    return ChangeNotifierProvider<ResetPasswordViewModel>(
      create: (context) {
        return ResetPasswordViewModel(
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
          authManager: Provider.of<AuthManager>(
            context,
            listen: false,
          ),
          communicationsManager: Provider.of<CommunicationsManager>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<ResetPasswordViewModel>(
        builder: (context, model, child) => ResetPassword(
          viewModel: model,
        ),
      ),
    );
  }
}
