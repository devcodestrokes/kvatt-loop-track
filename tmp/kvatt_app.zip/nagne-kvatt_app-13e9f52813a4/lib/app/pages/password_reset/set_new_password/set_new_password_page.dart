import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/password_reset/set_new_password/set_new_password_factory.dart';

class SetNewPasswordPage extends Page {
  final Map<String, String> params;

  const SetNewPasswordPage({
    required this.params,
  }) : super(key: const ValueKey('SetNewPasswordPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => SetNewPasswordFactory.build(
        params: params,
      ),
    );
  }
}
