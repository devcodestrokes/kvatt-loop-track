import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/password_reset/set_new_password/set_new_password.dart';
import 'package:kvatt_app/app/pages/password_reset/set_new_password/set_new_password_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:provider/provider.dart';

class SetNewPasswordFactory {
  static Widget build({
    required Map<String, String> params,
  }) {
    return ChangeNotifierProvider<SetNewPasswordViewModel>(
      create: (context) {
        return SetNewPasswordViewModel(
          authManager: Provider.of<AuthManager>(
            context,
            listen: false,
          ),
          communicationsManager: Provider.of<CommunicationsManager>(
            context,
            listen: false,
          ),
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
          oobCode: params['oobCode'],
        );
      },
      child: Consumer<SetNewPasswordViewModel>(
        builder: (context, model, child) => SetNewPassword(
          viewModel: model,
        ),
      ),
    );
  }
}
