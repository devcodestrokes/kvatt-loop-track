import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/services/auth/auth_service.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';

class SetNewPasswordViewModel extends ChangeNotifier {
  AuthManager authManager;
  CommunicationsManager communicationsManager;
  UiState uiState;

  String? oobCode;

  String? errorMessage;

  SetNewPasswordViewModel({
    required this.oobCode,
    required this.authManager,
    required this.communicationsManager,
    required this.uiState,
  });

  Future<bool> onSetNewPasswordPressed({
    required String password,
  }) async {
    try {
      await authManager.setNewPassword(
        password: password,
        code: oobCode ?? '',
      );
      return true;
    } catch (e) {
      if (e is InvalidActionCodeException) {
        errorMessage =
            'There was an issue while trying to reset your password.\nMost probably, the link is incorrect, or has expired.';
      } else {
        errorMessage = 'There was an issue resetting your password.';
      }
      notifyListeners();
      return false;
    }
  }

  onTryAgainPressed() {
    uiState.updateView(
      ViewConfig(
        appView: AppView.resetPassword,
        params: {},
      ),
    );
  }

  onContactSupportPressed() {
    communicationsManager.launchSupportEmail();
  }
}
