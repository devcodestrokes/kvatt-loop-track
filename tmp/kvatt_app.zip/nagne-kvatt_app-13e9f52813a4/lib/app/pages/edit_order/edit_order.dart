import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/layouts/tabs_layout.dart';
import 'package:kvatt_app/app/pages/edit_order/edit_order_view_model.dart';
import 'package:kvatt_app/app/views/orders_management/edit_order/edit_order_factory.dart';

class EditOrder extends StatelessWidget {
  final EditOrderViewModel viewModel;

  const EditOrder({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TabsLayout(
      title: 'Edit order',
      onBackButtonTapped: () => viewModel.onBackButtonTapped(),
      tabConfigs: [
        TabConfig(
          label: 'Edit Order',
          widget: EditOrderFactory.build(orderId: viewModel.orderId ?? ''),
        ),
      ],
    );
  }
}
