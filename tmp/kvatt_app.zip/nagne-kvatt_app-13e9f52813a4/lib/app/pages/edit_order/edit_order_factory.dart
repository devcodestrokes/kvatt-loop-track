import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/edit_order/edit_order.dart';
import 'package:kvatt_app/app/pages/edit_order/edit_order_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class EditOrderFactory {
  static Widget build({
    required Map<String, String> params,
  }) {
    return ChangeNotifierProvider<EditOrderViewModel>(
      create: (context) {
        return EditOrderViewModel(
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
          orderId: params['orderId'],
        );
      },
      child: Consumer<EditOrderViewModel>(
        builder: (context, model, child) => EditOrder(
          viewModel: model,
        ),
      ),
    );
  }
}
