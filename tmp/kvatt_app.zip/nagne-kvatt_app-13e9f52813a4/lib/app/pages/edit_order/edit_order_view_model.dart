import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';

class EditOrderViewModel extends ChangeNotifier {
  UiState uiState;

  String? orderId;

  EditOrderViewModel({
    required this.uiState,
    required this.orderId,
  });

  onBackButtonTapped() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeOrdersManagement,
      params: {},
    ));
  }
}
