import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/edit_order/edit_order_factory.dart';

class EditOrderPage extends Page {
  final Map<String, String> params;

  const EditOrderPage({
    required this.params,
  }) : super(key: const ValueKey('EditOrderPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => EditOrderFactory.build(
        params: params,
      ),
    );
  }
}
