import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/edit_user/edit_user.dart';
import 'package:kvatt_app/app/pages/edit_user/edit_user_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class EditUserFactory {
  static Widget build({
    required Map<String, String> params,
  }) {
    return ChangeNotifierProvider<EditUserViewModel>(
      create: (context) {
        return EditUserViewModel(
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
          userId: params['userId'],
        );
      },
      child: Consumer<EditUserViewModel>(
        builder: (context, model, child) => EditUser(
          viewModel: model,
        ),
      ),
    );
  }
}
