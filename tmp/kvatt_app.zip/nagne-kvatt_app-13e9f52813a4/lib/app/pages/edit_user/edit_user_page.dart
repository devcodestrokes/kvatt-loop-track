import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/edit_user/edit_user_factory.dart';

class EditUserPage extends Page {
  final Map<String, String> params;

  const EditUserPage({
    required this.params,
  }) : super(key: const ValueKey('EditUserPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => EditUserFactory.build(
        params: params,
      ),
    );
  }
}
