import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/layouts/tabs_layout.dart';
import 'package:kvatt_app/app/pages/edit_user/edit_user_view_model.dart';
import 'package:kvatt_app/app/views/user_management/edit_user/edit_user_factory.dart';

class EditUser extends StatelessWidget {
  final EditUserViewModel viewModel;

  const EditUser({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TabsLayout(
      title: 'Edit user',
      onBackButtonTapped: () => viewModel.onBackButtonTapped(),
      tabConfigs: [
        TabConfig(
          label: 'Edit User',
          widget: EditUserFactory.build(userId: viewModel.userId ?? ''),
        ),
      ],
    );
  }
}
