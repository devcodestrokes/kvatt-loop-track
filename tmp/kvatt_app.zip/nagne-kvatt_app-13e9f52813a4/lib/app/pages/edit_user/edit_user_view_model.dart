import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';

class EditUserViewModel extends ChangeNotifier {
  UiState uiState;

  String? userId;

  EditUserViewModel({
    required this.uiState,
    required this.userId,
  });

  onBackButtonTapped() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeUsers,
      params: {},
    ));
  }
}
