import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/not_found/not_found.dart';

class NotFoundPage extends Page {
  const NotFoundPage() : super(key: const ValueKey('NotFoundPage'));
  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => const NotFound(),
    );
  }
}
