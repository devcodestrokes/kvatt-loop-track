import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/domain/analytics/analytics_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_config.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_defaults.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_manager.dart';
import 'package:kvatt_core/domain/packagings/packaging_public.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';

class PackagingInfoViewModel extends ChangeNotifier {
  PackagingsManager packagingsManager;
  CommunicationsManager communicationsManager;
  LandingPageManager landingPageManager;
  AnalyticsManager analyticsManager;
  String? packagingId;
  String? labelStyle;
  String? source;
  String? merchantId;

  bool isLoading = true;

  PackagingPublic? packaging;

  LandingPageConfig? landingPageConfig;

  PackagingInfoViewModel({
    required this.packagingsManager,
    required this.communicationsManager,
    required this.landingPageManager,
    required this.analyticsManager,
    required this.packagingId,
    required this.labelStyle,
    required this.source,
    required this.merchantId,
  });

  init() async {
    if (packagingId != null) {
      packaging = await packagingsManager.getPackagingPublicInfo(
        id: packagingId!,
      );
      if (packaging?.merchantId != null) {
        landingPageConfig =
            await landingPageManager.getCustomConfigsForMerchant(
          merchantId: packaging?.merchantId ?? '',
        );
      }
    }
    isLoading = false;
    notifyListeners();
  }

  logVisit() async {
    await analyticsManager.recordLandingPageViewEvent(
      packagingId: packagingId,
      labelStyle: labelStyle,
      source: source,
      merchantId: merchantId,
    );
  }

  String? get packagingName => packaging?.type;

  String get returnLocationButtonLabel =>
      landingPageConfig?.returnLocationLabel ??
      LandingPageDefaults.returnLocationLabel;

  String? get packagingImage {
    switch (packaging?.type) {
      case 'Charlie S':
      case 'Charlie M':
      case 'Charlie L':
        return AssetsFactory.charlie;
      case 'Ray S':
      case 'Ray M':
      case 'Ray L':
        return AssetsFactory.ray;
      case 'Harry S':
      case 'Harry M':
        return AssetsFactory.harry;
      case 'Alfred M':
        return AssetsFactory.alfred;
      default:
        return null;
    }
  }

  String? get packagingNumber => packaging?.code.toString().padLeft(5, '0');

  String get logo => AssetsFactory.kvattLogoWhite;

  onDownloadReturnLabelPressed() {
    communicationsManager.launchReturnLabelDoc();
  }

  onFindNearestReturnLocation() {
    communicationsManager.launchReturnLocationLink(
      landingPageConfig?.returnLocationUrl ??
          LandingPageDefaults.returnLocationUrl,
    );
  }
}
