import 'package:flutter/widgets.dart';

class TextStylesHelper {
  static TextStyle header1 = const TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
    fontSize: 100.0,
  );

  static TextStyle header2 = const TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w600,
    fontSize: 48.0,
  );

  static TextStyle button = const TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
    fontSize: 20.0,
    letterSpacing: 1.0,
  );

  static TextStyle body = const TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w300,
    fontSize: 20.0,
    letterSpacing: 1.0,
  );

  static TextStyle bodyBold = const TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w500,
    fontSize: 20.0,
    letterSpacing: 1.0,
  );

  static TextStyle bodySmall = const TextStyle(
    fontFamily: 'Inter',
    fontWeight: FontWeight.w300,
    fontSize: 18.0,
    letterSpacing: 1.0,
  );
}
