import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/packaging_info/packaging_info_factory.dart';

class PackagingInfoPage extends Page {
  final Map<String, String> params;

  const PackagingInfoPage({
    required this.params,
  }) : super(key: const ValueKey('PackagingInfoPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => PackagingInfoFactory.build(
        params: params,
      ),
    );
  }
}
