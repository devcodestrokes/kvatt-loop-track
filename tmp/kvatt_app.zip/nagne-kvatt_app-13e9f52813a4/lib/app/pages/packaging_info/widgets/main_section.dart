import 'package:flutter/material.dart';
import 'dart:math' as math;
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/pages/packaging_info/text_styles_helper.dart';

class MainSection extends StatelessWidget {
  final double width;
  final String? packagingName;
  final String logo;
  final Function onReturnInstructionsPressed;
  final Function onDetailsPressed;

  const MainSection({
    super.key,
    required this.width,
    required this.packagingName,
    required this.logo,
    required this.onReturnInstructionsPressed,
    required this.onDetailsPressed,
  });

  @override
  Widget build(BuildContext context) {
    return width < 800
        ? _buildMainSectionSmall(context)
        : _buildMainSectionLarge(context);
  }

  Widget _buildMainSectionLarge(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.kvattGreyBrown,
      padding: const EdgeInsets.fromLTRB(120.0, 100.0, 120.0, 100.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$_welcomePrompt,\n$_title',
                style: TextStylesHelper.header1.copyWith(
                  color: Colors.black,
                ),
              ),
              const SizedBox(width: 60.0),
              Container(
                margin: const EdgeInsets.only(top: 48.0),
                child: Transform.rotate(
                  angle: -math.pi / 12.0,
                  child: Image.asset(
                    AssetsFactory.kvattLogoNewRed,
                    width: 180.0,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 24.0),
          SizedBox(
            width: MediaQuery.of(context).size.width * 0.3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '$_packDescription\n',
                  style: TextStylesHelper.body,
                ),
                Text(
                  '$_notThrowAwayText\n',
                  style: TextStylesHelper.bodyBold,
                ),
                Text(
                  _returnText,
                  style: TextStylesHelper.body,
                ),
              ],
            ),
          ),
          const SizedBox(height: 64.0),
          Align(
            alignment: Alignment.center,
            child: _customButton(
              height: 80.0,
              backgroundColor: Theme.of(context).colorScheme.kvattBrightRed,
              onPressed: () => onReturnInstructionsPressed(),
              label: _instructionsButtonLabel,
            ),
          ),
          const SizedBox(height: 16.0),
          Align(
            alignment: Alignment.center,
            child: _customButton(
              height: 80.0,
              backgroundColor: Theme.of(context).colorScheme.kvattBrown,
              onPressed: () => onDetailsPressed(),
              label: _learnMoreButtonLabel,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMainSectionSmall(BuildContext context) {
    return Container(
      color: Theme.of(context).colorScheme.kvattGreyBrown,
      padding: const EdgeInsets.fromLTRB(32.0, 0.0, 24.0, 0.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 72.0),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                '$_welcomePrompt,\n$_title',
                style: TextStylesHelper.header1.copyWith(
                  color: Colors.black,
                  fontSize: 39.0,
                ),
              ),
              const SizedBox(width: 16.0),
              Container(
                margin: const EdgeInsets.only(top: 12.0),
                child: Transform.rotate(
                  angle: -math.pi / 12.0,
                  child: Image.asset(
                    AssetsFactory.kvattLogoNewRed,
                    width: 72.0,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 32.0),
          Text(
            _packDescription,
            style: TextStylesHelper.body.copyWith(
              fontSize: 18.0,
              // height: 1.0,
            ),
          ),
          const SizedBox(height: 12.0),
          Text(
            _notThrowAwayText,
            style: TextStylesHelper.bodyBold.copyWith(
              fontSize: 18.0,
            ),
          ),
          const SizedBox(height: 12.0),
          Text(
            _returnText,
            style: TextStylesHelper.body.copyWith(
              fontSize: 18.0,
            ),
          ),
          const SizedBox(height: 32.0),
          Align(
            alignment: Alignment.center,
            child: _customButton(
              height: 60.0,
              backgroundColor: Theme.of(context).colorScheme.kvattBrightRed,
              onPressed: () => onReturnInstructionsPressed(),
              label: _instructionsButtonLabel,
              isSmall: true,
            ),
          ),
          const SizedBox(height: 16.0),
          Align(
            alignment: Alignment.center,
            child: _customButton(
              height: 60.0,
              backgroundColor: Theme.of(context).colorScheme.kvattBrown,
              onPressed: () => onDetailsPressed(),
              label: _learnMoreButtonLabel,
              isSmall: true,
            ),
          ),
          const SizedBox(height: 60.0),
        ],
      ),
    );
  }

  Widget _customButton({
    required Color backgroundColor,
    required Function onPressed,
    required String label,
    required double height,
    bool? isSmall = false,
  }) {
    return SizedBox(
      height: height,
      width: 240.0,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: backgroundColor,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(12.0),
          ),
        ),
        onPressed: () => onPressed(),
        child: Text(
          label,
          style: TextStylesHelper.button.copyWith(
            color: Colors.white,
            fontSize: isSmall == true ? 18.0 : 20.0,
          ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }

  String get _packDescription =>
      'A returnable packaging, designed to make your online shopping waste-less.';

  String get _notThrowAwayText => 'Don\'t throw me away!';

  String get _returnText => 'Return me, so I can be reused.';

  String get _welcomePrompt => 'Hey';

  String get _title {
    String title = 'I\'m ';
    switch (packagingName) {
      case 'Ray S':
      case 'Ray M':
      case 'Ray L':
        title += 'Ray.';
        break;
      case 'Charlie S':
      case 'Charlie M':
      case 'Charlie L':
        title += 'Charlie.';
        break;
      case 'Harry S':
      case 'Harry M':
        title += 'Harry';
        break;
      case 'Alfred M':
        title += 'Alfred';
        break;
      default:
        title += 'a\nreusable pack';
        break;
    }
    return title;
  }

  String get _instructionsButtonLabel => 'View return\nInstructions';

  String get _learnMoreButtonLabel => 'Learn more\nabout circularity';
}
