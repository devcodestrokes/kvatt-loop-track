import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/pages/packaging_info/text_styles_helper.dart';

class FooterSection extends StatelessWidget {
  final double width;

  const FooterSection({
    super.key,
    required this.width,
  });

  @override
  Widget build(BuildContext context) {
    return width < 800
        ? _buildSmallSection(context)
        : _buildLargeSection(context);
  }

  _buildLargeSection(BuildContext context) {
    return Container(
      color: Colors.black,
      padding: const EdgeInsets.fromLTRB(120.0, 100.0, 120.0, 100.0),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Expanded(
            flex: 1,
            child: Image.asset(
              AssetsFactory.kvattLogoNewWhite,
              width: 80.0,
            ),
          ),
          Expanded(
            flex: 3,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.center,
              children: [
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Text(
                        '',
                        style: TextStylesHelper.body.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ),
                    const SizedBox(width: 12.0),
                    Expanded(
                      flex: 1,
                      child: Text(
                        'Support',
                        style: TextStylesHelper.body.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 24.0),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          'Email',
                          style: TextStylesHelper.bodyBold.copyWith(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12.0),
                    Expanded(
                      flex: 1,
                      child: Text(
                        'returns@kvatt.com',
                        style: TextStylesHelper.body.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 8.0),
                Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Align(
                        alignment: Alignment.centerRight,
                        child: Text(
                          'Whatsapp',
                          style: TextStylesHelper.bodyBold.copyWith(
                            color: Colors.white,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 12.0),
                    Expanded(
                      flex: 1,
                      child: Text(
                        '+44(0).77.11.88.31.94',
                        style: TextStylesHelper.body.copyWith(
                          color: Colors.white,
                        ),
                      ),
                    ),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  _buildSmallSection(BuildContext context) {
    return Container(
      color: Colors.black,
      width: MediaQuery.of(context).size.width,
      alignment: Alignment.center,
      child: Column(
        children: [
          const SizedBox(height: 48.0),
          Image.asset(
            AssetsFactory.kvattLogoNewWhite,
            width: 120.0,
          ),
          const SizedBox(height: 40.0),
          Text(
            'Support',
            style: TextStylesHelper.body.copyWith(
              color: Colors.white,
            ),
          ),
          const SizedBox(height: 24.0),
          Row(
            children: [
              Expanded(
                flex: 3,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'Email',
                    style: TextStylesHelper.bodyBold.copyWith(
                      color: Colors.white,
                      fontSize: 16.0,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12.0),
              Expanded(
                flex: 5,
                child: Text(
                  'returns@kvatt.com',
                  style: TextStylesHelper.body.copyWith(
                    color: Colors.white,
                    fontSize: 16.0,
                  ),
                ),
              ),
            ],
          ),
          Row(
            children: [
              Expanded(
                flex: 3,
                child: Align(
                  alignment: Alignment.centerRight,
                  child: Text(
                    'Whatsapp',
                    style: TextStylesHelper.bodyBold.copyWith(
                      color: Colors.white,
                      fontSize: 16.0,
                    ),
                  ),
                ),
              ),
              const SizedBox(width: 12.0),
              Expanded(
                flex: 5,
                child: Text(
                  '+44(0).77.11.88.31.94',
                  style: TextStylesHelper.body.copyWith(
                    color: Colors.white,
                    fontSize: 16.0,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 40.0),
        ],
      ),
    );
  }
}
