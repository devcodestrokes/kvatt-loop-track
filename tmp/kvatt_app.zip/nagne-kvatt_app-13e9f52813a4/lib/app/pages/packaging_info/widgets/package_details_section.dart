import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class PackageDetailsSection extends StatelessWidget {
  final double width;
  final String? packagingName;
  final String? packagingImage;
  final String? packagingNumber;

  const PackageDetailsSection({
    super.key,
    required this.width,
    required this.packagingName,
    required this.packagingImage,
    required this.packagingNumber,
  });

  @override
  Widget build(BuildContext context) {
    return width < 800
        ? _buildSmallSection(context)
        : _buildLargeSection(context);
  }

  Widget _buildLargeSection(BuildContext context) {
    return Container(
      color: Theme.of(context).primaryColor,
      padding: const EdgeInsets.fromLTRB(120.0, 100.0, 120.0, 100.0),
      child: Row(
        children: [
          Expanded(
            flex: 1,
            child: Column(
              children: [
                Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    _title,
                    textAlign: TextAlign.left,
                    style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        fontSize: 48.0,
                        color: Theme.of(context)
                            .colorScheme
                            .onPrimaryHighEmphasis),
                  ),
                ),
                const SizedBox(height: 24.0),
                Align(
                  alignment: Alignment.topLeft,
                  child: Text(
                    _message,
                    textAlign: TextAlign.left,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                        fontSize: 22.0,
                        color: Theme.of(context)
                            .colorScheme
                            .onPrimaryHighEmphasis),
                  ),
                ),
              ],
            ),
          ),
          Expanded(
            flex: 1,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Image.asset(
                  packagingImage ?? AssetsFactory.charlie,
                  width: MediaQuery.of(context).size.width * 0.5 * 0.4,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSmallSection(BuildContext context) {
    return Container(
      color: Theme.of(context).primaryColor,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          children: [
            const SizedBox(height: 48.0),
            Align(
              alignment: Alignment.topLeft,
              child: Text(
                _title,
                textAlign: TextAlign.left,
                style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                    color: Theme.of(context).colorScheme.onPrimaryHighEmphasis),
              ),
            ),
            const SizedBox(height: 24.0),
            Image.asset(
              packagingImage ?? AssetsFactory.charlie,
              width: MediaQuery.of(context).size.width * 0.4,
            ),
            const SizedBox(height: 24.0),
            Align(
              alignment: Alignment.topLeft,
              child: Text(
                _message,
                textAlign: TextAlign.left,
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    fontSize: 16.0,
                    color: Theme.of(context).colorScheme.onPrimaryHighEmphasis),
              ),
            ),
            const SizedBox(height: 48.0),
          ],
        ),
      ),
    );
  }

  String get _title {
    if (packagingName == null || packagingNumber == null) {
      return 'I\'m a\nreusable pack';
    } else {
      return 'I\'m $packagingName\nNo. $packagingNumber.';
    }
  }

  String get _message =>
      'I can be used up to 50 times and can reduce my impact on the planet by half each time!';
}
