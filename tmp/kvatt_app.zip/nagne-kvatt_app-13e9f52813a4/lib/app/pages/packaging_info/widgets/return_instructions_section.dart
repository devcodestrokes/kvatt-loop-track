import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/pages/packaging_info/text_styles_helper.dart';

class ReturnInstructionsSection extends StatelessWidget {
  final double width;
  final String returnLocationButtonLabel;
  final Function onPrintReturnLabelPressed;
  final Function onFindNearestReturnLocationPressed;
  final Function onDownloadReturnLabelPressed;

  const ReturnInstructionsSection({
    super.key,
    required this.width,
    required this.returnLocationButtonLabel,
    required this.onPrintReturnLabelPressed,
    required this.onFindNearestReturnLocationPressed,
    required this.onDownloadReturnLabelPressed,
  });

  @override
  Widget build(BuildContext context) {
    return width < 800
        ? _buildSectionSmall(context)
        : _buildSectionLarge(context);
  }

  Widget _buildSectionLarge(BuildContext context) {
    return Column(
      children: [
        Container(
          width: MediaQuery.of(context).size.width,
          color: Theme.of(context).colorScheme.kvattBeige,
          padding: const EdgeInsets.symmetric(horizontal: 120.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              const SizedBox(height: 100.0),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.6,
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Image.asset(
                            AssetsFactory.charlieMPackBack,
                            width:
                                MediaQuery.of(context).size.width * 0.5 * 0.4,
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _step1Title,
                            style: TextStylesHelper.header2.copyWith(
                              color: Colors.black,
                            ),
                            textAlign: TextAlign.left,
                          ),
                          const SizedBox(height: 32.0),
                          Text(
                            _step1Text,
                            style: TextStylesHelper.bodySmall.copyWith(
                              color: Colors.black,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 120.0),
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.6,
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            _step2Title,
                            style: TextStylesHelper.header2.copyWith(
                              color: Colors.black,
                            ),
                          ),
                          const SizedBox(height: 32.0),
                          SizedBox(
                            width: MediaQuery.of(context).size.width * 0.2,
                            child: Text(
                              _step2Text,
                              style: TextStylesHelper.bodySmall.copyWith(
                                color: Colors.black,
                              ),
                            ),
                          ),
                          const SizedBox(height: 24.0),
                          Text(
                            _cannotFindLabelText,
                            style: TextStylesHelper.bodySmall.copyWith(
                              color: Colors.black,
                              fontWeight: FontWeight.w600,
                              fontSize: 16.0,
                            ),
                          ),
                          RichText(
                            text: TextSpan(
                              children: [
                                TextSpan(
                                  text: _downloadReturnLabelText,
                                  style: TextStylesHelper.bodyBold.copyWith(
                                    color: Colors.black,
                                    decoration: TextDecoration.underline,
                                    fontSize: 16.0,
                                    fontWeight: FontWeight.w600,
                                  ),
                                  recognizer: TapGestureRecognizer()
                                    ..onTap =
                                        () => onDownloadReturnLabelPressed(),
                                ),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Image.asset(
                            AssetsFactory.charlieMPackWithLabel,
                            width:
                                MediaQuery.of(context).size.width * 0.5 * 0.4,
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 120.0),
            ],
          ),
        ),
        Container(
          color: Theme.of(context).colorScheme.kvattGreyBrown,
          padding: const EdgeInsets.symmetric(vertical: 120.0),
          width: MediaQuery.of(context).size.width,
          child: Column(
            children: [
              SizedBox(
                width: MediaQuery.of(context).size.width * 0.6,
                child: Row(
                  children: [
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Image.asset(
                            AssetsFactory.postBoxNew,
                            width:
                                MediaQuery.of(context).size.width * 0.5 * 0.4,
                          ),
                        ],
                      ),
                    ),
                    Expanded(
                      flex: 1,
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.end,
                        children: [
                          Text(
                            _step3Title,
                            style: TextStylesHelper.header2.copyWith(
                              color: Colors.black,
                            ),
                          ),
                          const SizedBox(height: 32.0),
                          Text(
                            _step3Text,
                            textAlign: TextAlign.left,
                            style: TextStylesHelper.bodySmall,
                          ),
                          const SizedBox(height: 32.0),
                          Align(
                            alignment: Alignment.centerLeft,
                            child: RichText(
                              text: TextSpan(
                                children: [
                                  TextSpan(
                                    text: 'Find your nearest location.',
                                    style: TextStylesHelper.bodyBold.copyWith(
                                      color: Colors.black,
                                      decoration: TextDecoration.underline,
                                    ),
                                    recognizer: TapGestureRecognizer()
                                      ..onTap = () =>
                                          onFindNearestReturnLocationPressed(),
                                  ),
                                ],
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildSectionSmall(BuildContext context) {
    return Column(
      children: [
        Container(
          color: Theme.of(context).colorScheme.kvattBeige,
          padding: const EdgeInsets.symmetric(horizontal: 32.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 36.0),
              Align(
                alignment: Alignment.center,
                child: Image.asset(
                  AssetsFactory.charlieMPackBack,
                  width: MediaQuery.of(context).size.width * 0.5 * 0.7,
                ),
              ),
              const SizedBox(height: 32.0),
              Text(
                _step1Title,
                style: TextStylesHelper.header2.copyWith(
                  color: Colors.black,
                  fontSize: 23.0,
                ),
                textAlign: TextAlign.left,
              ),
              const SizedBox(height: 12.0),
              Text(
                _step1Text,
                style: TextStylesHelper.bodySmall.copyWith(
                  color: Colors.black,
                  fontSize: 17.0,
                ),
              ),
              const SizedBox(height: 60.0),
              Align(
                alignment: Alignment.center,
                child: Image.asset(
                  AssetsFactory.charlieMPackWithLabel,
                  width: MediaQuery.of(context).size.width * 0.5 * 0.9,
                ),
              ),
              const SizedBox(height: 32.0),
              Text(
                _step2Title,
                style: TextStylesHelper.header2.copyWith(
                  color: Colors.black,
                  fontSize: 23.0,
                ),
              ),
              const SizedBox(height: 12.0),
              Text(
                _step2Text,
                style: TextStylesHelper.bodySmall.copyWith(
                  color: Colors.black,
                  fontSize: 17.0,
                ),
              ),
              const SizedBox(height: 24.0),
              Text(
                _cannotFindLabelText,
                style: TextStylesHelper.bodySmall.copyWith(
                  color: Colors.black,
                  fontWeight: FontWeight.w600,
                  fontSize: 16.0,
                ),
              ),
              RichText(
                text: TextSpan(
                  children: [
                    TextSpan(
                      text: _downloadReturnLabelText,
                      style: TextStylesHelper.bodyBold.copyWith(
                        color: Colors.black,
                        decoration: TextDecoration.underline,
                        fontSize: 16.0,
                        fontWeight: FontWeight.w600,
                      ),
                      recognizer: TapGestureRecognizer()
                        ..onTap = () => onDownloadReturnLabelPressed(),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: 60.0),
            ],
          ),
        ),
        Container(
          color: Theme.of(context).colorScheme.kvattGreyBrown,
          padding: const EdgeInsets.symmetric(horizontal: 32.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 60.0),
              Align(
                alignment: Alignment.center,
                child: Image.asset(
                  AssetsFactory.postBoxNew,
                  width: MediaQuery.of(context).size.width * 0.5 * 0.9,
                ),
              ),
              const SizedBox(height: 32.0),
              Text(
                _step3Title,
                style: TextStylesHelper.header2.copyWith(
                  color: Colors.black,
                  fontSize: 23.0,
                ),
              ),
              const SizedBox(height: 12.0),
              Text(
                _step3Text,
                textAlign: TextAlign.left,
                style: TextStylesHelper.bodySmall.copyWith(
                  color: Colors.black,
                  fontSize: 17.0,
                ),
              ),
              const SizedBox(height: 32.0),
              Align(
                alignment: Alignment.center,
                child: RichText(
                  text: TextSpan(
                    children: [
                      TextSpan(
                        text: 'Find your nearest location.',
                        style: TextStylesHelper.bodyBold.copyWith(
                          color: Colors.black,
                          decoration: TextDecoration.underline,
                          fontSize: 17.0,
                        ),
                        recognizer: TapGestureRecognizer()
                          ..onTap = () => onFindNearestReturnLocationPressed(),
                      ),
                    ],
                  ),
                ),
              ),
              const SizedBox(height: 60.0),
            ],
          ),
        ),
      ],
    );
  }

  String get _step1Title => '1. Empty & Fold the packaging.';
  String get _step2Title => '2. Stick the return label.';
  String get _step3Title => '3. Drop it in any mailbox.';

  String get _step1Text =>
      'Make sure the packaging is empty. Then fold it following the printed instructions.\n\nThis part is important as it ensures that the packaging doesn\'t get stuck in the return process.';
  String get _step2Text =>
      'In the packaging, you will find a prepaid return label.\n\nStick it over the old label to seal the packaging.\n\nThat\'s it, you\'re ready!';
  String get _step3Text =>
      'Our system allows you to drop the empty packaging in any Royal Mail location in the country. Easy.';

  String get _cannotFindLabelText => 'Can\'t find your return label?';
  String get _downloadReturnLabelText => 'Download it here.';
}
