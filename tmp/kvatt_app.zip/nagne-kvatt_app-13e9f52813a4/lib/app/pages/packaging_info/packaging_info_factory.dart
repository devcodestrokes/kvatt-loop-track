import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/packaging_info/packaging_info.dart';
import 'package:kvatt_app/app/pages/packaging_info/packaging_info_view_model.dart';
import 'package:kvatt_app/domain/analytics/analytics_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_manager.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:provider/provider.dart';

class PackagingInfoFactory {
  static Widget build({
    required Map<String, String> params,
  }) {
    return ChangeNotifierProvider<PackagingInfoViewModel>(
      create: (context) {
        return PackagingInfoViewModel(
          packagingsManager: Provider.of<PackagingsManager>(
            context,
            listen: false,
          ),
          communicationsManager: Provider.of<CommunicationsManager>(
            context,
            listen: false,
          ),
          landingPageManager: Provider.of<LandingPageManager>(
            context,
            listen: false,
          ),
          analyticsManager: Provider.of<AnalyticsManager>(
            context,
            listen: false,
          ),
          packagingId: params['id'],
          labelStyle: params['labelStyle'],
          source: params['source'],
          merchantId: params['merchantId'],
        );
      },
      child: Consumer<PackagingInfoViewModel>(
        builder: (context, model, child) => PackagingInfo(
          viewModel: model,
        ),
      ),
    );
  }
}
