import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_spinner.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/pages/packaging_info/packaging_info_view_model.dart';
import 'package:kvatt_app/app/pages/packaging_info/widgets/footer_section.dart';
import 'package:kvatt_app/app/pages/packaging_info/widgets/main_section.dart';
import 'package:kvatt_app/app/pages/packaging_info/widgets/return_instructions_section.dart';
import 'package:kvatt_app/app/services/url_launcher/url_launcher_service.dart';

class PackagingInfo extends StatefulWidget {
  final PackagingInfoViewModel viewModel;
  const PackagingInfo({
    super.key,
    required this.viewModel,
  });

  @override
  State<PackagingInfo> createState() => _PackagingInfoState();
}

class _PackagingInfoState extends State<PackagingInfo> {
  GlobalKey returnInstructionsKey = GlobalKey();
  GlobalKey packagingDetailsKey = GlobalKey();

  @override
  void initState() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      widget.viewModel.init();
      widget.viewModel.logVisit();
    });
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(
      builder: (BuildContext context, BoxConstraints constraints) {
        return Scaffold(
            body: widget.viewModel.isLoading
                ? _buildLoading()
                : _buildContent(constraints));
      },
    );
  }

  Widget _buildContent(BoxConstraints constraints) {
    return SingleChildScrollView(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          MainSection(
            width: constraints.maxWidth,
            packagingName: widget.viewModel.packagingName,
            logo: widget.viewModel.logo,
            onReturnInstructionsPressed: () {
              Scrollable.ensureVisible(
                returnInstructionsKey.currentContext!,
                duration: const Duration(milliseconds: 400),
                curve: Curves.easeInOut,
              );
            },
            onDetailsPressed: () {
              UrlLauncherService().openLink(url: 'https://www.kvatt.com');
            },
          ),
          ReturnInstructionsSection(
            key: returnInstructionsKey,
            width: constraints.maxWidth,
            returnLocationButtonLabel:
                widget.viewModel.returnLocationButtonLabel,
            onPrintReturnLabelPressed: () =>
                widget.viewModel.onDownloadReturnLabelPressed(),
            onFindNearestReturnLocationPressed: () =>
                widget.viewModel.onFindNearestReturnLocation(),
            onDownloadReturnLabelPressed: () =>
                widget.viewModel.onDownloadReturnLabelPressed(),
          ),
          FooterSection(
            width: constraints.maxWidth,
          ),
        ],
      ),
    );
  }

  Widget _buildLoading() {
    return Container(
      color: Theme.of(context).colorScheme.surfaceColor,
      child: const Center(
        child: LoadingSpinner(),
      ),
    );
  }
}
