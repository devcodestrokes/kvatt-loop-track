import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/invite_user/invite_user_factory.dart';

class InviteUserPage extends Page {
  const InviteUserPage() : super(key: const ValueKey('InviteUserPage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => InviteUserFactory.build(),
    );
  }
}
