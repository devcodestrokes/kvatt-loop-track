import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/widgets/layouts/tabs_layout.dart';
import 'package:kvatt_app/app/pages/invite_user/invite_user_view_model.dart';
import 'package:kvatt_app/app/views/user_management/invite_user/invite_user_factory.dart';

class InviteUser extends StatelessWidget {
  final InviteUserViewModel viewModel;

  const InviteUser({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return TabsLayout(
      title: 'Invite a user',
      onBackButtonTapped: () => viewModel.onBackButtonTapped(),
      tabConfigs: [
        TabConfig(
          label: 'Invite User',
          widget: InviteUserFactory.build(),
        ),
      ],
    );
  }
}
