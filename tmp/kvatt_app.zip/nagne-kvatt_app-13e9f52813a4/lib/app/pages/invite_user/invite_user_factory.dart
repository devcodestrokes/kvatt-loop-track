import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/invite_user/invite_user.dart';
import 'package:kvatt_app/app/pages/invite_user/invite_user_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:provider/provider.dart';

class InviteUserFactory {
  static Widget build() {
    return ChangeNotifierProvider<InviteUserViewModel>(
      create: (context) {
        return InviteUserViewModel(
          uiState: Provider.of<UiState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<InviteUserViewModel>(
        builder: (context, model, child) => InviteUser(
          viewModel: model,
        ),
      ),
    );
  }
}
