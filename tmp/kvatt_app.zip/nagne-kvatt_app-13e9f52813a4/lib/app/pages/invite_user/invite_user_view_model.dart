import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/states/ui_state.dart';

class InviteUserViewModel extends ChangeNotifier {
  UiState uiState;

  InviteUserViewModel({
    required this.uiState,
  });

  onBackButtonTapped() {
    uiState.updateView(
      ViewConfig(appView: AppView.homeUsers, params: {}),
    );
  }
}
