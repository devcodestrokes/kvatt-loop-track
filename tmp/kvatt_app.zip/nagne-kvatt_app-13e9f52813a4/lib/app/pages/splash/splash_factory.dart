import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/splash/splash.dart';

class SplashFactory {
  static Widget build() {
    return const Splash();
  }
}
