import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class Splash extends StatelessWidget {
  const Splash({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.secondaryColor,
      body: Center(
        child: Image.asset(
          AssetsFactory.kvattLogoWhite,
          width: 110.0,
        ),
      ),
    );
  }
}
