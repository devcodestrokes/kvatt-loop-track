import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/splash/splash_factory.dart';

class SplashPage extends Page {
  const SplashPage() : super(key: const ValueKey('SplashPage'));
  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => SplashFactory.build(),
    );
  }
}
