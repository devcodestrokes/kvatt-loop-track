import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/routing/view_path.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/users/admin.dart';
import 'package:kvatt_app/domain/users/merchant.dart';

class HomeViewModel extends ChangeNotifier {
  AuthState authState;
  AuthManager authManager;
  UiState uiState;
  Map<String, String> params;

  HomeViewModel({
    required this.authState,
    required this.authManager,
    required this.uiState,
    required this.params,
  }) {
    if (params['view'] == ViewPath.merchantIntegrations &&
        showMerchantIntegrations) {
      onMerchantIntegrationsSelected();
    }
  }

  bool get showUsersInMenu => (authState.activeUser is Admin);
  bool get showStockManagement => (authState.activeUser is Admin);
  bool get showAdminPackagingsManagement => (authState.activeUser is Admin);
  bool get showOrdersManagement => (authState.activeUser is Admin);
  bool get showReturnLabelsManagement => (authState.activeUser is Admin);
  bool get showMerchantPackagingsManagement =>
      (authState.activeUser is Merchant);
  bool get showMerchantSettings => (authState.activeUser is Merchant);
  bool get showMerchantIntegrations => (authState.activeUser is Merchant);

  onHomeSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeDashboard,
      params: {},
    ));
    notifyListeners();
  }

  onSignOutPressed() async {
    await authManager.signOut();
  }

  //Merchant only

  onMerchantPackagingsManagementSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeMerchantPackagingsManagement,
      params: {},
    ));
  }

  onMerchantSettingsSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeMerchantSettings,
      params: {},
    ));
  }

  onMerchantIntegrationsSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeMerchantIntegrations,
      params: params,
    ));
  }

  //Admin only
  onUsersSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeUsers,
      params: {},
    ));
    notifyListeners();
  }

  onAdminPackagingsManagementSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeAdminPackagingsManagement,
      params: {},
    ));
  }

  onOrdersManagementSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeOrdersManagement,
      params: {},
    ));
  }

  onStockManagementSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeStockManagement,
      params: {},
    ));
  }

  onReturnLabelsSelected() {
    uiState.updateView(ViewConfig(
      appView: AppView.homeReturnLabelsManagement,
      params: {},
    ));
  }

  onAddUserPressed() {
    uiState.updateView(
      ViewConfig(appView: AppView.inviteUser, params: {}),
    );
    notifyListeners();
  }

  onCreatePackagingsPressed() {
    uiState.updateView(
      ViewConfig(appView: AppView.createPackagings, params: {}),
    );
    notifyListeners();
  }

  onCreateOrderPressed() {
    uiState.updateView(
      ViewConfig(appView: AppView.createOrder, params: {}),
    );
    notifyListeners();
  }
}
