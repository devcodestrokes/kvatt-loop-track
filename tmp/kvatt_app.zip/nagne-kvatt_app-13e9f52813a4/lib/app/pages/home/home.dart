import 'package:flutter/material.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/common/widgets/layouts/tabs_layout.dart';
import 'package:kvatt_app/app/common/widgets/menu/side_menu.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';
import 'package:kvatt_app/app/pages/home/home_view_model.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/views/dashboard/admin_dashboard/admin_dashboard_factory.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/merchant_dashboard_factory.dart';
import 'package:kvatt_app/app/views/dashboard/partner_dashboard/partner_dashboard_factory.dart';
import 'package:kvatt_app/app/views/merchant_integrations/merchant_integrations_factory.dart';
import 'package:kvatt_app/app/views/merchant_packagings_management/merchant_packagings_management_factory.dart';
import 'package:kvatt_app/app/views/merchant_settings/merchant_settings_factory.dart';
import 'package:kvatt_app/app/views/orders_management/orders_management_factory.dart';
import 'package:kvatt_app/app/views/admin_packagings_management/admin_packagings_management_factory.dart';
import 'package:kvatt_app/app/views/return_labels_management/return_labels_management_factory.dart';
import 'package:kvatt_app/app/views/stock_management/shipment_management/shipment_management_factory.dart';
import 'package:kvatt_app/app/views/stock_management/stock_levels/stock_levels_factory.dart';
import 'package:kvatt_app/app/views/user_management/admin_management/admin_management_factory.dart';
import 'package:kvatt_app/app/views/user_management/merchant_management/merchant_management_factory.dart';
import 'package:kvatt_app/app/views/user_management/partner_management/partner_management_factory.dart';
import 'package:kvatt_app/domain/users/admin.dart';
import 'package:kvatt_app/domain/users/merchant.dart';
import 'package:kvatt_app/domain/users/partner.dart';
import 'package:kvatt_app/domain/users/user.dart';

class Home extends StatelessWidget {
  final HomeViewModel viewModel;

  const Home({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Row(
        children: [
          Expanded(
            flex: 2,
            child: SideMenu(
              onSignOutPressed: () => viewModel.onSignOutPressed(),
              menuItems: _buildSideMenu(),
            ),
          ),
          Expanded(
            flex: 9,
            child: _buildPage(context),
          ),
        ],
      ),
    );
  }

  List<SideMenuItem> _buildSideMenu() {
    List<SideMenuItem> items = [
      SideMenuItem(
        iconPath: AssetsFactory.homeIcon,
        label: 'Home',
        isSelected:
            viewModel.uiState.currentView.appView == AppView.homeDashboard,
        onSelected: () => viewModel.onHomeSelected(),
      ),
    ];
    if (viewModel.showAdminPackagingsManagement) {
      items.add(
        SideMenuItem(
          iconPath: AssetsFactory.packagingsIcon,
          label: 'Packagings',
          isSelected: viewModel.uiState.currentView.appView ==
              AppView.homeAdminPackagingsManagement,
          onSelected: () => viewModel.onAdminPackagingsManagementSelected(),
        ),
      );
    }
    if (viewModel.showMerchantPackagingsManagement) {
      items.add(
        SideMenuItem(
          iconPath: AssetsFactory.packagingsIcon,
          label: 'Packagings',
          isSelected: viewModel.uiState.currentView.appView ==
              AppView.homeMerchantPackagingsManagement,
          onSelected: () => viewModel.onMerchantPackagingsManagementSelected(),
        ),
      );
    }
    if (viewModel.showMerchantIntegrations) {
      items.add(
        SideMenuItem(
          icon: Icons.handyman,
          label: 'Integrations',
          isSelected: viewModel.uiState.currentView.appView ==
              AppView.homeMerchantIntegrations,
          onSelected: () => viewModel.onMerchantIntegrationsSelected(),
        ),
      );
    }
    if (viewModel.showMerchantSettings) {
      items.add(
        SideMenuItem(
          icon: Icons.settings,
          label: 'Settings',
          isSelected: viewModel.uiState.currentView.appView ==
              AppView.homeMerchantSettings,
          onSelected: () => viewModel.onMerchantSettingsSelected(),
        ),
      );
    }

    if (viewModel.showOrdersManagement) {
      items.add(
        SideMenuItem(
          iconPath: AssetsFactory.ordersIcon,
          label: 'Orders',
          isSelected: viewModel.uiState.currentView.appView ==
              AppView.homeOrdersManagement,
          onSelected: () => viewModel.onOrdersManagementSelected(),
        ),
      );
    }
    if (viewModel.showStockManagement) {
      items.add(
        SideMenuItem(
          iconPath: AssetsFactory.stockIcon,
          label: 'Stock Management',
          isSelected: viewModel.uiState.currentView.appView ==
              AppView.homeStockManagement,
          onSelected: () => viewModel.onStockManagementSelected(),
        ),
      );
    }

    if (viewModel.showReturnLabelsManagement) {
      items.add(
        SideMenuItem(
          icon: Icons.label,
          label: 'Return Labels',
          isSelected: viewModel.uiState.currentView.appView ==
              AppView.homeReturnLabelsManagement,
          onSelected: () => viewModel.onReturnLabelsSelected(),
        ),
      );
    }
    if (viewModel.showUsersInMenu) {
      items.add(
        SideMenuItem(
          iconPath: AssetsFactory.peopleIcon,
          label: 'Users',
          isSelected:
              viewModel.uiState.currentView.appView == AppView.homeUsers,
          onSelected: () => viewModel.onUsersSelected(),
        ),
      );
    }

    return items;
  }

  Widget _buildPage(BuildContext context) {
    switch (viewModel.uiState.currentView.appView) {
      case AppView.homeDashboard:
        return _buildDashboard();
      case AppView.homeUsers:
        return _buildUsers();
      case AppView.homeStockManagement:
        return _buildStockManagement();
      case AppView.homeAdminPackagingsManagement:
        return _buildAdminPackagingsManagement(context);
      case AppView.homeMerchantPackagingsManagement:
        return _buildMerchantPackagingsManagement();
      case AppView.homeMerchantSettings:
        return _buildMerchantSettings();
      case AppView.homeMerchantIntegrations:
        return _buildMerchantIntegrations();
      case AppView.homeOrdersManagement:
        return _buildOrdersManagement();
      case AppView.homeReturnLabelsManagement:
        return _buildReturnLabelsManagement();
      default:
        return const SizedBox();
    }
  }

  Widget _buildDashboard() {
    User? activeUser = viewModel.authState.activeUser;
    if (activeUser is Admin) {
      return TabsLayout(
        title: 'Home',
        actionButtonLabel: 'Logout',
        tabConfigs: [
          TabConfig(
            label: 'Dashboard',
            widget: AdminDashboardFactory.build(),
          ),
        ],
      );
    }
    if (activeUser is Partner) {
      return TabsLayout(
        title: 'Home',
        actionButtonLabel: 'Logout',
        tabConfigs: [
          TabConfig(
            label: 'Dashboard',
            widget: PartnerDashboardFactory.build(),
          ),
        ],
      );
    }
    if (activeUser is Merchant) {
      return MerchantDashboardFactory.build();
    }
    return const SizedBox();
  }

  Widget _buildUsers() {
    return TabsLayout(
      title: 'Users',
      subText: 'Manage Kvatt users.',
      actionButtonLabel: 'Add new user',
      onActionButtonTapped: () => viewModel.onAddUserPressed(),
      tabConfigs: [
        TabConfig(
          label: 'Merchants',
          widget: MerchantManagementFactory.build(),
        ),
        TabConfig(
          label: 'Partners',
          widget: PartnerManagementFactory.build(),
        ),
        TabConfig(
          label: 'Admin',
          widget: AdminManagementFactory.build(),
        ),
      ],
    );
  }

  Widget _buildAdminPackagingsManagement(BuildContext context) {
    return TabsLayout(
      title: 'Packagings',
      subText: 'Manage packagings',
      actionButtonLabel: 'Generate packs and labels',
      onActionButtonTapped: () => viewModel.onCreatePackagingsPressed(),
      backgroundColor: Theme.of(context).colorScheme.surfaceColor,
      tabConfigs: [
        TabConfig(
          label: 'Packagings',
          widget: AdminPackagingsManagementFactory.build(),
        ),
      ],
    );
  }

  Widget _buildMerchantPackagingsManagement() {
    return MerchantPackagingsManagementFactory.build();
  }

  Widget _buildMerchantSettings() {
    return MerchantSettingsFactory.build();
  }

  Widget _buildMerchantIntegrations() {
    return MerchantIntegrationsFactory.build(
      params: viewModel.params,
    );
  }

  Widget _buildStockManagement() {
    return TabsLayout(
      title: 'Stock Management',
      subText: 'Manage stocks',
      tabConfigs: [
        TabConfig(
          label: 'Stock levels',
          widget: StockLevelsFactory.build(),
        ),
        TabConfig(
          label: 'Shipments',
          widget: ShipmentManagementFactory.build(),
        ),
      ],
    );
  }

  Widget _buildOrdersManagement() {
    return TabsLayout(
      title: 'Orders Management',
      subText: 'Manage orders',
      actionButtonLabel: 'Create new order',
      onActionButtonTapped: () => viewModel.onCreateOrderPressed(),
      tabConfigs: [
        TabConfig(
          label: 'Orders',
          widget: OrdersManagementFactory.build(),
        ),
      ],
    );
  }

  Widget _buildReturnLabelsManagement() {
    return TabsLayout(
      title: 'Return Labels',
      subText: 'Manage return labels',
      tabConfigs: [
        TabConfig(
          label: 'Return Labels',
          widget: ReturnLabelsManagementFactory.build(),
        ),
      ],
    );
  }
}
