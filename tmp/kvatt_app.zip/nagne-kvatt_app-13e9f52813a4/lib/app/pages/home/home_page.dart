import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/home/home_factory.dart';

class HomePage extends Page {
  final Map<String, String> params;

  const HomePage({
    required this.params,
  }) : super(key: const ValueKey('HomePage'));

  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => HomeFactory.build(
        params: params,
      ),
    );
  }
}
