import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/home/home.dart';
import 'package:kvatt_app/app/pages/home/home_view_model.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:provider/provider.dart';

class HomeFactory {
  static Widget build({
    required Map<String, String> params,
  }) {
    return ChangeNotifierProvider<HomeViewModel>(
      create: (context) {
        return HomeViewModel(
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
          authManager: Provider.of<AuthManager>(
            context,
            listen: false,
          ),
          uiState: Provider.of<UiState>(context, listen: false),
          params: params,
        );
      },
      child: Consumer<HomeViewModel>(
        builder: (context, model, child) => Home(
          viewModel: model,
        ),
      ),
    );
  }
}
