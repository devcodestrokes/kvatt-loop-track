import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_app/app/pages/sign_in/sign_in.dart';
import 'package:kvatt_app/app/pages/sign_in/sign_in_view_model.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:provider/provider.dart';

class SignInFactory {
  static Widget build({
    required Map<String, String> params,
  }) {
    return ChangeNotifierProvider<SignInViewModel>(
      create: (context) {
        return SignInViewModel(
          authManager: Provider.of<AuthManager>(context, listen: false),
          communicationsManager:
              Provider.of<CommunicationsManager>(context, listen: false),
          uiState: Provider.of<UiState>(context, listen: false),
          params: params,
        );
      },
      child: Consumer<SignInViewModel>(
        builder: (context, model, child) => SignIn(
          viewModel: model,
        ),
      ),
    );
  }
}
