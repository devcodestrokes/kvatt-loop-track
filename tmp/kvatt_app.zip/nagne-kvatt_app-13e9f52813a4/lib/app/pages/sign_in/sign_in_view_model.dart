import 'package:flutter/material.dart';
import 'package:kvatt_app/app/routing/app_view.dart';
import 'package:kvatt_app/app/routing/view_config.dart';
import 'package:kvatt_app/app/services/auth/auth_service.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';

class SignInViewModel extends ChangeNotifier {
  AuthManager authManager;
  CommunicationsManager communicationsManager;
  UiState uiState;
  Map<String, String> params;

  String? errorMessage;

  SignInViewModel({
    required this.authManager,
    required this.communicationsManager,
    required this.uiState,
    required this.params,
  });

  bool get showIntegrationConnectMessage => params['connect'] == '1';

  onSignInPressed({
    required String email,
    required String password,
  }) async {
    try {
      await authManager.signIn(
        email: email,
        password: password,
      );
      uiState.updateView(ViewConfig(
        appView: AppView.homeDashboard,
        params: params,
      ));
    } catch (e) {
      if (e is AuthInvalidCredentialsException) {
        errorMessage = 'The email/password you\'ve entered are incorrect.';
      } else {
        errorMessage =
            'There was an issue signing you in. Please try again later.';
      }
      notifyListeners();
    }
  }

  onForgotPasswordPressed() {
    uiState.updateView(ViewConfig(
      appView: AppView.resetPassword,
      params: {},
    ));
  }

  onContactSupportPressed() {
    communicationsManager.launchSupportEmail();
  }
}
