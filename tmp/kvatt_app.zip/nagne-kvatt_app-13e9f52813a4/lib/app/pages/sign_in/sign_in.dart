import 'package:flutter/material.dart';
import 'package:kvatt_app/app/common/utils/validators.dart';
import 'package:kvatt_app/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_app/app/common/widgets/buttons/prompt_text_button.dart';
import 'package:kvatt_app/app/common/widgets/form_fields/text_field_white.dart';
import 'package:kvatt_app/app/common/widgets/layouts/ride_side_layout.dart';
import 'package:kvatt_app/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_app/app/pages/sign_in/sign_in_view_model.dart';
import 'package:kvatt_app/app/extended_color_scheme.dart';

class SignIn extends StatelessWidget {
  final SignInViewModel viewModel;

  const SignIn({
    Key? key,
    required this.viewModel,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return RightSideLayout(
      widget: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Text(
            'Sign In',
            style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                ),
          ),
          viewModel.showIntegrationConnectMessage == true
              ? Column(
                  children: [
                    const SizedBox(height: 16.0),
                    Container(
                      padding:
                          const EdgeInsets.fromLTRB(12.0, 12.0, 12.0, 12.0),
                      decoration: BoxDecoration(
                        color: Theme.of(context).colorScheme.trafficLightAmber,
                        border: Border.all(
                          color:
                              Theme.of(context).colorScheme.onTrafficLightAmber,
                        ),
                        borderRadius: const BorderRadius.all(
                          Radius.circular(4.0),
                        ),
                      ),
                      child: Text(
                        'Please sign-in to complete the integration process.',
                        style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                      ),
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 60.0),
          viewModel.errorMessage != null
              ? Column(
                  children: [
                    Container(
                      color: Theme.of(context).colorScheme.trafficLightAmber,
                      padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                      child: Text(
                        viewModel.errorMessage!,
                        style: Theme.of(context).textTheme.bodySmall?.copyWith(
                              color: Theme.of(context)
                                  .colorScheme
                                  .onTrafficLightAmber,
                            ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                    const SizedBox(height: 24.0),
                  ],
                )
              : const SizedBox(),
          _SignInForm(
            emailValidator: (String? email) => Validators.validateEmail(email),
            passwordValidator: (String? password) =>
                Validators.validatePassword(password),
            onSignInPressed: (String email, String password) =>
                viewModel.onSignInPressed(
              email: email,
              password: password,
            ),
          ),
          const SizedBox(height: 60.0),
          PromptTextButton(
            promptText: 'Forgot your password?',
            actionLabel: 'Reset Password',
            onPressed: () => viewModel.onForgotPasswordPressed(),
            fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
          ),
          const SizedBox(height: 16.0),
          PromptTextButton(
            promptText: 'Having issues?',
            actionLabel: 'Contact Support',
            onPressed: () => viewModel.onContactSupportPressed(),
            fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
          ),
        ],
      ),
    );
  }
}

class _SignInForm extends StatefulWidget {
  final Function(String?) emailValidator;
  final Function(String?) passwordValidator;
  final Function(String email, String password) onSignInPressed;

  const _SignInForm({
    required this.emailValidator,
    required this.passwordValidator,
    required this.onSignInPressed,
  });

  @override
  State<_SignInForm> createState() => _SignInFormState();
}

class _SignInFormState extends State<_SignInForm> {
  TextEditingController emailTextController = TextEditingController();
  TextEditingController passwordTextController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextFieldWhite(
            validator: (String? email) => widget.emailValidator(email),
            label: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            controller: emailTextController,
          ),
          const SizedBox(height: 28.0),
          TextFieldWhite(
            validator: (String? password) => widget.passwordValidator(password),
            label: 'Password',
            keyboardType: TextInputType.text,
            controller: passwordTextController,
            obscureText: true,
          ),
          const SizedBox(height: 36.0),
          PrimaryButton(
            label: 'Sign In',
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                LoadingDialog.show(
                  context,
                  'signing in...',
                  loadingDialogMode: LoadingDialogMode.onPrimary,
                );
                await widget.onSignInPressed(
                  emailTextController.text.trim(),
                  passwordTextController.text.trim(),
                );
                if (!mounted) return;
                Navigator.of(context).pop();
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    emailTextController.dispose();
    passwordTextController.dispose();
    super.dispose();
  }
}
