import 'package:flutter/material.dart';
import 'package:kvatt_app/app/pages/sign_in/sign_in_factory.dart';

class SignInPage extends Page {
  final Map<String, String> params;

  const SignInPage({
    required this.params,
  }) : super(key: const ValueKey('SignInPage'));
  @override
  Route createRoute(BuildContext context) {
    return MaterialPageRoute(
      settings: this,
      builder: (BuildContext context) => SignInFactory.build(
        params: params,
      ),
    );
  }
}
