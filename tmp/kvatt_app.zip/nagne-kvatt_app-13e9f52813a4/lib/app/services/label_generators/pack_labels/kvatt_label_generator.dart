import 'package:flutter/services.dart';
import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/label_gamified_v1.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/label_gamified_v3_large.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/label_gamified_v3_small.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/label_simple_v1.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/label_simple_v2.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/label_simple_v3_large.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/label_simple_v3_small.dart';
import 'package:kvatt_app/app/prints/pack_labels/kvatt/minimal.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/base_label_generator.dart';
import 'package:kvatt_core/domain/labels/kvatt/kvatt_labels_config.dart';
import 'package:kvatt_core/domain/labels/label_style.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart';

import 'package:pdf/widgets.dart' as pw;

class KvattLabelGenerator extends BaseLabelGenerator {
  Config config;
  KvattLabelsConfig labelsConfig;

  KvattLabelGenerator({
    required this.config,
    required this.labelsConfig,
    required Packaging packaging,
  }) : super(packaging: packaging);

  static List<String> productsWithLargeLabels = [
    'Charlie M',
    'Charlie L',
    'Ray M',
    'Ray L'
  ];
  static List<String> productsWithSmallLabels = [
    'Charlie S',
    'Ray S',
    'Harry S',
    'Harry M',
    'Alfred M'
  ];

  pw.Page buildKvattLabels({
    required Map<String, Font> fonts,
    required Map<String, Uint8List> images,
  }) {
    double labelWidth = 0.0;
    double labelHeight = 0.0;
    Widget label;

    String url = labelsConfig.generateKvattQrCodeUrl(
      baseUrl: config.baseUrl!,
      packagingId: packaging.identifier,
      style: packaging.labelStyle,
    );

    switch (packaging.labelStyle) {
      case LabelStyle.simpleV1:
      case null:
        labelWidth = 4 * PdfPageFormat.inch;
        labelHeight = 2 * PdfPageFormat.inch;
        label = LabelSimpleV1(
            url: url, labelIdentifier: buildKvattPackagingLabelIdentifier());
        break;
      case LabelStyle.simpleV2:
        labelWidth = 4 * PdfPageFormat.inch;
        labelHeight = 2 * PdfPageFormat.inch;
        label = LabelSimpleV2(
          url: url,
          labelIdentifier: buildKvattPackagingLabelIdentifier(),
          fonts: fonts,
        );
        break;
      case LabelStyle.gamifiedV1:
        labelWidth = 4 * PdfPageFormat.inch;
        labelHeight = 2 * PdfPageFormat.inch;
        label = LabelGamifiedV1(
          url: url,
          labelIdentifier: buildKvattPackagingLabelIdentifier(),
          fonts: fonts,
        );
        break;
      case LabelStyle.simpleV3:
        if (productsWithLargeLabels.contains(packaging.type)) {
          labelWidth = 207 * PdfPageFormat.mm;
          labelHeight = 87 * PdfPageFormat.mm;
          label = LabelSimpleV3Large(
            url: url,
            labelIdentifier: buildKvattPackagingLabelIdentifier(),
            fonts: fonts,
            images: images,
          );
        } else {
          labelWidth = 152 * PdfPageFormat.mm;
          labelHeight = 72 * PdfPageFormat.mm;
          label = LabelSimpleV3Small(
            url: url,
            labelIdentifier: buildKvattPackagingLabelIdentifier(),
            fonts: fonts,
            images: images,
          );
        }
        break;
      case LabelStyle.gamifiedV3:
        if (productsWithLargeLabels.contains(packaging.type)) {
          labelWidth = 207 * PdfPageFormat.mm;
          labelHeight = 87 * PdfPageFormat.mm;
          label = LabelGamifiedV3Large(
            url: url,
            labelIdentifier: buildKvattPackagingLabelIdentifier(),
            fonts: fonts,
            images: images,
          );
        } else {
          labelWidth = 152 * PdfPageFormat.mm;
          labelHeight = 72 * PdfPageFormat.mm;
          label = LabelGamifiedV3Small(
            url: url,
            labelIdentifier: buildKvattPackagingLabelIdentifier(),
            fonts: fonts,
            images: images,
          );
        }
        break;
      case LabelStyle.minimal:
        labelWidth = 28 * PdfPageFormat.mm;
        labelHeight = 30 * PdfPageFormat.mm;
        label = Minimal(
          url: url,
          labelIdentifier: buildKvattPackagingLabelIdentifier(),
        );
        break;
      default:
        return pw.Page(
          pageFormat: PdfPageFormat(labelWidth, labelHeight),
          build: (pw.Context context) {
            return pw.Container();
          },
        );
    }

    return pw.Page(
      pageFormat: PdfPageFormat(labelWidth, labelHeight),
      build: (pw.Context context) {
        return label;
      },
    );
  }
}
