import 'package:flutter/services.dart';
import 'package:kvatt_app/app/prints/pack_labels/custom/goliath/label_goliath_back.dart';
import 'package:kvatt_app/app/prints/pack_labels/custom/goliath/label_goliath_front.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/base_label_generator.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/custom_label_configs.dart';
import 'package:kvatt_core/domain/labels/label_style.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class CustomLabelGenerator extends BaseLabelGenerator {
  CustomLabelGenerator({
    required Packaging packaging,
  }) : super(packaging: packaging);

  List<pw.Page> buildCustomLabels({
    required Map<String, Font> fonts,
    required Map<String, Uint8List> images,
  }) {
    switch (packaging.labelStyle) {
      case LabelStyle.customGoliathFR:
        return _buildGoliathLabels(
          lang: 'FR',
          fonts: fonts,
          images: images,
        );
      case LabelStyle.customGoliathEN:
        return _buildGoliathLabels(
          lang: 'EN',
          fonts: fonts,
          images: images,
        );
      default:
        return [];
    }
  }

  List<pw.Page> _buildGoliathLabels({
    required String lang,
    required Map<String, Font> fonts,
    required Map<String, Uint8List> images,
  }) {
    return [
      //Front label
      pw.Page(
        pageFormat: const PdfPageFormat(
          140.0 * PdfPageFormat.mm,
          210.0 * PdfPageFormat.mm,
        ),
        build: (pw.Context context) {
          return LabelGoliathFront(
            qrCodeUrl: lang == 'FR'
                ? CustomLabelConfigs.goliathQrCodeUrlFR
                : CustomLabelConfigs.goliathQrCodeUrlEN,
            kvattCode: buildKvattPackagingLabelIdentifier(),
            lang: lang,
            fonts: fonts,
            images: images,
          );
        },
      ),
      //Back label
      pw.Page(
        pageFormat: const PdfPageFormat(
          140.0 * PdfPageFormat.mm,
          55.0 * PdfPageFormat.mm,
        ),
        build: (pw.Context context) {
          return LabelGoliathBack(
            customCode: packaging.customId ?? '',
            fonts: fonts,
            images: images,
          );
        },
      ),
    ];
  }
}
