import 'package:flutter/services.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/services/downloads/downloader_service.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/custom_label_generator.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/kvatt_label_generator.dart';
import 'package:kvatt_core/domain/labels/kvatt/kvatt_labels_config.dart';
import 'package:kvatt_core/domain/labels/label_style.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:pdf/widgets.dart';

class PackLabelGenerationService {
  Config config;
  KvattLabelsConfig kvattLabelsConfig;
  DownloaderService downloaderService;

  PackLabelGenerationService({
    required this.config,
    required this.kvattLabelsConfig,
    required this.downloaderService,
  });

  Future<void> generateAndDownloadLabels({
    required List<Packaging> packagings,
  }) async {
    Uint8List pdfData = await _generatePdfWithLabels(
      packagings,
    );
    downloaderService.downloadFile(
      data: pdfData,
      name: 'labels.pdf',
    );
  }

  Future<Uint8List> _generatePdfWithLabels(
    List<Packaging> packagings,
  ) async {
    Document pdf = pw.Document();

    Map<String, Font> fonts = await _loadFonts();
    Map<String, Uint8List> images = await _loadImages(pdf);

    for (var i = 0; i < packagings.length; i++) {
      List<pw.Page> pages = _buildLabels(
        packaging: packagings[i],
        fonts: fonts,
        images: images,
      );
      for (var page in pages) {
        pdf.addPage(page);
      }
    }
    return await pdf.save();
  }

  List<pw.Page> _buildLabels({
    required Packaging packaging,
    required Map<String, Font> fonts,
    required Map<String, Uint8List> images,
  }) {
    switch (packaging.labelStyle) {
      case LabelStyle.simpleV1:
      case LabelStyle.simpleV2:
      case LabelStyle.simpleV3:
      case LabelStyle.gamifiedV1:
      case LabelStyle.gamifiedV3:
      case LabelStyle.minimal:
      case null:
        KvattLabelGenerator generator = KvattLabelGenerator(
          config: config,
          labelsConfig: kvattLabelsConfig,
          packaging: packaging,
        );
        return [
          generator.buildKvattLabels(
            fonts: fonts,
            images: images,
          )
        ];
      case LabelStyle.customGoliathFR:
      case LabelStyle.customGoliathEN:
        CustomLabelGenerator generator = CustomLabelGenerator(
          packaging: packaging,
        );
        return generator.buildCustomLabels(
          fonts: fonts,
          images: images,
        );
      default:
        return [];
    }
  }

  Future<Map<String, Font>> _loadFonts() async {
    ByteData data =
        await rootBundle.load('assets/label_fonts/HelveticaNeueLight.ttf');
    Font helveticaNeueLight = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueRegular.ttf');
    Font helveticaNeueRegular = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueMedium.ttf');
    Font helveticaNeueMedium = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueBold.ttf');
    Font helveticaNeueBold = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/DINAlternateBold.ttf');
    Font dinAlternateBold = pw.Font.ttf(data);
    data =
        await rootBundle.load('assets/label_fonts/PermanentMarkerRegular.ttf');
    Font permanentMarker = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/MavenProSemiBold.ttf');
    Font mavenProSemiBold = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/MavenProRegular.ttf');
    Font mavenProRegular = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/RobotoRegular.ttf');
    Font robotoRegular = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/SwitzerlandBlack.ttf');
    Font switzerlandBlack = pw.Font.ttf(data);

    return {
      'helveticaNeueLight': helveticaNeueLight,
      'helveticaNeueRegular': helveticaNeueRegular,
      'helveticaNeueMedium': helveticaNeueMedium,
      'helveticaNeueBold': helveticaNeueBold,
      'dinAlternateBold': dinAlternateBold,
      'permanentMarker': permanentMarker,
      'mavenProSemiBold': mavenProSemiBold,
      'mavenProRegular': mavenProRegular,
      'robotoRegular': robotoRegular,
      'switzerlandBlack': switzerlandBlack,
    };
  }

  Future<Map<String, Uint8List>> _loadImages(Document pdf) async {
    List<String> imagesToLoad = [
      AssetsFactory.kvattLogoBlack,
      AssetsFactory.labelLeftPointer,
      AssetsFactory.amazonSmileLogo,
      AssetsFactory.emballageReemployable,
      AssetsFactory.pvcLogo,
      AssetsFactory.recyclingLogo,
    ];

    Map<String, Uint8List> images = {};

    for (int i = 0; i < imagesToLoad.length; i++) {
      ByteData bytes = await rootBundle.load(
        imagesToLoad[i],
      );
      Uint8List logobytes = bytes.buffer.asUint8List();
      images[imagesToLoad[i]] = logobytes;
    }

    return images;
  }
}
