class CustomLabelConfigs {
  static const String goliathQrCodeUrlFR =
      'https://www.amazon.fr/b?node=67634719031';
  static const String goliathQrCodeUrlEN =
      'https://www.amazon.co.uk/b?node=67634722031';
}
