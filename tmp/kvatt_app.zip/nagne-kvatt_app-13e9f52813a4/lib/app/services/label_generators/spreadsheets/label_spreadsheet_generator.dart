import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/services/csv/csv_service.dart';
import 'package:kvatt_app/app/services/downloads/downloader_service.dart';
import 'package:kvatt_core/domain/labels/kvatt/kvatt_labels_config.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';

class LabelSpreadsheetGenerator {
  Config config;
  KvattLabelsConfig labelsConfig;
  CSVService csvService;
  DownloaderService downloaderService;

  LabelSpreadsheetGenerator({
    required this.config,
    required this.labelsConfig,
    required this.csvService,
    required this.downloaderService,
  });

  //TODO: Refactor this as duplicated in BaseLabelGenerator
  String _buildKvattPackagingLabelIdentifier({
    required Packaging packaging,
  }) {
    String labelIdentifier = 'KV-';
    switch (packaging.manufacturer) {
      case 'Minerva Loose Leaf':
        labelIdentifier += 'MV-';
        break;
      case 'Nargul Canta':
        labelIdentifier += 'NC-';
        break;
      case 'FCM Plast':
        labelIdentifier += 'FP-';
        break;
      default:
        break;
    }

    switch (packaging.type) {
      case 'Ray S':
        labelIdentifier += 'RS';
        break;
      case 'Ray M':
        labelIdentifier += 'RM';
        break;
      case 'Ray L':
        labelIdentifier += 'RL';
        break;
      case 'Charlie S':
        labelIdentifier += 'CS';
        break;
      case 'Charlie M':
        labelIdentifier += 'CM';
        break;
      case 'Charlie L':
        labelIdentifier += 'CL';
        break;
      case 'Charlie A2':
        labelIdentifier += 'CA2';
        break;
      case 'Charlie A3':
        labelIdentifier += 'CA3';
        break;
      case 'Harry S':
        labelIdentifier += 'HS';
        break;
      case 'Harry M':
        labelIdentifier += 'HM';
        break;
      case 'Alfred M':
        labelIdentifier += 'AM';
        break;
      default:
        break;
    }

    labelIdentifier += '-${packaging.code.toString().padLeft(5, '0')}';

    return labelIdentifier;
  }

  generateLabelsSpreadsheet({
    required List<Packaging> packs,
  }) {
    List<List<dynamic>> rows = [
      [
        'QR CODE',
        'ID NUMBER',
        'COPY',
      ]
    ];

    for (var pack in packs) {
      rows.add([
        labelsConfig.generateKvattQrCodeUrl(
          baseUrl: config.baseUrl!,
          packagingId: pack.identifier,
          style: pack.labelStyle,
        ),
        _buildKvattPackagingLabelIdentifier(packaging: pack),
        '1',
      ]);
    }

    String csvOutput = csvService.generateCsv(rows: rows);

    downloaderService.downloadFile(
      data: csvOutput.codeUnits,
      name: '${DateTime.now()}-kvatt-labels-spreadsheet.csv',
    );
  }
}
