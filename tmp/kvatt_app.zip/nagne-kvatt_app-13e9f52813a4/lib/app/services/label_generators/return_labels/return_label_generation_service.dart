import 'package:flutter/services.dart';
import 'package:kvatt_app/app/assets_factory.dart';
import 'package:kvatt_app/app/prints/return_labels/laposte/label_laposte.dart';
import 'package:kvatt_app/app/prints/return_labels/return_label_leaflet.dart';
import 'package:kvatt_app/app/services/downloads/downloader_service.dart';
import 'package:kvatt_app/app/services/label_generators/return_labels/return_label_configs.dart';
import 'package:kvatt_core/domain/return_labels/la_poste/la_poste_smart_data.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart';
import 'package:pdf/widgets.dart' as pw;

class ReturnLabelGenerationService {
  DownloaderService downloaderService;

  ReturnLabelGenerationService({
    required this.downloaderService,
  });

  Future<void> buildAndDownloadGoliathReturnLabels({
    required List<LaPosteSmartData> smartDataDefinitions,
  }) async {
    Document pdf = pw.Document();
    Map<String, Font> fonts = await _loadFonts();
    Map<String, Uint8List> images = await _loadImages(pdf);

    for (var i = 0; i < smartDataDefinitions.length; i++) {
      pw.Page page = pw.Page(
        pageFormat: const PdfPageFormat(
          297.0 * PdfPageFormat.mm,
          210.0 * PdfPageFormat.mm,
        ),
        build: (pw.Context context) {
          return ReturnLabelLeaflet(
            qrCodeUrl: ReturnLabelConfigs.goliathQrCodeUrlFR,
            label: LabelLaPoste(
              base64DatamatrixImage: smartDataDefinitions[i].datamatrixImage,
              smartCodeLabel: smartDataDefinitions[i].label,
              fonts: fonts,
              images: images,
            ),
            fonts: fonts,
            images: images,
          );
        },
      );
      pdf.addPage(page);
    }

    Uint8List pdfData = await pdf.save();
    downloaderService.downloadFile(
      data: pdfData,
      name: 'return-labels.pdf',
    );
  }

  Future<Map<String, Font>> _loadFonts() async {
    ByteData data =
        await rootBundle.load('assets/label_fonts/RobotoRegular.ttf');
    Font robotoRegular = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueRegular.ttf');
    Font helveticaNeueRegular = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueMedium.ttf');
    Font helveticaNeueMedium = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueLight.ttf');
    Font helveticaNeueLight = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueItalic.ttf');
    Font helveticaNeueItalic = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueBold.ttf');
    Font helveticaNeueBold = pw.Font.ttf(data);
    data = await rootBundle.load('assets/label_fonts/HelveticaNeueThin.ttf');
    Font helveticaNeueThin = pw.Font.ttf(data);
    data =
        await rootBundle.load('assets/label_fonts/PermanentMarkerRegular.ttf');
    Font permanentMarker = pw.Font.ttf(data);
    return {
      'robotoRegular': robotoRegular,
      'helveticaNeueRegular': helveticaNeueRegular,
      'helveticaNeueMedium': helveticaNeueMedium,
      'helveticaNeueLight': helveticaNeueLight,
      'helveticaNeueItalic': helveticaNeueItalic,
      'helveticaNeueThin': helveticaNeueThin,
      'helveticaNeueBold': helveticaNeueBold,
      'permanentMarker': permanentMarker,
    };
  }

  Future<Map<String, Uint8List>> _loadImages(Document pdf) async {
    List<String> imagesToLoad = [
      AssetsFactory.labelRightPointer,
      AssetsFactory.laPosteLabelTemplate,
    ];

    Map<String, Uint8List> images = {};

    for (int i = 0; i < imagesToLoad.length; i++) {
      ByteData bytes = await rootBundle.load(
        imagesToLoad[i],
      );
      Uint8List logobytes = bytes.buffer.asUint8List();
      images[imagesToLoad[i]] = logobytes;
    }

    return images;
  }
}
