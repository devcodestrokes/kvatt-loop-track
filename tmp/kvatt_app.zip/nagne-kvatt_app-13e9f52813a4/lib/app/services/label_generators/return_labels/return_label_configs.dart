class ReturnLabelConfigs {
  static const String goliathQrCodeUrlFR =
      'https://www.amazon.fr/b?node=67634719031';
}
