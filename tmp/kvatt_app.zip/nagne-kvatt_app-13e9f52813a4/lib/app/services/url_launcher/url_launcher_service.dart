import 'package:url_launcher/url_launcher.dart';

class UrlLauncherService {
  openLink({
    required String url,
    bool? inSameTab = false,
  }) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(
      uri,
      webOnlyWindowName: inSameTab == true ? '_self' : '_blank',
    )) throw 'Could not launch $url';
  }
}
