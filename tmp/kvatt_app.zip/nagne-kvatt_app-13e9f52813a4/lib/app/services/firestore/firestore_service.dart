import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:kvatt_core/data/base/db/db_interface.dart';
import 'package:kvatt_core/data/base/db/document_data.dart';

class FirestoreService implements DbInterface {
  FirebaseFirestore firestore = FirebaseFirestore.instance;

  @override
  Future<String> createDocument({
    required String collectionPath,
    required Map<String, dynamic> data,
  }) async {
    DocumentReference<Map<String, dynamic>> doc =
        await firestore.collection(collectionPath).add(data);
    return doc.id;
  }

  @override
  Future<void> updateDocument({
    required String documentPath,
    required Map<String, dynamic> data,
  }) async {
    await firestore.doc(documentPath).set(
          data,
          SetOptions(
            merge: true,
          ),
        );
  }

  @override
  Future<void> deleteDocument({
    required String documentPath,
  }) async {
    await firestore.doc(documentPath).delete();
  }

  @override
  Future<DocumentData?> retrieveDocument({
    required String documentPath,
  }) async {
    DocumentSnapshot<Map<String, dynamic>> doc =
        await firestore.doc(documentPath).get();
    if (doc.exists == false) return null;
    return DocumentData(
      id: doc.id,
      data: doc.data() ?? {},
    );
  }

  @override
  Future<List<DocumentData>> retrieveCollectionGroupDocuments({
    required String collectionGroupName,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
    List<String>? fieldNamesGreaterThanOrEqualTo,
    List<dynamic>? targetValuesGreaterThanOrEqualTo,
    List<String>? fieldNamesLessThanOrEqualTo,
    List<dynamic>? targetValuesLessThanOrEqualTo,
  }) async {
    Query<Map<String, dynamic>> query =
        firestore.collectionGroup(collectionGroupName);

    if (_hasFilters(fieldNamesEqual, targetValuesEqual)) {
      for (var i = 0; i < fieldNamesEqual!.length; i++) {
        query = query.where(
          fieldNamesEqual[i],
          isEqualTo: targetValuesEqual![i],
        );
      }
    }

    if (_hasFilters(
        fieldNamesGreaterThanOrEqualTo, targetValuesGreaterThanOrEqualTo)) {
      for (var i = 0; i < fieldNamesGreaterThanOrEqualTo!.length; i++) {
        query = query.where(
          fieldNamesGreaterThanOrEqualTo[i],
          isGreaterThanOrEqualTo: targetValuesGreaterThanOrEqualTo![i],
        );
      }
    }

    if (_hasFilters(
        fieldNamesLessThanOrEqualTo, targetValuesLessThanOrEqualTo)) {
      for (var i = 0; i < fieldNamesLessThanOrEqualTo!.length; i++) {
        query = query.where(
          fieldNamesLessThanOrEqualTo[i],
          isLessThanOrEqualTo: targetValuesLessThanOrEqualTo![i],
        );
      }
    }

    QuerySnapshot<Map<String, dynamic>> snap = await query.get();
    return snap.docs
        .map(
          (d) => DocumentData(
            id: d.id,
            data: d.data(),
            parentId: d.reference.parent.parent?.id,
          ),
        )
        .toList();
  }

  @override
  Future<List<DocumentData>> retrieveDocuments({
    required String collectionPath,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
    List<String>? fieldNamesGreaterThan,
    List<dynamic>? targetValuesGreaterThan,
    List<String>? fieldNamesNotNull,
    String? orderByField,
    bool? orderDescending,
    int? limit,
    int? startAt,
  }) async {
    Query<Map<String, dynamic>> query = firestore.collection(collectionPath);
    if (_hasFilters(fieldNamesEqual, targetValuesEqual)) {
      for (var i = 0; i < fieldNamesEqual!.length; i++) {
        query =
            query.where(fieldNamesEqual[i], isEqualTo: targetValuesEqual![i]);
      }
    }

    if (_hasFilters(fieldNamesGreaterThan, targetValuesGreaterThan)) {
      for (var i = 0; i < fieldNamesGreaterThan!.length; i++) {
        query = query.where(fieldNamesGreaterThan[i],
            isGreaterThan: targetValuesGreaterThan![i]);
        query = query.orderBy(fieldNamesGreaterThan[i]);
      }
    }

    if (fieldNamesNotNull != null) {
      for (var i = 0; i < fieldNamesNotNull.length; i++) {
        query = query.orderBy(
          fieldNamesNotNull[i],
          descending: false,
        );
        query = query.where(
          fieldNamesNotNull[i],
          isNotEqualTo: null,
        );
      }
    }

    if (orderByField != null) {
      query = query.orderBy(
        orderByField,
        descending: orderDescending ?? false,
      );
    }

    if (limit != null) {
      query = query.limit(limit);
    }

    if (startAt != null) {
      query = query.startAt([startAt]);
    }

    QuerySnapshot<Map<String, dynamic>> snap = await query.get();
    return snap.docs
        .map((d) => DocumentData(id: d.id, data: d.data()))
        .toList();
  }

  @override
  Future<int> countCollectionGroupDocuments({
    required String collectionGroupName,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
  }) async {
    Query<Map<String, dynamic>> query =
        firestore.collectionGroup(collectionGroupName);
    if (_hasFilters(fieldNamesEqual, targetValuesEqual)) {
      for (var i = 0; i < fieldNamesEqual!.length; i++) {
        query =
            query.where(fieldNamesEqual[i], isEqualTo: targetValuesEqual![i]);
      }
    }

    AggregateQuerySnapshot snap = await query.count().get();
    return snap.count == null ? 0 : snap.count!;
  }

  @override
  Future<int> countDocuments({
    required String collectionPath,
    List<String>? fieldNamesEqual,
    List<dynamic>? targetValuesEqual,
    List<String>? fieldNamesNotNull,
    List<String>? fieldNamesGreaterThan,
    List<dynamic>? targetValuesGreaterThan,
  }) async {
    Query<Map<String, dynamic>> query = firestore.collection(collectionPath);
    if (_hasFilters(fieldNamesEqual, targetValuesEqual)) {
      for (var i = 0; i < fieldNamesEqual!.length; i++) {
        query =
            query.where(fieldNamesEqual[i], isEqualTo: targetValuesEqual![i]);
      }
    }

    if (_hasFilters(fieldNamesGreaterThan, targetValuesGreaterThan)) {
      for (var i = 0; i < fieldNamesGreaterThan!.length; i++) {
        query = query.where(fieldNamesGreaterThan[i],
            isGreaterThan: targetValuesGreaterThan![i]);
        query = query.orderBy(fieldNamesGreaterThan[i]);
      }
    }

    if (fieldNamesNotNull != null) {
      for (var i = 0; i < fieldNamesNotNull.length; i++) {
        query = query.orderBy(
          fieldNamesNotNull[i],
          descending: false,
        );
        query = query.where(
          fieldNamesNotNull[i],
          isNotEqualTo: null,
        );
      }
    }

    AggregateQuerySnapshot snap = await query.count().get();
    return snap.count == null ? 0 : snap.count!;
  }

  @override
  Stream<List<DocumentData>> documents({
    required String collectionPath,
    List<String>? fieldNames,
    List<String>? targetValues,
  }) {
    Query<Map<String, dynamic>> query = firestore.collection(collectionPath);
    if (_hasFilters(fieldNames, targetValues)) {
      for (var i = 0; i < fieldNames!.length; i++) {
        query = query.where(fieldNames[i], isEqualTo: targetValues![i]);
      }
    }

    return query.snapshots().map((QuerySnapshot<Map<String, dynamic>> snap) {
      return snap.docs
          .map((d) => DocumentData(id: d.id, data: d.data()))
          .toList();
    });
  }

  @override
  Stream<DocumentData?> document({
    required String documentPath,
  }) {
    return firestore
        .doc(documentPath)
        .snapshots()
        .map((DocumentSnapshot<Map<String, dynamic>> doc) {
      if (doc.data() == null) return null;
      return DocumentData(id: doc.id, data: doc.data()!);
    });
  }

  bool _hasFilters(
    List<String>? fieldNames,
    List<dynamic>? targetValues,
  ) {
    return fieldNames != null &&
        targetValues != null &&
        fieldNames.length == targetValues.length &&
        fieldNames.isNotEmpty;
  }
}
