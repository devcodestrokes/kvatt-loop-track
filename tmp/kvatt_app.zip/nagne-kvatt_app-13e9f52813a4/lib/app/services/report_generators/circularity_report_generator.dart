import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kvatt_app/app/services/downloads/downloader_service.dart';
import 'package:kvatt_app/app/views/dashboard/merchant_dashboard/widgets/return_info_card.dart';
import 'package:pdf/pdf.dart';

import 'package:pdf/widgets.dart' as pw;
import 'package:screenshot/screenshot.dart';

class CircularityReportGenerator {
  DownloaderService downloaderService;

  CircularityReportGenerator({
    required this.downloaderService,
  });

  Future<void> generateAndDownloadCircularityReport({
    required String? comment,
  }) async {
    pw.Document pdf = pw.Document();

    ScreenshotController screenshotController = ScreenshotController();
    Uint8List? image;
    image = await screenshotController.captureFromWidget(
      MediaQuery(
        data: const MediaQueryData(),
        child: Material(
          child: SizedBox(
            width: 500.0,
            height: 250.0,
            child: ReturnInfoCard(
              onTooltipTapped: () {},
              numReturned: 12,
              numPending: 2,
              numLost: 6,
              returnRatePercentage: 60,
              maxReturnDays: 43,
              minReturnDays: 3,
              averageReturnDays: 21,
            ),
          ),
        ),
      ),
    );

    pdf.addPage(
      pw.Page(
        pageFormat: PdfPageFormat.a4,
        build: (pw.Context context) {
          return pw.Column(
            children: [
              pw.Container(
                child: pw.Image(
                  pw.MemoryImage(image!),
                ),
              ),
              pw.SizedBox(height: 20.0),
              pw.Text('Comments'),
              pw.SizedBox(height: 20.0),
              pw.Text(comment ?? ''),
            ],
          );
        },
      ),
    );

    Uint8List pdfData = await pdf.save();
    downloaderService.downloadFile(
      data: pdfData,
      name: 'report.pdf',
    );
  }
}
