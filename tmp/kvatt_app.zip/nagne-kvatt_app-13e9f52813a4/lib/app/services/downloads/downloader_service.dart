import 'dart:convert';
// ignore: avoid_web_libraries_in_flutter
import 'dart:html';

class DownloaderService {
  void downloadFile({
    required List<int> data,
    required String name,
  }) {
    final base64 = base64Encode(data);
    final anchor =
        AnchorElement(href: 'data:application/octet-stream;base64,$base64')
          ..target = 'blank';
    anchor.download = name;
    document.body!.append(anchor);
    anchor.click();
    anchor.remove();
  }
}
