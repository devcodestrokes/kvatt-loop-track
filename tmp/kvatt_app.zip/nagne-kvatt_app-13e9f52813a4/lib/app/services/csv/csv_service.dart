import 'package:csv/csv.dart';

class CSVService {
  String generateCsv({
    required List<List<dynamic>> rows,
  }) {
    return const ListToCsvConverter().convert(rows);
  }
}
