import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_app/app/configs/config.dart';
import 'package:kvatt_app/app/configs/config_factory.dart';
import 'package:kvatt_app/app/data/analytics/analytics_repository.dart';
import 'package:kvatt_app/app/data/merchant_settings/merchant_settings_repository.dart';
import 'package:kvatt_app/app/data/orders/order_repository.dart';
import 'package:kvatt_app/app/data/shipments/shipment_repository.dart';
import 'package:kvatt_app/app/data/users/user_repository.dart';
import 'package:kvatt_app/app/services/label_generators/return_labels/return_label_generation_service.dart';
import 'package:kvatt_app/app/services/auth/auth_service.dart';
import 'package:kvatt_app/app/services/cloud_functions/cloud_functions_service.dart';
import 'package:kvatt_app/app/services/csv/csv_service.dart';
import 'package:kvatt_app/app/services/downloads/downloader_service.dart';
import 'package:kvatt_app/app/services/firestore/firestore_service.dart';
import 'package:kvatt_app/app/services/label_generators/pack_labels/pack_label_generation_service.dart';
import 'package:kvatt_app/app/services/label_generators/spreadsheets/label_spreadsheet_generator.dart';
import 'package:kvatt_app/app/services/url_launcher/url_launcher_service.dart';
import 'package:kvatt_app/app/states/auth_state.dart';
import 'package:kvatt_app/app/states/ui_state.dart';
import 'package:kvatt_app/domain/analytics/analytics_manager.dart';
import 'package:kvatt_app/domain/analytics/analytics_repository_interface.dart';
import 'package:kvatt_app/domain/auth/auth_manager.dart';
import 'package:kvatt_app/domain/communications/communications_manager.dart';
import 'package:kvatt_app/domain/merchant_settings/merchant_settings_manager.dart';
import 'package:kvatt_app/domain/merchant_settings/merchant_settings_repository_interface.dart';
import 'package:kvatt_app/domain/orders/order_manager.dart';
import 'package:kvatt_app/domain/orders/order_repository_interface.dart';
import 'package:kvatt_app/domain/reporting/reporting_manager.dart';
import 'package:kvatt_app/domain/shipments/shipment_manager.dart';
import 'package:kvatt_app/domain/shipments/shipment_repository_interface.dart';
import 'package:kvatt_app/domain/users/user_manager.dart';
import 'package:kvatt_app/domain/users/user_repository_interface.dart';
import 'package:kvatt_core/data/insights/insights_repository.dart';
import 'package:kvatt_core/data/landing_page/landing_page_configs_repository.dart';
import 'package:kvatt_core/data/packaging_shipments/packaging_shipments_repository.dart';
import 'package:kvatt_core/data/packagings/packagings_repository.dart';
import 'package:kvatt_core/data/reporting/circularity_repository.dart';
import 'package:kvatt_core/data/return_labels/return_labels_repository.dart';
import 'package:kvatt_core/data/shopify/shopify_order_fulfillments_repository.dart';
import 'package:kvatt_core/data/stocks/stock_repository.dart';
import 'package:kvatt_core/data/tracking/tracking_counters_repository.dart';
import 'package:kvatt_core/data/tracking/tracking_history_repository.dart';
import 'package:kvatt_core/domain/insights/insights_manager.dart';
import 'package:kvatt_core/domain/insights/insights_repository_interface.dart';
import 'package:kvatt_core/domain/labels/custom/goliath_labels_config.dart';
import 'package:kvatt_core/domain/labels/kvatt/kvatt_labels_config.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_configs_repository_interface.dart';
import 'package:kvatt_core/domain/landing_page/landing_page_manager.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_manager.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_repository_interface.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:kvatt_core/domain/packagings/packagings_repository_interface.dart';
import 'package:kvatt_core/domain/reporting/circularity_manager.dart';
import 'package:kvatt_core/domain/reporting/circularity_repository_interface.dart';
import 'package:kvatt_core/domain/return_labels/return_labels_manager.dart';
import 'package:kvatt_core/domain/return_labels/return_labels_repository_interface.dart';
import 'package:kvatt_core/domain/shopify/shopify_manager.dart';
import 'package:kvatt_core/domain/shopify/shopify_order_fulfillments_repository_interface.dart';
import 'package:kvatt_core/domain/stocks/stock_repository_interface.dart';
import 'package:kvatt_core/domain/stocks/stocks_manager.dart';
import 'package:kvatt_core/domain/tracking/tracking_counters_repository_interface.dart';
import 'package:kvatt_core/domain/tracking/tracking_history_repository_interface.dart';
import 'package:kvatt_core/domain/tracking/tracking_manager.dart';
import 'package:provider/provider.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:sentry_flutter/sentry_flutter.dart';
import 'package:url_strategy/url_strategy.dart';

import 'app/app.dart';

//TODO: (MEDIUM) After adding a user, navigate back to the correct tab for that user

//TODO: (LOW) Prevent navigating directly to email sent page
//TODO: (LOW) Show date/time of last invite sent
//TODO: (LOW) Refactor input stock levels form as file too big

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  setPathUrlStrategy();
  const String env = String.fromEnvironment('env');
  Config config = ConfigFactory.getConfig(env);

  await Firebase.initializeApp(
    options: config.firebaseConfigs,
  );

  AuthService authService = AuthService();
  FirestoreService firestoreService = FirestoreService();
  CloudFunctionService cloudFunctionService = CloudFunctionService();
  UrlLauncherService urlLauncherService = UrlLauncherService();
  DownloaderService downloaderService = DownloaderService();
  CSVService csvService = CSVService();

  KvattLabelsConfig kvattLabelsConfig = KvattLabelsConfig();
  GoliathLabelsConfig goliathLabelsConfig = GoliathLabelsConfig();

  PackLabelGenerationService packagingLabelGenerationService =
      PackLabelGenerationService(
    config: config,
    kvattLabelsConfig: kvattLabelsConfig,
    downloaderService: downloaderService,
  );

  LabelSpreadsheetGenerator labelSpreadsheetGenerator =
      LabelSpreadsheetGenerator(
    config: config,
    labelsConfig: kvattLabelsConfig,
    csvService: csvService,
    downloaderService: downloaderService,
  );

  ReturnLabelGenerationService returnLabelGenerationService =
      ReturnLabelGenerationService(
    downloaderService: downloaderService,
  );

  UserRepositoryInterface userRepository =
      UserRepository(firestoreService: firestoreService);

  StocksRepositoryInterface stocksRepository =
      StocksRepository(db: firestoreService);

  InsightsRepositoryInterface insightsRepository = InsightsRepository(
    db: firestoreService,
    callable: cloudFunctionService,
    region: config.cloudFunctionRegion!,
  );

  OrderRepositoryInterface orderRepository = OrderRepository(
    firestoreService: firestoreService,
  );

  ShipmentRepositoryInterface shipmentRepository = ShipmentRepository(
    firestoreService: firestoreService,
  );

  PackagingsRepositoryInterface packagingsRepository = PackagingsRepository(
    db: firestoreService,
  );

  PackagingShipmentsRepositoryInterface packagingShipmentsRepository =
      PackagingShipmentsRepository(
    db: firestoreService,
  );

  TrackingHistoryRepositoryInterface trackingHistoryRepository =
      TrackingHistoryRepository(
    db: firestoreService,
  );

  AnalyticsRepositoryInterface analyticsRepository = AnalyticsRepository(
    firestoreService: firestoreService,
  );

  ReturnLabelsRepositoryInterface returnLabelsRepository =
      ReturnLabelsRepository(
    callable: cloudFunctionService,
    region: config.cloudFunctionRegion!,
  );

  ShopifyOrderFulfillmentsRepositoryInterface shopifyOrderFulfillmentRepo =
      ShopifyOrderFulfillmentsRepository(
    db: firestoreService,
  );

  LandingPageConfigsRepositoryInterface landingPageConfigsRepository =
      LandingPageConfigsRepository(
    db: firestoreService,
  );

  MerchantSettingsRepositoryInterface merchantSettingsRepository =
      MerchantSettingsRepository(
    db: firestoreService,
  );

  TrackingCountersRepositoryInterface trackingCountersRepository =
      TrackingCountersRepository(
    db: firestoreService,
  );

  CircularityRepositoryInterface circularityRepo = CircularityRepository(
    callable: cloudFunctionService,
    region: config.cloudFunctionRegion!,
  );

  OrderManager orderManager = OrderManager(
    cloudFunctionService: cloudFunctionService,
    orderRepo: orderRepository,
    config: config,
  );

  ShipmentManager shipmentManager = ShipmentManager(
    shipmentRepo: shipmentRepository,
  );

  PackagingShipmentsManager packagingShipmentsManager =
      PackagingShipmentsManager(
    packagingShipmentsRepository: packagingShipmentsRepository,
  );

  PackagingsManager packagingsManager = PackagingsManager(
    packagingsRepo: packagingsRepository,
    trackingHistoryRepo: trackingHistoryRepository,
    packagingShipmentsManager: packagingShipmentsManager,
    kvattLabelsConfig: kvattLabelsConfig,
    goliathLabelsConfig: goliathLabelsConfig,
    cloudFunctionCallable: cloudFunctionService,
  );

  StocksManager stocksManager = StocksManager(
    stocksRepository: stocksRepository,
    packagingsManager: packagingsManager,
  );

  UserManager userManager = UserManager(
    userRepo: userRepository,
    authService: authService,
    stocksManager: stocksManager,
    cloudFunctionService: cloudFunctionService,
    config: config,
  );

  TrackingManager trackingManager = TrackingManager(
    trackingHistoryRepo: trackingHistoryRepository,
    trackingCountersRepo: trackingCountersRepository,
  );

  ShopifyManager shopifyManager = ShopifyManager(
    callable: cloudFunctionService,
    shopifyOrderFulfillmentRepo: shopifyOrderFulfillmentRepo,
  );

  InsightsManager insightsManager = InsightsManager(
    trackingManager: trackingManager,
    shopifyManager: shopifyManager,
    insightsRepo: insightsRepository,
    platformStartDate: config.platformStartDate!,
  );

  AuthManager authManager = AuthManager(
    authService: authService,
  );

  CommunicationsManager communicationsManager =
      CommunicationsManager(urlLauncherService: urlLauncherService);

  AnalyticsManager analyticsManager = AnalyticsManager(
    analyticsRepo: analyticsRepository,
  );

  ReportingManager reportingManager = ReportingManager(
    packagingsManager: packagingsManager,
    trackingManager: trackingManager,
    insightsManager: insightsManager,
    csvService: csvService,
    downloaderService: downloaderService,
    platformStartDate: config.platformStartDate!,
  );

  ReturnLabelsManager returnLabelsManager = ReturnLabelsManager(
    returnLabelsRepo: returnLabelsRepository,
  );

  LandingPageManager landingPageManager = LandingPageManager(
    landingPageConfigsRepo: landingPageConfigsRepository,
  );

  MerchantSettingsManager merchantSettingsManager = MerchantSettingsManager(
    merchantSettingsRepo: merchantSettingsRepository,
  );

  CircularityManager circularityManager = CircularityManager(
    repo: circularityRepo,
  );

  AuthState authState = AuthState(
    authService: authService,
    userManager: userManager,
  );
  UiState uiState = UiState();

  runZonedGuarded(() async {
    await SentryFlutter.init((options) {
      options.environment = config.environmentName;
      options.dsn =
          'https://845b9f2628dd497eb8435eedd4072558@o348728.ingest.sentry.io/4504971892359168';
    });
    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (context) => authState),
          ChangeNotifierProvider(create: (context) => uiState),
          Provider.value(value: config),
          Provider.value(value: urlLauncherService),
          Provider.value(value: userManager),
          Provider.value(value: authManager),
          Provider.value(value: stocksManager),
          Provider.value(value: insightsManager),
          Provider.value(value: orderManager),
          Provider.value(value: shipmentManager),
          Provider.value(value: shopifyManager),
          Provider.value(value: communicationsManager),
          Provider.value(value: packagingsManager),
          Provider.value(value: trackingManager),
          Provider.value(value: packagingShipmentsManager),
          Provider.value(value: analyticsManager),
          Provider.value(value: reportingManager),
          Provider.value(value: packagingLabelGenerationService),
          Provider.value(value: labelSpreadsheetGenerator),
          Provider.value(value: returnLabelGenerationService),
          Provider.value(value: returnLabelsManager),
          Provider.value(value: landingPageManager),
          Provider.value(value: merchantSettingsManager),
          Provider.value(value: circularityManager),
        ],
        child: App(
          authState: authState,
          uiState: uiState,
        ),
      ),
    );
  }, (exception, stackTrace) async {
    Sentry.captureException(exception, stackTrace: stackTrace);
  });
}
