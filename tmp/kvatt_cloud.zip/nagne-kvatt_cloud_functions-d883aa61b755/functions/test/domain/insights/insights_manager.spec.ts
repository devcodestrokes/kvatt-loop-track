import 'mocha';
import * as sinon from 'sinon';
import { InsightsManager } from "../../../src/domain/insights/insights_manager";
import { TrackingManager } from '../../../src/domain/tracking/tracking_manager';
import { TrackingHistoryRepository } from '../../../src/features/tracking/data/tracking_history_repository';
import { ShopifyManager } from '../../../src/domain/shopify/shopify_manager';
import { ShopifyStoreRepository } from '../../../src/features/shopify/data/shopify_store_repository';
import { ShopifyOrderFulfillmentRepository } from '../../../src/features/shopify/data/shopify_order_fulfillment_repository';
import { ShopifyOrderRepository } from '../../../src/features/shopify/data/shopify_order_repository';

import { Period } from '../../../src/domain/common/period';
import { TrackingHistory } from '../../../src/domain/tracking/tracking_history';
import { TrackingEvent } from '../../../src/domain/tracking/tracking_event';
import { TrackingSource } from '../../../src/domain/tracking/tracking_source';
import { PackInsight } from '../../../src/domain/insights/pack_insight';
import { ShopifyOrder } from '../../../src/domain/shopify/shopify_order';

describe('InsightsManager: getMerchantReturnInfo', () => {

  let trackingManager: TrackingManager;
  let shopifyManager: ShopifyManager;
  let insightsManager: InsightsManager;

  let getShippedToCustomerTrackingHistoriesStub: any;
  let getReturnedFromCustomerTrackingHistoriesStub: any;
  let getReturnedToKvattTrackingHistoriesStub: any;
  let getShippedToMerchantTrackingHistoriesStub: any;
  let getReturnedToKvattTrackingHistoriesCountStub: any;

  let getNumberOfShopifyOrderFulfillmentsForMerchantStub: any;

  let getPackInsightFromTrackingHistoryStub: any;

  beforeEach(function () {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();
    const trackingHistoryRepo = new TrackingHistoryRepository();
    trackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });
    shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });
    insightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });

    getShippedToCustomerTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getShippedToCustomerTrackingHistories');
    getReturnedFromCustomerTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getReturnedFromCustomerTrackingHistories');
    getReturnedToKvattTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getReturnedToKvattTrackingHistories');
    getShippedToMerchantTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getShippedToMerchantTrackingHistories');
    getReturnedToKvattTrackingHistoriesCountStub = sinon.stub(TrackingManager.prototype, 'getReturnedToKvattTrackingHistoriesCount');

    getNumberOfShopifyOrderFulfillmentsForMerchantStub = sinon.stub(ShopifyManager.prototype, 'getNumberOfShopifyOrderFulfillmentsForMerchant');

    getPackInsightFromTrackingHistoryStub = sinon.stub(InsightsManager.prototype, 'getPackInsightFromTrackingHistory');
  });
  afterEach(function () {
    getShippedToCustomerTrackingHistoriesStub.restore();
    getReturnedFromCustomerTrackingHistoriesStub.restore();
    getReturnedToKvattTrackingHistoriesStub.restore();
    getPackInsightFromTrackingHistoryStub.restore();
    getShippedToMerchantTrackingHistoriesStub.restore();
    getReturnedToKvattTrackingHistoriesCountStub.restore();
    getNumberOfShopifyOrderFulfillmentsForMerchantStub.restore();
  });

  it('(trackingSource = kvattApp) retrieves returnInfo', async () => {

    getShippedToCustomerTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2022-08-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-09-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
      new TrackingHistory({
        packId: 'pack_3',
        date: new Date('2022-10-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getReturnedFromCustomerTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2022-08-30'),
        event: TrackingEvent.returnedFromCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getReturnedToKvattTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-10-03'),
        event: TrackingEvent.returnedToKvatt,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_1',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_1',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_1',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedFromCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_1',
        numTimesShipped: 1,
        numTimesReturned: 1,
        numPending: 0,
        minReturnTimeInDays: 3,
        maxReturnTimeInDays: 10,
        averageReturnTimeInDays: null,
        returnDays: [3, 5, 7],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_2',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-09-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-10-03'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_2',
        numTimesShipped: 1,
        numTimesReturned: 1,
        numPending: 0,
        minReturnTimeInDays: 4,
        maxReturnTimeInDays: 8,
        averageReturnTimeInDays: null,
        returnDays: [2],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_3',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_3',
          date: new Date('2022-10-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_3',
        numTimesShipped: 1,
        numTimesReturned: 0,
        numPending: 1,
        minReturnTimeInDays: 5,
        maxReturnTimeInDays: 20,
        averageReturnTimeInDays: null,
        returnDays: [6, 7],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    const returnInfo = await insightsManager.getMerchantReturnInfo({
      merchantId: 'merchant_id',
      trackingSource: TrackingSource.kvattApp,
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
    });

    sinon.assert.match(returnInfo.numShipped, 3);
    sinon.assert.match(returnInfo.numReturned, 2);
    sinon.assert.match(returnInfo.numPending, 1);
    sinon.assert.match(returnInfo.maxReturnDays, 20);
    sinon.assert.match(returnInfo.minReturnDays, 3);
    sinon.assert.match(returnInfo.averageReturnDays, 5);
  });

  it('(trackingSource = kvattApp) retrieves returnInfo - minReturnTime and avgReturnTime consider 0 as an outlier', async () => {

    getShippedToCustomerTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2022-08-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-09-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
      new TrackingHistory({
        packId: 'pack_3',
        date: new Date('2022-10-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getReturnedFromCustomerTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2022-08-30'),
        event: TrackingEvent.returnedFromCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getReturnedToKvattTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-10-03'),
        event: TrackingEvent.returnedToKvatt,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_1',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_1',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_1',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedFromCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_1',
        numTimesShipped: 1,
        numTimesReturned: 1,
        numPending: 0,
        minReturnTimeInDays: 0,
        maxReturnTimeInDays: 10,
        averageReturnTimeInDays: null,
        returnDays: [0, 4, 7],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_2',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-09-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-10-03'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_2',
        numTimesShipped: 1,
        numTimesReturned: 1,
        numPending: 0,
        minReturnTimeInDays: 4,
        maxReturnTimeInDays: 8,
        averageReturnTimeInDays: null,
        returnDays: [2],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_3',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_3',
          date: new Date('2022-10-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_3',
        numTimesShipped: 1,
        numTimesReturned: 0,
        numPending: 1,
        minReturnTimeInDays: 5,
        maxReturnTimeInDays: 20,
        averageReturnTimeInDays: null,
        returnDays: [5, 7],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    const returnInfo = await insightsManager.getMerchantReturnInfo({
      merchantId: 'merchant_id',
      trackingSource: TrackingSource.kvattApp,
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
    });

    sinon.assert.match(returnInfo.maxReturnDays, 20);
    sinon.assert.match(returnInfo.minReturnDays, 4);
    sinon.assert.match(returnInfo.averageReturnDays, 5);
  });

  it('(trackingSource = null) retrieves returnInfo', async () => {

    getShippedToMerchantTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2022-08-25'),
        event: TrackingEvent.shippedToMerchant,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-09-25'),
        event: TrackingEvent.shippedToMerchant,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getReturnedToKvattTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-10-03'),
        event: TrackingEvent.returnedToKvatt,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_1',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_1',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: false,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_1',
        numTimesShipped: 1,
        numTimesReturned: 0,
        numPending: 0,
        minReturnTimeInDays: 3,
        maxReturnTimeInDays: 10,
        averageReturnTimeInDays: null,
        returnDays: [],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_2',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-09-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-10-03'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: false,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_2',
        numTimesShipped: 1,
        numTimesReturned: 1,
        numPending: 0,
        minReturnTimeInDays: 4,
        maxReturnTimeInDays: 8,
        averageReturnTimeInDays: null,
        returnDays: [4],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    const returnInfo = await insightsManager.getMerchantReturnInfo({
      merchantId: 'merchant_id',
      trackingSource: null,
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
    });

    sinon.assert.match(returnInfo.numShipped, 2);
    sinon.assert.match(returnInfo.numReturned, 1);
    sinon.assert.match(returnInfo.numPending, 0);
    sinon.assert.match(returnInfo.maxReturnDays, 10);
    sinon.assert.match(returnInfo.minReturnDays, 3);
    sinon.assert.match(returnInfo.averageReturnDays, 4);
  });

  it('(trackingSource = shopify) retrieves returnInfo', async () => {

    getNumberOfShopifyOrderFulfillmentsForMerchantStub.withArgs({
      merchantId: 'merchant_id',
    }).resolves(20);

    getNumberOfShopifyOrderFulfillmentsForMerchantStub.withArgs({
      merchantId: 'merchant_id',
      datedAfter: new Date('2022-12-22'),
    }).resolves(5);

    getReturnedToKvattTrackingHistoriesCountStub.withArgs({
      merchantId: 'merchant_id',
    }).resolves(8);

    const returnInfo = await insightsManager.getMerchantReturnInfo({
      merchantId: 'merchant_id',
      trackingSource: TrackingSource.shopify,
      today: new Date('2023-01-05'),
    });

    sinon.assert.match(returnInfo.numShipped, 20);
    sinon.assert.match(returnInfo.numReturned, 8);
    sinon.assert.match(returnInfo.numPending, 5);
    sinon.assert.match(returnInfo.maxReturnDays, null);
    sinon.assert.match(returnInfo.minReturnDays, null);
    sinon.assert.match(returnInfo.averageReturnDays, null);
  });
});

describe('InsightsManager: getMerchantsPacksInsights', () => {

  let trackingManager: TrackingManager;
  let shopifyManager: ShopifyManager;
  let insightsManager: InsightsManager;

  let getShippedToCustomerTrackingHistoriesStub: any;
  let getReturnedFromCustomerTrackingHistoriesStub: any;
  let getReturnedToKvattTrackingHistoriesStub: any;
  let getShippedToMerchantTrackingHistoriesStub: any;
  let getReturnedToKvattTrackingHistoriesCountStub: any;

  let getNumberOfShopifyOrderFulfillmentsForMerchantStub: any;

  let getPackInsightFromTrackingHistoryStub: any;

  beforeEach(function () {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();
    const trackingHistoryRepo = new TrackingHistoryRepository();
    trackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });
    shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });
    insightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });

    getShippedToCustomerTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getShippedToCustomerTrackingHistories');
    getReturnedFromCustomerTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getReturnedFromCustomerTrackingHistories');
    getReturnedToKvattTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getReturnedToKvattTrackingHistories');
    getShippedToMerchantTrackingHistoriesStub = sinon.stub(TrackingManager.prototype, 'getShippedToMerchantTrackingHistories');
    getReturnedToKvattTrackingHistoriesCountStub = sinon.stub(TrackingManager.prototype, 'getReturnedToKvattTrackingHistoriesCount');

    getNumberOfShopifyOrderFulfillmentsForMerchantStub = sinon.stub(ShopifyManager.prototype, 'getNumberOfShopifyOrderFulfillmentsForMerchant');

    getPackInsightFromTrackingHistoryStub = sinon.stub(InsightsManager.prototype, 'getPackInsightFromTrackingHistory');
  });
  afterEach(function () {
    getShippedToCustomerTrackingHistoriesStub.restore();
    getReturnedFromCustomerTrackingHistoriesStub.restore();
    getReturnedToKvattTrackingHistoriesStub.restore();
    getPackInsightFromTrackingHistoryStub.restore();
    getShippedToMerchantTrackingHistoriesStub.restore();
    getReturnedToKvattTrackingHistoriesCountStub.restore();
    getNumberOfShopifyOrderFulfillmentsForMerchantStub.restore();
  });

  it('(trackingSource = kvattApp) retrieves packInsights', async () => {
    getShippedToCustomerTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2022-08-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-09-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
      new TrackingHistory({
        packId: 'pack_3',
        date: new Date('2022-10-25'),
        event: TrackingEvent.shippedToCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getReturnedFromCustomerTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2022-08-30'),
        event: TrackingEvent.returnedFromCustomer,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getReturnedToKvattTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2022-10-03'),
        event: TrackingEvent.returnedToKvatt,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_1',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_1',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_1',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedFromCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_1',
        numTimesShipped: 1,
        numTimesReturned: 1,
        numPending: 0,
        minReturnTimeInDays: null,
        maxReturnTimeInDays: null,
        averageReturnTimeInDays: null,
        returnDays: [],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_2',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-09-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_2',
          date: new Date('2022-10-03'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_2',
        numTimesShipped: 1,
        numTimesReturned: 1,
        numPending: 0,
        minReturnTimeInDays: null,
        maxReturnTimeInDays: null,
        averageReturnTimeInDays: null,
        returnDays: [],
        lastReturnedDate: null,
        lastShippedDate: null,
      })
    );

    getPackInsightFromTrackingHistoryStub.withArgs({
      packId: 'pack_3',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_3',
          date: new Date('2022-10-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      hasMerchantTracking: true,
      today: new Date('2023-01-05'),
    }).returns(
      new PackInsight({
        packId: 'pack_3',
        numTimesShipped: 1,
        numTimesReturned: 0,
        numPending: 1,
        minReturnTimeInDays: null,
        maxReturnTimeInDays: null,
        averageReturnTimeInDays: 34,
        returnDays: [],
        lastReturnedDate: new Date('2023-09-09'),
        lastShippedDate: new Date('2023-09-01'),
      })
    );

    const packInsights = await insightsManager.getMerchantPacksInsights({
      merchantId: 'merchant_id',
      trackingSource: TrackingSource.kvattApp,
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
    });

    sinon.assert.match(packInsights[0].packId, 'pack_1');
    sinon.assert.match(packInsights[0].numTimesShipped, 1);
    sinon.assert.match(packInsights[0].numTimesReturned, 1);
    sinon.assert.match(packInsights[0].numPending, 0);
    sinon.assert.match(packInsights[0].averageReturnTimeInDays, null);
    sinon.assert.match(packInsights[0].lastShippedDate, null);
    sinon.assert.match(packInsights[0].lastReturnedDate, null);

    sinon.assert.match(packInsights[1].packId, 'pack_2');
    sinon.assert.match(packInsights[1].numTimesShipped, 1);
    sinon.assert.match(packInsights[1].numTimesReturned, 1);
    sinon.assert.match(packInsights[1].numPending, 0);
    sinon.assert.match(packInsights[1].averageReturnTimeInDays, null);
    sinon.assert.match(packInsights[1].lastShippedDate, null);
    sinon.assert.match(packInsights[1].lastReturnedDate, null);

    sinon.assert.match(packInsights[2].packId, 'pack_3');
    sinon.assert.match(packInsights[2].numTimesShipped, 1);
    sinon.assert.match(packInsights[2].numTimesReturned, 0);
    sinon.assert.match(packInsights[2].numPending, 1);
    sinon.assert.match(packInsights[2].averageReturnTimeInDays, 34);
    sinon.assert.match(packInsights[2].lastShippedDate, new Date('2023-09-01'));
    sinon.assert.match(packInsights[2].lastReturnedDate, new Date('2023-09-09'));

  });
});

describe('InsightsManager: getPackInsightFromTrackingHistory', () => {

  let trackingManager: TrackingManager;
  let shopifyManager: ShopifyManager;
  let insightsManager: InsightsManager;

  beforeEach(function () {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();
    const trackingHistoryRepo = new TrackingHistoryRepository();

    trackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });
    shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });
    insightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });
  });
  afterEach(function () {

  });

  it('(hasMerchantTracking = true) should ignore packs shipped before period', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-06-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 0);
    sinon.assert.match(packInsight.numTimesReturned, 0);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = true) should not count return if not previously shipped', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.returnedFromCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 0);
    sinon.assert.match(packInsight.numTimesReturned, 0);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = true) should count return to merchant', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedFromCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 1);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = true) should count return to kvatt', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 1);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = true) should count return to kvatt (legacy)', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedToKvattNeedsMaintenance,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-09-03'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-09-10'),
          event: TrackingEvent.returnedToKvattNoMaintenance,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 2);
    sinon.assert.match(packInsight.numTimesReturned, 2);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = true) should not double count return when consolidating for kvatt return', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedFromCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-09-03'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 1);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = true) should count as pending if before grace period', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 0);
    sinon.assert.match(packInsight.numPending, 1);
  });

  it('(hasMerchantTracking = true) should count return if returned before grace period', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 1);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = true) should compute return time correctly', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2023-01-10'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2023-01-18'),
          event: TrackingEvent.returnedFromCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-25'),
      }),
      today: new Date('2023-01-31'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.averageReturnTimeInDays, 6);
    sinon.assert.match(packInsight.minReturnTimeInDays, 4);
    sinon.assert.match(packInsight.maxReturnTimeInDays, 8);
    sinon.assert.match(packInsight.returnDays, [4, 8]);
  });


  it('should handle unordered tracking histories', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 1);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = false) should ignore packs shipped before period', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-06-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.numTimesShipped, 0);
    sinon.assert.match(packInsight.numTimesReturned, 0);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = false) should not count return if not previously shipped', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.numTimesShipped, 0);
    sinon.assert.match(packInsight.numTimesReturned, 0);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = false) should count return to kvatt', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 1);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = false) should count return to kvatt (legacy)', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-08-30'),
          event: TrackingEvent.returnedToKvattNeedsMaintenance,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-09-03'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-09-10'),
          event: TrackingEvent.returnedToKvattNoMaintenance,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.numTimesShipped, 2);
    sinon.assert.match(packInsight.numTimesReturned, 2);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = false) should count as pending if before grace period', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 0);
    sinon.assert.match(packInsight.numPending, 1);
  });

  it('(hasMerchantTracking = false) should count return if returned before grace period', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.numTimesShipped, 1);
    sinon.assert.match(packInsight.numTimesReturned, 1);
    sinon.assert.match(packInsight.numPending, 0);
  });

  it('(hasMerchantTracking = false) should return averageReturnTimeInDays', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.averageReturnTimeInDays, 4);
  });

  it('(hasMerchantTracking = true) should return averageReturnTimeInDays', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.averageReturnTimeInDays, 4);
  });

  it('(hasMerchantTracking = false) should return lastShippedDate and lastReturnedDate', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.lastShippedDate, new Date('2022-12-25'));
    sinon.assert.match(packInsight.lastReturnedDate, new Date('2022-12-29'));
  });

  it('(hasMerchantTracking = true) should return lastShippedDate and lastReturnedDate', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToCustomer,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-05'),
      }),
      today: new Date('2023-01-05'),
      hasMerchantTracking: true,
    });

    sinon.assert.match(packInsight.lastShippedDate, new Date('2022-12-25'));
    sinon.assert.match(packInsight.lastReturnedDate, new Date('2022-12-29'));
  });

  it('(hasMerchantTracking = false) should compute return time correctly', async () => {
    const packInsight = insightsManager.getPackInsightFromTrackingHistory({
      packId: 'pack_id',
      trackingHistories: [
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-25'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2022-12-29'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2023-01-10'),
          event: TrackingEvent.shippedToMerchant,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
        new TrackingHistory({
          packId: 'pack_id',
          date: new Date('2023-01-18'),
          event: TrackingEvent.returnedToKvatt,
          trackedByUserId: 'user_id',
          merchantId: 'merchant_id',
        }),
      ],
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-25'),
      }),
      today: new Date('2023-01-31'),
      hasMerchantTracking: false,
    });

    sinon.assert.match(packInsight.averageReturnTimeInDays, 6);
    sinon.assert.match(packInsight.minReturnTimeInDays, 4);
    sinon.assert.match(packInsight.maxReturnTimeInDays, 8);
    sinon.assert.match(packInsight.returnDays, [4, 8]);
  });
});

describe('InsightsManager: getMerchantCheckoutPickUpInfo', () => {

  let trackingManager: TrackingManager;
  let shopifyManager: ShopifyManager;
  let insightsManager: InsightsManager;

  let retrieveShopifyOrdersForMerchantStub: any;

  beforeEach(function () {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();
    const trackingHistoryRepo = new TrackingHistoryRepository();
    trackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });
    shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });
    insightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });

    retrieveShopifyOrdersForMerchantStub = sinon.stub(ShopifyManager.prototype, 'retrieveShopifyOrdersForMerchant');
  });
  afterEach(function () {
    retrieveShopifyOrdersForMerchantStub.restore();
  });

  it('Retrieves checkoutPickUpInfo', async () => {

    retrieveShopifyOrdersForMerchantStub.withArgs({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01T19:59:59.000Z'),
      }),
    }).resolves([
      new ShopifyOrder({
        createdAt: new Date('2022-07-07'),
        orderNumber: '0100',
        orderId: 'order_id',
        customerAcceptedMarketingComms: false,
        shippingOptions: [],
        isWithKvattShippingOption: true,
        customerEmail: null,
        customerId: null,
        shippingPostCode: null,
        shippingCountry: null,
        shippingCity: null,
      }),
      new ShopifyOrder({
        createdAt: new Date('2022-07-07'),
        orderNumber: '0100',
        orderId: 'order_id',
        customerAcceptedMarketingComms: false,
        shippingOptions: [],
        isWithKvattShippingOption: false,
        customerEmail: null,
        customerId: null,
        shippingPostCode: null,
        shippingCountry: null,
        shippingCity: null,
      }),
      new ShopifyOrder({
        createdAt: new Date('2022-07-07'),
        orderNumber: '0100',
        orderId: 'order_id',
        customerAcceptedMarketingComms: false,
        shippingOptions: [],
        isWithKvattShippingOption: true,
        customerEmail: null,
        customerId: null,
        shippingPostCode: null,
        shippingCountry: null,
        shippingCity: null,
      }),
      new ShopifyOrder({
        createdAt: new Date('2022-07-07'),
        orderNumber: '0100',
        orderId: 'order_id',
        customerAcceptedMarketingComms: false,
        shippingOptions: [],
        isWithKvattShippingOption: false,
        customerEmail: null,
        customerId: null,
        shippingPostCode: null,
        shippingCountry: null,
        shippingCity: null,
      }),
    ]);

    const info = await insightsManager.getMerchantCheckoutPickUpInfo({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2022-07-01'),
        end: new Date('2023-01-01'),
      }),
    });

    sinon.assert.match(info?.totalOrders, 4);
    sinon.assert.match(info?.numOrdersWithKvattPack, 2);
    sinon.assert.match(info?.getPickUpRate(), 0.5);
  });


});