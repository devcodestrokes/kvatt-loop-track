import { ReturnInfo } from "../../../src/domain/insights/return_info";
import * as sinon from 'sinon';

describe('ReturnInfo: getReturnRate', () => {

  it('returns null if numShipped is 0', () => {
    const returnInfo = new ReturnInfo({
      numShipped: 0,
      numPending: 1,
      numReturned: 1,
      maxReturnDays: null,
      minReturnDays: null,
      averageReturnDays: null,
    });

    sinon.assert.match(returnInfo.getReturnRate(), null);
  });

  it('returns null if negative', () => {
    const returnInfo = new ReturnInfo({
      numShipped: 10,
      numPending: 1,
      numReturned: 12,
      maxReturnDays: null,
      minReturnDays: null,
      averageReturnDays: null,
    });

    sinon.assert.match(returnInfo.getReturnRate(), null);
  });

  it('returns null if numPending > numShipped', () => {
    const returnInfo = new ReturnInfo({
      numShipped: 10,
      numPending: 12,
      numReturned: 0,
      maxReturnDays: null,
      minReturnDays: null,
      averageReturnDays: null,
    });

    sinon.assert.match(returnInfo.getReturnRate(), null);
  });

  it('returns returnRate', () => {
    const returnInfo = new ReturnInfo({
      numShipped: 105,
      numPending: 5,
      numReturned: 20,
      maxReturnDays: null,
      minReturnDays: null,
      averageReturnDays: null,
    });

    sinon.assert.match(returnInfo.getReturnRate(), 0.2);
  });
});

describe('ReturnInfo: getNumLost', () => {

  it('returns numLost', () => {
    const returnInfo = new ReturnInfo({
      numShipped: 105,
      numPending: 5,
      numReturned: 20,
      maxReturnDays: null,
      minReturnDays: null,
      averageReturnDays: null,
    });

    sinon.assert.match(returnInfo.getNumLost(), 80);
  });

});
