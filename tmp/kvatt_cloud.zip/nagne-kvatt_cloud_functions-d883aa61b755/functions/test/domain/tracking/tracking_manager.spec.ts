import * as sinon from 'sinon';
import 'mocha';

import { TrackingManager } from "../../../src/domain/tracking/tracking_manager";
import { TrackingHistoryRepository } from "../../../src/features/tracking/data/tracking_history_repository";
import { TrackingEvent } from '../../../src/domain/tracking/tracking_event';
import { Period } from '../../../src/domain/common/period';
import { TrackingHistory } from '../../../src/domain/tracking/tracking_history';

describe('TrackingManager: getReturnedToKvattTrackingHistories', () => {

  let trackingManager: TrackingManager;

  let getTrackingHistoriesStub: any;

  beforeEach(function () {
    const trackingHistoryRepo = new TrackingHistoryRepository();
    trackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });

    getTrackingHistoriesStub = sinon.stub(TrackingHistoryRepository.prototype, 'getTrackingHistories');
  });
  afterEach(function () {
    getTrackingHistoriesStub.restore();
  });

  it('returns all returned tracking histories', async () => {
    getTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      event: TrackingEvent.returnedToKvatt,
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_1',
        date: new Date('2023-04-10'),
        event: TrackingEvent.returnedToKvatt,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      event: TrackingEvent.returnedToKvattNeedsMaintenance,
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_2',
        date: new Date('2023-04-10'),
        event: TrackingEvent.returnedToKvattNeedsMaintenance,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    getTrackingHistoriesStub.withArgs({
      merchantId: 'merchant_id',
      event: TrackingEvent.returnedToKvattNoMaintenance,
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    }).resolves([
      new TrackingHistory({
        packId: 'pack_3',
        date: new Date('2023-04-10'),
        event: TrackingEvent.returnedToKvattNoMaintenance,
        trackedByUserId: 'user_id',
        merchantId: 'merchant_id',
      }),
    ]);

    const histories = await trackingManager.getReturnedToKvattTrackingHistories({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    });

    sinon.assert.match(histories[0].packId, 'pack_1');
    sinon.assert.match(histories[1].packId, 'pack_2');
    sinon.assert.match(histories[2].packId, 'pack_3');
  });
});

describe('TrackingManager: getReturnedToKvattTrackingHistoriesCount', () => {

  let trackingManager: TrackingManager;

  let getTrackingHistoriesCountStub: any;

  beforeEach(function () {
    const trackingHistoryRepo = new TrackingHistoryRepository();
    trackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });

    getTrackingHistoriesCountStub = sinon.stub(TrackingHistoryRepository.prototype, 'getTrackingHistoriesCount');
  });
  afterEach(function () {
    getTrackingHistoriesCountStub.restore();
  });

  it('returns count of return histories', async () => {
    getTrackingHistoriesCountStub.withArgs({
      merchantId: 'merchant_id',
      event: TrackingEvent.returnedToKvatt,
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    }).resolves(2);

    getTrackingHistoriesCountStub.withArgs({
      merchantId: 'merchant_id',
      event: TrackingEvent.returnedToKvattNeedsMaintenance,
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    }).resolves(3);

    getTrackingHistoriesCountStub.withArgs({
      merchantId: 'merchant_id',
      event: TrackingEvent.returnedToKvattNoMaintenance,
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    }).resolves(1);

    const historiesCount = await trackingManager.getReturnedToKvattTrackingHistoriesCount({
      merchantId: 'merchant_id',
      period: new Period({
        start: new Date('2023-04-01'),
        end: new Date('2023-06-30'),
      }),
    });

    sinon.assert.match(historiesCount, 6);
  });
});