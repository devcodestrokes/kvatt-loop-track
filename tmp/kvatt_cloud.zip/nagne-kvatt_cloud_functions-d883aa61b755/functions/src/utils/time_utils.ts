export class TimeUtils {

  static isDateStringValid({
    dateString,
  }: {
    dateString: string,
  }): boolean {
    return !isNaN(Date.parse(dateString));
  }

  static getDifferenceInDays({
    date1,
    date2,
  }: {
    date1: Date,
    date2: Date,
  }): number {
    const millisecondsDiff = date2.getTime() - date1.getTime()

    const daysDiff = Math.round(Math.abs(
      millisecondsDiff / 1000 / 3600 / 24
    ));

    return daysDiff;
  }

  static subtractDaysFromDate({
    date,
    numDays,
  }: {
    date: Date,
    numDays: number,
  }): Date {
    const newDate = new Date(date);
    newDate.setDate(newDate.getDate() - numDays);
    return newDate;
  }

  static getBeginningOfMonth(): Date {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth(), 1);
  }

  static getBeginningOfPreviousMonth(): Date {
    const today = new Date();
    return new Date(today.getFullYear(), today.getMonth() - 1, 1);
  }

  static getEndOfPreviousMonth(): Date {
    const date = new Date();
    date.setDate(1);
    date.setHours(-1);
    date.setMinutes(59);
    date.setSeconds(59);
    return date;
  }
}