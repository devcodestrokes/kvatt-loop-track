import functions = require('firebase-functions');

import { Configs } from "./configs";

export class StagingConfig extends Configs {

  ENVIRONMENT_NAME: string = 'staging';
  PROJECT_ID: string = 'kvatt-platform-staging';

  SIB_API_KEY: string = functions.config().sib.api_key;

  USER_INVITE_SIB_TEMPLATE_ID: number = 2;
  ORDER_REQUEST_SIB_TEMPLATE_ID: number = 3;
  ORDER_CONFIRMATION_SIB_TEMPLATE_ID: number = 4;
  STOCK_INPUT_REMINDER_SIB_TEMPLATE_ID: number = 5;
  RETURN_REMINDER_NUDGE_SIB_TEMPLATE_ID: number = 12;
  SHIPPING_SIB_TEMPLATE_ID: number = 7;
  MONTHLY_INVOICE_REMINDER_SIB_TEMPLATE_ID: number = 13;
  STOCK_LEVEL_DROP_TEMPLATE_ID: number = 11;

  APP_REDIRECT_URL: string = 'https://kvatt-platform-staging.web.app';

  ORDER_REQUEST_RECIPIENT_EMAIL = 'gianfranco@kvatt.com';
  ADMIN_RECIPIENT_EMAIL = 'gianfranco@kvatt.com';

  LA_POSTE_API_BASE_URL = 'https://apim-gw-acc.net.extra.laposte.fr';
  LA_POSTE_API_CLIENT_ID = functions.config().laposte.client_id;
  LA_POSTE_API_CLIENT_SECRET = functions.config().laposte.client_secret;
  LA_POSTE_API_RANGE_ENDPOINT = '/markingRange/v1/ranges';
  LA_POSTE_API_CUST_ACC_NUMBER = '05007892';
  LA_POSTE_API_CONTRACT_NUMBER = 'D-991874-1';
  LA_POSTE_API_COMP_NAME = 'Kvatt';

  SHOPIFY_CLIENT_ID = functions.config().shopify.client_id;
  SHOPIFY_CLIENT_SECRET = functions.config().shopify.client_secret;
  SHOPIFY_SCOPES = [
    'read_products',
    'read_orders',
    'read_fulfillments',
    'read_customers',
    'read_shipping',
  ];
  SHOPIFY_WEBHOOK_PUBSUB_TOPIC: string = 'shopifyWebhooks';

  LEGACY_SHOPIFY_STORES: string[] = [];


}