import { firestore } from 'firebase-admin';

const admin = require('firebase-admin');
admin.initializeApp();

firestore().settings({
  ignoreUndefinedProperties: true,
});

export {
  //Firestore
  onUserCreatedEvent,

  //Callable
  createAccountCallable,
  resendInviteCallable,
  changeEmailCallable,
  removeMerchantCallable,
} from './features/accounts';

export {
  //Firestore
  onStockLevelEntryCreatedEvent,
  onPackagingUpdatedEvent,
  insightsCallable,
} from './features/insights';

export {
  //Callable
  orderRequestCallable,
} from './features/orders';

export {
  //Firestore
  onShipmentCreatedEvent,
} from './features/shipments';

export {
  //Firestore
  onAnalyticsCreatedEvent,
} from './features/analytics';

export {
  //Firestore
  onPackagingShipmentUpdatedEvent,
} from './features/packaging_shipments';

export {
  getLaPosteSDCallable,
} from './features/return_labels';

export {
  shopifyApp,
  shopifyAuthEndpoint,
  shopifyAuthCallback,
  shopifyConnectCallable,
  shopifyWebhook,
  //PubSub
  shopifyWebhookPubSub,
} from './features/shopify';

export {
  //Callable
  trackPacksCallable,
} from './features/tracking';

export {
  //Firestore
  nudgesOnPackagingUpdatedEvent,
  //Cron
  nudgesCron,
} from './features/nudges';

export {
  //Callable
  circularityCallable,
} from './features/reporting';

export {
  //Cron
  sendMonthlyInvoiceReminderCron,
} from './features/reminders';
