import functions = require('firebase-functions');
import { Configs } from './configs/configs';
import { DevelopmentConfig } from './configs/development_config';
import { ProductionConfig } from './configs/production_config';
import { StagingConfig } from './configs/staging_config';

export function getEnvironment(): string {
    return functions.config().environment.name;
}

export function getConfigs(): Configs {
  try {
    const environment = getEnvironment();
      switch (environment) {
        case 'development':
          return new DevelopmentConfig();
        case 'staging':
          return new StagingConfig();
        case 'production':
          return new ProductionConfig();
        default:
          throw Error();
    }
  } catch (e) {
    return new DevelopmentConfig();
  }
}

