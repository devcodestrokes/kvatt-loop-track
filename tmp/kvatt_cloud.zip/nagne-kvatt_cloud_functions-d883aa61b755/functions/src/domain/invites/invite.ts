export class Invite {
  id: string;
  email: string;
  userId: string;
  userType: string;

  constructor({
    id,
    email,
    userId,
    userType,
  } : {
    id: string,
    email : string,
    userId: string,
    userType: string,
  }) {
    this.id = id;
    this.email = email;
    this.userId = userId;
    this.userType = userType;
  }
}