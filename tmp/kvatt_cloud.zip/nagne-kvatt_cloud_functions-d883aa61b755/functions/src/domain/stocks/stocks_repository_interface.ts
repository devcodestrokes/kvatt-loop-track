export abstract class StocksRepositoryInterface {
    abstract incrementStockLevel({
        merchantId,
        product,
        incrementValue,
    }: {
        merchantId: string,
        product: string,
        incrementValue: number,
    }): Promise<void>;
}