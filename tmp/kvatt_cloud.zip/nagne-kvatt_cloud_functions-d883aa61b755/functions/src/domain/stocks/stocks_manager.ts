import { PackagingStatus } from "../packagings/packaging_status";
import { PackagingsRepositoryInterface } from "../packagings/packagings_repository_interface";
import { StocksRepositoryInterface } from "./stocks_repository_interface";

export class StocksManager {

  packsRepo: PackagingsRepositoryInterface;
  stocksRepo: StocksRepositoryInterface;

  constructor({
    stocksRepo,
    packsRepo,
  }: {
    stocksRepo: StocksRepositoryInterface,
    packsRepo: PackagingsRepositoryInterface,
  }) {
    this.stocksRepo = stocksRepo;
    this.packsRepo = packsRepo;
  }

  async getMerchantStockLevelForProduct({
    merchantId,
    product,
  }: {
    merchantId: string,
    product: string,
  }): Promise<number> {
    return await this.packsRepo.getPacksCount({
      status: PackagingStatus.withMerchant,
      merchantId: merchantId,
      productType: product,
    });
  }

  async updateMerchantStocks({
    merchantId,
    productQuantities,
  }: {
    merchantId: string,
    productQuantities: Map<string, number>,
  }): Promise<void> {
    const tasks: Promise<void>[] = [];

    for (const entry of productQuantities.entries()) {
      tasks.push(
        this.stocksRepo.incrementStockLevel({
          merchantId: merchantId,
          product: entry[0],
          incrementValue: entry[1],
        })
      );
    }

    await Promise.all(tasks);
  }
}