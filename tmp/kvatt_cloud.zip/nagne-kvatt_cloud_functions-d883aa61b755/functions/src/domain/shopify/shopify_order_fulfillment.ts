export class ShopifyOrderFulfillment {

  shopId: string;
  merchantId: string;
  orderId: number;
  orderNumber: string;
  shippingMethodCode: string;
  date: Date;

  constructor({
    shopId,
    merchantId,
    orderId,
    orderNumber,
    shippingMethodCode,
    date,
  }: {
    shopId: string,
    merchantId: string,
    orderId: number,
    orderNumber: string,
    shippingMethodCode: string,
    date: Date,
  }) {
    this.shopId = shopId;
    this.merchantId = merchantId;
    this.orderId = orderId;
    this.orderNumber = orderNumber;
    this.shippingMethodCode = shippingMethodCode;
    this.date = date;
  }
}