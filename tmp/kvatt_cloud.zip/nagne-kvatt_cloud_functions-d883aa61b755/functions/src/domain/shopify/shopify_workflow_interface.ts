export abstract class ShopifyWorkflowInterface {

  abstract triggerLostPackStatusChangedWorkflow({
    orderId,
    customerId,
  }: {
    orderId: number,
    customerId: number,
  }): Promise<void>;

  abstract triggerReturnedPackStatusChangedWorkflow({
    orderId,
    customerId,
  }: {
    orderId: number,
    customerId: number,
  }): Promise<void>;
}