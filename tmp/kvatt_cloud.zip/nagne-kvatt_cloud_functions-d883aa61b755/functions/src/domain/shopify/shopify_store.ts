export class ShopifyStore {

  shopId: string;
  merchantId?: string | undefined;
  clientId: string;
  clientSecret: string;
  scopes: string[];
  accessToken?: string;
  kvattShippingMethods?: string[];
  packStatusChangedTriggerId?: string;
  sendGenericReturnEmailNudge?: boolean;
  checkCode?: string | undefined;

  constructor({
    shopId,
    merchantId,
    clientId,
    clientSecret,
    scopes,
    accessToken,
    kvattShippingMethods,
    packStatusChangedTriggerId,
    sendGenericReturnEmailNudge,
    checkCode,
  }: {
    shopId: string,
    merchantId?: string | undefined,
    clientId: string,
    clientSecret: string,
    scopes: string[],
    accessToken?: string,
    kvattShippingMethods?: string[],
    packStatusChangedTriggerId?: string,
    sendGenericReturnEmailNudge?: boolean,
    checkCode?: string | undefined,
  }) {
    this.shopId = shopId;
    this.merchantId = merchantId;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.scopes = scopes;
    this.accessToken = accessToken;
    this.kvattShippingMethods = kvattShippingMethods;
    this.packStatusChangedTriggerId = packStatusChangedTriggerId;
    this.sendGenericReturnEmailNudge = sendGenericReturnEmailNudge;
    this.checkCode = checkCode;
  }
}