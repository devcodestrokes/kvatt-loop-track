export abstract class ShopifyOrderFulfillmentRepositoryInterface {

  abstract createNewOrderFulfillment({
    id,
    shopId,
    merchantId,
    orderId,
    orderNumber,
    shippingMethodCode,
    date,
    countryCode,
    postCode,
  }: {
    id: string,
    shopId: string,
    merchantId: string,
    orderId: string,
    orderNumber: string,
    shippingMethodCode: string,
    date: Date,
    countryCode?: string | undefined,
    postCode?: string | undefined,
  }): Promise<void>;

  abstract countShipifyOrderFulfillments({
    merchantId,
    datedAfter,
  }: {
    merchantId: string,
    datedAfter?: Date | undefined,
  }): Promise<number>;
}