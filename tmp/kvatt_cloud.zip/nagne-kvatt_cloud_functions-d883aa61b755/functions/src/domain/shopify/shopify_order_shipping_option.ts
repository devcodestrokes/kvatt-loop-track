export class ShopifyOrderShippingOption {
  code: string;
  price: string;
  currency: string;
  title: string;

  constructor({
    code,
    price,
    currency,
    title,
  }: {
    code: string,
    price: string,
    currency: string,
    title: string,
  }) {
    this.code = code;
    this.price = price;
    this.currency = currency;
    this.title = title;
  }
}