import { Period } from "../common/period";
import { ShopifyOrder } from "./shopify_order";

export abstract class ShopifyOrderRepositoryInterface {

  abstract createShopifyOrder({
    id,
    shopId,
    order,
  }: {
    id: string,
    shopId: string,
    order: ShopifyOrder,
  }): Promise<void>;

  abstract retrieveShopifyOrders({
    shopId,
    period,

  }: {
    shopId: string,
    period?: Period | undefined,
  }): Promise<ShopifyOrder[]>;

  abstract retrieveShopifyOrdersByOrderId({
    shopId,
    orderId,
  }: {
    shopId: string,
    orderId: string,
  }): Promise<ShopifyOrder | null>;
}