import { CryptoService } from "../../services/crypto/crypto_service";
import { Period } from "../common/period";
import { ShippingMethod } from "./shipping_method";
import { ShopifyOrder } from "./shopify_order";
import { ShopifyOrderFulfillmentRepositoryInterface } from "./shopify_order_fulfillment_repository_interface";
import { ShopifyOrderRepositoryInterface } from "./shopify_order_repository_interface";
import { ShopifyOrderShippingOption } from "./shopify_order_shipping_option";
import { ShopifyStore } from "./shopify_store";
import { ShopifyStoreRepositoryInterface } from "./shopify_store_repository_interface";

export class ShopifyManager {
  shopifyStoreRepo: ShopifyStoreRepositoryInterface;
  shopifyOrderFulfillmentsRepo: ShopifyOrderFulfillmentRepositoryInterface;
  shopifyOrderRepo: ShopifyOrderRepositoryInterface;

  constructor({
    shopifyStoreRepo,
    shopifyOrderFulfillmentsRepo,
    shopifyOrderRepo,
  }: {
    shopifyStoreRepo: ShopifyStoreRepositoryInterface,
    shopifyOrderFulfillmentsRepo: ShopifyOrderFulfillmentRepositoryInterface,
    shopifyOrderRepo: ShopifyOrderRepositoryInterface,
  }) {
    this.shopifyStoreRepo = shopifyStoreRepo;
    this.shopifyOrderFulfillmentsRepo = shopifyOrderFulfillmentsRepo;
    this.shopifyOrderRepo = shopifyOrderRepo;
  }

  async setShopConfigurations({
    shopId,
    accessToken,
    scopes,
  }: {
    shopId: string,
    accessToken: string,
    scopes: string[],
  }): Promise<string> {
    await this.updateAccessToken({
      shopId: shopId,
      token: accessToken,
    });
    await this.updateScopes({
      shopId: shopId,
      scopes: scopes,
    });

    const checkCode: string = CryptoService.generateRandomUuid();
    await this.updateCheckCode({
      shopId: shopId,
      code: checkCode,
    });

    return checkCode;
  }

  async updateCheckCode({
    shopId,
    code,
  }: {
    shopId: string,
    code: string,
  }): Promise<void> {
    await this.shopifyStoreRepo.setCheckCode({
      shopId: shopId,
      code: code,
    });
  }

  async updateAccessToken({
    shopId,
    token,
  }: {
    shopId: string,
    token: string,
  }): Promise<void> {
    await this.shopifyStoreRepo.setToken({
      shopId: shopId,
      token: token,
    });
  }

  async updateScopes({
    shopId,
    scopes,
  }: {
    shopId: string,
    scopes: string[],
  }): Promise<void> {
    await this.shopifyStoreRepo.setScopes({
      shopId: shopId,
      scopes: scopes,
    });
  }

  async updateSendGenericReturnEmailNudge({
    shopId,
    sendGenericReturnEmailNudge,
  }: {
    shopId: string,
    sendGenericReturnEmailNudge: boolean,
  }): Promise<void> {
    await this.shopifyStoreRepo.setSendGenericReturnEmailNudge({
      shopId: shopId,
      sendGenericReturnEmailNudge: sendGenericReturnEmailNudge,
    });
  }

  async linkMerchantToStore({
    shopId,
    merchantId,
  }: {
    shopId: string,
    merchantId: string,
  }): Promise<void> {
    await this.shopifyStoreRepo.setMerchantId({
      shopId: shopId,
      merchantId: merchantId,
    });
    await this.shopifyStoreRepo.setCheckCode({
      shopId: shopId,
      code: '',
    });
  }

  async verifyMerchantConnectionStatus({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<ShopifyStore | null> {
    const store: ShopifyStore | null = await this.retrieveShopifyStoreForMerchant({
      merchantId: merchantId,
    });

    if (store === null) {
      return null;
    }
    //TODO: Might be good to verify validity of token here
    if (store.accessToken === undefined || store.accessToken === null) {
      return null;
    }
    return store;
  }

  async checkShippingMethodAddedAtCheckout({
    shopId,
    availableShippingMethodsAtCheckout,
    expectedShippingMethod,
  }: {
    shopId: string,
    availableShippingMethodsAtCheckout: ShippingMethod[],
    expectedShippingMethod: string,
  }): Promise<boolean> {
    await this.shopifyStoreRepo.setKvattShippingMethods({
      shopId: shopId,
      shippingMethods: [expectedShippingMethod],
    });

    for (const method of availableShippingMethodsAtCheckout) {
      if (method.isActive) {
        if (method.name.toLowerCase().includes(expectedShippingMethod.toLowerCase())) {
          return true;
        }
      }
    }
    return false;
  }

  async retrieveShopifyStore({
    shopId,
  }: {
    shopId: string,
  }): Promise<ShopifyStore | null> {
    return await this.shopifyStoreRepo.retrieveShopifyStoreByShopId({
      shopId: shopId,
    });
  }

  async retrieveShopifyStoreForMerchant({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<ShopifyStore | null> {
    return await this.shopifyStoreRepo.retrieveShopifyStoreByMerchantId({
      merchantId: merchantId,
    });
  }

  async retrieveShopifyStoreWithCheckCode({
    checkCode,
  }: {
    checkCode: string,
  }): Promise<ShopifyStore | null> {
    return await this.shopifyStoreRepo.retrieveShopifyStoreByCheckCode({
      checkCode: checkCode,
    });
  }

  //Note: We use the webhook ID from Shopify as the ID of the document
  //in Firestore. This is because each Shopify webhook has a unique ID
  //and Shopify webhooks can be triggered more than once.
  //This ensures that if the same webhook is triggered twice, it 
  //does not create another document but updates the same document.
  async recordShopifyOrderFulfillmentWithKvattPack({
    id,
    shopId,
    merchantId,
    orderId,
    orderNumber,
    shippingMethodCode,
    date,
    countryCode,
    postCode,
  }: {
    id: string,
    shopId: string,
    merchantId: string,
    orderId: string,
    orderNumber: string,
    shippingMethodCode: string,
    date: Date,
    countryCode?: string | undefined,
    postCode?: string | undefined,
  }): Promise<void> {
    await this.shopifyOrderFulfillmentsRepo.createNewOrderFulfillment({
      id: id,
      shopId: shopId,
      merchantId: merchantId,
      orderId: orderId,
      orderNumber: orderNumber,
      shippingMethodCode: shippingMethodCode,
      date: date,
      countryCode: countryCode,
      postCode: postCode,
    });
  }

  async recordShopifyOrder({
    id,
    shopId,
    availableShippingMethodsAtCheckout,
    kvattShippingMethods,
    createdAt,
    orderNumber,
    orderId,
    customerAcceptedMarketingComms,
    orderCurrency,
    totalOrderPrice,
    shippingOptions,
    customerEmail,
    customerId,
    shippingPostCode,
    shippingCountry,
    shippingCity,
  }: {
    id: string,
    shopId: string,
    availableShippingMethodsAtCheckout: ShippingMethod[],
    kvattShippingMethods: string[] | undefined,
    createdAt: Date,
    orderNumber: string,
    orderId: string,
    customerAcceptedMarketingComms: boolean,
    orderCurrency: string,
    totalOrderPrice: string,
    shippingOptions: ShopifyOrderShippingOption[],
    customerEmail: string | null,
    customerId: string | null,
    shippingPostCode: string | null,
    shippingCountry: string | null,
    shippingCity: string | null,
  }): Promise<void> {

    //We want to check whether the shipping method is added at checkout and only store orders
    //when this is the case, since orders will be used to calculate pick-up rate.
    if (kvattShippingMethods === undefined || kvattShippingMethods.length === 0) {
      return;
    }

    const isShippingMethodAddedAtCheckout = await this.checkShippingMethodAddedAtCheckout({
      shopId: shopId,
      availableShippingMethodsAtCheckout: availableShippingMethodsAtCheckout,
      expectedShippingMethod: kvattShippingMethods[0],
    });

    if (isShippingMethodAddedAtCheckout === false) {
      return;
    }

    let isWithKvattShippingOption = false;

    for (const option of shippingOptions) {
      if (option.title.toLowerCase().includes(kvattShippingMethods[0].toLowerCase())) {
        isWithKvattShippingOption = true;
      }
    }

    const shopifyOrder = new ShopifyOrder({
      createdAt: createdAt,
      orderNumber: orderNumber,
      orderId: orderId,
      customerAcceptedMarketingComms,
      shippingOptions: shippingOptions,
      isWithKvattShippingOption: isWithKvattShippingOption,
      orderCurrency: orderCurrency,
      totalOrderPrice: totalOrderPrice,
      customerEmail: customerEmail,
      customerId: customerId,
      shippingPostCode: shippingPostCode,
      shippingCountry: shippingCountry,
      shippingCity: shippingCity,
    });

    await this.shopifyOrderRepo.createShopifyOrder({
      id: id,
      shopId: shopId,
      order: shopifyOrder,
    });
  }

  async retrieveShopifyOrdersForMerchant({
    merchantId,
    period,
  }: {
    merchantId: string,
    period?: Period | undefined,
  }): Promise<ShopifyOrder[] | null> {
    const store: ShopifyStore | null = await this.retrieveShopifyStoreForMerchant({
      merchantId: merchantId,
    });
    if (store === null) return null;

    return await this.shopifyOrderRepo.retrieveShopifyOrders({
      shopId: store.shopId,
      period: period,
    });
  }

  async retrieveShopifyOrderFromOrderId({
    shopId,
    orderId,
  }: {
    shopId: string,
    orderId: string,
  }): Promise<ShopifyOrder | null> {
    return await this.shopifyOrderRepo.retrieveShopifyOrdersByOrderId({
      shopId: shopId,
      orderId: orderId,
    });
  }

  async getNumberOfShopifyOrderFulfillmentsForMerchant({
    merchantId,
    datedAfter,
  }: {
    merchantId: string,
    datedAfter?: Date | undefined,
  }): Promise<number> {
    return await this.shopifyOrderFulfillmentsRepo.countShipifyOrderFulfillments({
      merchantId: merchantId,
      datedAfter: datedAfter,
    });
  }
}