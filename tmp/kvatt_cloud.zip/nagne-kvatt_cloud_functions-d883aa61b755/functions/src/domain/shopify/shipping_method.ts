export interface ShippingMethod {
  name: string;
  isActive: boolean;
}