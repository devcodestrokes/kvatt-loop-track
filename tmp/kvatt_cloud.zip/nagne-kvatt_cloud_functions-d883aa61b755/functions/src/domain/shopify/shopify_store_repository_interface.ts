import { ShopifyStore } from "./shopify_store";

export abstract class ShopifyStoreRepositoryInterface {

  abstract setMerchantId({
    shopId,
    merchantId,
  }: {
    shopId: string,
    merchantId: string,
  }): Promise<void>;

  abstract setCheckCode({
    shopId,
    code,
  }: {
    shopId: string,
    code: string,
  }): Promise<void>;

  abstract setToken({
    shopId,
    token,
  }: {
    shopId: string,
    token: string,
  }): Promise<void>;

  abstract setScopes({
    shopId,
    scopes,
  }: {
    shopId: string,
    scopes: string[],
  }): Promise<void>;

  abstract setKvattShippingMethods({
    shopId,
    shippingMethods,
  }: {
    shopId: string,
    shippingMethods: string[],
  }): Promise<void>;

  abstract setSendGenericReturnEmailNudge({
    shopId,
    sendGenericReturnEmailNudge,
  }: {
    shopId: string,
    sendGenericReturnEmailNudge: boolean,
  }): Promise<void>;

  abstract retrieveShopifyStoreByShopId({
    shopId,
  }: {
    shopId: string,
  }): Promise<ShopifyStore | null>;

  abstract retrieveShopifyStoreByMerchantId({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<ShopifyStore | null>;

  abstract retrieveShopifyStoreByCheckCode({
    checkCode,
  }: {
    checkCode: string,
  }): Promise<ShopifyStore | null>;
}