import { ShopifyOrderShippingOption } from "./shopify_order_shipping_option";

export class ShopifyOrder {
  createdAt: Date;
  orderNumber: string;
  orderId: string;
  customerAcceptedMarketingComms: boolean;
  shippingOptions: ShopifyOrderShippingOption[];
  isWithKvattShippingOption: boolean;
  orderCurrency: string;
  totalOrderPrice: string;
  customerEmail: string | null;
  customerId: string | null;
  shippingPostCode: string | null;
  shippingCountry: string | null;
  shippingCity: string | null;

  constructor({
    createdAt,
    orderNumber,
    orderId,
    customerAcceptedMarketingComms,
    shippingOptions,
    isWithKvattShippingOption,
    orderCurrency,
    totalOrderPrice,
    customerEmail,
    customerId,
    shippingPostCode,
    shippingCountry,
    shippingCity,
  }: {
    createdAt: Date,
    orderNumber: string,
    orderId: string,
    customerAcceptedMarketingComms: boolean,
    shippingOptions: ShopifyOrderShippingOption[],
    isWithKvattShippingOption: boolean,
    orderCurrency: string,
    totalOrderPrice: string,
    customerEmail: string | null,
    customerId: string | null,
    shippingPostCode: string | null,
    shippingCountry: string | null,
    shippingCity: string | null,
  }) {
    this.createdAt = createdAt;
    this.orderNumber = orderNumber;
    this.orderId = orderId;
    this.customerAcceptedMarketingComms = customerAcceptedMarketingComms;
    this.shippingOptions = shippingOptions;
    this.isWithKvattShippingOption = isWithKvattShippingOption;
    this.orderCurrency = orderCurrency;
    this.totalOrderPrice = totalOrderPrice;
    this.customerEmail = customerEmail;
    this.customerId = customerId;
    this.shippingPostCode = shippingPostCode;
    this.shippingCountry = shippingCountry;
    this.shippingCity = shippingCity;
  }
}