import { getConfigs } from "../../environments";
import { EmailClient } from "../../services/email/email_client";

export class RemindersManager {

  emailClient: EmailClient;

  constructor({
    emailClient,
  }: {
    emailClient: EmailClient,
  }) {
    this.emailClient = emailClient;
  }

  async sendStockLevelReminderIfRequired({
    emailAddress,
    productMinReminderLevel,
    productCurrentLevel,
    product,
  }: {
    emailAddress: string,
    productMinReminderLevel: number,
    productCurrentLevel: number,
    product: string,
  }): Promise<void> {
    if (productCurrentLevel <= productMinReminderLevel) {
      await this.emailClient.sendEmail({
        email: emailAddress,
        templateId: getConfigs().STOCK_LEVEL_DROP_TEMPLATE_ID,
        params: {
          minLevel: productMinReminderLevel,
          product: product,
          currentLevel: productCurrentLevel,
        },
      });
    }
  }
}