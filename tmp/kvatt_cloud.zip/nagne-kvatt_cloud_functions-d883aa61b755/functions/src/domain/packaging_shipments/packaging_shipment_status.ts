export enum PackagingShipmentStatus {
  received,
  awaitingMerchantConfirmation,
}