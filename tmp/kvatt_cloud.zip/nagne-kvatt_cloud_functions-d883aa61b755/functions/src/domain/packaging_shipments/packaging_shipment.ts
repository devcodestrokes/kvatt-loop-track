import { PackagingShipmentStatus } from "./packaging_shipment_status";

export class PackagingShipment {

  id: string;
  merchantId: string;
  packagingIds: string[];
  productQuantities: Map<string, number>;
  sentDate: Date;
  status: PackagingShipmentStatus;

  constructor({
    id,
    merchantId,
    packagingIds,
    productQuantities,
    sentDate,
    status,
  }: {
    id: string,
    merchantId: string,
    packagingIds: string[],
    productQuantities: Map<string, number>,
    sentDate: Date,
    status: PackagingShipmentStatus,
  }) {
    this.id = id;
    this.merchantId = merchantId;
    this.packagingIds = packagingIds;
    this.productQuantities = productQuantities;
    this.sentDate = sentDate;
    this.status = status;
  }
}