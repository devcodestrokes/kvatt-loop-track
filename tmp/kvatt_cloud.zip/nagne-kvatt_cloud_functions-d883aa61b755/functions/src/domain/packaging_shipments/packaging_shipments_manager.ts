import { PackagingsManager } from "../packagings/packagings_manager";
import { PackagingHistoryManager } from "../packaging_history/packaging_history_manager";
import { StocksManager } from "../stocks/stocks_manager";
import { PackagingShipment } from "./packaging_shipment";

export class PackagingShipmentsManager {

  stocksManager: StocksManager;
  packagingsManager: PackagingsManager;
  packagingsHistoryManager: PackagingHistoryManager;

  constructor({
    stocksManager,
    packagingsManager,
    packagingsHistoryManager,
  }: {
    stocksManager: StocksManager,
    packagingsManager: PackagingsManager,
    packagingsHistoryManager: PackagingHistoryManager,
  }) {
    this.stocksManager = stocksManager;
    this.packagingsManager = packagingsManager;
    this.packagingsHistoryManager = packagingsHistoryManager;
  }

  async processMerchantReceivedShipment({
    packagingShipment,
  }: {
    packagingShipment: PackagingShipment,
  }): Promise<void> {
    const tasks: Promise<void>[] = [];

    tasks.push(
      this.stocksManager.updateMerchantStocks({
        merchantId: packagingShipment.merchantId,
        productQuantities: packagingShipment.productQuantities,
      })
    );

    tasks.push(
      this.packagingsManager.trackPackagingsAsReceivedByMerchant({
        packagingIds: packagingShipment.packagingIds,
      })
    );

    tasks.push(
      this.packagingsHistoryManager.recordReceivedByMerchantHistory({
        packagingIds: packagingShipment.packagingIds,
        merchantId: packagingShipment.merchantId,
      })
    );

    await Promise.all(tasks);
  }
}