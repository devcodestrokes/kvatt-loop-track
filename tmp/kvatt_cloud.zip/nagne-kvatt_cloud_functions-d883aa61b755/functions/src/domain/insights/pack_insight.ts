export class PackInsight {
  packId: string;
  numTimesShipped: number;
  numTimesReturned: number;
  numPending: number;
  minReturnTimeInDays: number | null;
  maxReturnTimeInDays: number | null;
  averageReturnTimeInDays: number | null;
  returnDays: number[];
  lastShippedDate: Date | null;
  lastReturnedDate: Date | null;

  constructor({
    packId,
    numTimesShipped,
    numTimesReturned,
    numPending,
    minReturnTimeInDays,
    maxReturnTimeInDays,
    averageReturnTimeInDays,
    returnDays,
    lastShippedDate,
    lastReturnedDate,
  }: {
    packId: string,
    numTimesShipped: number,
    numTimesReturned: number,
    numPending: number,
    minReturnTimeInDays: number | null,
    maxReturnTimeInDays: number | null,
    averageReturnTimeInDays: number | null,
    returnDays: number[],
    lastShippedDate: Date | null,
    lastReturnedDate: Date | null;
  }) {
    this.packId = packId;
    this.numTimesShipped = numTimesShipped;
    this.numTimesReturned = numTimesReturned;
    this.numPending = numPending;
    this.minReturnTimeInDays = minReturnTimeInDays;
    this.maxReturnTimeInDays = maxReturnTimeInDays;
    this.averageReturnTimeInDays = averageReturnTimeInDays;
    this.returnDays = returnDays;
    this.lastShippedDate = lastShippedDate;
    this.lastReturnedDate = lastReturnedDate;
  }
}
