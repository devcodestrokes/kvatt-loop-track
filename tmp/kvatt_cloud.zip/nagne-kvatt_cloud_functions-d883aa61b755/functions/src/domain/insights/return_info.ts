export class ReturnInfo {
  numShipped: number;
  numReturned: number;
  numPending: number;
  maxReturnDays: number | null;
  minReturnDays: number | null;
  averageReturnDays: number | null;

  constructor({
    numShipped,
    numReturned,
    numPending,
    maxReturnDays,
    minReturnDays,
    averageReturnDays,
  }: {
    numShipped: number,
    numReturned: number,
    numPending: number,
    maxReturnDays: number | null,
    minReturnDays: number | null,
    averageReturnDays: number | null,
  }) {
    this.numShipped = numShipped;
    this.numReturned = numReturned;
    this.numPending = numPending;
    this.maxReturnDays = maxReturnDays;
    this.minReturnDays = minReturnDays;
    this.averageReturnDays = averageReturnDays;
  }

  getReturnRate(): number | null {
    if (this.numShipped === 0 || this.numReturned > (this.numShipped - this.numPending)) {
      return null;
    } else {
      if ((this.numShipped - this.numPending) <= 0) {
        return null;
      }
      return (this.numReturned / (this.numShipped - this.numPending));
    }
  }

  getNumLost(): number {
    return this.numShipped - this.numReturned - this.numPending;
  }

  toString(): string {
    return `numShipped: ${this.numShipped}, numReturned: ${this.numReturned}, numPending: ${this.numPending}`;
  }
}