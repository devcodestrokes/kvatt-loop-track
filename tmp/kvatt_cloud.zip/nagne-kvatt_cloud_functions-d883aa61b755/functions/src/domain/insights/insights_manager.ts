import { TimeUtils } from "../../utils/time_utils";
import { Period } from "../common/period";
import { ShopifyManager } from "../shopify/shopify_manager";
import { ShopifyOrder } from "../shopify/shopify_order";
import { TrackingEvent } from "../tracking/tracking_event";
import { TrackingHistory } from "../tracking/tracking_history";
import { TrackingManager } from "../tracking/tracking_manager";
import { TrackingSource } from "../tracking/tracking_source";
import { CheckoutPickUpInfo } from "./checkout_pick_up_info";
import { PackInsight } from "./pack_insight";
import { ReturnInfo } from "./return_info";

export class InsightsManager {


  readonly PLATFORM_START_DATE: Date = new Date(2022, 9, 1); //NOTE: 01 Oct 2022
  readonly defaultReturnGracePeriodInDays: number = 14;

  trackingManager: TrackingManager;
  shopifyManager: ShopifyManager;

  constructor({
    trackingManager,
    shopifyManager,
  }: {
    trackingManager: TrackingManager,
    shopifyManager: ShopifyManager,
  }) {
    this.trackingManager = trackingManager;
    this.shopifyManager = shopifyManager;
  }

  async getMerchantCheckoutPickUpInfo({
    merchantId,
    period,
  }: {
    merchantId: string,
    period?: Period | undefined,

  }): Promise<CheckoutPickUpInfo | null> {
    let activePeriod: Period;
    if (period === undefined) {
      activePeriod = new Period({
        start: this.PLATFORM_START_DATE,
        end: new Date(),
      });
    } else {
      activePeriod = new Period({
        start: period.start,
        //Ensure that we include until the end of the day
        end: new Date(
          period.end.getFullYear(),
          period.end.getMonth(),
          period.end.getDate(),
          23,
          59,
          59,
        ),
      });
    }

    const orders: ShopifyOrder[] | null = await this.shopifyManager.retrieveShopifyOrdersForMerchant({
      merchantId: merchantId,
      period: activePeriod,
    });

    if (orders === null) return null;

    const totalOrders = orders.length;
    let ordersWithKvattPack = 0;

    for (const order of orders) {
      if (order.isWithKvattShippingOption) {
        ordersWithKvattPack++;
      }
    }

    return new CheckoutPickUpInfo({
      totalOrders: totalOrders,
      numOrdersWithKvattPack: ordersWithKvattPack,
    });
  }

  async getMerchantReturnInfo({
    merchantId,
    trackingSource,
    period,
    today,
  }: {
    merchantId: string,
    trackingSource: TrackingSource | null,
    period?: Period,
    today?: Date,
  }): Promise<ReturnInfo> {
    let todayDate: Date;
    if (today === undefined) {
      todayDate = new Date();
    } else {
      todayDate = today;
    }

    let activePeriod: Period;

    if (period === undefined) {
      activePeriod = new Period({
        start: this.PLATFORM_START_DATE,
        end: new Date(),
      });
    } else {
      activePeriod = period;
    }

    switch (trackingSource) {
      case TrackingSource.kvattApp:
        return this.getReturnInfoWithKvattAppTracking({
          merchantId: merchantId,
          period: activePeriod,
          today: todayDate,
        });
      case TrackingSource.shopify:
        return this.getReturnInfoWithShopifyTracking({
          merchantId: merchantId,
          today: todayDate,
        });
      default:
        return this.getReturnInfoWithNoTracking({
          merchantId: merchantId,
          period: activePeriod,
          today: todayDate,
        });
    }
  }

  async getMerchantPacksInsights({
    merchantId,
    trackingSource,
    period,
    today,
  }: {
    merchantId: string,
    trackingSource: TrackingSource | null,
    period?: Period | undefined,
    today?: Date | undefined,
  }): Promise<PackInsight[]> {
    let todayDate: Date;
    if (today === undefined) {
      todayDate = new Date();
    } else {
      todayDate = today;
    }

    let activePeriod: Period;

    if (period === undefined) {
      activePeriod = new Period({
        start: this.PLATFORM_START_DATE,
        end: new Date(),
      });
    } else {
      activePeriod = period;
    }

    switch (trackingSource) {
      case TrackingSource.kvattApp:
        return this.getPackInsightsWithKvattAppTracking({
          merchantId: merchantId,
          period: activePeriod,
          today: todayDate,
        });
      case TrackingSource.shopify:
        return [];
      default:
        return this.getPackInsightsWithNoTracking({
          merchantId: merchantId,
          period: activePeriod,
          today: todayDate,
        });
    }
  }

  getPackInsightFromTrackingHistory({
    packId,
    trackingHistories,
    period,
    today,
    hasMerchantTracking = true,
  }: {
    packId: string,
    trackingHistories: TrackingHistory[],
    period: Period,
    today: Date,
    hasMerchantTracking?: boolean,
  }): PackInsight {
    trackingHistories.sort((a: TrackingHistory, b: TrackingHistory) => { return a.date.getTime() - b.date.getTime() });

    if (hasMerchantTracking === true) {
      return this.getPackInsightFromTrackingHistoryWithMerchantTracking({
        trackingHistories: trackingHistories,
        period: period,
        packId: packId,
        today: today,
      });
    } else {
      return this.getPackInsightFromTrackingHistoryWithNoTracking({
        trackingHistories: trackingHistories,
        period: period,
        packId: packId,
        today: today,
      });
    }
  }

  private async getPackInsightsWithKvattAppTracking({
    merchantId,
    period,
    today,
  }: {
    merchantId: string,
    period: Period,
    today: Date,
  }): Promise<PackInsight[]> {

    const packHistories: Map<string, any[]> = await this.getPackHistoriesWithKvattAppTracking({
      merchantId: merchantId,
      period: period,
      today: today,
    });

    const packInsights: PackInsight[] = [];

    for (const [packId, histories] of packHistories) {
      const packInsight: PackInsight = this.getPackInsightFromTrackingHistory({
        packId: packId,
        trackingHistories: histories,
        period: period,
        hasMerchantTracking: true,
        today: today,
      });
      packInsights.push(packInsight);
    }

    return packInsights;
  }

  private async getPackInsightsWithNoTracking({
    merchantId,
    period,
    today,
  }: {
    merchantId: string,
    period: Period,
    today: Date,
  }): Promise<PackInsight[]> {

    const packHistories: Map<string, any[]> = await this.getPackHistoriesWithNoTracking({
      merchantId: merchantId,
      period: period,
      today: today,
    });

    const packInsights: PackInsight[] = [];

    for (const [packId, histories] of packHistories) {
      const packInsight: PackInsight = this.getPackInsightFromTrackingHistory({
        packId: packId,
        trackingHistories: histories,
        period: period,
        hasMerchantTracking: false,
        today: today,
      });
      packInsights.push(packInsight);
    }

    return packInsights;
  }

  private getPackInsightFromTrackingHistoryWithMerchantTracking({
    trackingHistories,
    period,
    packId,
    today,
  }: {
    trackingHistories: TrackingHistory[],
    period: Period,
    packId: string,
    today: Date,
  }): PackInsight {
    const returnDays: number[] = [];
    let sentDate: Date | null = null;

    let isWithCustomer: boolean = false;
    let numShipped: number = 0;
    let numReturns: number = 0;
    let numPending: number = 0;

    let lastShippedDate: Date | null = null;
    let lastReturnedDate: Date | null = null;

    for (const history of trackingHistories) {
      if (history.date < period.start) {
        continue;
      }
      switch (history.event) {
        case TrackingEvent.receivedByMerchant:
        case TrackingEvent.shippedToMerchant:
        case TrackingEvent.sentToMaintenance:
        case TrackingEvent.outOfMaintenance:
          break;
        case TrackingEvent.returnedFromCustomer:
        case TrackingEvent.returnedToKvattNeedsMaintenance:
        case TrackingEvent.returnedToKvattNoMaintenance:
        case TrackingEvent.returnedToKvatt:
          if (isWithCustomer === true) {
            if (numPending > 0) {
              numPending--;
            }
            numReturns++;
            lastReturnedDate = history.date;
            isWithCustomer = false;
            if (sentDate !== null) {
              const diffDays = TimeUtils.getDifferenceInDays({
                date1: history.date,
                date2: sentDate,
              });
              returnDays.push(diffDays);
            }
            sentDate = null;
          }
          break;
        case TrackingEvent.shippedToCustomer:
          sentDate = history.date;
          lastShippedDate = history.date;
          numShipped++;
          if (TimeUtils.getDifferenceInDays({
            date1: today,
            date2: history.date
          }) <= this.defaultReturnGracePeriodInDays) {
            numPending++;
          }
          isWithCustomer = true;
          break;
      }
    }

    const maxDays = returnDays.length === 0 ? null : returnDays.reduce(function (prev, current) {
      return (prev && prev > current) ? prev : current
    });

    const minDays = returnDays.length === 0 ? null : returnDays.reduce(function (prev, current) {
      return (prev && prev < current) ? prev : current
    });

    return new PackInsight({
      packId: packId,
      numTimesShipped: numShipped,
      numTimesReturned: numReturns,
      numPending: numPending,
      minReturnTimeInDays: minDays,
      maxReturnTimeInDays: maxDays,
      averageReturnTimeInDays: this.computeAverageReturnDays({
        returnDays: returnDays,
      }),
      returnDays: returnDays,
      lastReturnedDate: lastReturnedDate,
      lastShippedDate: lastShippedDate,
    });
  }

  private getPackInsightFromTrackingHistoryWithNoTracking({
    trackingHistories,
    period,
    packId,
    today,
  }: {
    trackingHistories: TrackingHistory[],
    period: Period,
    packId: string,
    today: Date,
  }): PackInsight {
    const returnDays: number[] = [];
    let sentDate: Date | null = null;

    let isWithMerchant: boolean = false;
    let numShipped: number = 0;
    let numReturns: number = 0;
    let numPending: number = 0;

    let lastShippedDate: Date | null = null;
    let lastReturnedDate: Date | null = null;

    for (const history of trackingHistories) {
      if (history.date < period.start) {
        continue;
      }
      switch (history.event) {
        case TrackingEvent.receivedByMerchant:
        case TrackingEvent.sentToMaintenance:
        case TrackingEvent.outOfMaintenance:
        case TrackingEvent.shippedToCustomer:
        case TrackingEvent.returnedFromCustomer:
          break;
        case TrackingEvent.returnedToKvattNeedsMaintenance:
        case TrackingEvent.returnedToKvattNoMaintenance:
        case TrackingEvent.returnedToKvatt:
          if (isWithMerchant === true) {
            if (numPending > 0) {
              numPending--;
            }
            numReturns++;
            lastReturnedDate = history.date;
            isWithMerchant = false;
            if (sentDate !== null) {
              const diffDays = TimeUtils.getDifferenceInDays({
                date1: history.date,
                date2: sentDate,
              });
              returnDays.push(diffDays);
            }
            sentDate = null;
          }
          break;
        case TrackingEvent.shippedToMerchant:
          sentDate = history.date;
          lastShippedDate = history.date;
          numShipped++;
          if (TimeUtils.getDifferenceInDays({
            date1: today,
            date2: history.date
          }) <= this.defaultReturnGracePeriodInDays) {
            numPending++;
          }
          isWithMerchant = true;
          break;
      }
    }

    const maxDays = returnDays.length === 0 ? null : returnDays.reduce(function (prev, current) {
      return (prev && prev > current) ? prev : current
    });

    const minDays = returnDays.length === 0 ? null : returnDays.reduce(function (prev, current) {
      return (prev && prev < current) ? prev : current
    });

    return new PackInsight({
      packId: packId,
      numTimesShipped: numShipped,
      numTimesReturned: numReturns,
      numPending: numPending,
      minReturnTimeInDays: minDays,
      maxReturnTimeInDays: maxDays,
      averageReturnTimeInDays: this.computeAverageReturnDays({
        returnDays: returnDays,
      }),
      returnDays: returnDays,
      lastReturnedDate: lastReturnedDate,
      lastShippedDate: lastShippedDate,
    });
  }


  private computeAverageReturnDays({
    returnDays,
  }: {
    returnDays: number[],
  }): number | null {
    if (returnDays.length === 0) {
      return null;
    }

    let count = 0;
    for (const days of returnDays) {
      count += days;
    }

    return count / returnDays.length;
  }

  private async getReturnInfoWithShopifyTracking({
    merchantId,
    today,
  }: {
    merchantId: string,
    today: Date,
  }): Promise<ReturnInfo> {
    const numShipped: number = await this.shopifyManager.getNumberOfShopifyOrderFulfillmentsForMerchant({
      merchantId: merchantId,
    });

    const numPending: number = await this.shopifyManager.getNumberOfShopifyOrderFulfillmentsForMerchant({
      merchantId: merchantId,
      datedAfter: TimeUtils.subtractDaysFromDate({
        date: today,
        numDays: this.defaultReturnGracePeriodInDays,
      }),
    });

    const numReturned: number = await this.trackingManager.getReturnedToKvattTrackingHistoriesCount({
      merchantId: merchantId,
    });

    return new ReturnInfo({
      numShipped: numShipped,
      numReturned: numReturned,
      numPending: numPending,
      maxReturnDays: null,
      minReturnDays: null,
      averageReturnDays: null,
    });
  }

  private async getPackHistoriesWithKvattAppTracking({
    merchantId,
    period,
    today,
  }: {
    merchantId: string,
    period: Period,
    today: Date,
  }): Promise<Map<string, any[]>> {
    const shippedToCustomerHistories: TrackingHistory[] = await this.trackingManager.getShippedToCustomerTrackingHistories({
      merchantId: merchantId,
      period: period,
    });

    const returnedFromCustomerHistories: TrackingHistory[] = await this.trackingManager.getReturnedFromCustomerTrackingHistories({
      merchantId: merchantId,
      period: new Period({
        start: period.start,
        end: today
      }),
    });

    const returnedToKvattHistories: TrackingHistory[] = await this.trackingManager.getReturnedToKvattTrackingHistories({
      merchantId: merchantId,
      period: new Period({
        start: period.start,
        end: today,
      }),
    });

    const packHistories: Map<string, any[]> = new Map<string, any[]>();

    for (const history of shippedToCustomerHistories) {
      if (packHistories.get(history.packId) !== undefined) {
        packHistories.set(
          history.packId,
          [
            ...packHistories.get(history.packId)!,
            ...[history],
          ],
        );
      } else {
        packHistories.set(history.packId, [history]);
      }
    }

    for (const history of returnedFromCustomerHistories) {
      if (packHistories.get(history.packId) !== undefined) {
        packHistories.set(
          history.packId,
          [
            ...packHistories.get(history.packId)!,
            ...[history],
          ],
        );
      } else {
        packHistories.set(history.packId, [history]);
      }
    }

    for (const history of returnedToKvattHistories) {
      if (packHistories.get(history.packId) !== undefined) {
        packHistories.set(
          history.packId,
          [
            ...packHistories.get(history.packId)!,
            ...[history],
          ],
        );
      } else {
        packHistories.set(history.packId, [history]);
      }
    }

    return packHistories;
  }

  private async getPackHistoriesWithNoTracking({
    merchantId,
    period,
    today,
  }: {
    merchantId: string,
    period: Period,
    today: Date,
  }): Promise<Map<string, any[]>> {

    const shippedToMerchantHistories: TrackingHistory[] = await this.trackingManager.getShippedToMerchantTrackingHistories({
      merchantId: merchantId,
      period: period,
    });

    const returnedToKvattHistories: TrackingHistory[] = await this.trackingManager.getReturnedToKvattTrackingHistories({
      merchantId: merchantId,
      period: new Period({
        start: period.start,
        end: today,
      }),
    });

    const packHistories: Map<string, any[]> = new Map<string, any[]>();

    for (const history of shippedToMerchantHistories) {
      if (packHistories.get(history.packId) !== undefined) {
        packHistories.set(
          history.packId,
          [
            ...packHistories.get(history.packId)!,
            ...[history],
          ],
        );
      } else {
        packHistories.set(history.packId, [history]);
      }
    }

    for (const history of returnedToKvattHistories) {
      if (packHistories.get(history.packId) !== undefined) {
        packHistories.set(
          history.packId,
          [
            ...packHistories.get(history.packId)!,
            ...[history],
          ],
        );
      } else {
        packHistories.set(history.packId, [history]);
      }
    }

    return packHistories;
  }

  private async getReturnInfoWithKvattAppTracking({
    merchantId,
    period,
    today,
  }: {
    merchantId: string,
    period: Period,
    today: Date,
  }): Promise<ReturnInfo> {

    const packHistories: Map<string, any[]> = await this.getPackHistoriesWithKvattAppTracking({
      merchantId: merchantId,
      period: period,
      today: today,
    });

    return this.getReturnInfoForPeriodFromPackHistories({
      packHistories: packHistories,
      period: period,
      hasMerchantTracking: true,
      today: today,
    });

  }

  private async getReturnInfoWithNoTracking({
    merchantId,
    period,
    today,
  }: {
    merchantId: string,
    period: Period,
    today: Date,
  }): Promise<ReturnInfo> {
    const packHistories: Map<string, any[]> = await this.getPackHistoriesWithNoTracking({
      merchantId: merchantId,
      period: period,
      today: today,
    });

    return this.getReturnInfoForPeriodFromPackHistories({
      packHistories: packHistories,
      period: period,
      hasMerchantTracking: false,
      today: today,
    });
  }

  private getReturnInfoForPeriodFromPackHistories({
    packHistories,
    period,
    hasMerchantTracking,
    today,
  }: {
    packHistories: Map<string, any[]>,
    period: Period,
    hasMerchantTracking: boolean,
    today: Date,
  }) {
    let totalShipped: number = 0;
    let totalReturned: number = 0;
    let totalPending: number = 0;
    let maxReturnDays: number | null = null;
    let minReturnDays: number | null = null;

    const allReturnDays: number[] = [];

    for (const [packId, histories] of packHistories) {
      const packInsight: PackInsight = this.getPackInsightFromTrackingHistory({
        packId: packId,
        trackingHistories: histories,
        period: period,
        hasMerchantTracking: hasMerchantTracking,
        today: today,
      });
      totalReturned += packInsight.numTimesReturned;
      totalShipped += packInsight.numTimesShipped;
      totalPending += packInsight.numPending;
      if (maxReturnDays === null) {
        maxReturnDays = packInsight.maxReturnTimeInDays;
      } else {
        if (packInsight.maxReturnTimeInDays !== null && (packInsight.maxReturnTimeInDays > maxReturnDays)) {
          maxReturnDays = packInsight.maxReturnTimeInDays;
        }
      }
      if (minReturnDays === null) {
        if (packInsight.minReturnTimeInDays !== 0) {
          minReturnDays = packInsight.minReturnTimeInDays;
        }
      } else {
        if (packInsight.minReturnTimeInDays !== null && packInsight.minReturnTimeInDays !== 0 && (packInsight.minReturnTimeInDays < minReturnDays)) {
          minReturnDays = packInsight.minReturnTimeInDays;
        }
      }
      for (const day of packInsight.returnDays) {
        if (day !== 0) {
          allReturnDays.push(day);
        }
      }
    }

    const overallAverageReturnDays: number | null = this.computeAverageReturnDays({
      returnDays: allReturnDays,
    })

    return new ReturnInfo({
      numShipped: totalShipped,
      numReturned: totalReturned,
      numPending: totalPending,
      maxReturnDays: maxReturnDays,
      minReturnDays: minReturnDays,
      averageReturnDays: overallAverageReturnDays,
    });
  }
}