export class CheckoutPickUpInfo {
  totalOrders: number;
  numOrdersWithKvattPack: number;

  constructor({
    totalOrders,
    numOrdersWithKvattPack,
  }: {
    totalOrders: number,
    numOrdersWithKvattPack: number,
  }) {
    this.totalOrders = totalOrders;
    this.numOrdersWithKvattPack = numOrdersWithKvattPack;
  }

  getPickUpRate(): number | null {
    if (this.totalOrders === 0) return null;
    return this.numOrdersWithKvattPack / this.totalOrders;
  }
}