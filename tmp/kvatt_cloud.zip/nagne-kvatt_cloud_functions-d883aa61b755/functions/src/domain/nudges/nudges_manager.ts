import { getConfigs, getEnvironment } from "../../environments";
import { NudgeRecordRepository } from "../../features/nudges/data/nudge_record_repository";
import { EmailClient } from "../../services/email/email_client";
import { SentryClient } from "../../services/error_logging/sentry_client";
import { TimeUtils } from "../../utils/time_utils";
import { PackagingStatus } from "../packagings/packaging_status";
import { InvalidNudgeError } from "./common/errors";
import { Nudge } from "./nudge";
import { NudgeRecord } from "./nudge_record";
import { NudgeRecordRepositoryInterface } from "./nudge_record_repository_interface";
import { NudgeType } from "./nudge_type";
import { NudgesRepositoryInterface } from "./nudges_repository_interface";
import { ReturnReminderNudge } from "./return_reminder_nudge";
import { ReturnReminderNudgesRepositoryInterface } from "./return_reminder_nudges_repository_interface";

export class NudgesManager {

  private readonly RETURN_REMINDER_DEFAULT_FREQUENCY_DAYS: number = 21;
  private readonly RETURN_REMINDER_DEFAULT_MAX_TIMES_SENT: number = 2;
  private readonly NUDGES_INTERVAL_DAYS: number = 30;
  private readonly RETURN_NUDGE_EMAIl_DELAY_DAYS: number = 5;

  returnReminderNudgesRepo: ReturnReminderNudgesRepositoryInterface;
  nudgeRecordRepo: NudgeRecordRepository;
  nudgesRepo: NudgesRepositoryInterface;
  emailClient: EmailClient;

  constructor({
    returnReminderNudgesRepo,
    nudgeRecordRepo,
    nudgesRepo,
    emailClient,
  }: {
    returnReminderNudgesRepo: ReturnReminderNudgesRepositoryInterface,
    nudgeRecordRepo: NudgeRecordRepositoryInterface,
    nudgesRepo: NudgesRepositoryInterface,
    emailClient: EmailClient,
  }) {
    this.returnReminderNudgesRepo = returnReminderNudgesRepo;
    this.nudgeRecordRepo = nudgeRecordRepo;
    this.nudgesRepo = nudgesRepo;
    this.emailClient = emailClient;
  }

  async scheduleReturnNudge({
    customerEmail,
    merchantName,
  }: {
    customerEmail: string,
    merchantName: string,
  }): Promise<void> {
    const sendDate = new Date();
    sendDate.setDate(sendDate.getDate() + this.RETURN_NUDGE_EMAIl_DELAY_DAYS);
    await this.nudgesRepo.setNudge({
      nudge: new Nudge({
        nudgeType: NudgeType.returnNudgeEmail,
        sendDate: sendDate,
        merchantName: merchantName,
        customerEmail: customerEmail,
      }),
    });
  }

  async checkAndSendReturnNudges() {
    const date: Date = new Date();
    const nudgesToBeSent: Nudge[] = await this.nudgesRepo.retrieveNudges({
      dateBefore: date,
    });

    const sendEmailTasks = [];
    const deleteNudgeTasks = [];

    for (const nudge of nudgesToBeSent) {
      try {
        if (nudge.nudgeType !== NudgeType.returnNudgeEmail) continue;
        sendEmailTasks.push(this.emailClient.sendEmail({
          email: nudge.customerEmail!,
          templateId: getConfigs().RETURN_REMINDER_NUDGE_SIB_TEMPLATE_ID,
          params: {
            merchantName: nudge.merchantName,
          },
        }));
        deleteNudgeTasks.push(this.nudgesRepo.deleteNudge({
          id: nudge.id!,
        }));
      } catch (e) {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(
          new InvalidNudgeError(
            'InvalidNudgeError',
            nudge.id,
          ),
          '',
          {
            'nudgeId': nudge.id,
            'message': 'InvalidNudgeError',
          });
      }
    }
    await Promise.all(sendEmailTasks);
    await Promise.all(deleteNudgeTasks);
  }

  async initialiseNudgesReminderForPackSentToCustomer({
    packId,
    merchantId,
    orderNumber,
  }: {
    packId: string,
    merchantId: string,
    orderNumber: string,
  }): Promise<void> {
    const nextSendDate = new Date();
    nextSendDate.setDate(nextSendDate.getDate() + this.RETURN_REMINDER_DEFAULT_FREQUENCY_DAYS);
    const returnReminderNudge = new ReturnReminderNudge({
      packId: packId,
      merchantId: merchantId,
      orderNumber: orderNumber,
      nextSendDate: nextSendDate,
      numTimesSent: 0,
    });

    await this.returnReminderNudgesRepo.updateReturnReminder({
      returnReminder: returnReminderNudge,
    });
  }

  async extendReturnReminderNudge({
    returnReminderNudge,
  }: {
    returnReminderNudge: ReturnReminderNudge,
  }): Promise<void> {
    const nextSendDate = new Date();
    nextSendDate.setDate(nextSendDate.getDate() + this.NUDGES_INTERVAL_DAYS);
    const extendedReturnReminderNudge = new ReturnReminderNudge({
      packId: returnReminderNudge.packId,
      merchantId: returnReminderNudge.merchantId,
      orderNumber: returnReminderNudge.orderNumber,
      nextSendDate: nextSendDate,
      numTimesSent: returnReminderNudge.numTimesSent,
    });
    await this.returnReminderNudgesRepo.updateReturnReminder({
      returnReminder: extendedReturnReminderNudge,
    });
  }

  async updateReturnReminderNudgeSent({
    returnReminderNudge,
  }: {
    returnReminderNudge: ReturnReminderNudge,
  }): Promise<void> {
    if (returnReminderNudge.numTimesSent === this.RETURN_REMINDER_DEFAULT_MAX_TIMES_SENT - 1) {
      await this.returnReminderNudgesRepo.deleteReturnReminder({
        packId: returnReminderNudge.packId,
      });
    } else {
      const nextSendDate = new Date();
      nextSendDate.setDate(nextSendDate.getDate() + this.RETURN_REMINDER_DEFAULT_FREQUENCY_DAYS);
      const updatedReturnReminderNudge = new ReturnReminderNudge({
        packId: returnReminderNudge.packId,
        merchantId: returnReminderNudge.merchantId,
        orderNumber: returnReminderNudge.orderNumber,
        nextSendDate: nextSendDate,
        numTimesSent: (returnReminderNudge.numTimesSent! + 1),
      });
      await this.returnReminderNudgesRepo.updateReturnReminder({
        returnReminder: updatedReturnReminderNudge,
      });
    }
  }

  async clearReturnReminderNudge({
    packId,
  }: {
    packId: string,
  }): Promise<void> {
    await this.returnReminderNudgesRepo.deleteReturnReminder({
      packId: packId,
    });
  }

  async retrieveRemindersToBeSent(): Promise<ReturnReminderNudge[]> {
    const sentBeforeDate = new Date();
    return await this.returnReminderNudgesRepo.retrieveReturnReminders({
      nextSendDateBefore: sentBeforeDate,
    });
  }

  async setThankYouRecord({
    merchantId,
    customerId,
  }: {
    merchantId: string,
    customerId: string,
  }) {
    await this.nudgeRecordRepo.setRecord({
      record: new NudgeRecord({
        recordId: `${merchantId}-${customerId}`,
        lastSentDate: new Date(),
        nudgeType: NudgeType.thankYouEmail,
      }),
    });
  }

  async setReminderRecord({
    merchantId,
    customerId,
  }: {
    merchantId: string,
    customerId: string,
  }) {
    await this.nudgeRecordRepo.setRecord({
      record: new NudgeRecord({
        recordId: `${merchantId}-${customerId}`,
        lastSentDate: new Date(),
        nudgeType: NudgeType.reminderEmail,
      }),
    });
  }

  async hasSentNudgeRecently({
    merchantId,
    customerId,
  }: {
    merchantId: string,
    customerId: string,
  }): Promise<boolean> {
    const nudgeRecord: NudgeRecord | null = await this.nudgeRecordRepo.retrieveRecord({
      recordId: `${merchantId}-${customerId}`,
    });

    if (nudgeRecord === null) {
      return false;
    }

    const interval: number = TimeUtils.getDifferenceInDays({
      date1: nudgeRecord.lastSentDate,
      date2: new Date(),
    });

    if ((interval < this.NUDGES_INTERVAL_DAYS)) {
      return true;
    }

    return false;
  }

  async shouldSendPackReturnThankYouMessage({
    previousPackStatus,
    newPackStatus,
  }: {
    previousPackStatus: PackagingStatus,
    newPackStatus: PackagingStatus,
  }): Promise<boolean> {
    if (previousPackStatus === PackagingStatus.withCustomer && newPackStatus === PackagingStatus.withMerchantReturned) {
      return true;
    }

    if (previousPackStatus === PackagingStatus.withCustomer && newPackStatus === PackagingStatus.inStoreReturned) {
      return true;
    }

    return false;
  }
}