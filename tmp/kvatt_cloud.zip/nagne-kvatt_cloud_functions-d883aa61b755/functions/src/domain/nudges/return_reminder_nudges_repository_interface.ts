import { ReturnReminderNudge } from "./return_reminder_nudge";

export abstract class ReturnReminderNudgesRepositoryInterface {

	abstract retrieveReturnReminders({
		nextSendDateBefore,
	}: {
		nextSendDateBefore: Date,
	}): Promise<ReturnReminderNudge[]>;

	abstract updateReturnReminder({
		returnReminder,
	}: {
		returnReminder: ReturnReminderNudge,
	}): Promise<void>;

	abstract deleteReturnReminder({
		packId,
	}: {
		packId: string,
	}): Promise<void>;
}