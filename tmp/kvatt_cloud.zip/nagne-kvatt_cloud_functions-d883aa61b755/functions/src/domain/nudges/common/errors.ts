export class InvalidNudgeError extends Error {
  nudgeId?: string | undefined;
  message: string;
  constructor(
    message: string,
    nudgeId?: string | undefined,
  ) {
    super();
    this.nudgeId = nudgeId;
    this.message = message;
  }
}

