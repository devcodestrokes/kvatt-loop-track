import { NudgeRecord } from "./nudge_record";

export abstract class NudgeRecordRepositoryInterface {

  abstract setRecord({
    record,
  }: {
    record: NudgeRecord,
  }): Promise<void>;

  abstract retrieveRecord({
    recordId,
  }: {
    recordId: string,
  }): Promise<NudgeRecord | null>;

}