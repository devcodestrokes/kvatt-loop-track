import { Nudge } from "./nudge";

export abstract class NudgesRepositoryInterface {

  abstract setNudge({
    nudge,
  }: {
    nudge: Nudge,
  }): Promise<void>;

  abstract retrieveNudges({
    dateBefore,
  }: {
    dateBefore: Date,
  }): Promise<Nudge[]>;

  abstract deleteNudge({
    id,
  }: {
    id: string,
  }): Promise<void>;
}