export enum NudgeType {
  reminderEmail,
  thankYouEmail,
  returnNudgeEmail,
}