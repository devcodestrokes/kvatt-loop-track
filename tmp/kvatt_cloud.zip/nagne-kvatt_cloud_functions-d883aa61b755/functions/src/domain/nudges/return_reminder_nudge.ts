export class ReturnReminderNudge {

  packId: string;
  merchantId: string;
  orderNumber: string;
  nextSendDate?: Date | null;
  numTimesSent?: number | null;

  constructor({
    packId,
    merchantId,
    orderNumber,
    nextSendDate,
    numTimesSent,
  }: {
    packId: string,
    merchantId: string,
    orderNumber: string,
    nextSendDate?: Date | null;
    numTimesSent?: number | null;
  }) {
    this.packId = packId;
    this.merchantId = merchantId;
    this.orderNumber = orderNumber;
    this.nextSendDate = nextSendDate;
    this.numTimesSent = numTimesSent;
  }
}
