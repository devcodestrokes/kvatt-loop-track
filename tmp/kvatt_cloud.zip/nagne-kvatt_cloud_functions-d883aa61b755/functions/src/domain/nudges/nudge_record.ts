import { NudgeType } from "./nudge_type";

export class NudgeRecord {

  recordId: string;
  lastSentDate: Date;
  nudgeType: NudgeType;

  constructor({
    recordId,
    lastSentDate,
    nudgeType,
  }: {
    recordId: string,
    lastSentDate: Date,
    nudgeType: NudgeType,
  }) {
    this.recordId = recordId;
    this.lastSentDate = lastSentDate;
    this.nudgeType = nudgeType;
  }
}