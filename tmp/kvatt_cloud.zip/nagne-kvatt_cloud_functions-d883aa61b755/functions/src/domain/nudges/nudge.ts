import { NudgeType } from "./nudge_type";

export class Nudge {

  id?: string | undefined;
  nudgeType: NudgeType;
  sendDate: Date;
  merchantName: string;
  customerEmail?: string | undefined;

  constructor({
    id,
    nudgeType,
    sendDate,
    merchantName,
    customerEmail,
  }: {
    id?: string | undefined,
    nudgeType: NudgeType,
    sendDate: Date,
    merchantName: string,
    customerEmail?: string | undefined;
  }) {
    this.id = id;
    this.nudgeType = nudgeType;
    this.sendDate = sendDate;
    this.merchantName = merchantName;
    this.customerEmail = customerEmail;
  }
}