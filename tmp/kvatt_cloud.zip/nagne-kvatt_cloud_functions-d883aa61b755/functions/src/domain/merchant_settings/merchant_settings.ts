import { StockLevelReminderSetting } from "./stock_level_reminder_setting";

export class MerchantSettings {

  stockLevelReminderSettings: StockLevelReminderSetting[];

  constructor({
    stockLevelReminderSettings,
  }: {
    stockLevelReminderSettings: StockLevelReminderSetting[],
  }) {
    this.stockLevelReminderSettings = stockLevelReminderSettings;
  }
}