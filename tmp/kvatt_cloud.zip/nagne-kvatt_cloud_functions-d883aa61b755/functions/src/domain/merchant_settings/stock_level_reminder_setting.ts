export class StockLevelReminderSetting {
  product: string;
  minLevel: number;

  constructor({
    product,
    minLevel,
  }: {
    product: string,
    minLevel: number,
  }) {
    this.product = product;
    this.minLevel = minLevel;
  }
}