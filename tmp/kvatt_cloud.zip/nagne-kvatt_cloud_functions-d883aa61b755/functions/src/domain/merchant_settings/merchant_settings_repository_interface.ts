import { MerchantSettings } from "./merchant_settings";

export abstract class MerchantSettingsRepositoryInterface {

  abstract getMerchantSettings({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<MerchantSettings | null>;
}