import { TrackingEvent } from "./tracking_event";

export class TrackingHistory {
  packId: string;
  date: Date;
  event: TrackingEvent;
  trackedByUserId: string;
  merchantId?: string;
  merchantName?: string;
  customerName?: string;
  orderNumber?: string;

  constructor({
    packId,
    date,
    event,
    trackedByUserId,
    merchantId,
    merchantName,
    customerName,
    orderNumber,
  }: {
    packId: string,
    date: Date,
    event: TrackingEvent,
    trackedByUserId: string,
    merchantId?: string,
    merchantName?: string,
    customerName?: string,
    orderNumber?: string,
  }) {
    this.packId = packId;
    this.date = date;
    this.event = event;
    this.trackedByUserId = trackedByUserId;
    this.merchantId = merchantId;
    this.merchantName = merchantName;
    this.customerName = customerName;
    this.orderNumber = orderNumber;
  }
}
