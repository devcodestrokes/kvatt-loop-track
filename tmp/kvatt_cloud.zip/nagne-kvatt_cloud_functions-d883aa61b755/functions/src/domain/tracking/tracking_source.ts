export enum TrackingSource {
  kvattApp,
  shopify,
}