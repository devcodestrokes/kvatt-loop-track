import { Period } from "../common/period";
import { TrackingEvent } from "./tracking_event";
import { TrackingHistory } from "./tracking_history";

export abstract class TrackingHistoryRepositoryInterface {

  abstract getTrackingHistories({
    merchantId,
    event,
    period,
  }: {
    merchantId: string,
    event: TrackingEvent,
    period: Period,
  }): Promise<TrackingHistory[]>;

  abstract getTrackingHistoriesCount({
    merchantId,
    event,
    period,
  }: {
    merchantId: string,
    event: TrackingEvent,
    period?: Period | undefined,
  }): Promise<number>;
}