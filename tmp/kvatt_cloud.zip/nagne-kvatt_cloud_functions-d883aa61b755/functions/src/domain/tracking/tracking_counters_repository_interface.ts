import { TrackingEvent } from "./tracking_event";

export abstract class TrackingCountersRepositoryInterface {

  abstract incrementTrackingCounter({
    userId,
    trackingEvent,
    numPacksTracked,
  }: {
    userId: string,
    trackingEvent: TrackingEvent,
    numPacksTracked: number,
  }): Promise<void>;
}