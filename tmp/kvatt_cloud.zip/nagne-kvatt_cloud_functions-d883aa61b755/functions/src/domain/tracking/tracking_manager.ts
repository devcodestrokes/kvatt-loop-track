import { Period } from "../common/period";
import { TrackingEvent } from "./tracking_event";
import { TrackingHistory } from "./tracking_history";
import { TrackingHistoryRepositoryInterface } from "./tracking_history_repository_interface";

export class TrackingManager {

  trackingHistoryRepo: TrackingHistoryRepositoryInterface;

  constructor({
    trackingHistoryRepo,
  }: {
    trackingHistoryRepo: TrackingHistoryRepositoryInterface,
  }) {
    this.trackingHistoryRepo = trackingHistoryRepo;
  }

  async getShippedToMerchantTrackingHistories({
    merchantId,
    period
  }: {
    merchantId: string,
    period: Period,
  }): Promise<TrackingHistory[]> {
    return await this.trackingHistoryRepo.getTrackingHistories({
      merchantId: merchantId,
      event: TrackingEvent.shippedToMerchant,
      period: period,
    });
  }

  async getShippedToCustomerTrackingHistories({
    merchantId,
    period
  }: {
    merchantId: string,
    period: Period,
  }): Promise<TrackingHistory[]> {
    return await this.trackingHistoryRepo.getTrackingHistories({
      merchantId: merchantId,
      event: TrackingEvent.shippedToCustomer,
      period: period,
    });
  }

  async getReturnedFromCustomerTrackingHistories({
    merchantId,
    period
  }: {
    merchantId: string,
    period: Period,
  }): Promise<TrackingHistory[]> {
    return await this.trackingHistoryRepo.getTrackingHistories({
      merchantId: merchantId,
      event: TrackingEvent.returnedFromCustomer,
      period: period,
    });
  }

  async getReturnedToKvattTrackingHistories({
    merchantId,
    period
  }: {
    merchantId: string,
    period: Period,
  }): Promise<TrackingHistory[]> {
    const returnedToKvattHistories: TrackingHistory[] = await this.trackingHistoryRepo.getTrackingHistories({
      merchantId: merchantId,
      event: TrackingEvent.returnedToKvatt,
      period: period,
    });

    const returnedToKvattNeedsMaintenanceHistories: TrackingHistory[] = await this.trackingHistoryRepo.getTrackingHistories({
      merchantId: merchantId,
      event: TrackingEvent.returnedToKvattNeedsMaintenance,
      period: period,
    });

    const returnedToKvattNoMaintenanceHistories: TrackingHistory[] = await this.trackingHistoryRepo.getTrackingHistories({
      merchantId: merchantId,
      event: TrackingEvent.returnedToKvattNoMaintenance,
      period: period,
    });

    return [
      ...returnedToKvattHistories,
      ...returnedToKvattNeedsMaintenanceHistories,
      ...returnedToKvattNoMaintenanceHistories,
    ];
  }

  async getReturnedToKvattTrackingHistoriesCount({
    merchantId,
    period
  }: {
    merchantId: string,
    period?: Period | undefined,
  }): Promise<number> {
    const returnedToKvattCount: number = await this.trackingHistoryRepo.getTrackingHistoriesCount({
      merchantId: merchantId,
      event: TrackingEvent.returnedToKvatt,
      period: period,
    });

    const returnedToKvattNeedsMaintenanceCount: number = await this.trackingHistoryRepo.getTrackingHistoriesCount({
      merchantId: merchantId,
      event: TrackingEvent.returnedToKvattNeedsMaintenance,
      period: period,
    });

    const returnedToKvattNoMaintenanceCount: number = await this.trackingHistoryRepo.getTrackingHistoriesCount({
      merchantId: merchantId,
      event: TrackingEvent.returnedToKvattNoMaintenance,
      period: period,
    });

    return returnedToKvattCount + returnedToKvattNeedsMaintenanceCount + returnedToKvattNoMaintenanceCount;
  }
}