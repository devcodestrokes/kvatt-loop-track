import { TrackingCountersRepositoryInterface } from "./tracking_counters_repository_interface";
import { TrackingEvent } from "./tracking_event";

export class TrackingCountersManager {

  trackingCountersRepo: TrackingCountersRepositoryInterface;

  constructor({
    trackingCountersRepo,
  }: {
    trackingCountersRepo: TrackingCountersRepositoryInterface,
  }) {
    this.trackingCountersRepo = trackingCountersRepo;
  }

  async incrementReturnToKvattCounterForUser({
    userId,
    numPacks,
  }: {
    userId: string,
    numPacks: number,
  }): Promise<void> {
    await this.trackingCountersRepo.incrementTrackingCounter({
      userId: userId,
      trackingEvent: TrackingEvent.returnedToKvatt,
      numPacksTracked: numPacks,
    });
  }
}