import { PackagingHistoryRepositoryInterface } from "./packaging_history_repository_interface";
import { TrackingEvent } from "../tracking/tracking_event";

export class PackagingHistoryManager {

  packagingHistoryRepo: PackagingHistoryRepositoryInterface;

  constructor({
    packagingHistoryRepo,
  }: {
    packagingHistoryRepo: PackagingHistoryRepositoryInterface,
  }) {
    this.packagingHistoryRepo = packagingHistoryRepo;
  }

  async recordReceivedByMerchantHistory({
    packagingIds,
    merchantId,
  }: {
    packagingIds: string[],
    merchantId: string,
  }): Promise<void> {
    const tasks: Promise<void>[] = [];

    for (const packagingId of packagingIds) {
      tasks.push(
        this.packagingHistoryRepo.createPackagingHistory({
          packagingId: packagingId,
          date: new Date(),
          event: TrackingEvent.receivedByMerchant,
          trackedByUserId: merchantId,
          merchantId: merchantId,
        })
      );
    }

    await Promise.all(tasks);
  }

}