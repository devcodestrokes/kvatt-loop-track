import { TrackingEvent } from "../tracking/tracking_event";

export abstract class PackagingHistoryRepositoryInterface {

  abstract createPackagingHistory({
    packagingId,
    date,
    event,
    trackedByUserId,
    customerName,
    orderNumber,
    merchantId,
    merchantName,
  }: {
    packagingId: string,
    date: Date,
    event: TrackingEvent,
    trackedByUserId: string,
    customerName?: string | null,
    orderNumber?: string | null,
    merchantId?: string | null,
    merchantName?: string | null,
  }): Promise<void>;
}