import { TrackingSource } from "../tracking/tracking_source";

export class Merchant {
  id: string;
  email: string;
  name: string;
  trackingSource: TrackingSource | null;

  constructor({
    id, email, name, trackingSource,
  }: {
    id: string,
    email: string,
    name: string,
    trackingSource: TrackingSource | null,
  }) {
    this.id = id;
    this.email = email;
    this.name = name;
    this.trackingSource = trackingSource;
  }
}