export enum UserAccountStatus {
  active,
  pending,
}