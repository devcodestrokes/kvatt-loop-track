import { BarcodeService } from "../../../services/barcode/barcode_service";
import { CryptoService } from "../../../services/crypto/crypto_service";

export class SmartDataManager {

  async buildDataMatrixFromPlage({
    plageNumber,
  }: {
    plageNumber: number,
  }): Promise<string> {
    const start = '%0000000';
    const end = '597250A10^';
    const sdPrefix = '88';
    const sdCode = plageNumber.toString().padStart(12, '0');

    const toEncode = `${start}${sdPrefix}${sdCode}${end}`;

    return await BarcodeService.generate16x48Datamatrix(toEncode);
  }

  buildSmartDataLabelFromPlage({
    plageNumber,
  }: {
    plageNumber: number,
  }): string {
    const sdPrefix = '88';
    const sdCode = plageNumber.toString().padStart(12, '0');
    const checksum = CryptoService.computeMod37_36CheckSum(`${sdPrefix}${sdCode}`);
    return `SD : ${sdPrefix}${sdCode}${checksum}`;
  }
}