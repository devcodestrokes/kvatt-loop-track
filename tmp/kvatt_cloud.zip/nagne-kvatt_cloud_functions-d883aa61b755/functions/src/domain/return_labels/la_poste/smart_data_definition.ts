export interface SmartDataDefinition {
  datamatrixImage: string;
  sdLabel: string;
}