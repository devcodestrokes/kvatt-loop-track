export class CircularityReportComment {

  id?: string | undefined;
  from: Date;
  to: Date;
  comment: string;

  constructor({
    id,
    from,
    to,
    comment,
  }: {
    id?: string | undefined,
    from: Date,
    to: Date,
    comment: string,
  }) {
    this.id = id;
    this.from = from;
    this.to = to;
    this.comment = comment;
  }
}