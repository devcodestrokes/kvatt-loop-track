export enum CircularityAction {
  addComment,
  retrieveComments,
}