import { CircularityReportComment } from "./circularity_report_comment";
import { CircularityReportsRepositoryInterface } from "./circularity_reports_repository_interface";

export class CircularityManager {

  circularityReportsRepo: CircularityReportsRepositoryInterface;

  constructor({
    circularityReportsRepo,
  }: {
    circularityReportsRepo: CircularityReportsRepositoryInterface,
  }) {
    this.circularityReportsRepo = circularityReportsRepo;
  }

  async addCommentForMerchant({
    merchantId,
    from,
    to,
    comment,
  }: {
    merchantId: string,
    from: Date,
    to: Date,
    comment: string,
  }): Promise<void> {
    const reportComment = new CircularityReportComment({
      from: from,
      to: to,
      comment: comment,
    });

    await this.circularityReportsRepo.addComment({
      merchantId: merchantId,
      comment: reportComment,
    });
  }

  async retrieveCommentsForMerchant({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<CircularityReportComment[]> {
    return await this.circularityReportsRepo.retrieveComments({
      merchantId: merchantId,
    });
  }
}