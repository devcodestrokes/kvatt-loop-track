import { CircularityReportComment } from "./circularity_report_comment";

export abstract class CircularityReportsRepositoryInterface {

  abstract addComment({
    merchantId,
    comment
  }: {
    merchantId: string,
    comment: CircularityReportComment,
  }): Promise<void>;

  abstract retrieveComments({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<CircularityReportComment[]>;
}