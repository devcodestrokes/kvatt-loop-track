export enum PackagingStatus {
  inStoreNew,
  enRouteToMerchant,
  withMerchant,
  withCustomer,
  withMerchantReturned,
  inStoreReturned,
  inMaintenance,
  inStoreReady,
}

