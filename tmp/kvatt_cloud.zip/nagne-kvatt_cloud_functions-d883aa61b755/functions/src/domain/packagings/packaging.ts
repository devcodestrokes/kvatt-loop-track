import { PackagingStatus } from "./packaging_status";

export class Packaging {
  id: string;
  code: number;
  type: string;
  status: PackagingStatus;
  merchantId: string | null;
  merchantName: string | null;
  orderNumber?: string | null;

  constructor({
    id,
    code,
    type,
    status,
    merchantId,
    merchantName,
    orderNumber,
  }: {
    id: string,
    code: number,
    type: string,
    status: PackagingStatus,
    merchantId: string | null,
    merchantName: string | null,
    orderNumber?: string | null,
  }) {
    this.id = id;
    this.code = code;
    this.type = type;
    this.status = status;
    this.merchantId = merchantId;
    this.merchantName = merchantName;
    this.orderNumber = orderNumber;
  }
}