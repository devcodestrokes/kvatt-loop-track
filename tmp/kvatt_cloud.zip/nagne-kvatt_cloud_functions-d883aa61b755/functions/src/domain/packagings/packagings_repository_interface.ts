import { Packaging } from "./packaging";
import { PackagingStatus } from "./packaging_status";

export abstract class PackagingsRepositoryInterface {

  abstract getPacksCount({
    status,
    productType,
    merchantId,
  }: {
    status: PackagingStatus,
    productType: string,
    merchantId: string,
  }): Promise<number>;

  abstract updatePackaging({
    packagingId,
    status,
    lastTracked,
  }: {
    packagingId: string,
    status?: PackagingStatus | null,
    lastTracked?: Date | null,
  }): Promise<void>;

  abstract getPacksFromIds({
    packIds,
  }: {
    packIds: string[],
  }): Promise<(Packaging | null)[]>;
}