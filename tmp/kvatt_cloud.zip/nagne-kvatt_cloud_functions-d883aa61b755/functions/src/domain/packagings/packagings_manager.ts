import { PackagingsRepositoryInterface } from "./packagings_repository_interface";
import { PackagingStatus } from "./packaging_status";
import { Packaging } from "./packaging";

export class PackagingsManager {

  packagingsRepo: PackagingsRepositoryInterface;


  constructor({
    packagingsRepo,
  }: {
    packagingsRepo: PackagingsRepositoryInterface,
  }) {
    this.packagingsRepo = packagingsRepo;
  }

  async trackPackagingsAsReceivedByMerchant({
    packagingIds,
  }: {
    packagingIds: string[],
  }): Promise<void> {
    const tasks: Promise<void>[] = [];

    for (const packagingId of packagingIds) {
      tasks.push(
        this.packagingsRepo.updatePackaging({
          packagingId: packagingId,
          status: PackagingStatus.withMerchant,
          lastTracked: new Date(),
        })
      );
    }

    await Promise.all(tasks);
  }

  async getPacksFromPackIds({
    packIds,
  }: {
    packIds: string[],
  }): Promise<(Packaging | null)[]> {
    return await this.packagingsRepo.getPacksFromIds({
      packIds: packIds,
    });
  }
}