export interface PackInfoPayload {
  code: number;
  type: string;
  numTimesShipped: number;
  numTimesReturned: number;
  averageReturnTimeInDays: number | null;
  lastShippedDate: string | null,
  lastReturnedDate: string | null,
}