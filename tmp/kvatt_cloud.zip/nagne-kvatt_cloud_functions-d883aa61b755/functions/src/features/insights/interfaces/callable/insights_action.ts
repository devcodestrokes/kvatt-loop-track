export enum InsightsAction {
  getReturnInfo,
  getPacksInfo,
  getCheckoutPickUpInfo,
}