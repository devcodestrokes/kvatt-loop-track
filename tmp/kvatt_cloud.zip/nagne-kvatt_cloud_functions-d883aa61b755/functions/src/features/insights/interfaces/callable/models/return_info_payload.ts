export interface ReturnInfoPayload {
  numShipped: number;
  numReturned: number;
  numPending: number;
  numLost: number;
  returnRate: number | null;
  maxReturnDays: number | null;
  minReturnDays: number | null;
  averageReturnDays: number | null;
}