import { Period } from "../../../../domain/common/period";
import { TimeUtils } from "../../../../utils/time_utils";
import { InsightsAction } from "./insights_action";

export class UnsupportedInsightsAction extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class Parser {

  static parseAction({
    action
  }: {
    action: string,
  }): InsightsAction {
    switch (action) {
      case 'getPacksInfo':
        return InsightsAction.getPacksInfo;
      case 'getReturnInfo':
        return InsightsAction.getReturnInfo;
      case 'getCheckoutPickUpInfo':
        return InsightsAction.getCheckoutPickUpInfo;
      default:
        throw new UnsupportedInsightsAction(`action ${action} is not supported by insightsCallable`);
    }
  }

  static parsePeriod({
    start,
    end,
  }: {
    start: string | undefined,
    end: string | undefined,
  }): Period | undefined {
    if (start === undefined || end === undefined) {
      return undefined;
    }

    if (
      !TimeUtils.isDateStringValid({ dateString: start })
      || !TimeUtils.isDateStringValid({ dateString: end })) {
      return undefined;
    }

    const period: Period = new Period({
      start: new Date(start),
      end: new Date(end),
    });

    return period;
  }
}