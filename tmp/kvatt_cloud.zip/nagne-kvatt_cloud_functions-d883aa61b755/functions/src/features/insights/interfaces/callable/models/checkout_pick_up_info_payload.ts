export interface CheckoutPickUpInfoPayload {
    totalOrders: number;
    numOrdersWithKvattPack: number;
    pickUpRate: number | null;
}