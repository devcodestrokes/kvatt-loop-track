import { InsightsController } from "../../controllers/insights_controller";

export class OnStockLevelEntryCreatedEvent {

  static async call({
    snap,
  }: {
    snap: any,
  }) : Promise<void> {
    if (snap.data()['accountStatus'] === 'active') return;
    await InsightsController.updateInsights({
      merchantId: snap.data()['merchantId'],
      numDelivered: snap.data()['numDelivered'],
      numReturned: snap.data()['numReturned'],
    });
  }
}