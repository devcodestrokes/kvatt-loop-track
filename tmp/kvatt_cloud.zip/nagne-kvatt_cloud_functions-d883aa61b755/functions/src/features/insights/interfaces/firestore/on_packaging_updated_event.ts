import { Serialisers } from "../../../packagings/common/serialisers";
import { InsightsController } from "../../controllers/insights_controller";

export class OnPackagingUpdatedEvent {

  static async call({
    change,
  }: {
    change: any,
  }): Promise<void> {
    const previousData = change.before.data();
    const newData = change.after.data();

    const previousStatus: string = previousData['status'];
    const newStatus: string = newData['status'];

    const merchantId: string = previousData['merchantId'];

    //Shipped to customer
    if (previousStatus === Serialisers.WITH_MERCHANT_STATUS && newStatus === Serialisers.WITH_CUSTOMER_STATUS) {
      await InsightsController.updateInsights({
        merchantId: merchantId,
        numDelivered: 1,
        numReturned: 0,
      });
      return;
    }

    //Returned to merchant
    if (previousStatus === Serialisers.WITH_CUSTOMER_STATUS && newStatus === Serialisers.WITH_MERCHANT_STATUS) {
      await InsightsController.updateInsights({
        merchantId: merchantId,
        numDelivered: 0,
        numReturned: 1,
      });
    }

    //Returned to Kvatt
    if (previousStatus === Serialisers.WITH_CUSTOMER_STATUS && newStatus === Serialisers.IN_STORE_RETURNED_STATUS) {
      await InsightsController.updateInsights({
        merchantId: merchantId,
        numDelivered: 0,
        numReturned: 1,
      });
    }

    return;
  }
}