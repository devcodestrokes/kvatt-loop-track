import * as functions from 'firebase-functions';
import { CallableContext, HttpsError } from 'firebase-functions/v1/https';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { getEnvironment } from '../../../../environments';
import { ReturnInfo } from '../../../../domain/insights/return_info';
import { UsersRepository } from '../../../../data/users/users_repository';
import { ReturnInfoPayload } from './models/return_info_payload';
import { Merchant } from '../../../../domain/users/merchant';
import { Parser, UnsupportedInsightsAction } from './parser';
import { InsightsController } from '../../controllers/insights_controller';
import { InsightsAction } from './insights_action';
import { PackInfoPayload } from './models/pack_info_payload';
import { CheckoutPickUpInfo } from '../../../../domain/insights/checkout_pick_up_info';
import { CheckoutPickUpInfoPayload } from './models/checkout_pick_up_info_payload';

export class InsightsCallable {

  static async call({
    data,
    context,
  }: {
    data: any,
    context: CallableContext,
  }): Promise<any> {
    if (!context.auth) {
      return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
    }

    if (!data.action) {
      //This is here for backwards compatibility.
      //We default to getting return info if action is not present.
      return await this.getReturnInfoAction({
        data: data,
        uid: context.auth.uid,
      });
    }

    try {
      const action: InsightsAction = Parser.parseAction({
        action: data.action,
      });

      switch (action) {
        case InsightsAction.getReturnInfo:
          return await this.getReturnInfoAction({
            data: data,
            uid: context.auth.uid,
          });
        case InsightsAction.getPacksInfo:
          return await this.getPacksInfoAction({
            data: data,
            uid: context.auth.uid,
          });
        case InsightsAction.getCheckoutPickUpInfo:
          return await this.getCheckoutPickUpInfoAction({
            data: data,
            uid: context.auth.uid,
          });
      }
    } catch (e: any) {
      if (e instanceof UnsupportedInsightsAction) {
        return new functions.https.HttpsError('failed-precondition', e.message);
      }
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }

  }

  private static async getReturnInfoAction({
    data,
    uid,
  }: {
    data: any,
    uid: string,
  }): Promise<ReturnInfoPayload | HttpsError> {

    try {
      if (!data.merchantId) {
        return new functions.https.HttpsError('failed-precondition', 'merchantId is required');
      }

      const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({ userId: uid });

      if (isActiveAdmin === false && uid !== data.merchantId) {
        return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
      }

      const merchantId: string = data.merchantId;

      const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
        merchantId: merchantId,
      });

      if (merchant === null) {
        return new functions.https.HttpsError('not-found', `Merchant with ID ${merchantId} not found.`);
      }

      const period = Parser.parsePeriod({
        start: data.start,
        end: data.end,
      });

      const info: ReturnInfo = await InsightsController.retrieveMerchantReturnInfo({
        merchantId: merchantId,
        trackingSource: merchant.trackingSource,
        period: period,
      });

      return {
        'numShipped': info.numShipped,
        'numReturned': info.numReturned,
        'numPending': info.numPending,
        'numLost': info.getNumLost(),
        'returnRate': info.getReturnRate(),
        'maxReturnDays': info.maxReturnDays,
        'minReturnDays': info.minReturnDays,
        'averageReturnDays': info.averageReturnDays,
      }
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e, '', {
        'action': 'getReturnInfoAction',
        'merchantId': data.merchantId,
      });
      return new functions.https.HttpsError('internal', `getReturnInfo - merchantId: ${data.merchantId}`);
    }
  }

  private static async getPacksInfoAction({
    data,
    uid,
  }: {
    data: any,
    uid: string,
  }): Promise<PackInfoPayload[] | HttpsError> {
    if (!data.merchantId) {
      return new functions.https.HttpsError('failed-precondition', 'merchantId is required');
    }

    const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({ userId: uid });

    if (isActiveAdmin === false) {
      return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
    }

    try {
      const merchantId: string = data.merchantId;

      const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
        merchantId: merchantId,
      });

      if (merchant === null) {
        return new functions.https.HttpsError('not-found', `Merchant with ID ${merchantId} not found.`);
      }

      const period = Parser.parsePeriod({
        start: data.start,
        end: data.end,
      });

      return await InsightsController.retrieveMerchantPacksInfo({
        merchantId: merchantId,
        trackingSource: merchant.trackingSource,
        period: period,
      });

    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e, '', {
        'action': 'getPacksInfoAction',
        'merchantId': data.merchantId,
      });
      return new functions.https.HttpsError('internal', `getPacksInfo - merchantId: ${data.merchantId}`);
    }
  }

  private static async getCheckoutPickUpInfoAction({
    data,
    uid,
  }: {
    data: any,
    uid: string,
  }): Promise<CheckoutPickUpInfoPayload | null | HttpsError> {

    try {
      if (!data.merchantId) {
        return new functions.https.HttpsError('failed-precondition', 'merchantId is required');
      }

      const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({ userId: uid });

      if (isActiveAdmin === false && uid !== data.merchantId) {
        return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
      }

      const merchantId: string = data.merchantId;

      const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
        merchantId: merchantId,
      });

      if (merchant === null) {
        return new functions.https.HttpsError('not-found', `Merchant with ID ${merchantId} not found.`);
      }

      const period = Parser.parsePeriod({
        start: data.start,
        end: data.end,
      });

      const info: CheckoutPickUpInfo | null = await InsightsController.retrieveMerchantCheckoutPickUpInfo({
        merchantId: merchantId,
        period: period,
      });

      if (info === null) return null;

      return {
        'totalOrders': info.totalOrders,
        'numOrdersWithKvattPack': info.numOrdersWithKvattPack,
        'pickUpRate': info.getPickUpRate(),
      }
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e, '', {
        'action': 'getCheckoutPickUpInfoAction',
        'merchantId': data.merchantId,
      });
      return new functions.https.HttpsError('internal', `getReturnInfo - merchantId: ${data.merchantId}`);
    }
  }
}