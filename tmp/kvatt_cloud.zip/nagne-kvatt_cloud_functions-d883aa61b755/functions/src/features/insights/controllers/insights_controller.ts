import { InsightsRepository } from "../../../data/insights/insights_repository";
import { Period } from "../../../domain/common/period";
import { InsightsManager } from "../../../domain/insights/insights_manager";
import { ReturnInfo } from "../../../domain/insights/return_info";
import { ShopifyManager } from "../../../domain/shopify/shopify_manager";
import { ShopifyOrderFulfillmentRepositoryInterface } from "../../../domain/shopify/shopify_order_fulfillment_repository_interface";
import { ShopifyStoreRepositoryInterface } from "../../../domain/shopify/shopify_store_repository_interface";
import { TrackingHistoryRepositoryInterface } from "../../../domain/tracking/tracking_history_repository_interface";
import { TrackingManager } from "../../../domain/tracking/tracking_manager";
import { TrackingSource } from "../../../domain/tracking/tracking_source";
import { PackInfoPayload } from "../interfaces/callable/models/pack_info_payload";
import { ShopifyOrderFulfillmentRepository } from "../../shopify/data/shopify_order_fulfillment_repository";
import { ShopifyStoreRepository } from "../../shopify/data/shopify_store_repository";
import { TrackingHistoryRepository } from "../../tracking/data/tracking_history_repository";
import { PackagingsRepositoryInterface } from "../../../domain/packagings/packagings_repository_interface";
import { PackagingsRepository } from "../../packagings/data/packagings_repository";
import { PackagingsManager } from "../../../domain/packagings/packagings_manager";
import { PackInsight } from "../../../domain/insights/pack_insight";
import { Packaging } from "../../../domain/packagings/packaging";
import { ShopifyOrderRepositoryInterface } from "../../../domain/shopify/shopify_order_repository_interface";
import { ShopifyOrderRepository } from "../../shopify/data/shopify_order_repository";
import { CheckoutPickUpInfo } from "../../../domain/insights/checkout_pick_up_info";

export class InsightsController {

  static async updateInsights({
    merchantId,
    numDelivered,
    numReturned,
  }: {
    merchantId: string,
    numDelivered: number,
    numReturned: number,
  }): Promise<void> {
    await Promise.all([
      InsightsRepository.incrementMerchantTotalLevels({
        merchantId: merchantId,
        numDelivered: numDelivered,
        numReturned: numReturned,
      }),
      InsightsRepository.updateAdminInsights({
        merchantId: merchantId,
        numDelivered: numDelivered,
        numReturned: numReturned,
      })
    ]);
  }

  static async retrieveMerchantCheckoutPickUpInfo({
    merchantId,
    period,
  }: {
    merchantId: string,
    period?: Period | undefined,
  }): Promise<CheckoutPickUpInfo | null> {
    const trackingHistoryRepo: TrackingHistoryRepositoryInterface = new TrackingHistoryRepository();

    const trackingManager: TrackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });

    const shopifyStoreRepo: ShopifyStoreRepositoryInterface = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo: ShopifyOrderFulfillmentRepositoryInterface = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo: ShopifyOrderRepositoryInterface = new ShopifyOrderRepository();

    const shopifyManager: ShopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const insightsManager: InsightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });

    const info: CheckoutPickUpInfo | null = await insightsManager.getMerchantCheckoutPickUpInfo({
      merchantId: merchantId,
      period: period,
    });

    return info;
  }

  static async retrieveMerchantReturnInfo({
    merchantId,
    trackingSource,
    period,
  }: {
    merchantId: string,
    trackingSource: TrackingSource | null,
    period?: Period | undefined,
  }): Promise<ReturnInfo> {
    const trackingHistoryRepo: TrackingHistoryRepositoryInterface = new TrackingHistoryRepository();

    const trackingManager: TrackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });

    const shopifyStoreRepo: ShopifyStoreRepositoryInterface = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo: ShopifyOrderFulfillmentRepositoryInterface = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo: ShopifyOrderRepositoryInterface = new ShopifyOrderRepository();

    const shopifyManager: ShopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const insightsManager: InsightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });

    const info: ReturnInfo = await insightsManager.getMerchantReturnInfo({
      merchantId: merchantId,
      trackingSource: trackingSource,
      period: period,
    });

    return info;
  }

  static async retrieveMerchantPacksInfo({
    merchantId,
    trackingSource,
    period,
  }: {
    merchantId: string,
    trackingSource: TrackingSource | null,
    period?: Period | undefined,
  }): Promise<PackInfoPayload[]> {

    const trackingHistoryRepo: TrackingHistoryRepositoryInterface = new TrackingHistoryRepository();

    const trackingManager: TrackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });

    const packsRepo: PackagingsRepositoryInterface = new PackagingsRepository();

    const packagingManager: PackagingsManager = new PackagingsManager({
      packagingsRepo: packsRepo,
    });

    const shopifyStoreRepo: ShopifyStoreRepositoryInterface = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo: ShopifyOrderFulfillmentRepositoryInterface = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo: ShopifyOrderRepositoryInterface = new ShopifyOrderRepository();

    const shopifyManager: ShopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const insightsManager: InsightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });

    const packInsights: PackInsight[] = await insightsManager.getMerchantPacksInsights({
      merchantId: merchantId,
      trackingSource: trackingSource,
      period: period,
    });

    const packIds: string[] = packInsights.map((packInsight: PackInsight) => {
      return packInsight.packId;
    });

    const packs: (Packaging | null)[] = await packagingManager.getPacksFromPackIds({
      packIds: packIds,
    });

    const packsPayloadList: PackInfoPayload[] = [];

    for (let i = 0; i < packInsights.length; i++) {
      packsPayloadList.push({
        code: packs[i]?.code ?? 0,
        type: packs[i]?.type ?? '',
        numTimesShipped: packInsights[i].numTimesShipped,
        numTimesReturned: packInsights[i].numTimesReturned,
        averageReturnTimeInDays: packInsights[i].averageReturnTimeInDays,
        lastShippedDate: packInsights[i].lastShippedDate !== null ? packInsights[i].lastShippedDate!.toISOString() : null,
        lastReturnedDate: packInsights[i].lastReturnedDate !== null ? packInsights[i].lastReturnedDate!.toISOString() : null,

      });
    }

    return packsPayloadList;
  }
}