import * as functions from 'firebase-functions';
import { STOCK_LEVEL_ENTRIES_COLLECTION } from '../../data/stocks/constants';
import { getConfigs } from '../../environments';
import { Serialisers } from '../packagings/common/serialisers';
import { OnPackagingUpdatedEvent } from './interfaces/firestore/on_packaging_updated_event';
import { OnStockLevelEntryCreatedEvent } from './interfaces/firestore/on_stock_level_entry_created_event';
import { InsightsCallable } from './interfaces/callable/insights_callable';

export const onStockLevelEntryCreatedEvent = functions.region(getConfigs().CLOUD_FUNCTION_REGION).firestore.document(
  `${STOCK_LEVEL_ENTRIES_COLLECTION}/{id}`
).onCreate(async (snap, _) => {
  await OnStockLevelEntryCreatedEvent.call({
    snap: snap,
  });
});

export const onPackagingUpdatedEvent = functions.region(getConfigs().CLOUD_FUNCTION_REGION).firestore.document(
  `${Serialisers.PACKAGINGS_COLLECTION}/{packagingId}`
).onUpdate(async (change, _) => {
  await OnPackagingUpdatedEvent.call({
    change: change,
  });
});

export const insightsCallable = functions.runWith({
  timeoutSeconds: 540,
  memory: "8GB",
}).region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await InsightsCallable.call({
    data: data,
    context: context,
  });
});

