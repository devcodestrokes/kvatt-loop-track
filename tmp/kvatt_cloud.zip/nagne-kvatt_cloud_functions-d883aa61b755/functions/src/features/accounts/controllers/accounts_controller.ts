import { InsightsRepository } from "../../../data/insights/insights_repository";
import { InvitesRepository } from "../../../data/invites/invites_repository";
import { UsersRepository } from "../../../data/users/users_repository";
import { Invite } from "../../../domain/invites/invite";
import { UserAccountStatus } from "../../../domain/users/user_account_status";
import { getConfigs } from "../../../environments";
import { CryptoService } from "../../../services/crypto/crypto_service";
import { EmailClient } from "../../../services/email/email_client";
import { AuthClient } from "../../../services/firebase/auth_client";

export class AccountsController {

  static async inviteUser({
    email, userId, userType,
  } : {
    email: string,
    userId: string,
    userType: string
  }): Promise<void> {
    const code: string = CryptoService.generateRandomUuid();
    
    await InvitesRepository.saveInvite({
      email: email,
      code: code,
      userId: userId,
      userType: userType,
    });
    
    await new EmailClient().sendEmail({
      email: email,
      templateId: getConfigs().USER_INVITE_SIB_TEMPLATE_ID,
      params: {
        inviteLink: `${getConfigs().APP_REDIRECT_URL}/create-account?email=${email}&code=${code}&type=${userType}`,
      },
    });
  }

  static async createUserAccount({
    code,
    password,
  } : {
    code: string,
    password: string,
  }): Promise<void> {
    const invite = await InvitesRepository.retrieveInviteByCode({
      code: code,
    });

    if (invite === null) {
      throw Error();
    }

    const authUid: string = await AuthClient.createVerifiedUserAccount({
      email: invite.email,
      password: password,
    });

    await UsersRepository.updateUserAccountStatus({
      userId: invite.userId,
      accountStatus: UserAccountStatus.active,
    });

    await UsersRepository.updateUserId({
      oldUserId: invite.userId,
      newUserId: authUid,
    });

    await InvitesRepository.deleteInvite({
      inviteId: invite.id,
    });
  }

  static async resendInvite({
    email,
  } : {
    email: string,
  }): Promise<boolean> {

    const invite: Invite | null = await InvitesRepository.retrieveInviteByEmail({email: email});
    
    if (invite === null) return false;
    
    await new EmailClient().sendEmail({
      email: email,
      templateId: getConfigs().USER_INVITE_SIB_TEMPLATE_ID,
      params: {
        inviteLink: `${getConfigs().APP_REDIRECT_URL}/create-account?email=${email}&code=${invite.id}&type=${invite.userType}`,
      },
    });

    return true;
  }

  static async changeUserEmail({
    userId,
    email,
  } : {
    userId: string,
    email: string,
  }): Promise<void> {
    await AuthClient.updateUserEmail({
      userId: userId,
      email: email,
    });
  }

  static async removeMerchant({
    merchantId,
    merchantEmail,
  } : {
    merchantId: string,
    merchantEmail: string,
  }): Promise<void> {
    const merchant = await UsersRepository.retrieveActiveMerchantById({merchantId: merchantId});
    const isMerchantActive = merchant !== null;
   
    if (isMerchantActive) {
      await AuthClient.deleteUser({userId: merchantId});
      await InsightsRepository.deleteMerchantInsights({merchantId: merchantId});
    } else {
      const invite: Invite | null = await InvitesRepository.retrieveInviteByEmail({
        email: merchantEmail,
      });
      if (invite !== null) {
        await InvitesRepository.deleteInvite({inviteId: invite.id});
      }
    }

    await UsersRepository.deleteUser({userId: merchantId});
  }

}