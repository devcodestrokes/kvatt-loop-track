import * as functions from 'firebase-functions';
import { USERS_COLLECTION } from '../../data/users/constants';
import { getConfigs } from '../../environments';
import { ChangeEmailCallable } from './interfaces/callable/change_email_callable';
import { CreateAccountCallable } from './interfaces/callable/create_account_callable';
import { RemoveMerchantCallable } from './interfaces/callable/remove_merchant_callable';
import { ResendInviteCallable } from './interfaces/callable/resend_invite_callable';
import { OnUserCreatedEvent } from './interfaces/firestore/on_user_created_event';

export const onUserCreatedEvent = functions.region(getConfigs().CLOUD_FUNCTION_REGION).firestore.document(
    `${USERS_COLLECTION}/{userId}`
).onCreate(async (snap, context) => {
  await OnUserCreatedEvent.call({
    snap: snap,
    context: context,
  });
});

export const createAccountCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await CreateAccountCallable.createAccount({
      data: data,
  });
});

export const resendInviteCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await ResendInviteCallable.resendInvite({
      data: data,
      context: context,
  });
});

export const changeEmailCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await ChangeEmailCallable.changeEmail({
      data: data,
      context: context,
  });
});

export const removeMerchantCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await RemoveMerchantCallable.removeMerchant({
      data: data,
      context: context,
  });
});