import { AccountsController } from "../../controllers/accounts_controller";
import * as functions from 'firebase-functions';
import { UsersRepository } from "../../../../data/users/users_repository";

export class ChangeEmailCallable {

  static async changeEmail({
    data,
    context, 
  }: {
    data: any,
    context: any,
  }): Promise<any> {
    const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({userId: context.auth.uid});
    if (isActiveAdmin === false) {
      return new functions.https.HttpsError('unauthenticated', 'only active admins can perform this operation');
    }
    
    if (!(data.email && data.userId)) {
      return new functions.https.HttpsError('failed-precondition', 'email and userId are required');
    }

    try {
      await AccountsController.changeUserEmail({
        email: data.email,
        userId: data.userId,
      });
    } catch(e) {
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }
}