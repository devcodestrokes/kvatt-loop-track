import { AccountsController } from "../../controllers/accounts_controller";
import * as functions from 'firebase-functions';
import { UsersRepository } from "../../../../data/users/users_repository";

export class RemoveMerchantCallable {

  static async removeMerchant({
    data,
    context, 
  }: {
    data: any,
    context: any,
  }): Promise<any> {
    const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({userId: context.auth.uid});
    if (isActiveAdmin === false) {
      return new functions.https.HttpsError('unauthenticated', 'only active admins can perform this operation');
    }
    
    if (!(data.merchantId && data.merchantEmail)) {
      return new functions.https.HttpsError('failed-precondition', 'merchantId is required');
    }

    try {
      await AccountsController.removeMerchant({
        merchantId: data.merchantId,
        merchantEmail: data.merchantEmail,
      });
    } catch(e) {
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }
}