import { AccountsController } from "../../controllers/accounts_controller";
import * as functions from 'firebase-functions';
import { UsersRepository } from "../../../../data/users/users_repository";

export class ResendInviteCallable {

  static async resendInvite({
    data,
    context, 
  }: {
    data: any,
    context: any,
  }): Promise<any> {
    const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({userId: context.auth.uid});
    if (isActiveAdmin === false) {
      return new functions.https.HttpsError('unauthenticated', 'only active admins can perform this operation');
    }
    
    if (!(data.email)) {
      return new functions.https.HttpsError('failed-precondition', 'email is required');
    }

    try {
      const res: boolean = await AccountsController.resendInvite({
        email: data.email,
      });
      if (res === true) {
        return null;
      } else {
        return new functions.https.HttpsError('failed-precondition', 'invite with this email could not be found');
      }
    } catch(e) {
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }
}