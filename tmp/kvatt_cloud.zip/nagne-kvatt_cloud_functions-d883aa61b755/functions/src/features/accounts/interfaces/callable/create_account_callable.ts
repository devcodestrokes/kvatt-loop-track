import { AccountsController } from "../../controllers/accounts_controller";
import * as functions from 'firebase-functions';

export class CreateAccountCallable {

  static async createAccount({
    data,
  }: {
    data: any,
  }): Promise<any> {
    if (!(data.password && data.code)) {
      return new functions.https.HttpsError('failed-precondition', 'password and code are required');
    }

    try {
      await AccountsController.createUserAccount({
        password: data.password,
        code: data.code,
      });
    } catch(e) {
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }
}