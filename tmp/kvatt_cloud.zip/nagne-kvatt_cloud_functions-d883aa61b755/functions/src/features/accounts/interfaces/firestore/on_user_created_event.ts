import { AccountsController } from "../../controllers/accounts_controller";

export class OnUserCreatedEvent {

  static async call({
    snap,
    context,
  }: {
    snap: any,
    context: any,
  }) : Promise<void> {
    if (snap.data()['accountStatus'] === 'active') return;
    await AccountsController.inviteUser({
      email: snap.data()['email'],
      userId: context.params.userId,
      userType: snap.data()['type'],
    });
  }
}