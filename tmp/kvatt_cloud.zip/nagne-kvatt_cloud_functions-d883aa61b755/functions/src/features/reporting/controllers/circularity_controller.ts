import { CircularityManager } from "../../../domain/reporting/circularity_manager";
import { CircularityReportComment } from "../../../domain/reporting/circularity_report_comment";
import { CircularityReportsRepository } from "../data/circularity_reports_repository";

export class CircularityController {
  static async handleAddComment({
    merchantId,
    from,
    to,
    comment,
  }: {
    merchantId: string,
    from: Date,
    to: Date,
    comment: string,
  }): Promise<void> {

    const circularityReportsRepo = new CircularityReportsRepository();
    const circularityManager = new CircularityManager({
      circularityReportsRepo: circularityReportsRepo,
    });

    await circularityManager.addCommentForMerchant({
      merchantId: merchantId,
      from: from,
      to: to,
      comment: comment,
    });
  }

  static async handleRetrieveComments({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<CircularityReportComment[]> {
    const circularityReportsRepo = new CircularityReportsRepository();
    const circularityManager = new CircularityManager({
      circularityReportsRepo: circularityReportsRepo,
    });

    return await circularityManager.retrieveCommentsForMerchant({
      merchantId: merchantId,
    });
  }
}