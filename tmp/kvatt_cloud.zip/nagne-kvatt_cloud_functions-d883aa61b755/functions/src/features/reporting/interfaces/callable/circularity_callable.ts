import * as functions from 'firebase-functions';

import { CallableContext, HttpsError } from "firebase-functions/v1/https";
import { CircularityAction } from '../../../../domain/reporting/circularity_action';
import { Parser, UnsupportedCircularityAction } from './parser';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { getEnvironment } from '../../../../environments';
import { CommentPayload } from './models/comment_payload';
import { UsersRepository } from '../../../../data/users/users_repository';
import { CircularityController } from '../../controllers/circularity_controller';
import { CircularityReportComment } from '../../../../domain/reporting/circularity_report_comment';
import { TimeUtils } from '../../../../utils/time_utils';

export class CircularityCallable {

  static async call({
    data,
    context,
  }: {
    data: any,
    context: CallableContext,
  }): Promise<any> {
    if (!context.auth) {
      return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
    }

    if (!data.action) {
      return new functions.https.HttpsError('failed-precondition', 'action is required');
    }

    try {
      const action: CircularityAction = Parser.parseAction({
        action: data.action,
      });

      switch (action) {
        case CircularityAction.addComment:
          return await this.addCommentAction({
            data: data,
            uid: context.auth.uid,
          });
        case CircularityAction.retrieveComments:
          return await this.retrieveCommentsAction({
            data: data,
            uid: context.auth.uid,
          });
      }
    } catch (e: any) {
      if (e instanceof UnsupportedCircularityAction) {
        return new functions.https.HttpsError('failed-precondition', e.message);
      }
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }

  private static async addCommentAction({
    data,
    uid,
  }: {
    data: any,
    uid: string,
  }): Promise<void | HttpsError> {
    try {
      if (!data.merchantId || !data.comment || !data.from || !data.to) {
        return new functions.https.HttpsError('failed-precondition', 'merchantId, from, to, and comment are required');
      }

      const isFromValid = TimeUtils.isDateStringValid({ dateString: data.from });
      const isToValid = TimeUtils.isDateStringValid({ dateString: data.to });

      if (isFromValid === false || isToValid === false) {
        return new functions.https.HttpsError('failed-precondition', 'from and to should be valid dates');

      }

      const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({ userId: uid });

      if (isActiveAdmin === false) {
        return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
      }

      await CircularityController.handleAddComment({
        merchantId: data.merchantId,
        from: new Date(data.from),
        to: new Date(data.to),
        comment: data.comment,
      });

    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e, '', {
        'action': 'addCommentAction',
        'merchantId': data.merchantId,
      });
      return new functions.https.HttpsError('internal', `addComment - merchantId: ${data.merchantId}`);
    }
  }

  private static async retrieveCommentsAction({
    data,
    uid,
  }: {
    data: any,
    uid: string,
  }): Promise<CommentPayload[] | HttpsError> {
    try {
      if (!data.merchantId) {
        return new functions.https.HttpsError('failed-precondition', 'merchantId is required');
      }

      const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({ userId: uid });

      if (isActiveAdmin === false) {
        return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
      }

      const comments = await CircularityController.handleRetrieveComments({
        merchantId: data.merchantId,
      });

      return comments.map((comment: CircularityReportComment) => {
        return {
          'from': comment.from.toISOString(),
          'to': comment.to.toISOString(),
          'comment': comment.comment,
        };
      });
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e, '', {
        'action': 'retrieveCommentsAction',
        'merchantId': data.merchantId,
      });
      return new functions.https.HttpsError('internal', `retrieveComments - merchantId: ${data.merchantId}`);
    }
  }
}