export interface CommentPayload {
  from: string,
  to: string,
  comment: string,
}