import { CircularityAction } from "../../../../domain/reporting/circularity_action";

export class UnsupportedCircularityAction extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class Parser {

  static parseAction({
    action,
  }: {
    action: string,
  }): CircularityAction {
    switch (action) {
      case 'addComment':
        return CircularityAction.addComment;
      case 'retrieveComments':
        return CircularityAction.retrieveComments;
      default:
        throw new UnsupportedCircularityAction(`action ${action} is not supported`);
    }
  }
}