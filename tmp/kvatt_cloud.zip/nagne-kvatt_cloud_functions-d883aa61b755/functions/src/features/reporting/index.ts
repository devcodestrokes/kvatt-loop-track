import * as functions from 'firebase-functions';
import { CircularityCallable } from './interfaces/callable/circularity_callable';
import { getConfigs } from '../../environments';

export const circularityCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await CircularityCallable.call({
    data: data,
    context: context,
  });
});