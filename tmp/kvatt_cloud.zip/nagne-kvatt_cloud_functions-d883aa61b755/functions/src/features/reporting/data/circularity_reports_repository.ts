import { CircularityReportComment } from "../../../domain/reporting/circularity_report_comment";
import { CircularityReportsRepositoryInterface } from "../../../domain/reporting/circularity_reports_repository_interface";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "./serialisers";

export class CircularityReportsRepository implements CircularityReportsRepositoryInterface {

  async addComment({
    merchantId,
    comment,
  }: {
    merchantId: string,
    comment: CircularityReportComment,
  }): Promise<void> {
    await FirestoreClient.createDocument({
      collectionPath: `${Serialisers.CIRCULARITY_REPORTS_COLLECTION}/${merchantId}/${Serialisers.CIRCULARITY_REPORTS_COMMENTS_SUBCOLLECTION}`,
      data: Serialisers.serialiseCircularityReportsComment({
        comment: comment,
      }),
    });
  }

  async retrieveComments({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<CircularityReportComment[]> {
    const results: QueryResult[] = await FirestoreClient.retrieveDocuments({
      collectionPath: `${Serialisers.CIRCULARITY_REPORTS_COLLECTION}/${merchantId}/${Serialisers.CIRCULARITY_REPORTS_COMMENTS_SUBCOLLECTION}`,
    });

    return results.map((result: QueryResult) => {
      return Serialisers.deserialiseCircularityReportsComment({
        id: result.documentId,
        data: result.data,
      });
    });
  }
}