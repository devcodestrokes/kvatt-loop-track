import { CircularityReportComment } from "../../../domain/reporting/circularity_report_comment";

export class Serialisers {

  static CIRCULARITY_REPORTS_COLLECTION: string = 'circularity_reports';

  static CIRCULARITY_REPORTS_COMMENTS_SUBCOLLECTION: string = 'comments';

  static circularityReportsCommentsFromField: string = 'from';
  static circularityReportsCommentsToField: string = 'to';
  static circularityReportsCommentsCommentField: string = 'comment';


  static serialiseCircularityReportsComment({
    comment,
  }: {
    comment: CircularityReportComment,
  }): any {
    const data: any = {};
    data[this.circularityReportsCommentsFromField] = comment.from;
    data[this.circularityReportsCommentsToField] = comment.to;
    data[this.circularityReportsCommentsCommentField] = comment.comment;
    return data;
  }

  static deserialiseCircularityReportsComment({
    id,
    data,
  }: {
    id: string,
    data: any,
  }): CircularityReportComment {
    return new CircularityReportComment({
      id: id,
      from: data[this.circularityReportsCommentsFromField].toDate(),
      to: data[this.circularityReportsCommentsToField].toDate(),
      comment: data[this.circularityReportsCommentsCommentField],
    });
  }
}