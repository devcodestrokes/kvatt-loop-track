import { ConnectAction } from "./connect_action";

export class UnsupportedConnectAction extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class Parser {

  static parseAction({
    action,
  }: {
    action: string,
  }): ConnectAction {
    switch (action) {
      case 'linkShopToMerchant':
        return ConnectAction.linkShopToMerchant;
      case 'getConnectionStatus':
        return ConnectAction.getConnectionStatus;
      case 'checkShippingMethodAdded':
        return ConnectAction.checkShippingMethodAdded;
      case 'setGenericReturnEmailNudge':
        return ConnectAction.setGenericReturnEmailNudge;
      default:
        throw new UnsupportedConnectAction(`action ${action} is not supported`);

    }
  }
}