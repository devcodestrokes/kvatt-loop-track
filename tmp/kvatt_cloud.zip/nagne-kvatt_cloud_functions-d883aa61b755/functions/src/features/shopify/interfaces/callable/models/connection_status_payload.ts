export interface ConnectionStatusPayload {
  isConnected: boolean;
  sendGenericReturnEmailNudge: boolean;
}