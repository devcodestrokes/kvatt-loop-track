import * as functions from 'firebase-functions';
import { FulfillmentCreatePayload } from '../../common/models/fulfillment_create_payload';
import { Serialisers } from '../http/serialisers';
import { ShopifyController } from '../../controllers/shopify_controller';
import { getEnvironment } from '../../../../environments';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { ShopifyWebhookUnknownError } from '../../../../services/shopify/errors';
import { OrderCreatePayload } from '../../common/models/order_create_payload';
import { ShopifyOrderNotFound, ShopifyShopMisconfigured } from '../../common/errors';

export class ShopifyWebhookPubSub {
  static async call({
    message,
  }: {
    message: functions.pubsub.Message,
  }): Promise<void> {
    try {
      const attributes = message.attributes;
      const json = message.json;

      const webhookTopic = attributes['X-Shopify-Topic'];
      const webhookId = attributes['X-Shopify-Webhook-Id'];
      const shop = attributes['X-Shopify-Shop-Domain'];

      switch (webhookTopic) {
        case 'fulfillments/create':
          const fulfillmentCreatePayload: FulfillmentCreatePayload = Serialisers.deserialiseFulfillmentCreatePayload(json);
          await ShopifyController.processFulfillmentCreateWebhook({
            webhookId: webhookId,
            webhookPayload: fulfillmentCreatePayload,
            shopId: shop,
          });
          break;
        case 'orders/create':
          const orderCreatePayload: OrderCreatePayload = Serialisers.deserialiseOrderCreatePayload(json);
          await ShopifyController.processOrderCreateWebhook({
            webhookId: webhookId,
            webhookPayload: orderCreatePayload,
            shopId: shop,
          });
          break;
        default:
          break;
      }
      return;

    } catch (e: any) {
      if (e instanceof ShopifyWebhookUnknownError) {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(
          e,
          undefined,
          {
            'shopId': e.shopId,
            'orderId': e.orderId,
            'message': e.message,
          }
        );
      }
      else if (e instanceof ShopifyShopMisconfigured || e instanceof ShopifyOrderNotFound) {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(
          e,
          undefined,
          {
            'message': e.message,
          }
        );
      }
      else {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(e);
      }
      return;
    }
  }
}