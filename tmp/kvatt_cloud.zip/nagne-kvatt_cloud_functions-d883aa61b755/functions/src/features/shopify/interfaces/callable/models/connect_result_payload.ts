export interface ConnectResultPayload {
  success: boolean;
}