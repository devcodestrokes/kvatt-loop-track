export enum ConnectAction {
  linkShopToMerchant,
  getConnectionStatus,
  checkShippingMethodAdded,
  setGenericReturnEmailNudge,
}