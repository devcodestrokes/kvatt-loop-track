import * as functions from 'firebase-functions';
import { ShopifyAuthController } from '../../controllers/shopify_auth_controller';
import { shopifyAppBasicUI } from '../../ui/html_strings';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { getConfigs, getEnvironment } from '../../../../environments';

export class ShopifyAppEndpoint {
  //TODO: Use friendlier url domain
  //TODO: Display nicer error message page
  static async call({
    request,
    response,
  }: {
    request: functions.https.Request,
    response: functions.Response,
  }): Promise<void> {
    if (request.method !== "GET") {
      response.status(405).send('Method not supported.');
      return;
    }

    try {

      let isRequestValid: boolean;

      if (getConfigs().LEGACY_SHOPIFY_STORES.includes(request.query['shop'] as string)) {
        isRequestValid = await ShopifyAuthController.verifyShopifyRequestLegacy({
          queryParams: request.query,
        });
      } else {
        isRequestValid = await ShopifyAuthController.verifyShopifyRequest({
          queryParams: request.query,
        });
      }

      if (isRequestValid === false) {
        response.status(403).send('Forbidden');
        return;
      }

      if (request.query.embedded !== undefined && request.query.embedded === '1') {
        response.status(200).send(shopifyAppBasicUI);
        return;
      }

      // const connectionStatus: StoreConnectionStatus = await ShopifyAuthController.verifyStoreConnectionStatus({
      //   shopId: request.query['shop'] as string,
      // });
      await ShopifyAuthController.redirectToShopifyAuth({
        request: request,
        response: response,
      });
      // if (connectionStatus.isConnected === false || connectionStatus.hasAccessToken === false || connectionStatus.hasRequiredScopes === false) {

      // } else {
      //   response.redirect(`${getConfigs().APP_REDIRECT_URL}/home?view=merchant-integrations`);
      // }

      return;
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      response.status(403).send('There was an issue authenticating with Shopify. Please contact your system administrator.');

      return;
    }
  }
}