import * as functions from 'firebase-functions';
import { ShopifyAuthController } from '../../controllers/shopify_auth_controller';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { getEnvironment } from '../../../../environments';

export class ShopifyAuthEndpoint {
  static async call({
    request,
    response,
  }: {
    request: functions.https.Request,
    response: functions.Response,
  }): Promise<void> {
    if (request.method !== "GET") {
      response.status(405).send('Method not supported.');
      return;
    }

    try {
      const shop = request.query.shop;
      if (shop === undefined) {
        response.status(500).send('The was an issue with your request. Please contact the system administrator.');
        return;
      }

      await ShopifyAuthController.redirectToShopifyAuth({
        request: request,
        response: response,
      });
      return;
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      response.status(500).send('There was an issue with your request. Please contact the system administrator');
      return;
    }
  }
}