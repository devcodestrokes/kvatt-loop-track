import * as functions from 'firebase-functions';
import { ShopifyAuthController } from '../../controllers/shopify_auth_controller';
import { Serialisers } from './serialisers';
import { ShopifyController } from '../../controllers/shopify_controller';
import { getConfigs, getEnvironment } from '../../../../environments';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { ShopifyWebhookUnknownError } from '../../../../services/shopify/errors';
import { FulfillmentCreatePayload } from '../../common/models/fulfillment_create_payload';
import { ShopifyOrderNotFound, ShopifyShopMisconfigured } from '../../common/errors';

export class ShopifyWebhook {
  static async call({
    request,
    response,
  }: {
    request: functions.https.Request,
    response: functions.Response,
  }): Promise<void> {
    try {
      const shop = request.headers['x-shopify-shop-domain'] as string;

      let isWebhookValid: boolean;

      if (getConfigs().LEGACY_SHOPIFY_STORES.includes(shop)) {
        isWebhookValid = await ShopifyAuthController.validateShopifyWebhookLegacy({
          request: request,
          response: response,
        });
      } else {
        isWebhookValid = await ShopifyAuthController.validateShopifyWebhook({
          request: request,
          response: response,
        });
      }

      if (isWebhookValid === true) {
        const webhookTopic = request.headers['x-shopify-topic'];
        const webhookId = request.headers['x-shopify-webhook-id'];

        switch (webhookTopic) {
          case 'fulfillments/create':
            const payload: FulfillmentCreatePayload = Serialisers.deserialiseFulfillmentCreatePayload(request.body);
            await ShopifyController.processFulfillmentCreateWebhook({
              webhookId: webhookId as string,
              webhookPayload: payload,
              shopId: shop,
            });
          default:
            break;
        }
        response.status(200).send('OK');
      } else {
        response.status(401).send('Webhook could not be verified.');
      }
    } catch (e: any) {
      if (e instanceof ShopifyWebhookUnknownError) {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(
          e,
          undefined,
          {
            'shopId': e.shopId,
            'orderId': e.orderId,
            'message': e.message,
          }
        );
      } else if (e instanceof ShopifyShopMisconfigured || e instanceof ShopifyOrderNotFound) {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(
          e,
          undefined,
          {
            'message': e.message,
          }
        );
      }
      else {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(e);
      }
      response.status(200).send('OK');
    }
    return;
  }
}