import { FulfillmentCreatePayload } from "../../common/models/fulfillment_create_payload";
import { OrderCreatePayload, ShippingLinePayload } from "../../common/models/order_create_payload";

export class Serialisers {

  static deserialiseFulfillmentCreatePayload(body: any): FulfillmentCreatePayload {
    return {
      orderId: body['order_id'],
      updatedAt: new Date(body['updated_at']),
      postCode: body['destination'] !== null ? body['destination']['zip'] : undefined,
      countryCode: body['destination'] !== null ? body['destination']['country_code'] : undefined,
    }
  }

  static deserialiseOrderCreatePayload(body: any): OrderCreatePayload {
    return {
      'customerEmail': body['email'] !== undefined ? body['email'] : null,
      'customerId': body['customer'] !== undefined && body['customer'] !== null ? body['customer']['id'] : null,
      'createdAt': new Date(body['created_at']),
      'orderNumber': body['name'],
      'orderId': body['id'],
      'customerAcceptedMarketingComms': body['customer'] !== undefined && body['customer'] !== null && body['customer']['email_marketing_consent'] !== null ? body['customer']['email_marketing_consent']['state'] === 'subscribed' : false,
      'orderCurrency': body['currency'],
      'totalOrderPrice': body['current_total_price'],
      'shippingPostCode': body['shipping_address'] !== undefined && body['shipping_address'] !== null ? body['shipping_address']['zip'] : null,
      'shippingCountry': body['shipping_address'] !== undefined && body['shipping_address'] !== null ? body['shipping_address']['country'] : null,
      'shippingCity': body['shipping_address'] !== undefined && body['shipping_address'] !== null ? body['shipping_address']['city'] : null,
      'shippingOptions': body['shipping_lines'].map((data: any) => {
        return this.deserialiseShippingLine(data);
      }),

    };
  }

  static deserialiseShippingLine(shippingLine: any): ShippingLinePayload {
    return {
      'code': shippingLine['code'],
      'price': shippingLine['price_set']['shop_money']['amount'],
      'currency': shippingLine['price_set']['shop_money']['currency_code'],
      'title': shippingLine['title'],
    };
  }
}