import * as functions from 'firebase-functions';
import { ShopifyAuthController } from '../../controllers/shopify_auth_controller';
import { getConfigs, getEnvironment } from '../../../../environments';
import { SentryClient } from '../../../../services/error_logging/sentry_client';

export class ShopifyAuthCallback {
  //TODO: Display nicer error message page
  static async call({
    request,
    response,
  }: {
    request: functions.https.Request,
    response: functions.Response,
  }): Promise<void> {

    if (request.method !== "GET") {
      response.status(405).send('Method not supported.');
      return;
    }

    try {
      const checkCode = await ShopifyAuthController.configureIntegration({
        request: request,
        response: response,
      });
      response.redirect(`${getConfigs().APP_REDIRECT_URL}/home?view=merchant-integrations&connect=1&checkCode=${checkCode}`);
      return;

    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      response.status(403).send('There was an issue authenticating with Shopify. Please contact your system administrator.');
    }
  }
}