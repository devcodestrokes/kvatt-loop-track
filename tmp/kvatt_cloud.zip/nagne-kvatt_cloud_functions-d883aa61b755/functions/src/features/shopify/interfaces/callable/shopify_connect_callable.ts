import * as functions from 'firebase-functions';
import { CallableContext, HttpsError } from 'firebase-functions/v1/https';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { getEnvironment } from '../../../../environments';
import { UsersRepository } from '../../../../data/users/users_repository';
import { Merchant } from '../../../../domain/users/merchant';
import { ShopifyController } from '../../controllers/shopify_controller';
import { ConnectAction } from './connect_action';
import { Parser, UnsupportedConnectAction } from './parser';
import { ConnectionStatusPayload } from './models/connection_status_payload';
import { ShopifyStore } from '../../../../domain/shopify/shopify_store';
import { ShopifyInvalidCheckCode } from '../../common/errors';


export class ShopifyConnectCallable {

  static async call({
    data,
    context,
  }: {
    data: any,
    context: CallableContext,
  }): Promise<any> {
    if (!context.auth) {
      return new functions.https.HttpsError('unauthenticated', 'You do not have the required permissions to perform this operation.');
    }

    if (!data.action) {
      return new functions.https.HttpsError('failed-precondition', 'action is required.');
    }

    try {
      const action: ConnectAction = Parser.parseAction({
        action: data.action,
      });

      switch (action) {
        case ConnectAction.linkShopToMerchant:
          return await this.linkShopToMerchantAction({
            data: data,
            uid: context.auth.uid,
          });
        case ConnectAction.getConnectionStatus:
          return await this.getConnectionStatusAction({
            uid: context.auth.uid,
          });
        case ConnectAction.checkShippingMethodAdded:
          return await this.checkShippingMethodAdded({
            uid: context.auth.uid,
            data: data,
          });
        case ConnectAction.setGenericReturnEmailNudge:
          return await this.setGenericReturnEmailNudgeAction({
            uid: context.auth.uid,
            data: data,
          });
      }

    } catch (e: any) {
      if (e instanceof UnsupportedConnectAction) {
        return new functions.https.HttpsError('failed-precondition', e.message);
      }
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }

  private static async linkShopToMerchantAction({
    data,
    uid,
  }: {
    data: any,
    uid: string,
  }): Promise<any> {
    try {

      if (!data.checkCode) {
        return new functions.https.HttpsError('failed-precondition', 'checkCode is required.');
      }

      const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
        merchantId: uid,
      });

      if (merchant === null) {
        return new functions.https.HttpsError('not-found', `Merchant with ID ${uid} not found.`);
      }

      await ShopifyController.processMerchantStoreConnection({
        merchantId: uid,
        checkCode: data['checkCode'],
      });
      return;
    } catch (e: any) {
      if (e instanceof ShopifyInvalidCheckCode) {
        SentryClient.getInstance({
          environment: getEnvironment(),
        }).capture(e, '', {
          'action': 'linkShopToMerchantAction',
          'merchantId': uid,
          'message': e.message,
        });
      }

      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }

  private static async getConnectionStatusAction({
    uid,
  }: {
    uid: string,
  }): Promise<ConnectionStatusPayload | HttpsError> {
    try {
      const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
        merchantId: uid,
      });

      if (merchant === null) {
        return new functions.https.HttpsError('not-found', `Merchant with ID ${uid} not found.`);
      }

      const store: ShopifyStore | null = await ShopifyController.getStoreConnectionStatusForMerchant({
        merchantId: uid,
      });

      if (store === null) {
        return {
          'isConnected': false,
          'sendGenericReturnEmailNudge': false,
        }
      } else {
        return {
          'isConnected': true,
          'sendGenericReturnEmailNudge': store.sendGenericReturnEmailNudge ?? false,
        }
      }
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }

  private static async setGenericReturnEmailNudgeAction({
    uid,
    data,
  }: {
    uid: string,
    data: any,
  }): Promise<void | HttpsError> {
    try {
      const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
        merchantId: uid,
      });

      if (merchant === null) {
        return new functions.https.HttpsError('not-found', `Merchant with ID ${uid} not found.`);
      }

      if (data.sendGenericReturnEmailNudge === undefined) {
        return new functions.https.HttpsError('failed-precondition', 'sendGenericReturnEmailNudge is required.');
      }

      await ShopifyController.setGenericReturnEmailNudge({
        merchantId: uid,
        sendGenericReturnEmailNudge: data.sendGenericReturnEmailNudge,
      });

    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }

  private static async checkShippingMethodAdded({
    uid,
    data,
  }: {
    uid: string,
    data: any,
  }): Promise<boolean | HttpsError> {
    if (!data.shippingMethodText) {
      return new functions.https.HttpsError('failed-precondition', 'shippingMethodText is required.');
    }
    try {
      return await ShopifyController.checkShippingMethodAdded({
        merchantId: uid,
        expectedShippingMethod: data.shippingMethodText,
      });
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }
}