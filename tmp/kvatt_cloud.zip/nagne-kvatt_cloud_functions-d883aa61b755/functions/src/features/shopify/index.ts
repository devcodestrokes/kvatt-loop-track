import * as functions from 'firebase-functions';
import { getConfigs } from '../../environments';
import { ShopifyAppEndpoint } from './interfaces/http/shopify_app_endpoint';
import { ShopifyAuthCallback } from './interfaces/http/shopify_auth_callback';
import { ShopifyWebhookPubSub } from './interfaces/pubsub/shopify_webhook_pubsub';
import { ShopifyConnectCallable } from './interfaces/callable/shopify_connect_callable';
import { ShopifyAuthEndpoint } from './interfaces/http/shopify_auth_endpoint';
import { ShopifyWebhook } from './interfaces/http/shopify_webhook';

export const shopifyApp = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onRequest(async (request, response) => {
  await ShopifyAppEndpoint.call({
    request: request,
    response: response,
  });
  return;
});

export const shopifyAuthEndpoint = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onRequest(async (request, response) => {
  await ShopifyAuthEndpoint.call({
    request: request,
    response: response,
  });
  return;
});

export const shopifyAuthCallback = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onRequest(async (request, response) => {
  await ShopifyAuthCallback.call({
    request: request,
    response: response,
  });
  return;
});

export const shopifyConnectCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await ShopifyConnectCallable.call({
    data: data,
    context: context,
  });
});

export const shopifyWebhookPubSub = functions.region(getConfigs().CLOUD_FUNCTION_REGION).pubsub.topic(getConfigs().SHOPIFY_WEBHOOK_PUBSUB_TOPIC)
  .onPublish(async (message) => {
    await ShopifyWebhookPubSub.call({
      message: message,
    });
    return;
  });

export const shopifyWebhook = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onRequest(async (request, response) => {
  await ShopifyWebhook.call({
    request: request,
    response: response,
  });
  return;
});



