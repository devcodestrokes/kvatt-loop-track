export interface ShippingLinePayload {
  code: string;
  price: string;
  currency: string;
  title: string;
}

export interface OrderCreatePayload {
  customerEmail: string | null;
  customerId: string | null;
  createdAt: Date;
  orderNumber: string;
  orderId: string;
  customerAcceptedMarketingComms: boolean;
  orderCurrency: string;
  totalOrderPrice: string;
  shippingPostCode: string | null;
  shippingCountry: string | null;
  shippingCity: string | null;
  shippingOptions: ShippingLinePayload[];
}