import { ShopifyOrder } from "../../../domain/shopify/shopify_order";
import { ShopifyOrderShippingOption } from "../../../domain/shopify/shopify_order_shipping_option";
import { ShopifyStore } from "../../../domain/shopify/shopify_store";

export class Serialisers {

  static SHOPIFY_STORES_COLLECTION: string = 'shopify_stores';

  static shopifyStoresMerchantIdField: string = 'merchantId';
  static shopifyStoresClientIdField: string = 'clientId';
  static shopifyStoresClientSecretField: string = 'clientSecret';
  static shopifyStoresScopesField: string = 'scopes';
  static shopifyStoresAccessTokenField: string = 'accessToken';
  static shopifyStoresKvattShippingMethodsField: string = 'kvattShippingMethods';
  static shopifyStoresPackStatusChangedTriggerIdField: string = 'packStatusChangedTriggerId';
  static shopifyStoresSendGenericReturnEmailNudgeField: string = 'sendGenericReturnEmailNudge';
  static shopifyStoresCheckCodeField: string = 'checkCode';

  static SHOPIFY_ORDER_FULFILLMENTS_COLLECTION: string = 'shopify_order_fulfillments';

  static shopifyOrderFulfillmentsShopIdField: string = 'shopId';
  static shopifyOrderFulfillmentsMerchantIdField: string = 'merchantId';
  static shopifyOrderFulfillmentsOrderIdField: string = 'orderId';
  static shopifyOrderFulfillmentsOrderNumberField: string = 'orderNumber';
  static shopifyOrderFulfillmentsShippingMethodCodeField: string = 'shippingMethodCode';
  static shopifyOrderFulfillmentsDateField: string = 'date';
  static shopifyOrderFulfillmentsCountryCodeField: string = 'countryCode';
  static shopifyOrderFulfillmentsPostCodeField: string = 'postCode';

  static SHOPIFY_ORDERS_SUBCOLLECTION: string = 'shopify_orders';
  static shopifyOrderCreatedAtField: string = 'createdAt';
  static shopifyOrderOrderNumberField: string = 'orderNumber';
  static shopifyOrderOrderIdField: string = 'orderId';
  static shopifyOrderCustomerAcceptedMarketingCommsField: string = 'customerAcceptedMarketingComms';
  static shopifyOrderShippingOptionsField: string = 'shippingOptions';
  static shopifyOrderIsWithKvattShippingOptionField: string = 'isWithKvattShippingOption';
  static shopifyOrderOrderCurrencyField: string = 'orderCurrency';
  static shopifyOrderTotalOrderPriceField: string = 'totalOrderPrice';
  static shopifyOrderCustomerEmailField: string = 'customerEmail';
  static shopifyOrderCustomerIdField: string = 'customerId';
  static shopifyOrderShippingPostCodeField: string = 'shippingPostCode';
  static shopifyOrderShippingCountryField: string = 'shippingCountry';
  static shopifyOrderShippingCityField: string = 'shippingCity';

  static shopifyOrderShippingOptionCodeField: string = 'code';
  static shopifyOrderShippingOptionCurrencyField: string = 'currency';
  static shopifyOrderShippingOptionPriceField: string = 'price';
  static shopifyOrderShippingOptionTitleField: string = 'title';

  static deserialiseShopifyStore(id: string, data: any): ShopifyStore {
    return new ShopifyStore({
      shopId: id,
      merchantId: data[this.shopifyStoresMerchantIdField],
      clientId: data[this.shopifyStoresClientIdField],
      clientSecret: data[this.shopifyStoresClientSecretField],
      scopes: data[this.shopifyStoresScopesField],
      accessToken: data[this.shopifyStoresAccessTokenField],
      checkCode: data[this.shopifyStoresCheckCodeField],
      kvattShippingMethods: data[this.shopifyStoresKvattShippingMethodsField],
      packStatusChangedTriggerId: data[this.shopifyStoresPackStatusChangedTriggerIdField],
      sendGenericReturnEmailNudge: data[this.shopifyStoresSendGenericReturnEmailNudgeField],
    });
  }

  static serialiseShopifyOrder({
    order,
  }: {
    order: ShopifyOrder,
  }): any {
    const data: any = {};
    data[this.shopifyOrderCreatedAtField] = order.createdAt;
    data[this.shopifyOrderOrderNumberField] = order.orderNumber;
    data[this.shopifyOrderOrderIdField] = order.orderId;
    data[this.shopifyOrderCustomerAcceptedMarketingCommsField] = order.customerAcceptedMarketingComms;
    data[this.shopifyOrderShippingOptionsField] = order.shippingOptions.map((option) => {
      return this.serialiseShopifyOrderShippingOption({ option: option });
    });
    data[this.shopifyOrderIsWithKvattShippingOptionField] = order.isWithKvattShippingOption;
    data[this.shopifyOrderOrderCurrencyField] = order.orderCurrency;
    data[this.shopifyOrderTotalOrderPriceField] = order.totalOrderPrice;
    data[this.shopifyOrderCustomerEmailField] = order.customerEmail;
    data[this.shopifyOrderCustomerIdField] = order.customerId;
    data[this.shopifyOrderShippingPostCodeField] = order.shippingPostCode;
    data[this.shopifyOrderShippingCountryField] = order.shippingCountry;
    data[this.shopifyOrderShippingCityField] = order.shippingCity;

    return data;
  }

  static deserialiseShopifyOrder({
    data,
  }: {
    data: any,
  }): ShopifyOrder {
    return new ShopifyOrder({
      createdAt: data[this.shopifyOrderCreatedAtField].toDate(),
      orderNumber: data[this.shopifyOrderOrderNumberField],
      orderId: data[this.shopifyOrderOrderIdField],
      customerAcceptedMarketingComms: data[this.shopifyOrderCustomerAcceptedMarketingCommsField],
      shippingOptions: data[this.shopifyOrderShippingOptionsField].map((option: any) => {
        return this.deserialiseShopifyOrderShippingOption({ data: option })
      }),
      isWithKvattShippingOption: data[this.shopifyOrderIsWithKvattShippingOptionField],
      orderCurrency: data[this.shopifyOrderOrderCurrencyField],
      totalOrderPrice: data[this.shopifyOrderTotalOrderPriceField],
      customerEmail: data[this.shopifyOrderCustomerEmailField] !== undefined ? data[this.shopifyOrderCustomerEmailField] : null,
      customerId: data[this.shopifyOrderCustomerIdField] !== undefined ? data[this.shopifyOrderCustomerIdField] : null,
      shippingPostCode: data[this.shopifyOrderShippingPostCodeField] !== undefined ? data[this.shopifyOrderShippingPostCodeField] : null,
      shippingCountry: data[this.shopifyOrderShippingCountryField] !== undefined ? data[this.shopifyOrderShippingCountryField] : null,
      shippingCity: data[this.shopifyOrderShippingCityField] !== undefined ? data[this.shopifyOrderShippingCityField] : null,
    });
  }

  static serialiseShopifyOrderShippingOption({
    option,
  }: {
    option: ShopifyOrderShippingOption,
  }): any {
    const data: any = {};
    data[this.shopifyOrderShippingOptionCodeField] = option.code;
    data[this.shopifyOrderShippingOptionPriceField] = option.price;
    data[this.shopifyOrderShippingOptionCurrencyField] = option.currency;
    data[this.shopifyOrderShippingOptionTitleField] = option.title;
    return data;
  }

  static deserialiseShopifyOrderShippingOption({
    data,
  }: {
    data: any,
  }): ShopifyOrderShippingOption {
    return new ShopifyOrderShippingOption({
      code: data[this.shopifyOrderShippingOptionCodeField],
      price: data[this.shopifyOrderShippingOptionPriceField],
      currency: data[this.shopifyOrderShippingOptionCurrencyField],
      title: data[this.shopifyOrderShippingOptionTitleField],
    });
  }
}