export interface FulfillmentCreatePayload {
  orderId: string;
  updatedAt: Date;
  countryCode?: string | undefined;
  postCode?: string | undefined;
}