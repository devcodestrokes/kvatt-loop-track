export class ShopifyShopNotRegistered extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class ShopifyInvalidCheckCode extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class ShopifyOrderNotFound extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class ShopifyShopMisconfigured extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class ShopifyShopAlreadyLinked extends Error {
  shopId: string;
  merchantId: string;
  message: string;
  constructor(
    shopId: string,
    merchantId: string,
    message: string,
  ) {
    super();
    this.shopId = shopId;
    this.merchantId = merchantId;
    this.message = message;
  }

  toString() {
    return `ShopifyShopAlreadyLinked - ShopID: ${this.shopId} - MerchantID: ${this.merchantId} - ${this.message} `;
  }
}

