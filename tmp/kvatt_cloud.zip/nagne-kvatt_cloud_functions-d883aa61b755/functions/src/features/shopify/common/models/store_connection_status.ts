export interface StoreConnectionStatus {
  isConnected: boolean;
  hasRequiredScopes: boolean;
  hasAccessToken: boolean;

}