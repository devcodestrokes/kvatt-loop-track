import { Period } from "../../../domain/common/period";
import { ShopifyOrder } from "../../../domain/shopify/shopify_order";
import { ShopifyOrderRepositoryInterface } from "../../../domain/shopify/shopify_order_repository_interface";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "../common/serialisers";

export class ShopifyOrderRepository implements ShopifyOrderRepositoryInterface {
  async createShopifyOrder({
    id,
    shopId,
    order,
  }: {
    id: string,
    shopId: string,
    order: ShopifyOrder,
  }): Promise<void> {
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}/${Serialisers.SHOPIFY_ORDERS_SUBCOLLECTION}/${id}`,
      data: Serialisers.serialiseShopifyOrder({
        order: order,
      })
    });
  }

  async retrieveShopifyOrders({
    shopId,
    period,
  }: {
    shopId: string,
    period?: Period | undefined,
  }): Promise<ShopifyOrder[]> {
    const fieldNames: string[] = [];
    const operators: any[] = [];
    const targetValues: any[] = [];

    if (period !== undefined) {
      fieldNames.push(Serialisers.shopifyOrderCreatedAtField);
      operators.push('>=');
      targetValues.push(period.start);
      fieldNames.push(Serialisers.shopifyOrderCreatedAtField);
      operators.push('<=');
      targetValues.push(period.end);
    }

    const results: QueryResult[] = await FirestoreClient.retrieveDocuments({
      collectionPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}/${Serialisers.SHOPIFY_ORDERS_SUBCOLLECTION}`,
      fieldNames: fieldNames,
      operators: operators,
      targetValues: targetValues,
    });

    return results.map((result: QueryResult) => {
      return Serialisers.deserialiseShopifyOrder({
        data: result.data,
      });
    });
  }

  async retrieveShopifyOrdersByOrderId({
    shopId,
    orderId,
  }: {
    shopId: string,
    orderId: string,
  }): Promise<ShopifyOrder | null> {
    const results: QueryResult[] = await FirestoreClient.retrieveDocuments({
      collectionPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}/${Serialisers.SHOPIFY_ORDERS_SUBCOLLECTION}`,
      fieldNames: [Serialisers.shopifyOrderOrderIdField],
      operators: ['=='],
      targetValues: [orderId],
    });

    if (results.length === 0) {
      return null;
    }

    return Serialisers.deserialiseShopifyOrder({
      data: results[0].data,
    });
  }
}