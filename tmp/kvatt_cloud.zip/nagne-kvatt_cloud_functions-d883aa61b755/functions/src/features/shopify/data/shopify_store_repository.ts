import { ShopifyStore } from "../../../domain/shopify/shopify_store";
import { ShopifyStoreRepositoryInterface } from "../../../domain/shopify/shopify_store_repository_interface";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "../common/serialisers";

export class ShopifyStoreRepository implements ShopifyStoreRepositoryInterface {

  async setMerchantId({
    shopId,
    merchantId,
  }: {
    shopId: string,
    merchantId: string,
  }): Promise<void> {
    const data: any = {};
    data[`${Serialisers.shopifyStoresMerchantIdField}`] = merchantId;
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}`,
      data: data,
    });
  }

  async setCheckCode({
    shopId,
    code
  }: {
    shopId: string,
    code: string
  }): Promise<void> {
    const data: any = {};
    data[`${Serialisers.shopifyStoresCheckCodeField}`] = code;
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}`,
      data: data,
    });
  }

  async setToken({
    shopId,
    token
  }: {
    shopId: string,
    token: string
  }): Promise<void> {
    const data: any = {};
    data[`${Serialisers.shopifyStoresAccessTokenField}`] = token;
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}`,
      data: data,
    });
  }

  async setScopes({
    shopId,
    scopes,
  }: {
    shopId: string,
    scopes: string[],
  }): Promise<void> {
    const data: any = {};
    data[`${Serialisers.shopifyStoresScopesField}`] = scopes;
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}`,
      data: data,
    });
  }

  async setKvattShippingMethods({
    shopId,
    shippingMethods,
  }: {
    shopId: string,
    shippingMethods: string[],
  }): Promise<void> {
    const data: any = {};
    data[`${Serialisers.shopifyStoresKvattShippingMethodsField}`] = shippingMethods;
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}`,
      data: data,
    });
  }

  async setSendGenericReturnEmailNudge({
    shopId,
    sendGenericReturnEmailNudge,
  }: {
    shopId: string,
    sendGenericReturnEmailNudge: boolean,
  }): Promise<void> {
    const data: any = {};
    data[`${Serialisers.shopifyStoresSendGenericReturnEmailNudgeField}`] = sendGenericReturnEmailNudge;
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}`,
      data: data,
    });
  }

  async retrieveShopifyStoreByShopId({
    shopId,
  }: {
    shopId: string,
  }): Promise<ShopifyStore | null> {
    const doc: QueryResult | null = await FirestoreClient.retrieveDocument({
      documentPath: `${Serialisers.SHOPIFY_STORES_COLLECTION}/${shopId}`,
    });

    if (doc === null) {
      return null;
    }

    return Serialisers.deserialiseShopifyStore(
      doc.documentId,
      doc.data,
    );
  }

  async retrieveShopifyStoreByMerchantId({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<ShopifyStore | null> {
    const docs: QueryResult[] = await FirestoreClient.retrieveDocuments({
      collectionPath: Serialisers.SHOPIFY_STORES_COLLECTION,
      fieldNames: ['merchantId'],
      operators: ['=='],
      targetValues: [merchantId],
    });

    if (docs.length === 0) {
      return null;
    }

    return Serialisers.deserialiseShopifyStore(
      docs[0].documentId,
      docs[0].data,
    );
  }

  async retrieveShopifyStoreByCheckCode({
    checkCode,
  }: {
    checkCode: string,
  }): Promise<ShopifyStore | null> {
    const docs: QueryResult[] = await FirestoreClient.retrieveDocuments({
      collectionPath: Serialisers.SHOPIFY_STORES_COLLECTION,
      fieldNames: [Serialisers.shopifyStoresCheckCodeField],
      operators: ['=='],
      targetValues: [checkCode],
    });

    if (docs.length === 0) {
      return null;
    }

    return Serialisers.deserialiseShopifyStore(
      docs[0].documentId,
      docs[0].data,
    );
  }
}