import { ShopifyOrderFulfillmentRepositoryInterface } from "../../../domain/shopify/shopify_order_fulfillment_repository_interface";
import { FirestoreClient } from "../../../services/firebase/firestore_client";
import { Serialisers } from "../common/serialisers";

export class ShopifyOrderFulfillmentRepository implements ShopifyOrderFulfillmentRepositoryInterface {

  async createNewOrderFulfillment({
    id,
    shopId,
    merchantId,
    orderId,
    orderNumber,
    shippingMethodCode,
    date,
    countryCode,
    postCode,
  }: {
    id: string,
    shopId: string,
    merchantId: string,
    orderId: string,
    orderNumber: string,
    shippingMethodCode: string,
    date: Date,
    countryCode?: string | undefined,
    postCode?: string | undefined,
  }): Promise<void> {
    const data: any = {};

    data[Serialisers.shopifyOrderFulfillmentsShopIdField] = shopId;
    data[Serialisers.shopifyOrderFulfillmentsMerchantIdField] = merchantId;
    data[Serialisers.shopifyOrderFulfillmentsOrderIdField] = orderId;
    data[Serialisers.shopifyOrderFulfillmentsOrderNumberField] = orderNumber;
    data[Serialisers.shopifyOrderFulfillmentsShippingMethodCodeField] = shippingMethodCode;
    data[Serialisers.shopifyOrderFulfillmentsDateField] = date;
    data[Serialisers.shopifyOrderFulfillmentsCountryCodeField] = countryCode;
    data[Serialisers.shopifyOrderFulfillmentsPostCodeField] = postCode;

    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.SHOPIFY_ORDER_FULFILLMENTS_COLLECTION}/${id}`,
      data: data,
    });
  }

  async countShipifyOrderFulfillments({
    merchantId,
    datedAfter,
  }: {
    merchantId: string,
    datedAfter?: Date | undefined,
  }): Promise<number> {
    const fieldNames: string[] = [
      Serialisers.shopifyOrderFulfillmentsMerchantIdField,
    ];
    const operators: string[] = ['=='];
    const targetValues: any[] = [merchantId];

    if (datedAfter !== undefined) {
      fieldNames.push(Serialisers.shopifyOrderFulfillmentsDateField);
      operators.push('>');
      targetValues.push(datedAfter);
    }

    const count: number = await FirestoreClient.countDocuments({
      collectionPath: Serialisers.SHOPIFY_ORDER_FULFILLMENTS_COLLECTION,
      fieldNames: fieldNames,
      operators: operators,
      targetValues: targetValues,
    });
    return count;
  }
}