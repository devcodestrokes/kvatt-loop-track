import { ShopifyStore } from "../../../domain/shopify/shopify_store";
import { ShopifyWorkflowInterface } from "../../../domain/shopify/shopify_workflow_interface";
import { ShopifyGraphQLClient } from "../../../services/shopify/shopify_graphql_client";
import { ShopifyShopMisconfigured } from "../common/errors";

export class ShopifyWorkflowUtil implements ShopifyWorkflowInterface {

  shopifyStore: ShopifyStore;
  shopifyGraphQLClient: ShopifyGraphQLClient;

  constructor({
    shopifyStore,
    shopifyGraphQLClient,
  }: {
    shopifyStore: ShopifyStore,
    shopifyGraphQLClient: ShopifyGraphQLClient,
  }) {
    this.shopifyStore = shopifyStore;
    this.shopifyGraphQLClient = shopifyGraphQLClient;
  }

  async triggerLostPackStatusChangedWorkflow({
    orderId,
    customerId,
  }: {
    orderId: number,
    customerId: number,
  }) {
    if (this.shopifyStore.packStatusChangedTriggerId === null) {
      throw new ShopifyShopMisconfigured(`Shopify shop with ID ${this.shopifyStore.shopId} has missing configuration for packStatusChangedTriggerId`);
    }

    await this.shopifyGraphQLClient.triggerWorkflow({
      triggerId: this.shopifyStore.packStatusChangedTriggerId!,
      fields: ['status', 'order_id', 'customer_id'],
      values: ['LOST', orderId, customerId],
    });
  }

  async triggerReturnedPackStatusChangedWorkflow({
    orderId,
    customerId,
  }: {
    orderId: number,
    customerId: number,
  }) {
    if (this.shopifyStore.packStatusChangedTriggerId === null) {
      throw new ShopifyShopMisconfigured(`Shopify shop with ID ${this.shopifyStore.shopId} has missing configuration for packStatusChangedTriggerId`);
    }

    await this.shopifyGraphQLClient.triggerWorkflow({
      triggerId: this.shopifyStore.packStatusChangedTriggerId!,
      fields: ['status', 'order_id', 'customer_id'],
      values: ['RETURNED', orderId, customerId],
    });
  }
}