import { ShopifyManager } from "../../../domain/shopify/shopify_manager";
import { ShopifyStore } from "../../../domain/shopify/shopify_store";
import { DeliveryMethodDefinitionObject, DeliveryProfileObject, OrderObject } from "../../../services/shopify/models";
import { ShopifyInvalidCheckCode, ShopifyShopMisconfigured, ShopifyShopNotRegistered } from "../common/errors";
import { FulfillmentCreatePayload } from "../common/models/fulfillment_create_payload";
import { ShopifyOrderFulfillmentRepository } from "../data/shopify_order_fulfillment_repository";
import { ShopifyStoreRepository } from "../data/shopify_store_repository";
import { ShopifyClientFactory } from "../../../services/shopify/shopify_client_factory";
import { ShopifyOrderNotFound, ShopifyWebhookUnknownError } from "../../../services/shopify/errors";
import { ShopifyStoreRepositoryInterface } from "../../../domain/shopify/shopify_store_repository_interface";
import { ShopifyOrderFulfillmentRepositoryInterface } from "../../../domain/shopify/shopify_order_fulfillment_repository_interface";
import { getConfigs } from "../../../environments";
import { ShopifyUtils } from "../../../services/shopify/shopify_utils";
import { ShippingMethod } from "../../../domain/shopify/shipping_method";
import { OrderCreatePayload } from "../common/models/order_create_payload";
import { ShopifyOrderRepository } from "../data/shopify_order_repository";
import { ShopifyGraphQLClient } from "../../../services/shopify/shopify_graphql_client";
import { NudgesManager } from "../../../domain/nudges/nudges_manager";
import { ReturnReminderNudgesRepositoryInterface } from "../../../domain/nudges/return_reminder_nudges_repository_interface";
import { ReturnReminderNudgesRepository } from "../../nudges/data/return_reminder_nudges_repository";
import { NudgeRecordRepositoryInterface } from "../../../domain/nudges/nudge_record_repository_interface";
import { NudgeRecordRepository } from "../../nudges/data/nudge_record_repository";
import { NudgesRepositoryInterface } from "../../../domain/nudges/nudges_repository_interface";
import { NudgesRepository } from "../../nudges/data/nudges_repository";
import { EmailClient } from "../../../services/email/email_client";
import { ShopifyOrder } from "../../../domain/shopify/shopify_order";
import { UsersRepository } from "../../../data/users/users_repository";
import { Merchant } from "../../../domain/users/merchant";

export class ShopifyController {

  static async setGenericReturnEmailNudge({
    merchantId,
    sendGenericReturnEmailNudge,
  }: {
    merchantId: string,
    sendGenericReturnEmailNudge: boolean,
  }): Promise<void> {
    const shopifyStoreRepo: ShopifyStoreRepositoryInterface = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepository: ShopifyOrderFulfillmentRepositoryInterface = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepository,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const store: ShopifyStore | null = await shopifyManager.retrieveShopifyStoreForMerchant({
      merchantId: merchantId,
    });

    if (store === null) {
      throw new ShopifyShopNotRegistered(`Merchant with ID ${merchantId} has no shop registered`);
    }

    await shopifyManager.updateSendGenericReturnEmailNudge({
      shopId: store.shopId,
      sendGenericReturnEmailNudge: sendGenericReturnEmailNudge,
    });
  }

  static async getStoreConnectionStatusForMerchant({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<ShopifyStore | null> {
    const shopifyStoreRepo: ShopifyStoreRepositoryInterface = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepository: ShopifyOrderFulfillmentRepositoryInterface = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepository,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    return await shopifyManager.verifyMerchantConnectionStatus({
      merchantId: merchantId,
    });
  }

  static async checkShippingMethodAdded({
    merchantId,
    expectedShippingMethod,
  }: {
    merchantId: string,
    expectedShippingMethod: string,
  }): Promise<boolean> {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStoreForMerchant({
      merchantId: merchantId,
    });

    if (shopifyStore === null || shopifyStore.accessToken === undefined || shopifyStore.merchantId === undefined) return false;

    const shopifyGraphQLClient = ShopifyClientFactory.buildShopifyGraphQLClient({
      shopifyStore: shopifyStore,
      hostName: 'none',
    });

    const availableDeliveryMethods: ShippingMethod[] = await this.getAvailableShippingMethodsAtCheckout({
      shopifyGraphQLClient: shopifyGraphQLClient,
    });

    const isShippingMethodAdded = shopifyManager.checkShippingMethodAddedAtCheckout({
      shopId: shopifyStore.shopId,
      availableShippingMethodsAtCheckout: availableDeliveryMethods,
      expectedShippingMethod: expectedShippingMethod,
    });

    return isShippingMethodAdded;
  }

  static async processMerchantStoreConnection({
    merchantId,
    checkCode,
  }: {
    merchantId: string,
    checkCode: string,
  }) {
    const shopifyStoreRepo: ShopifyStoreRepositoryInterface = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepository: ShopifyOrderFulfillmentRepositoryInterface = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepository,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const store: ShopifyStore | null = await shopifyManager.retrieveShopifyStoreWithCheckCode({
      checkCode: checkCode,
    });

    if (store === null) {
      throw new ShopifyInvalidCheckCode(`Invalid checkCode - ${merchantId}`);
    }

    await shopifyManager.linkMerchantToStore({
      shopId: store.shopId,
      merchantId: merchantId,
    });

    return;
  }

  static async processFulfillmentCreateWebhook({
    webhookId,
    webhookPayload,
    shopId,
  }: {
    webhookId: string,
    webhookPayload: FulfillmentCreatePayload,
    shopId: string,
  }): Promise<void> {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();


    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStore({
      shopId: shopId,
    });

    if (shopifyStore === null) {
      throw new ShopifyShopNotRegistered(`Shop with ID ${shopId} has not been registered yet.`);
    }

    if (shopifyStore.merchantId === undefined) {
      return;
    }

    if (shopifyStore.kvattShippingMethods === undefined || shopifyStore.kvattShippingMethods.length === 0) {
      throw new ShopifyShopMisconfigured(`kvattShippingMethods not available for shop: ${shopId}`);
    }

    try {

      if (getConfigs().LEGACY_SHOPIFY_STORES.includes(shopifyStore.shopId)) {

        const shopifyGraphQLClient = ShopifyClientFactory.buildShopifyGraphQLClient({
          shopifyStore: shopifyStore,
          hostName: 'none',
        });

        let order: OrderObject;
        order = await shopifyGraphQLClient.fetchOrderFromOrderId({
          orderId: webhookPayload.orderId,
        });

        if (shopifyStore.kvattShippingMethods?.includes(order.shippingLine?.code ?? '')) {
          await shopifyManager.recordShopifyOrderFulfillmentWithKvattPack({
            id: webhookId,
            shopId: shopId,
            merchantId: shopifyStore.merchantId,
            orderId: webhookPayload.orderId,
            orderNumber: order.name ?? '',
            shippingMethodCode: order.shippingLine?.code ?? '',
            date: webhookPayload.updatedAt,
            countryCode: webhookPayload.countryCode,
            postCode: webhookPayload.postCode,
          });
        }

      } else {
        const shopifyOrder: ShopifyOrder | null = await shopifyManager.retrieveShopifyOrderFromOrderId({
          shopId: shopifyStore.shopId,
          orderId: webhookPayload.orderId,
        });


        if (shopifyOrder === null) {
          throw new ShopifyOrderNotFound(`Could not find shopify_order with orderId ${webhookPayload.orderId}`);
        }

        let orderSentWithKvattOption: boolean = false;

        for (const option of shopifyOrder.shippingOptions) {
          if (option.title.toLowerCase().includes(shopifyStore.kvattShippingMethods[0].toLocaleLowerCase())) {
            orderSentWithKvattOption = true;
            break;
          }
        }

        if (orderSentWithKvattOption) {
          await shopifyManager.recordShopifyOrderFulfillmentWithKvattPack({
            id: webhookId,
            shopId: shopId,
            merchantId: shopifyStore.merchantId,
            orderId: webhookPayload.orderId,
            orderNumber: shopifyOrder?.orderNumber ?? '',
            shippingMethodCode: shopifyStore.kvattShippingMethods[0],
            date: webhookPayload.updatedAt,
            countryCode: webhookPayload.countryCode,
            postCode: webhookPayload.postCode,
          });

          if (shopifyOrder?.customerEmail !== null && shopifyStore.sendGenericReturnEmailNudge === true) {
            const returnReminderNudgesRepo: ReturnReminderNudgesRepositoryInterface = new ReturnReminderNudgesRepository();
            const nudgeRecordRepo: NudgeRecordRepositoryInterface = new NudgeRecordRepository();
            const nudgesRepo: NudgesRepositoryInterface = new NudgesRepository();
            const emailClient: EmailClient = new EmailClient();

            const nudgesManager = new NudgesManager({
              returnReminderNudgesRepo: returnReminderNudgesRepo,
              nudgeRecordRepo: nudgeRecordRepo,
              nudgesRepo: nudgesRepo,
              emailClient: emailClient,
            });

            const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
              merchantId: shopifyStore.merchantId,
            });

            await nudgesManager.scheduleReturnNudge({
              customerEmail: shopifyOrder?.customerEmail,
              merchantName: merchant === null ? '' : merchant.name,
            });
          }
        }
      }
    } catch (e: any) {
      if (e instanceof ShopifyOrderNotFound) {
        throw new ShopifyWebhookUnknownError(
          shopId,
          webhookPayload.orderId,
          `Order not found - ${e.toString()}`,
        );
      } else {
        throw new ShopifyWebhookUnknownError(
          shopId,
          webhookPayload.orderId,
          `Unknown error - ${e.toString()}`,
        );
      }
    }
  }

  static async processOrderCreateWebhook({
    webhookId,
    webhookPayload,
    shopId,
  }: {
    webhookId: string,
    webhookPayload: OrderCreatePayload,
    shopId: string,
  }): Promise<void> {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();


    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStore({
      shopId: shopId,
    });

    if (shopifyStore === null) {
      throw new ShopifyShopNotRegistered(`Shop with ID ${shopId} has not been registered yet.`);
    }

    if (shopifyStore.merchantId === undefined) {
      return;
    }

    const shopifyGraphQLClient = ShopifyClientFactory.buildShopifyGraphQLClient({
      shopifyStore: shopifyStore,
      hostName: 'none',
    });

    const availableShippingMethods: ShippingMethod[] = await this.getAvailableShippingMethodsAtCheckout({
      shopifyGraphQLClient: shopifyGraphQLClient,
    });

    try {

      await shopifyManager.recordShopifyOrder({
        id: webhookId,
        shopId: shopId,
        availableShippingMethodsAtCheckout: availableShippingMethods,
        kvattShippingMethods: shopifyStore.kvattShippingMethods,
        createdAt: webhookPayload.createdAt,
        orderNumber: webhookPayload.orderNumber,
        orderId: webhookPayload.orderId,
        customerAcceptedMarketingComms: webhookPayload.customerAcceptedMarketingComms,
        orderCurrency: webhookPayload.orderCurrency,
        totalOrderPrice: webhookPayload.totalOrderPrice,
        shippingOptions: webhookPayload.shippingOptions,
        customerEmail: webhookPayload.customerEmail,
        customerId: webhookPayload.customerId,
        shippingPostCode: webhookPayload.shippingPostCode,
        shippingCountry: webhookPayload.shippingCountry,
        shippingCity: webhookPayload.shippingCity,
      });
    } catch (e: any) {
      if (e instanceof ShopifyShopNotRegistered) {
        throw new ShopifyWebhookUnknownError(
          shopId,
          webhookPayload.orderId,
          `Shop not registered - ${e.toString()}`,
        );
      } else {
        throw new ShopifyWebhookUnknownError(
          shopId,
          webhookPayload.orderId,
          `Unknown error - ${e.toString()}`,
        );
      }
    }
  }

  private static async getAvailableShippingMethodsAtCheckout({
    shopifyGraphQLClient,
  }: {
    shopifyGraphQLClient: ShopifyGraphQLClient,
  }): Promise<ShippingMethod[]> {
    const deliveryProfiles: DeliveryProfileObject[] = await shopifyGraphQLClient.fetchDeliveryProfiles();

    const deliveryMethodDefinitions: DeliveryMethodDefinitionObject[] = ShopifyUtils.getDeliveryMethodDefinitionsFromDeliveryProfiles({
      deliveryProfiles: deliveryProfiles,
    });

    const availableDeliveryMethods: ShippingMethod[] = [];
    for (const definition of deliveryMethodDefinitions) {
      if (definition.name !== undefined && definition.active !== undefined) {
        availableDeliveryMethods.push({
          'name': definition.name ?? '',
          'isActive': definition.active ?? false,
        });
      }
    }

    return availableDeliveryMethods;
  }
}