import { ShopifyManager } from "../../../domain/shopify/shopify_manager";
import { ShopifyStore } from "../../../domain/shopify/shopify_store";
import { getConfigs } from "../../../environments";
import { CryptoService } from "../../../services/crypto/crypto_service";
import { ShopifyAuthClient } from "../../../services/shopify/shopify_auth_client";
import { ShopifyShopNotRegistered } from "../common/errors";
import { StoreConnectionStatus } from "../common/models/store_connection_status";
import { ShopifyOrderFulfillmentRepository } from "../data/shopify_order_fulfillment_repository";
import { ShopifyOrderRepository } from "../data/shopify_order_repository";
import { ShopifyStoreRepository } from "../data/shopify_store_repository";

export class ShopifyAuthController {

  static async verifyShopifyRequest({
    queryParams,
  }: {
    queryParams: any,
  }): Promise<boolean> {
    const queryStringWithoutHmac = this.extractHmac({
      queryParams: queryParams,
    });

    const generatedHmacHash = CryptoService.sha256Hash({
      data: queryStringWithoutHmac,
      secret: getConfigs().SHOPIFY_CLIENT_SECRET,
    });

    const hmac = queryParams['hmac'];

    return generatedHmacHash === hmac;
  }

  static async verifyStoreConnectionStatus({
    shopId,
  }: {
    shopId: string,
  }): Promise<StoreConnectionStatus> {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();
    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const store: ShopifyStore | null = await shopifyManager.retrieveShopifyStore({
      shopId: shopId,
    });

    let hasRequiredScopes: boolean = true;

    for (const scope of getConfigs().SHOPIFY_SCOPES) {
      if (store?.scopes.includes(scope) === false) {
        hasRequiredScopes = false;
        break;
      }
    }

    return {
      isConnected: store === null || store.merchantId === undefined ? false : true,
      hasAccessToken: store?.accessToken === undefined ? false : true,
      hasRequiredScopes: hasRequiredScopes,
    }
  }

  static async redirectToShopifyAuth({
    request,
    response,
  }: {
    request: any,
    response: any,
  }) {

    const shopifyClient = this.buildShopifyClient({
      hostName: request.hostname,
    });

    await shopifyClient.redirectToShopifyAuthScreen({
      request: request,
      response: response,
    });

  }

  static async configureIntegration({
    request,
    response,
  }: {
    request: any,
    response: any,
  }): Promise<string> {

    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyClient = this.buildShopifyClient({
      hostName: request.hostname,
    });

    const callback = await shopifyClient.getSession({
      request: request,
      response: response,
    });

    const shop = callback.session.shop;
    const token = callback.session.accessToken;

    const checkCode = await shopifyManager.setShopConfigurations({
      shopId: shop,
      accessToken: token,
      scopes: getConfigs().SHOPIFY_SCOPES,
    });

    await shopifyClient.setUpWebhooks({
      callbackSession: callback.session,
    });

    return checkCode;
  }

  static async validateShopifyWebhook({
    request,
    response,
  }: {
    request: any,
    response: any,
  }): Promise<boolean> {
    const shopifyClient = this.buildShopifyClient({
      hostName: request.hostname,
    });

    const isValid = await shopifyClient.verifyWebhook({
      request: request,
      response: response,
    });

    return isValid;
  }

  private static buildShopifyClient({
    hostName,
  }: {
    hostName: string,
  }): ShopifyAuthClient {
    const shopifyClient = new ShopifyAuthClient({
      clientId: getConfigs().SHOPIFY_CLIENT_ID,
      clientSecret: getConfigs().SHOPIFY_CLIENT_SECRET,
      scopes: getConfigs().SHOPIFY_SCOPES,
      hostName: hostName,
    });

    return shopifyClient;
  }

  static async verifyShopifyRequestLegacy({
    queryParams,
  }: {
    queryParams: any,
  }): Promise<boolean> {

    const queryStringWithoutHmac = this.extractHmac({
      queryParams: queryParams,
    });

    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStore({
      shopId: queryParams.shop,
    });

    if (shopifyStore === null) {
      throw new ShopifyShopNotRegistered(`Shop with ID ${queryParams.shop} has not been registered yet.`);
    }

    const generatedHmacHash = CryptoService.sha256Hash({
      data: queryStringWithoutHmac,
      secret: shopifyStore.clientSecret,
    });

    const hmac = queryParams['hmac'];

    return generatedHmacHash === hmac;
  }

  static async validateShopifyWebhookLegacy({
    request,
    response,
  }: {
    request: any,
    response: any,
  }): Promise<boolean> {
    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStore({
      shopId: request.headers['x-shopify-shop-domain'],
    });

    if (shopifyStore === null) {
      throw new ShopifyShopNotRegistered(`Shop with ID ${request.query.shop} has not been registered yet.`);
    }

    const shopifyClient = this.buildShopifyClientLegacy({
      shopifyStore: shopifyStore,
      hostName: request.hostname,
    });

    const isValid = await shopifyClient.verifyWebhook({
      request: request,
      response: response,
    });

    return isValid;
  }

  static async redirectToShopifyAuthLegacy({
    request,
    response,
  }: {
    request: any,
    response: any,
  }) {

    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStore({
      shopId: request.query.shop,
    });

    if (shopifyStore === null) {
      throw new ShopifyShopNotRegistered(`Shop with ID ${request.query.shop} has not been registered yet.`);
    }

    const shopifyClient = this.buildShopifyClientLegacy({
      shopifyStore: shopifyStore,
      hostName: request.hostname,
    });

    await shopifyClient.redirectToShopifyAuthScreen({
      request: request,
      response: response,
    });
  }

  static async configureIntegrationLegacy({
    request,
    response,
  }: {
    request: any,
    response: any,
  }): Promise<void> {

    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStore({
      shopId: request.query.shop,
    });

    if (shopifyStore === null) {
      throw new ShopifyShopNotRegistered(`Shop with ID ${request.query.shop} has not been registered yet.`);
    }

    const shopifyClient = this.buildShopifyClientLegacy({
      shopifyStore: shopifyStore,
      hostName: request.hostname,
    });

    const callback = await shopifyClient.getSession({
      request: request,
      response: response,
    });

    const shop = callback.session.shop;
    const token = callback.session.accessToken;

    await shopifyManager.updateAccessToken({
      shopId: shop,
      token: token,
    });

    await shopifyClient.setUpWebhooks({
      callbackSession: callback.session,
    });
  }

  private static extractHmac({
    queryParams
  }: {
    queryParams: any,
  }): string {

    let queryStringWithoutHmac = '';

    for (const key in queryParams) {
      if (key !== 'hmac') {
        if (queryStringWithoutHmac === '') {
          queryStringWithoutHmac += `${key}=${queryParams[key]}`;
        } else {
          queryStringWithoutHmac += `&${key}=${queryParams[key]}`;
        }
      }
    }

    return queryStringWithoutHmac;
  }

  private static buildShopifyClientLegacy({
    shopifyStore,
    hostName,
  }: {
    shopifyStore: ShopifyStore,
    hostName: string,
  }): ShopifyAuthClient {
    const shopifyClient = new ShopifyAuthClient({
      clientId: shopifyStore.clientId,
      clientSecret: shopifyStore.clientSecret,
      scopes: shopifyStore.scopes,
      hostName: hostName,
    });

    return shopifyClient;
  }
}