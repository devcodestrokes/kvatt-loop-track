export const shopifyAppBasicUI: string = `<!doctype html>
<head>
  <title>Kvatt x Shopify</title>
  <style>
    .center {
      position: absolute;
      left: 50%;
      top: 50%;
      transform: translate(-50%, -50%);
      -ms-transform: translate(-50%, -50%);
    }
    .cta {
      color: #242527;
      margin-top: 50px;
      display: block;
      text-align: center;
    }
  </style>
</head>
<body style="background-color: #EBEBEB; color: #242527">
  <div class="center">
    <img src="https://firebasestorage.googleapis.com/v0/b/kvatt-public-assets/o/kvatt_logo_black.png?alt=media&token=304345b7-aac7-443b-b1bb-c3aa552e052c" />
    <a class="cta" href="https://app.kvatt.com/home?view=merchant-integrations" target="_blank">Go to Kvatt App >>></a>
  </div>
</body>
</html>
`;