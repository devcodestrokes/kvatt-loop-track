import { UsersRepository } from "../../../data/users/users_repository";
import { getConfigs } from "../../../environments";
import { EmailClient } from "../../../services/email/email_client";

export class ShipmentsController {

  static async sendShippingEmail({
    productQuantities,
    shippingService,
    trackingCode,
    merchantId,
  } : {
    productQuantities: any[],
    shippingService: string,
    trackingCode: string,
    merchantId: string,
  }): Promise<void> {

    const merchant = await UsersRepository.retrieveActiveMerchantById({
        merchantId: merchantId,
    });

    if (merchant === null) throw Error();

    const client = new EmailClient();

    const trackingUrl = this.getTrackingUrl(shippingService, trackingCode);

    await client.sendEmail({
        email: merchant.email,
        templateId: getConfigs().SHIPPING_SIB_TEMPLATE_ID,
        params: {
          products: productQuantities,
          shippingService: shippingService === null ? 'Not available' : shippingService,
          trackingCode: shippingService === null ? 'Not available' : trackingCode,
          trackingUrl: trackingUrl === null ? '' : trackingUrl, 
        },
      });
  }

  static getTrackingUrl(shippingService: string, trackingCode: string): string | null {
    const trackingNumber = trackingCode !== undefined ? trackingCode : '';
    switch(shippingService) {
      case 'UPS':
        return `https://wwwapps.ups.com/WebTracking/track?track=yes&trackNums=${trackingNumber}`;
      case 'DHL':
        return `https://www.dhl.com/global-en/home/tracking.html?tracking-id=${trackingNumber}`;
      case 'Royal Mail':
        return `http://www.royalmail.com/portal/rm/track?trackNumber=Z${trackingNumber}`;
      case 'DB Schenker':
        return `https://eschenker.dbschenker.com/app/tracking-public/?refNumber=${trackingNumber}`;
      default:
        return null;
    }
  }
}