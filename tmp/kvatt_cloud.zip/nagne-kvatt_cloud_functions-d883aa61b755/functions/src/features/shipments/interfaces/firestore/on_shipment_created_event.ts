import { ShipmentsController } from "../../controllers/shipments_controller";

export class OnShipmentCreatedEvent {

  static async call({
    snap,
  }: {
    snap: any,
  }) : Promise<void> {
    await ShipmentsController.sendShippingEmail({
      productQuantities: snap.data()['productQuantities'],
      shippingService: snap.data()['shippingService'],
      trackingCode: snap.data()['trackingNumber'],
      merchantId: snap.data()['merchantId'],
    });
  }
}