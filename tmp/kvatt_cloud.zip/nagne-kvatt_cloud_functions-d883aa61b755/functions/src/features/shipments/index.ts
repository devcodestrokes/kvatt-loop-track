import * as functions from 'firebase-functions';
import { SHIPMENTS_COLLECTION } from '../../data/shipments/constants';
import { getConfigs } from '../../environments';
import { OnShipmentCreatedEvent } from './interfaces/firestore/on_shipment_created_event';

export const onShipmentCreatedEvent = functions.region(getConfigs().CLOUD_FUNCTION_REGION).firestore.document(
    `${SHIPMENTS_COLLECTION}/{id}`
).onCreate(async (snap, context) => {
  await OnShipmentCreatedEvent.call({
    snap: snap,
  });
});