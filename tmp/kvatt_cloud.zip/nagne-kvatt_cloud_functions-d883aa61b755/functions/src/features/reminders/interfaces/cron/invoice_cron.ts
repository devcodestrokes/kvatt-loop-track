import { RemindersController } from "../../controllers/reminders_controller";

export class InvoiceCron {

  static async sendMonthlyReminder(): Promise<any> {
    await RemindersController.sendMonthlyInvoiceReminderToAdmin();
  }
}