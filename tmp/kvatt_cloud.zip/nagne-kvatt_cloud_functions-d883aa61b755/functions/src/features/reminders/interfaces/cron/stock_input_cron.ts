import { RemindersController } from "../../controllers/reminders_controller";

export class StockInputCron {

  static async sendReminder(): Promise<any> {
    await RemindersController.sendStockInputReminderToMerchants();
  }
}