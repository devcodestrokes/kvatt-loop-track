import * as functions from 'firebase-functions';
import { getConfigs } from '../../environments';
import { StockInputCron } from './interfaces/cron/stock_input_cron';
import { InvoiceCron } from './interfaces/cron/invoice_cron';

export const sendStockLevelsReminderCron = functions.region(getConfigs().CLOUD_FUNCTION_REGION).pubsub
    .schedule('00 09 * * 1,5')
    .timeZone('Europe/London')
    .onRun(async (_) => {
        return await StockInputCron.sendReminder();
    });

export const sendMonthlyInvoiceReminderCron = functions.region(getConfigs().CLOUD_FUNCTION_REGION).pubsub
    .schedule('00 09 01 * *')
    .timeZone('Europe/London')
    .onRun(async (_) => {
        return await InvoiceCron.sendMonthlyReminder();
    });