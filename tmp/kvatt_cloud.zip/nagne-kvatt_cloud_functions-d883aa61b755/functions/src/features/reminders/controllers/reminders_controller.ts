import { UsersRepository } from "../../../data/users/users_repository";
import { Period } from "../../../domain/common/period";
import { CheckoutPickUpInfo } from "../../../domain/insights/checkout_pick_up_info";
import { InsightsManager } from "../../../domain/insights/insights_manager";
import { ShopifyManager } from "../../../domain/shopify/shopify_manager";
import { ShopifyOrderFulfillmentRepositoryInterface } from "../../../domain/shopify/shopify_order_fulfillment_repository_interface";
import { ShopifyOrderRepositoryInterface } from "../../../domain/shopify/shopify_order_repository_interface";
import { ShopifyStoreRepositoryInterface } from "../../../domain/shopify/shopify_store_repository_interface";
import { TrackingHistoryRepositoryInterface } from "../../../domain/tracking/tracking_history_repository_interface";
import { TrackingManager } from "../../../domain/tracking/tracking_manager";
import { TrackingSource } from "../../../domain/tracking/tracking_source";

import { Merchant } from "../../../domain/users/merchant";
import { getConfigs } from "../../../environments";
import { EmailClient } from "../../../services/email/email_client";
import { TimeUtils } from "../../../utils/time_utils";
import { ShopifyOrderFulfillmentRepository } from "../../shopify/data/shopify_order_fulfillment_repository";
import { ShopifyOrderRepository } from "../../shopify/data/shopify_order_repository";
import { ShopifyStoreRepository } from "../../shopify/data/shopify_store_repository";
import { TrackingHistoryRepository } from "../../tracking/data/tracking_history_repository";


export class RemindersController {

  static async sendStockInputReminderToMerchants(): Promise<void> {
    const merchants: Merchant[] = await UsersRepository.retrieveAllActiveMerchants();
    const emailClient = new EmailClient();

    const sendEmailTasks = merchants.map((merchant: Merchant) => emailClient.sendEmail({
      email: merchant.email,
      templateId: getConfigs().STOCK_INPUT_REMINDER_SIB_TEMPLATE_ID,
      params: {
        name: merchant.name,
      }
    }));

    await Promise.all(sendEmailTasks);
  }

  static async sendMonthlyInvoiceReminderToAdmin(): Promise<void> {
    const merchants: Merchant[] = await UsersRepository.retrieveAllActiveMerchants();
    const emailClient = new EmailClient();

    const trackingHistoryRepo: TrackingHistoryRepositoryInterface = new TrackingHistoryRepository();

    const trackingManager: TrackingManager = new TrackingManager({
      trackingHistoryRepo: trackingHistoryRepo,
    });

    const shopifyStoreRepo: ShopifyStoreRepositoryInterface = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentRepo: ShopifyOrderFulfillmentRepositoryInterface = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo: ShopifyOrderRepositoryInterface = new ShopifyOrderRepository();

    const shopifyManager: ShopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const insightsManager: InsightsManager = new InsightsManager({
      trackingManager: trackingManager,
      shopifyManager: shopifyManager,
    });

    const merchantsData: any[] = [];

    for (const merchant of merchants) {
      if (merchant.trackingSource === TrackingSource.shopify) {
        const beginningOfPreviousMonth: Date = TimeUtils.getBeginningOfPreviousMonth();
        const endOfPreviousMonth: Date = TimeUtils.getEndOfPreviousMonth();

        const info: CheckoutPickUpInfo | null = await insightsManager.getMerchantCheckoutPickUpInfo({
          merchantId: merchant.id,
          period: new Period({
            start: beginningOfPreviousMonth,
            end: endOfPreviousMonth,
          })
        });
        merchantsData.push({
          merchantName: merchant.name,
          totalOrders: info?.totalOrders ?? '0',
          kvattOrders: info?.numOrdersWithKvattPack ?? '0',
          pickUpRate: info === null || info.getPickUpRate() === null ? '0' : (info.getPickUpRate()! * 100).toFixed(1),
        });
      }
    }

    await emailClient.sendEmail({
      email: getConfigs().ADMIN_RECIPIENT_EMAIL,
      templateId: getConfigs().MONTHLY_INVOICE_REMINDER_SIB_TEMPLATE_ID,
      params: {
        merchantsData: merchantsData,
      }
    });
  }
}