import { AnalyticsRepository } from "../../../data/analytics/analytics_repository";
import { PackagingsRepository } from "../../packagings/data/packagings_repository";

export class AnalyticsController {

  static async augmentAnalytics({
    analyticsId,
    packagingId,
  }: {
    analyticsId: string,
    packagingId: string,
  }): Promise<void> {
    const packaging = await PackagingsRepository.retrievePackagingById({
      packagingId: packagingId,
    });

    if (packaging === null) return;

    await AnalyticsRepository.addAdditionalPackagingInfo({
      analyticsId: analyticsId,
      packaging: packaging,
    });
  }
}