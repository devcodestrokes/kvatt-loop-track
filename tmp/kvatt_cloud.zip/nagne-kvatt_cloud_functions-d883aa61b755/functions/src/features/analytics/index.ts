import * as functions from 'firebase-functions';
import { ANALYTICS_COLLECTION } from '../../data/analytics/constants';
import { getConfigs } from '../../environments';
import { OnAnalyticsCreatedEvent } from './interfaces/firestore/on_analytics_created_event';


export const onAnalyticsCreatedEvent = functions.region(getConfigs().CLOUD_FUNCTION_REGION).firestore.document(
  `${ANALYTICS_COLLECTION}/{id}`
).onCreate(async (snap, context) => {
  await OnAnalyticsCreatedEvent.call({
    snap: snap,
    context: context,
  })
});



