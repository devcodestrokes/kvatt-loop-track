import { AnalyticsController } from "../../controllers/analytics_controller";

export class OnAnalyticsCreatedEvent {

  static async call({
    snap,
    context,
  }: {
    snap: any,
    context: any,
  }): Promise<void> {
    await AnalyticsController.augmentAnalytics({
      analyticsId: context.params.id,
      packagingId: snap.data()['packagingId'],
    });
  }
}