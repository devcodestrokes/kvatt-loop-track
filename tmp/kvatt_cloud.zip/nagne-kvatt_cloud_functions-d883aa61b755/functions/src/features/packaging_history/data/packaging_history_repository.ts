import { PackagingHistoryRepositoryInterface } from "../../../domain/packaging_history/packaging_history_repository_interface";
import { TrackingEvent } from "../../../domain/tracking/tracking_event";
import { FirestoreClient } from "../../../services/firebase/firestore_client";
import { Serialisers as packagingsSerialisers } from "../../packagings/common/serialisers";
import { Serialisers as trackingHistorySerialisers } from "../../tracking/data/serialisers";

export class PackagingHistoryRepository implements PackagingHistoryRepositoryInterface {

  async createPackagingHistory({
    packagingId,
    date,
    event,
    trackedByUserId,
    customerName = null,
    orderNumber = null,
    merchantId = null,
    merchantName = null,
  }: {
    packagingId: string,
    date: Date,
    event: TrackingEvent,
    trackedByUserId: string,
    customerName?: string | null,
    orderNumber?: string | null,
    merchantId?: string | null,
    merchantName?: string | null,
  }): Promise<void> {
    const data: any = {};
    data[trackingHistorySerialisers.trackingHistoryDateField] = date;
    data[trackingHistorySerialisers.trackingHistoryEventField] = trackingHistorySerialisers.serialiseTrackingEvent({ event: event });
    data[trackingHistorySerialisers.trackingHistoryTrackedByUserIdField] = trackedByUserId;
    data[trackingHistorySerialisers.trackingHistoryCustomerNameField] = customerName;
    data[trackingHistorySerialisers.trackingHistoryOrderNumberField] = orderNumber;
    data[trackingHistorySerialisers.trackingHistoryMerchantIdField] = merchantId;
    data[trackingHistorySerialisers.trackingHistoryMerchantNameField] = merchantName;

    await FirestoreClient.createDocument({
      collectionPath: `${packagingsSerialisers.PACKAGINGS_COLLECTION}/${packagingId}/${trackingHistorySerialisers.TRACKING_HISTORY_SUBCOLLECTION}`,
      data: data,
    });
  }

}