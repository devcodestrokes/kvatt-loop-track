import { firestore } from "firebase-admin";
import { PackagingStatus } from "../../../domain/packagings/packaging_status";
import { Packaging } from "../../../domain/packagings/packaging";

export class Serialisers {

  static PACKAGINGS_COLLECTION: string = 'packagings';

  static typeField: string = 'type';
  static codeField: string = 'code';
  static merchantIdField: string = 'merchantId';
  static merchantNameField: string = 'merchantName';
  static productTypeField: string = 'type';
  static statusField: string = 'status';
  static lastTrackedField: string = 'lastTracked';
  static orderNumberField: string = 'orderNumber';

  static WITH_CUSTOMER_STATUS = 'with-customer';
  static WITH_MERCHANT_STATUS = 'with-merchant';
  static IN_STORE_RETURNED_STATUS = 'in-store-returned';

  static deserialisePackaging({
    id,
    data,
  }: {
    id: string,
    data: firestore.DocumentData,
  }): Packaging {
    return new Packaging({
      id: id,
      code: data[Serialisers.codeField],
      type: data[Serialisers.typeField],
      status: Serialisers.deserialisePackagingStatus(data[Serialisers.statusField]),
      merchantId: data[Serialisers.merchantIdField],
      merchantName: data[Serialisers.merchantNameField],
      orderNumber: data[Serialisers.orderNumberField],
    });
  }


  static serialisePackagingStatus(status: PackagingStatus) {
    switch (status) {
      case PackagingStatus.inStoreNew:
        return 'in-store-new';
      case PackagingStatus.inStoreReturned:
        return 'in-store-returned';
      case PackagingStatus.enRouteToMerchant:
        return 'en-route-to-merchant';
      case PackagingStatus.withMerchant:
        return 'with-merchant';
      case PackagingStatus.withMerchantReturned:
        return 'with-merchant-returned';
      case PackagingStatus.withCustomer:
        return 'with-customer';
      case PackagingStatus.inMaintenance:
        return 'in-maintenance';
      case PackagingStatus.inStoreReady:
        return 'in-store-ready';
    }
  }

  static deserialisePackagingStatus(status: string): PackagingStatus {
    switch (status) {
      case 'in-store-new':
        return PackagingStatus.inStoreNew;
      case 'in-store-returned':
        return PackagingStatus.inStoreReturned;
      case 'en-route-to-merchant':
        return PackagingStatus.enRouteToMerchant;
      case 'with-merchant':
        return PackagingStatus.withMerchant;
      case 'with-merchant-returned':
        return PackagingStatus.withMerchantReturned;
      case 'with-customer':
        return PackagingStatus.withCustomer;
      case 'in-maintenance':
        return PackagingStatus.inMaintenance;
      case 'in-store-ready':
        return PackagingStatus.inStoreReady;
      default:
        throw Error(`Packaging status ${status} is not valid`);
    }
  }
}