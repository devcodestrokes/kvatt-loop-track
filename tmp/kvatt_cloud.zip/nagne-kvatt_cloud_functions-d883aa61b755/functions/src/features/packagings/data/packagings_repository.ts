import { Packaging } from "../../../domain/packagings/packaging";
import { PackagingsRepositoryInterface } from "../../../domain/packagings/packagings_repository_interface";
import { PackagingStatus } from "../../../domain/packagings/packaging_status";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "../common/serialisers";

export class PackagingsRepository implements PackagingsRepositoryInterface {

  async getPacksCount({
    status,
    productType,
    merchantId
  }: {
    status: PackagingStatus,
    productType: string,
    merchantId: string,
  }): Promise<number> {
    const num = await FirestoreClient.countDocuments({
      collectionPath: Serialisers.PACKAGINGS_COLLECTION,
      fieldNames: [
        Serialisers.statusField,
        Serialisers.productTypeField,
        Serialisers.merchantIdField,
      ],
      operators: [
        '==',
        '==',
        '=='
      ],
      targetValues: [
        Serialisers.serialisePackagingStatus(status),
        productType,
        merchantId,
      ],
    });
    return num;
  }

  static async retrievePackagingById({
    packagingId,
  }: {
    packagingId: string,
  }): Promise<Packaging | null> {
    const res = await FirestoreClient.retrieveDocument({
      documentPath: `${Serialisers.PACKAGINGS_COLLECTION}/${packagingId}`,
    });
    if (res === null) return null;

    const data = res.data;

    return new Packaging({
      id: packagingId,
      code: data['code'],
      type: data['type'],
      status: Serialisers.deserialisePackagingStatus(data['status']),
      merchantId: data['merchantId'],
      merchantName: data['merchantName'],
    });
  }

  async updatePackaging({
    packagingId,
    status = null,
    lastTracked = null,
  }: {
    packagingId: string,
    status?: PackagingStatus | null,
    lastTracked?: Date | null,
  }): Promise<void> {

    const data: any = {};

    if (status !== null) {
      data[Serialisers.statusField] = Serialisers.serialisePackagingStatus(status);
    }

    if (lastTracked !== null) {
      data[Serialisers.lastTrackedField] = lastTracked;
    }

    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.PACKAGINGS_COLLECTION}/${packagingId}`,
      data: data,
    });
  }

  async getPacksFromIds({
    packIds,
  }: {
    packIds: string[],
  }): Promise<(Packaging | null)[]> {

    const fetchTasks: Promise<QueryResult | null>[] = packIds.map((packId: string) => {
      return FirestoreClient.retrieveDocument({
        documentPath: `${Serialisers.PACKAGINGS_COLLECTION}/${packId}`,
      })
    });

    const results: (QueryResult | null)[] = await Promise.all(fetchTasks);

    const packs: (Packaging | null)[] = results.map((result: QueryResult | null) => {
      if (result === null) {
        return null;
      }
      return Serialisers.deserialisePackaging({
        id: result.documentId,
        data: result.data,
      })
    });

    return packs;
  }
}