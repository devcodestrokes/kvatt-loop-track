import { Change, EventContext } from "firebase-functions/lib/cloud-functions";
import { QueryDocumentSnapshot } from "firebase-functions/v1/firestore";
import { Serialisers } from "../../common/serialisers";
import { PackagingShipmentsController } from "../../controllers/packaging_shipments_controller";
import { SentryClient } from "../../../../services/error_logging/sentry_client";
import { getEnvironment } from "../../../../environments";

export class OnPackagingShipmentUpdatedEvent {

  static async call({
    change,
    context,
  }: {
    change: Change<QueryDocumentSnapshot>,
    context: EventContext,
  }): Promise<void> {
    const previousData = change.before.data();
    const newData = change.after.data();

    const previousPackagingShipment = Serialisers.deserialisePackagingShipment({
      id: context.params.id,
      data: previousData,
    });

    const newPackagingShipment = Serialisers.deserialisePackagingShipment({
      id: context.params.id,
      data: newData,
    });

    try {
      await PackagingShipmentsController.processPackagingShipmentUpdated({
        previousPackagingShipment: previousPackagingShipment,
        newPackagingShipment: newPackagingShipment,
      });
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
    }

    return;
  }
}