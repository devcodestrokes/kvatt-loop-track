import * as functions from 'firebase-functions';
// import { Change, EventContext } from 'firebase-functions';
import { QueryDocumentSnapshot } from 'firebase-functions/v1/firestore';
import { getConfigs } from '../../environments';
import { Serialisers } from './common/serialisers';
import { OnPackagingShipmentUpdatedEvent } from './interfaces/firestore/on_packaging_shipment_updated_event';

export const onPackagingShipmentUpdatedEvent = functions.region(getConfigs().CLOUD_FUNCTION_REGION).firestore.document(
  `${Serialisers.PACKAGING_SHIPMENTS_COLLECTION}/{id}`
).onUpdate(async (change: functions.Change<QueryDocumentSnapshot>, context: functions.EventContext) => {
  await OnPackagingShipmentUpdatedEvent.call({
    change: change,
    context: context,
  });
});