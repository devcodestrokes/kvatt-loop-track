import { PackagingShipment } from "../../../domain/packaging_shipments/packaging_shipment";
import { PackagingShipmentStatus } from "../../../domain/packaging_shipments/packaging_shipment_status";

export class Serialisers {

  static PACKAGING_SHIPMENTS_COLLECTION: string = 'packaging_shipments';

  static merchantIdField: string = 'merchantId';
  static packagingIdsField: string = 'packagingIds';
  static productQuantitiesField: string = 'productQuantities';
  static sentDateField: string = 'sentDate';
  static statusField: string = 'status';


  static deserialisePackagingShipment({
    id,
    data,
  }: {
    id: string,
    data: FirebaseFirestore.DocumentData,
  }): PackagingShipment {
    return new PackagingShipment({
      id: id,
      merchantId: data[this.merchantIdField],
      packagingIds: data[this.packagingIdsField],
      productQuantities: this.getMappedValues(data[this.productQuantitiesField]),
      sentDate: data[this.sentDateField],
      status: this.deserialisePackagingShipmentStatus({
        status: data[this.statusField],
      }),
    });
  }


  static deserialisePackagingShipmentStatus({
    status,
  }: {
    status: string,
  }): PackagingShipmentStatus {
    switch (status) {
      case 'received':
        return PackagingShipmentStatus.received;
      case 'awaiting-merchant-confirmation':
        return PackagingShipmentStatus.awaitingMerchantConfirmation;
      default:
        throw Error(`Packaging shipment status ${status} is not valid`);
    }
  }

  private static getMappedValues(map: object) {
    const tempMap: Map<string, number> = new Map<string, number>();
    for (const [key, value] of Object.entries(map)) {
      tempMap.set(key, value);
    }
    return tempMap;
  }
}