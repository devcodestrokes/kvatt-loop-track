import { PackagingsManager } from "../../../domain/packagings/packagings_manager";
import { PackagingHistoryManager } from "../../../domain/packaging_history/packaging_history_manager";
import { PackagingShipment } from "../../../domain/packaging_shipments/packaging_shipment";
import { PackagingShipmentsManager } from "../../../domain/packaging_shipments/packaging_shipments_manager";
import { PackagingShipmentStatus } from "../../../domain/packaging_shipments/packaging_shipment_status";
import { StocksManager } from "../../../domain/stocks/stocks_manager";
import { PackagingsRepository } from "../../packagings/data/packagings_repository";
import { PackagingHistoryRepository } from "../../packaging_history/data/packaging_history_repository";
import { StocksRepository } from "../../stocks/data/stocks_repository";

export class PackagingShipmentsController {

  static async processPackagingShipmentUpdated({
    previousPackagingShipment,
    newPackagingShipment,
  }: {
    previousPackagingShipment: PackagingShipment,
    newPackagingShipment: PackagingShipment,
  }): Promise<void> {
    if (previousPackagingShipment.status === PackagingShipmentStatus.awaitingMerchantConfirmation
      && newPackagingShipment.status === PackagingShipmentStatus.received) {
      const stocksRepo = new StocksRepository();
      const packagingsRepo = new PackagingsRepository();
      const packagingHistoryRepo = new PackagingHistoryRepository();

      const stocksManager = new StocksManager({
        stocksRepo: stocksRepo,
        packsRepo: packagingsRepo,
      });

      const packagingsManager = new PackagingsManager({
        packagingsRepo: packagingsRepo,
      });

      const packagingsHistoryManager = new PackagingHistoryManager({
        packagingHistoryRepo: packagingHistoryRepo,
      });

      const packagingShipmentsManager = new PackagingShipmentsManager({
        stocksManager: stocksManager,
        packagingsManager: packagingsManager,
        packagingsHistoryManager: packagingsHistoryManager,
      });

      await packagingShipmentsManager.processMerchantReceivedShipment({
        packagingShipment: newPackagingShipment,
      });
    }
  }
}