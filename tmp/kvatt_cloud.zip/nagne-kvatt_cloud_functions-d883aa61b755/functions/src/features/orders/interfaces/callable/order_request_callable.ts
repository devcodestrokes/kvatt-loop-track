import * as functions from 'firebase-functions';
import { OrdersController } from '../../controllers/orders_controller';

export class OrderRequestCallable {

  static async processOrderRequest({
    data,
    context, 
  }: {
    data: any,
    context: any,
  }): Promise<any> {

    if (!context.auth) {
      return new functions.https.HttpsError('unauthenticated', 'orderType, productType, quantity, comment, merchantEmail, and merchantName are required.');
    }

    if (!(data.orderType && data.productType && data.quantity && data.comment)) {
      return new functions.https.HttpsError('failed-precondition', 'orderType, productType, quantity, and comment are required.');
    }

    try {
      await OrdersController.sendOrderRequestEmails({
        orderType: data.orderType,
        productType: data.productType,
        quantity: data.quantity,
        comment: data.comment,
        merchantId: context.auth.uid,
      });
      return null;
    } catch(e) {
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }
}