import { OrderRequestCallable } from "./interfaces/callable/order_request_callable";
import * as functions from 'firebase-functions';
import { getConfigs } from "../../environments";

export const orderRequestCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await OrderRequestCallable.processOrderRequest({
      data: data,
      context: context,
  });
});