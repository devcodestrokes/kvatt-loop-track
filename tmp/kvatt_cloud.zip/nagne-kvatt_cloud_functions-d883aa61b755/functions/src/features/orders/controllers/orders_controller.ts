import { UsersRepository } from "../../../data/users/users_repository";
import { getConfigs } from "../../../environments";
import { EmailClient } from "../../../services/email/email_client";


export class OrdersController {

  static async sendOrderRequestEmails({
    orderType, productType, quantity,
    comment, merchantId,
  } : {
    orderType: string,
    productType: string,
    quantity: number,
    comment: string,
    merchantId: string,
  }): Promise<void> { 
    
    const merchant = await UsersRepository.retrieveActiveMerchantById({
        merchantId: merchantId,
    })

    if (merchant === null) throw Error();

    const client = new EmailClient();

    await Promise.all([
      //Email sent to Kvatt staff
      client.sendEmail({
        email: getConfigs().ORDER_REQUEST_RECIPIENT_EMAIL,
        templateId: getConfigs().ORDER_REQUEST_SIB_TEMPLATE_ID,
        params: {
          orderType: orderType,
          productType: productType,
          quantity: quantity,
          comment: comment,
          merchantEmail: merchant.email,
          merchantName: merchant.name,
        },
      }),
      //Confirmation email sent to merchant
      client.sendEmail({
        email: merchant.email,
        templateId: getConfigs().ORDER_CONFIRMATION_SIB_TEMPLATE_ID,
        params: {
          orderType: orderType,
          productType: productType,
          quantity: quantity,
          comment: comment,
        },
      }),
    ]);
  }
}