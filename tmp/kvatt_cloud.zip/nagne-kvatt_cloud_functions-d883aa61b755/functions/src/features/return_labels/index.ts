import * as functions from 'firebase-functions';
import { getConfigs } from '../../environments';
import { GetLaPosteSDCallable } from './la_poste/interfaces/callable/get_la_poste_sd_callable';

const runtimeOpts = {
  timeoutSeconds: 540,
}

export const getLaPosteSDCallable = functions.runWith(runtimeOpts).region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await GetLaPosteSDCallable.call({
    data: data,
    context: context,
  });
});



