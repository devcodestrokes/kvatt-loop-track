import { getConfigs } from "../../../../environments";
import { LaPosteClient, PlagesRangeDefinition } from "../../../../services/la_poste/la_poste_client";
import { SmartDataDefinition } from "../../../../domain/return_labels/la_poste/smart_data_definition";
import { SmartDataManager } from "../../../../domain/return_labels/la_poste/smart_data_manager";

export class LaPosteController {

  static async generateSmartDataCodes({
    quantity,
  }: {
    quantity: number,
  }): Promise<SmartDataDefinition[]> {
    const range: PlagesRangeDefinition = await this.getPlagesRange(quantity);

    const codes: SmartDataDefinition[] = [];

    const sdManager: SmartDataManager = new SmartDataManager();

    let plageNumber = range.minRangeNumber;

    while (plageNumber <= range.maxRangeNumber) {
      const datamatrix: string = await sdManager.buildDataMatrixFromPlage({
        plageNumber: plageNumber,
      });
      const label: string = sdManager.buildSmartDataLabelFromPlage({
        plageNumber: plageNumber,
      });

      codes.push({
        datamatrixImage: datamatrix,
        sdLabel: label,
      });
      plageNumber++;
    }

    return codes;
  }


  private static async getPlagesRange(
    quantity: number,
  ): Promise<PlagesRangeDefinition> {
    const client = new LaPosteClient({
      baseUrl: getConfigs().LA_POSTE_API_BASE_URL,
      plagesRangeEndpoint: getConfigs().LA_POSTE_API_RANGE_ENDPOINT,
      environment: getConfigs().ENVIRONMENT_NAME,
      clientId: getConfigs().LA_POSTE_API_CLIENT_ID,
      clientSecret: getConfigs().LA_POSTE_API_CLIENT_SECRET,
      custAccNumber: getConfigs().LA_POSTE_API_CUST_ACC_NUMBER,
      contractNumber: getConfigs().LA_POSTE_API_CONTRACT_NUMBER,
      compName: getConfigs().LA_POSTE_API_COMP_NAME,
    });
    try {
      return await client.getPlagesRange({
        quantity: quantity,
      });
    } catch (e: any) {
      throw Error(e.message);
    }
  }
}