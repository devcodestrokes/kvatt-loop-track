import { CallableContext, HttpsError } from "firebase-functions/v1/https";
import * as functions from 'firebase-functions';
import { LaPosteController } from "../../controllers/la_poste_controller";
import { SmartDataDefinition } from "../../../../../domain/return_labels/la_poste/smart_data_definition";
import { UsersRepository } from "../../../../../data/users/users_repository";


export class GetLaPosteSDCallable {

  static async call({
    data,
    context,
  }: {
    data: any,
    context: CallableContext,
  }): Promise<SmartDataDefinition[] | HttpsError> {
    if (context.auth === undefined) {
      return new functions.https.HttpsError('unauthenticated', 'only active admins can perform this operation');
    }

    const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({ userId: context.auth.uid });
    if (isActiveAdmin === false) {
      return new functions.https.HttpsError('unauthenticated', 'only active admins can perform this operation');
    }

    if (!(data.quantity)) {
      return new functions.https.HttpsError('failed-precondition', 'quantity is required');
    }

    try {
      const res: SmartDataDefinition[] = await LaPosteController.generateSmartDataCodes({
        quantity: data.quantity,
      });
      return res;
    } catch (e: any) {
      return new functions.https.HttpsError('internal', e);
    }
  }
}