import { TrackingEvent } from "../../../domain/tracking/tracking_event";
import { TrackingHistory } from "../../../domain/tracking/tracking_history";
import { TrackingSource } from "../../../domain/tracking/tracking_source";

export class InvalidTrackingEvent extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class Serialisers {

  static TRACKING_COUNTERS_COLLECTION: string = 'tracking_counters';
  static TRACKING_HISTORY_SUBCOLLECTION: string = 'history';

  static trackingCountersReturnedToKvattCountField: string = 'returnedToKvattCount';

  static trackingHistoryMerchantIdField: string = 'merchantId';
  static trackingHistoryEventField: string = 'event';
  static trackingHistoryDateField: string = 'date';
  static trackingHistoryTrackedByUserIdField: string = 'trackedByUserId';
  static trackingHistoryMerchantNameField: string = 'merchantName';
  static trackingHistoryCustomerNameField: string = 'customerName';
  static trackingHistoryOrderNumberField: string = 'orderNumber';

  static deserialiseTrackingHistory({
    parentId,
    data,
  }: {
    parentId: string,
    data: any,
  }): TrackingHistory {
    return new TrackingHistory({
      packId: parentId,
      date: data[this.trackingHistoryDateField].toDate(),
      event: this.deserialiseTrackingEvent({ event: data[this.trackingHistoryEventField] }),
      trackedByUserId: data[this.trackingHistoryTrackedByUserIdField],
      merchantId: data[this.trackingHistoryMerchantIdField],
      merchantName: data[this.trackingHistoryMerchantNameField],
      customerName: data[this.trackingHistoryCustomerNameField],
      orderNumber: data[this.trackingHistoryOrderNumberField],
    });
  }

  static serialiseTrackingEvent({
    event,
  }: {
    event: TrackingEvent,
  }): string {
    switch (event) {
      case TrackingEvent.shippedToMerchant:
        return 'shipped-to-merchant';
      case TrackingEvent.receivedByMerchant:
        return 'received-by-merchant';
      case TrackingEvent.shippedToCustomer:
        return 'shipped-to-customer';
      case TrackingEvent.returnedFromCustomer:
        return 'returned-from-customer';
      case TrackingEvent.returnedToKvatt:
        return 'returned-to-kvatt';
      case TrackingEvent.sentToMaintenance:
        return 'sent-to-maintenance';
      case TrackingEvent.outOfMaintenance:
        return 'out-of-maintenance';
      //Legacy events
      case TrackingEvent.returnedToKvattNoMaintenance:
        return 'returned-to-kvatt-no-maintenance';
      case TrackingEvent.returnedToKvattNeedsMaintenance:
        return 'returned-to-kvatt-needs-maintenance';
    }
  }

  static deserialiseTrackingEvent({
    event,
  }: {
    event: string,
  }): TrackingEvent {
    switch (event) {
      case 'shipped-to-merchant':
        return TrackingEvent.shippedToMerchant;
      case 'received-by-merchant':
        return TrackingEvent.receivedByMerchant;
      case 'shipped-to-customer':
        return TrackingEvent.shippedToCustomer;
      case 'returned-from-customer':
        return TrackingEvent.returnedFromCustomer;
      case 'returned-to-kvatt':
        return TrackingEvent.returnedToKvatt;
      case 'sent-to-maintenance':
        return TrackingEvent.sentToMaintenance;
      case 'out-of-maintenance':
        return TrackingEvent.outOfMaintenance;
      //Legacy events
      case 'returned-to-kvatt-no-maintenance':
        return TrackingEvent.returnedToKvattNoMaintenance;
      case 'returned-to-kvatt-needs-maintenance':
        return TrackingEvent.returnedToKvattNeedsMaintenance;
      default:
        throw new InvalidTrackingEvent(`Tracking event ${event} is not valid`);
    }
  }

  static deserialiseTrackingSource({
    trackingSource,
  }: {
    trackingSource: string,
  }): TrackingSource | null {
    switch (trackingSource) {
      case 'kvatt_app':
        return TrackingSource.kvattApp;
      case 'shopify':
        return TrackingSource.shopify;
      default:
        return null;
    }
  }
}