import { Period } from "../../../domain/common/period";
import { TrackingEvent } from "../../../domain/tracking/tracking_event";
import { TrackingHistory } from "../../../domain/tracking/tracking_history";
import { TrackingHistoryRepositoryInterface } from "../../../domain/tracking/tracking_history_repository_interface";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "./serialisers";

export class TrackingHistoryRepository implements TrackingHistoryRepositoryInterface {

  async getTrackingHistories({
    merchantId,
    event,
    period,
  }: {
    merchantId: string,
    event: TrackingEvent,
    period?: Period,
  }): Promise<TrackingHistory[]> {
    const fieldNames: string[] = [
      Serialisers.trackingHistoryMerchantIdField,
      Serialisers.trackingHistoryEventField,
    ];
    const operators: any[] = [
      '==',
      '==',
    ];
    const targetValues: any[] = [
      merchantId,
      Serialisers.serialiseTrackingEvent({ event: event }),
    ];

    if (period !== undefined) {
      fieldNames.push(Serialisers.trackingHistoryDateField);
      operators.push('>=');
      targetValues.push(period.start);
      fieldNames.push(Serialisers.trackingHistoryDateField);
      operators.push('<=');
      targetValues.push(period.end);
    }

    const results: QueryResult[] = await FirestoreClient.retrieveCollectionGroupDocuments({
      collectionPath: Serialisers.TRACKING_HISTORY_SUBCOLLECTION,
      fieldNames: fieldNames,
      operators: operators,
      targetValues: targetValues,
    });

    return results.map((result: QueryResult) => {
      return Serialisers.deserialiseTrackingHistory({
        parentId: result.parentId!,
        data: result.data,
      });
    });
  }

  async getTrackingHistoriesCount({
    merchantId,
    event,
    period,
  }: {
    merchantId: string,
    event: TrackingEvent,
    period?: Period | undefined,
  }): Promise<number> {
    const fieldNames: string[] = [
      Serialisers.trackingHistoryMerchantIdField,
      Serialisers.trackingHistoryEventField,
    ];
    const operators: any[] = [
      '==',
      '==',
    ];
    const targetValues: any[] = [
      merchantId,
      Serialisers.serialiseTrackingEvent({ event: event }),
    ];

    if (period !== undefined) {
      fieldNames.push(Serialisers.trackingHistoryDateField);
      operators.push('>=');
      targetValues.push(period.start);
      fieldNames.push(Serialisers.trackingHistoryDateField);
      operators.push('<=');
      targetValues.push(period.end);
    }

    return await FirestoreClient.countCollectionGroupDocuments({
      collectionPath: Serialisers.TRACKING_HISTORY_SUBCOLLECTION,
      fieldNames: fieldNames,
      operators: operators,
      targetValues: targetValues,
    });
  }
}