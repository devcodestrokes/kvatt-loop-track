import { TrackingCountersRepositoryInterface } from "../../../domain/tracking/tracking_counters_repository_interface";
import { TrackingEvent } from "../../../domain/tracking/tracking_event";
import { FirestoreClient } from "../../../services/firebase/firestore_client";
import { Serialisers } from "./serialisers";

export class TrackingCountersRepository implements TrackingCountersRepositoryInterface {

  async incrementTrackingCounter({
    userId,
    trackingEvent,
    numPacksTracked,
  }: {
    userId: string,
    trackingEvent: TrackingEvent,
    numPacksTracked: number,
  }): Promise<void> {

    if (trackingEvent !== TrackingEvent.returnedToKvatt) {
      return;
    }

    await FirestoreClient.incrementField({
      documentPath: `${Serialisers.TRACKING_COUNTERS_COLLECTION}/${userId}`,
      fieldName: Serialisers.trackingCountersReturnedToKvattCountField,
      incrementValue: numPacksTracked,
    });
  }
}