import { TrackingEvent } from "../../../../domain/tracking/tracking_event";

export class UnsupportedTrackingEvent extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class Serialisers {

  static parseTrackingEvent(trackingEvent: string): TrackingEvent {
    switch (trackingEvent) {
      case 'shipped-to-customer':
        return TrackingEvent.shippedToCustomer;
      case 'returned-to-kvatt':
        return TrackingEvent.returnedToKvatt;
      default:
        throw new UnsupportedTrackingEvent(`trackingEvent ${trackingEvent} is not supported.`);
    }
  }
}