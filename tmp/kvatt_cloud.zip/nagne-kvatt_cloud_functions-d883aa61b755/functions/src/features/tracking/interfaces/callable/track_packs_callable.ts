import * as functions from 'firebase-functions';
import { CallableContext } from 'firebase-functions/v1/https';
import { TrackingEvent } from '../../../../domain/tracking/tracking_event';
import { Serialisers, UnsupportedTrackingEvent } from './serialisers';
import { TrackingController } from '../../controllers/tracking_controller';
import { SentryClient } from '../../../../services/error_logging/sentry_client';
import { getEnvironment } from '../../../../environments';
import { UsersRepository } from '../../../../data/users/users_repository';

export class TrackPacksCallable {

  static async call({
    data,
    context,
  }: {
    data: any,
    context: CallableContext,
  }): Promise<any> {
    if (!context.auth) {
      return new functions.https.HttpsError('unauthenticated', '');
    }

    if (!data.trackingEvent) {
      return new functions.https.HttpsError('failed-precondition', 'trackingEvent is required.');
    }

    try {
      const userId: string = context.auth.uid;
      const trackingEvent: TrackingEvent = Serialisers.parseTrackingEvent(data.trackingEvent);


      switch (trackingEvent) {
        case TrackingEvent.shippedToCustomer:
          await TrackingController.processShippedToCustomerPacks({
            userId: userId,
          });
          break;
        case TrackingEvent.returnedToKvatt:
          if (trackingEvent === TrackingEvent.returnedToKvatt) {
            const isActiveAdmin: boolean = await UsersRepository.isUserActiveAdmin({ userId: userId });
            if (isActiveAdmin === false) {
              return new functions.https.HttpsError('unauthenticated', 'only active admins can perform this operation');
            }

            if (!data.numPacks) {
              return new functions.https.HttpsError('failed-precondition', 'numPacks is required for returned-to-kvatt event.');
            }
          }
          await TrackingController.processReturnedToKvattPacks({
            userId: userId,
            numPacks: data.numPacks,
          });
          break;
        default:
          return new functions.https.HttpsError('failed-precondition', `trackingEvent ${data.trackingEvent} is not supported.`);

      }
    } catch (e: any) {
      if (e instanceof UnsupportedTrackingEvent) {
        return new functions.https.HttpsError('failed-precondition', `trackingEvent ${data.trackingEvent} is not supported.`);
      }
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
      return new functions.https.HttpsError('internal', 'internal error');
    }
  }
}