import { UsersRepository } from "../../../data/users/users_repository";
import { MerchantSettings } from "../../../domain/merchant_settings/merchant_settings";
import { MerchantSettingsRepositoryInterface } from "../../../domain/merchant_settings/merchant_settings_repository_interface";
import { PackagingsRepositoryInterface } from "../../../domain/packagings/packagings_repository_interface";
import { RemindersManager } from "../../../domain/reminders/reminders_manager";
import { StocksManager } from "../../../domain/stocks/stocks_manager";
import { StocksRepositoryInterface } from "../../../domain/stocks/stocks_repository_interface";
import { TrackingCountersManager } from "../../../domain/tracking/tracking_counters_manager";
import { TrackingCountersRepositoryInterface } from "../../../domain/tracking/tracking_counters_repository_interface";
import { Merchant } from "../../../domain/users/merchant";
import { EmailClient } from "../../../services/email/email_client";
import { MerchantSettingsRepository } from "../../merchant_settings/data/merchant_settings_repository";
import { PackagingsRepository } from "../../packagings/data/packagings_repository";
import { StocksRepository } from "../../stocks/data/stocks_repository";
import { TrackingCountersRepository } from "../data/tracking_counters_respository";

export class TrackingController {

  static async processReturnedToKvattPacks({
    userId,
    numPacks,
  }: {
    userId: string,
    numPacks: number,
  }): Promise<void> {
    const trackingCountersRepo: TrackingCountersRepositoryInterface = new TrackingCountersRepository();
    const trackingCountersManager: TrackingCountersManager = new TrackingCountersManager({
      trackingCountersRepo: trackingCountersRepo,
    });

    await trackingCountersManager.incrementReturnToKvattCounterForUser({
      userId: userId,
      numPacks: numPacks,
    });
  }


  static async processShippedToCustomerPacks({
    userId,
  }: {
    userId: string,
  }) {
    const merchant: Merchant | null = await UsersRepository.retrieveActiveMerchantById({
      merchantId: userId,
    });

    if (merchant === null) {
      return;
    }

    const merchantSettingsRepo: MerchantSettingsRepositoryInterface = new MerchantSettingsRepository();

    const merchantSettings: MerchantSettings | null = await merchantSettingsRepo.getMerchantSettings({
      merchantId: userId,
    });

    if (merchantSettings === null) {
      return;
    }

    const stocksRepo: StocksRepositoryInterface = new StocksRepository();
    const packsRepo: PackagingsRepositoryInterface = new PackagingsRepository();

    const stocksManager = new StocksManager({
      stocksRepo: stocksRepo,
      packsRepo: packsRepo,
    });

    const remindersManager = new RemindersManager({
      emailClient: new EmailClient(),
    });

    for (const reminderSetting of merchantSettings.stockLevelReminderSettings) {
      const productLevel = await stocksManager.getMerchantStockLevelForProduct({
        merchantId: userId,
        product: reminderSetting.product,
      });

      await remindersManager.sendStockLevelReminderIfRequired({
        emailAddress: merchant.email,
        productMinReminderLevel: reminderSetting.minLevel,
        productCurrentLevel: productLevel,
        product: reminderSetting.product,
      });
    }
  }
}