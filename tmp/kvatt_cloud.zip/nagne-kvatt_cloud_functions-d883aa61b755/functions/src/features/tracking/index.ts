import * as functions from 'firebase-functions';
import { getConfigs } from '../../environments';
import { TrackPacksCallable } from './interfaces/callable/track_packs_callable';

export const trackPacksCallable = functions.region(getConfigs().CLOUD_FUNCTION_REGION).https.onCall(async (data, context) => {
  return await TrackPacksCallable.call({
    data: data,
    context: context,
  });
});



