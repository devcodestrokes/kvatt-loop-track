import { Nudge } from "../../../domain/nudges/nudge";
import { NudgesRepositoryInterface } from "../../../domain/nudges/nudges_repository_interface";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "./serialisers";

export class NudgesRepository implements NudgesRepositoryInterface {

  async setNudge({
    nudge,
  }: {
    nudge: Nudge,
  }): Promise<void> {
    await FirestoreClient.createDocument({
      collectionPath: `${Serialisers.NUDGES_COLLECTION}`,
      data: Serialisers.serialiseNudge({
        nudge: nudge,
      })
    });
  }

  async retrieveNudges({
    dateBefore,
  }: {
    dateBefore: Date,
  }): Promise<Nudge[]> {
    const docs: QueryResult[] = await FirestoreClient.retrieveDocuments({
      collectionPath: Serialisers.NUDGES_COLLECTION,
      fieldNames: [
        Serialisers.nudgesSendDateField,
      ],
      operators: [
        '<',
      ],
      targetValues: [
        dateBefore,
      ],
    });

    return docs.map((doc: QueryResult) => {
      return Serialisers.deserialiseNudge({
        id: doc.documentId,
        data: doc.data
      });
    });
  }

  async deleteNudge({
    id,
  }: {
    id: string,
  }): Promise<void> {
    await FirestoreClient.deleteDocument({
      documentPath: `${Serialisers.NUDGES_COLLECTION}/${id}`,
    });
  }
}