import { NudgeRecord } from "../../../domain/nudges/nudge_record";
import { NudgeRecordRepositoryInterface } from "../../../domain/nudges/nudge_record_repository_interface";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "./serialisers";

export class NudgeRecordRepository implements NudgeRecordRepositoryInterface {

  async setRecord({
    record,
  }: {
    record: NudgeRecord,
  }): Promise<void> {
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.NUDGES_RECORDS_COLLECTION}/${record.recordId}`,
      data: Serialisers.serialiseNudgeRecord({ record: record }),
    });
  }

  async retrieveRecord({
    recordId
  }: {
    recordId: string,
  }): Promise<NudgeRecord | null> {
    const doc: QueryResult | null = await FirestoreClient.retrieveDocument({
      documentPath: `${Serialisers.NUDGES_RECORDS_COLLECTION}/${recordId}`,
    });
    if (doc === null) return null;
    return Serialisers.deserialiseNudgeRecord({
      id: doc.documentId,
      data: doc.data
    });
  }
}