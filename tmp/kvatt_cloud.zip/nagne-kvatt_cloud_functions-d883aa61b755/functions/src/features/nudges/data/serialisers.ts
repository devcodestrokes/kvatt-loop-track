import { Nudge } from "../../../domain/nudges/nudge";
import { NudgeRecord } from "../../../domain/nudges/nudge_record";
import { NudgeType } from "../../../domain/nudges/nudge_type";
import { ReturnReminderNudge } from "../../../domain/nudges/return_reminder_nudge";

export class UnsupportedNudgeTypeError extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class Serialisers {

  static NUDGES_RETURN_REMINDERS_COLLECTION: string = 'nudges_return_reminders';

  static nudgesReturnRemindersNextSendDateField: string = 'nextSendDate';
  static nudgesReturnRemindersNumTimesSentField: string = 'numTimesSent';
  static nudgesReturnRemindersMerchantIdField: string = 'merchantId';
  static nudgesReturnRemindersOrderNumberField: string = 'orderNumber';

  static NUDGES_RECORDS_COLLECTION: string = 'nudges_records';

  static nudgesRecordsLastSentDateField: string = 'lastSentDate';
  static nudgesRecordsNudgeTypeField: string = 'nudgeType';

  static NUDGES_COLLECTION: string = 'nudges';

  static nudgesNudgeTypeField: string = 'nudgeType';
  static nudgesSendDateField: string = 'sendDate';
  static nudgesCustomerEmailField: string = 'customerEmail';
  static nudgesMerchantNameField: string = 'merchantName';

  static deserialiseReturnReminderNudge({
    id,
    data,
  }: {
    id: string,
    data: any,
  }): ReturnReminderNudge {
    return new ReturnReminderNudge({
      packId: id,
      merchantId: data[this.nudgesReturnRemindersMerchantIdField],
      orderNumber: data[this.nudgesReturnRemindersOrderNumberField],
      nextSendDate: data[this.nudgesReturnRemindersNextSendDateField],
      numTimesSent: data[this.nudgesReturnRemindersNumTimesSentField],
    });
  }

  static serialiseReturnReminderNudge({
    returnReminderNudge,
  }: {
    returnReminderNudge: ReturnReminderNudge,
  }): any {
    const data: any = {};
    data[this.nudgesReturnRemindersNextSendDateField] = returnReminderNudge.nextSendDate;
    data[this.nudgesReturnRemindersNumTimesSentField] = returnReminderNudge.numTimesSent;
    data[this.nudgesReturnRemindersMerchantIdField] = returnReminderNudge.merchantId;
    data[this.nudgesReturnRemindersOrderNumberField] = returnReminderNudge.orderNumber;
    return data;
  }

  static serialiseNudgeRecord({
    record,
  }: {
    record: NudgeRecord,
  }): any {
    const data: any = {};
    data[this.nudgesRecordsLastSentDateField] = record.lastSentDate;
    data[this.nudgesRecordsNudgeTypeField] = this.serialiseNudgeType({ type: record.nudgeType });
    return data;
  }

  static deserialiseNudgeRecord({
    id,
    data,
  }: {
    id: string,
    data: any,
  }): NudgeRecord {
    return new NudgeRecord({
      recordId: id,
      lastSentDate: data[this.nudgesRecordsLastSentDateField].toDate(),
      nudgeType: this.deserialiseNudgeType({ type: data[this.nudgesRecordsNudgeTypeField] }),
    });
  }

  static serialiseNudge({
    nudge,
  }: {
    nudge: Nudge,
  }): any {
    const data: any = {};
    data[this.nudgesNudgeTypeField] = this.serialiseNudgeType({ type: nudge.nudgeType });
    data[this.nudgesSendDateField] = nudge.sendDate;
    data[this.nudgesCustomerEmailField] = nudge.customerEmail;
    data[this.nudgesMerchantNameField] = nudge.merchantName;

    return data;
  }

  static deserialiseNudge({
    id,
    data,
  }: {
    id: string,
    data: any,
  }): Nudge {
    return new Nudge({
      id: id,
      nudgeType: this.deserialiseNudgeType({ type: data[this.nudgesNudgeTypeField] }),
      sendDate: data[this.nudgesSendDateField].toDate(),
      customerEmail: data[this.nudgesCustomerEmailField],
      merchantName: data[this.nudgesMerchantNameField],

    });
  }

  static serialiseNudgeType({
    type,
  }: {
    type: NudgeType,
  }): string {
    switch (type) {
      case NudgeType.reminderEmail:
        return 'reminder-email';
      case NudgeType.thankYouEmail:
        return 'thank-you-email';
      case NudgeType.returnNudgeEmail:
        return 'return-nudge-email';
    }
  }

  static deserialiseNudgeType({
    type,
  }: {
    type: string,
  }): NudgeType {
    switch (type) {
      case 'reminder-email':
        return NudgeType.reminderEmail;
      case 'thank-you-email':
        return NudgeType.thankYouEmail;
      case 'return-nudge-email':
        return NudgeType.returnNudgeEmail;
      default:
        throw new UnsupportedNudgeTypeError(`NudgeType ${type} is not valid`);
    }
  }
}