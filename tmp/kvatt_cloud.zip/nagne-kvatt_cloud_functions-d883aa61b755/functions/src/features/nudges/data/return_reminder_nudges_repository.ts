import { ReturnReminderNudge } from "../../../domain/nudges/return_reminder_nudge";
import { ReturnReminderNudgesRepositoryInterface } from "../../../domain/nudges/return_reminder_nudges_repository_interface";
import { FirestoreClient, QueryResult } from "../../../services/firebase/firestore_client";
import { Serialisers } from "./serialisers";

export class ReturnReminderNudgesRepository implements ReturnReminderNudgesRepositoryInterface {

  async retrieveReturnReminders({
    nextSendDateBefore,
  }: {
    nextSendDateBefore: Date,
  }): Promise<ReturnReminderNudge[]> {
    const docs: QueryResult[] = await FirestoreClient.retrieveDocuments({
      collectionPath: Serialisers.NUDGES_RETURN_REMINDERS_COLLECTION,
      fieldNames: [
        Serialisers.nudgesReturnRemindersNextSendDateField,
      ],
      operators: [
        '<',
      ],
      targetValues: [
        nextSendDateBefore,
      ],
    });

    return docs.map((doc: QueryResult) => {
      return Serialisers.deserialiseReturnReminderNudge({
        id: doc.documentId,
        data: doc.data
      });
    });
  }


  async updateReturnReminder({
    returnReminder,
  }: {
    returnReminder: ReturnReminderNudge,
  }): Promise<void> {
    await FirestoreClient.saveDocument({
      documentPath: `${Serialisers.NUDGES_RETURN_REMINDERS_COLLECTION}/${returnReminder.packId}`,
      data: Serialisers.serialiseReturnReminderNudge({
        returnReminderNudge: returnReminder,
      }),
    });
  }

  async deleteReturnReminder({
    packId,
  }: {
    packId: string,
  }): Promise<void> {
    await FirestoreClient.deleteDocument({
      documentPath: `${Serialisers.NUDGES_RETURN_REMINDERS_COLLECTION}/${packId}`,
    });
  }
}