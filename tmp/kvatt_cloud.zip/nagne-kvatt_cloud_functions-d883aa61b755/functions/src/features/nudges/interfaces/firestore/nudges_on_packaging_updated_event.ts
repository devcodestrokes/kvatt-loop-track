import { PackagingStatus } from "../../../../domain/packagings/packaging_status";
import { getEnvironment } from "../../../../environments";
import { SentryClient } from "../../../../services/error_logging/sentry_client";
import { Serialisers } from "../../../packagings/common/serialisers";
import { NudgesController } from "../../controllers/nudges_controller";

export class NudgesOnPackagingUpdatedEvent {

  static async call({
    change,
    context,
  }: {
    change: any,
    context: any,
  }): Promise<void> {
    const previousData = change.before.data();
    const newData = change.after.data();

    try {
      const previousStatus: PackagingStatus = Serialisers.deserialisePackagingStatus(previousData['status']);
      const newStatus: PackagingStatus = Serialisers.deserialisePackagingStatus(newData['status']);
      const previousOrderNumber: string | null = previousData['orderNumber'];
      const previousMerchantId: string | null = previousData['merchantId'];
      const newOrderNumber: string | null = newData['orderNumber'];
      const newMerchantId: string | null = newData['merchantId'];


      if (previousStatus !== newStatus) {
        await NudgesController.handlePackStatusChange({
          packId: context.params.packagingId,
          previousStatus: previousStatus,
          newStatus: newStatus,
          previousOrderNumber: previousOrderNumber,
          newOrderNumber: newOrderNumber,
          previousMerchantId: previousMerchantId,
          newMerchantId: newMerchantId,
        });
      }

    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
    }
    return;
  }
}