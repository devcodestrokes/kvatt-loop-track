import { getEnvironment } from "../../../../environments";
import { SentryClient } from "../../../../services/error_logging/sentry_client";
import { NudgesController } from "../../controllers/nudges_controller";

export class NudgesCron {

  static async call() {
    try {
      await NudgesController.processScheduledNudges();
    } catch (e: any) {
      SentryClient.getInstance({
        environment: getEnvironment(),
      }).capture(e);
    }
  }
}