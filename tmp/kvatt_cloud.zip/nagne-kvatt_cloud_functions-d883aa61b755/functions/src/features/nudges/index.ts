import * as functions from 'firebase-functions';
import { getConfigs } from '../../environments';
import { Serialisers } from '../packagings/common/serialisers';
import { NudgesOnPackagingUpdatedEvent } from './interfaces/firestore/nudges_on_packaging_updated_event';
import { NudgesCron } from './interfaces/cron/nudges_cron';

export const nudgesCron = functions.region(getConfigs().CLOUD_FUNCTION_REGION).pubsub.schedule("every 4 hours").onRun(async (_) => {
  await NudgesCron.call();
});

export const nudgesOnPackagingUpdatedEvent = functions.region(getConfigs().CLOUD_FUNCTION_REGION).firestore.document(
  `${Serialisers.PACKAGINGS_COLLECTION}/{packagingId}`
).onUpdate(async (change, context) => {
  await NudgesOnPackagingUpdatedEvent.call({
    change: change,
    context: context,
  });
});

