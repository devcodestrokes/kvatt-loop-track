import { NudgeRecordRepositoryInterface } from "../../../domain/nudges/nudge_record_repository_interface";
import { NudgesManager } from "../../../domain/nudges/nudges_manager";
import { NudgesRepositoryInterface } from "../../../domain/nudges/nudges_repository_interface";
import { ReturnReminderNudge } from "../../../domain/nudges/return_reminder_nudge";
import { ReturnReminderNudgesRepositoryInterface } from "../../../domain/nudges/return_reminder_nudges_repository_interface";
import { PackagingStatus } from "../../../domain/packagings/packaging_status";
import { ShopifyManager } from "../../../domain/shopify/shopify_manager";
import { ShopifyOrderRepositoryInterface } from "../../../domain/shopify/shopify_order_repository_interface";
import { ShopifyStore } from "../../../domain/shopify/shopify_store";
import { ShopifyWorkflowInterface } from "../../../domain/shopify/shopify_workflow_interface";
import { getConfigs } from "../../../environments";
import { EmailClient } from "../../../services/email/email_client";
import { OrderObject } from "../../../services/shopify/models";
import { ShopifyClientFactory } from "../../../services/shopify/shopify_client_factory";
import { ShopifyGraphQLClient } from "../../../services/shopify/shopify_graphql_client";
import { ShopifyOrderFulfillmentRepository } from "../../shopify/data/shopify_order_fulfillment_repository";
import { ShopifyOrderRepository } from "../../shopify/data/shopify_order_repository";
import { ShopifyStoreRepository } from "../../shopify/data/shopify_store_repository";
import { ShopifyWorkflowUtil } from "../../shopify/utils/shopify_workflow_util";
import { NudgeRecordRepository } from "../data/nudge_record_repository";
import { NudgesRepository } from "../data/nudges_repository";
import { ReturnReminderNudgesRepository } from "../data/return_reminder_nudges_repository";

export class NudgesController {

  static async handlePackStatusChange({
    packId,
    previousStatus,
    newStatus,
    previousOrderNumber,
    newOrderNumber,
    previousMerchantId,
    newMerchantId,
  }: {
    packId: string,
    previousStatus: PackagingStatus,
    newStatus: PackagingStatus,
    previousOrderNumber: string | null,
    newOrderNumber: string | null,
    previousMerchantId: string | null,
    newMerchantId: string | null,
  }): Promise<void> {
    const returnReminderNudgesRepo: ReturnReminderNudgesRepositoryInterface = new ReturnReminderNudgesRepository();
    const nudgeRecordRepo: NudgeRecordRepositoryInterface = new NudgeRecordRepository();
    const nudgesRepo: NudgesRepositoryInterface = new NudgesRepository();
    const emailClient: EmailClient = new EmailClient();

    const nudgesManager: NudgesManager = new NudgesManager({
      returnReminderNudgesRepo: returnReminderNudgesRepo,
      nudgeRecordRepo: nudgeRecordRepo,
      nudgesRepo: nudgesRepo,
      emailClient: emailClient,
    });

    if (await nudgesManager.shouldSendPackReturnThankYouMessage({
      previousPackStatus: previousStatus,
      newPackStatus: newStatus,
    }) === true) {

      if (previousOrderNumber === null || previousOrderNumber === undefined || previousOrderNumber === "" || previousMerchantId === null) {
        return;
      }

      const shopifyStoreRepo = new ShopifyStoreRepository();
      const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
      const shopifyOrderRepo: ShopifyOrderRepositoryInterface = new ShopifyOrderRepository();

      const shopifyManager = new ShopifyManager({
        shopifyStoreRepo: shopifyStoreRepo,
        shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
        shopifyOrderRepo: shopifyOrderRepo,
      });

      const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStoreForMerchant({
        merchantId: previousMerchantId,
      });

      if (shopifyStore === null) {
        return;
      }

      let shopifyGraphQLClient: ShopifyGraphQLClient;

      if (getConfigs().LEGACY_SHOPIFY_STORES.includes(shopifyStore.shopId)) {
        shopifyGraphQLClient = ShopifyClientFactory.buildShopifyGraphQLClientLegacy({
          shopifyStore: shopifyStore,
          hostName: 'none',
        });
      } else {
        shopifyGraphQLClient = ShopifyClientFactory.buildShopifyGraphQLClient({
          shopifyStore: shopifyStore,
          hostName: 'none',
        });
      }

      const orderData: OrderObject = await shopifyGraphQLClient.fetchOrderIdAndCustomerIdFromOrderNumber({
        orderNumber: previousOrderNumber,
      });

      const customerId: string | undefined = orderData.customerId;
      const orderId: string | undefined = orderData.id;

      if (customerId === undefined || orderId === undefined) {
        return;
      }

      const hasRecentlySent = await nudgesManager.hasSentNudgeRecently({
        merchantId: previousMerchantId,
        customerId: customerId,
      });

      if (hasRecentlySent === true) {
        await nudgesManager.clearReturnReminderNudge({
          packId: packId,
        });
        return;
      }

      await this.triggerShopifyPackReturnedWorkflow({
        orderId: orderId,
        customerId: customerId,
        shopifyStore: shopifyStore,
        shopifyGraphQLClient: shopifyGraphQLClient,
      });

      await nudgesManager.clearReturnReminderNudge({
        packId: packId,
      });

      await nudgesManager.setThankYouRecord({
        merchantId: previousMerchantId,
        customerId: customerId,
      });
    }

    if (previousStatus !== PackagingStatus.withCustomer
      && newStatus === PackagingStatus.withCustomer
      && newOrderNumber !== null
      && newOrderNumber !== ""
      && previousMerchantId !== null) {
      await nudgesManager.initialiseNudgesReminderForPackSentToCustomer({
        packId: packId,
        merchantId: previousMerchantId,
        orderNumber: newOrderNumber,
      });
    }

    return;
  }

  static async processScheduledNudges() {
    const returnReminderNudgesRepo: ReturnReminderNudgesRepositoryInterface = new ReturnReminderNudgesRepository();
    const nudgeRecordRepo: NudgeRecordRepositoryInterface = new NudgeRecordRepository();
    const nudgesRepo: NudgesRepositoryInterface = new NudgesRepository();
    const emailClient: EmailClient = new EmailClient();

    const nudgesManager: NudgesManager = new NudgesManager({
      returnReminderNudgesRepo: returnReminderNudgesRepo,
      nudgeRecordRepo: nudgeRecordRepo,
      nudgesRepo: nudgesRepo,
      emailClient: emailClient,
    });

    const nudgeTasks = [];

    nudgeTasks.push(
      this.sendPackReturnReminders({
        nudgesManager: nudgesManager,
      }),
    );

    nudgeTasks.push(
      this.sendGenericReturnEmailNudges({
        nudgesManager: nudgesManager,
      }),
    )

    await Promise.all(nudgeTasks);
  }

  private static async sendGenericReturnEmailNudges({
    nudgesManager,
  }: {
    nudgesManager: NudgesManager,
  }) {
    await nudgesManager.checkAndSendReturnNudges();
  }

  private static async sendPackReturnReminders({
    nudgesManager,
  }: {
    nudgesManager: NudgesManager
  }) {
    const reminders: ReturnReminderNudge[] = await nudgesManager.retrieveRemindersToBeSent();

    const shopifyStoreRepo = new ShopifyStoreRepository();
    const shopifyOrderFulfillmentsRepo = new ShopifyOrderFulfillmentRepository();
    const shopifyOrderRepo: ShopifyOrderRepositoryInterface = new ShopifyOrderRepository();

    const shopifyManager = new ShopifyManager({
      shopifyStoreRepo: shopifyStoreRepo,
      shopifyOrderFulfillmentsRepo: shopifyOrderFulfillmentsRepo,
      shopifyOrderRepo: shopifyOrderRepo,
    });

    const workFlowTasks = [];
    const updateTasks = [];
    const recordUpdateTasks = [];
    const extensionTasks = [];

    for (const reminder of reminders) {
      const shopifyStore: ShopifyStore | null = await shopifyManager.retrieveShopifyStoreForMerchant({
        merchantId: reminder.merchantId,
      });

      if (shopifyStore === null) {
        continue;
      }

      let shopifyGraphQLClient: ShopifyGraphQLClient;

      if (getConfigs().LEGACY_SHOPIFY_STORES.includes(shopifyStore.shopId)) {
        shopifyGraphQLClient = ShopifyClientFactory.buildShopifyGraphQLClientLegacy({
          shopifyStore: shopifyStore,
          hostName: 'none',
        });
      } else {
        shopifyGraphQLClient = ShopifyClientFactory.buildShopifyGraphQLClient({
          shopifyStore: shopifyStore,
          hostName: 'none',
        });
      }


      const orderData: OrderObject = await shopifyGraphQLClient.fetchOrderIdAndCustomerIdFromOrderNumber({
        orderNumber: reminder.orderNumber,
      });

      const customerId: string | undefined = orderData.customerId;
      const orderId: string | undefined = orderData.id;

      if (customerId === undefined || orderId === undefined) {
        continue;
      }

      const hasSentRecently = await nudgesManager.hasSentNudgeRecently({
        merchantId: reminder.merchantId,
        customerId: customerId,
      });

      if (hasSentRecently === false) {
        workFlowTasks.push(
          this.triggerShopifyPackLostWorkflow({
            orderId: orderId,
            customerId: customerId,
            shopifyStore: shopifyStore,
            shopifyGraphQLClient: shopifyGraphQLClient,
          })
        );

        updateTasks.push(
          nudgesManager.updateReturnReminderNudgeSent({
            returnReminderNudge: reminder,
          }),
        );

        recordUpdateTasks.push(
          nudgesManager.setReminderRecord({
            merchantId: reminder.merchantId,
            customerId: customerId,
          }),
        );
      } else {
        extensionTasks.push(
          nudgesManager.extendReturnReminderNudge({
            returnReminderNudge: reminder,
          })
        );
      }
    }

    await Promise.all(workFlowTasks);
    await Promise.all(updateTasks);
    await Promise.all(recordUpdateTasks);
    await Promise.all(extensionTasks);
    return;
  }

  private static async triggerShopifyPackLostWorkflow({
    orderId,
    customerId,
    shopifyStore,
    shopifyGraphQLClient,
  }: {
    orderId: string,
    customerId: string,
    shopifyStore: ShopifyStore,
    shopifyGraphQLClient: ShopifyGraphQLClient,
  }) {

    const shopifyWorkflowUtil: ShopifyWorkflowInterface = new ShopifyWorkflowUtil({
      shopifyStore: shopifyStore,
      shopifyGraphQLClient: shopifyGraphQLClient,
    });

    await shopifyWorkflowUtil.triggerLostPackStatusChangedWorkflow({
      orderId: parseInt(orderId),
      customerId: parseInt(customerId),
    });
  }

  private static async triggerShopifyPackReturnedWorkflow({
    orderId,
    customerId,
    shopifyStore,
    shopifyGraphQLClient,
  }: {
    orderId: string,
    customerId: string,
    shopifyStore: ShopifyStore,
    shopifyGraphQLClient: ShopifyGraphQLClient,
  }) {

    const shopifyWorkflowUtil: ShopifyWorkflowInterface = new ShopifyWorkflowUtil({
      shopifyStore: shopifyStore,
      shopifyGraphQLClient: shopifyGraphQLClient,
    });

    await shopifyWorkflowUtil.triggerReturnedPackStatusChangedWorkflow({
      orderId: parseInt(orderId),
      customerId: parseInt(customerId),
    });
  }
}