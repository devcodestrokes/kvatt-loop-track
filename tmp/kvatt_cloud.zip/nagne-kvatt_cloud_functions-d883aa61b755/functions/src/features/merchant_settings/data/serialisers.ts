import { MerchantSettings } from "../../../domain/merchant_settings/merchant_settings";
import { StockLevelReminderSetting } from "../../../domain/merchant_settings/stock_level_reminder_setting";

export class Serialisers {

  static MERCHANT_SETTINGS_COLLECTION: string = 'merchant_settings';

  static stockLevelReminderSettingsField: string = 'stockLevelReminderSettings';

  static stockLevelReminderSettingProductField: string = 'product';
  static stockLevelReminderSettingMinLevelField: string = 'minLevel';


  static deserialiseMerchantSettings({
    data,
  }: {
    data: FirebaseFirestore.DocumentData,
  }): MerchantSettings {
    const stockLevelReminderSettings: StockLevelReminderSetting[] = data[this.stockLevelReminderSettingsField].map((setting: Map<string, any>) => {
      return this.deserialiseStockLevelReminderSetting({
        data: setting,
      });
    });

    return new MerchantSettings({
      stockLevelReminderSettings: stockLevelReminderSettings,
    });
  }

  private static deserialiseStockLevelReminderSetting({
    data,
  }: {
    data: any,
  }): StockLevelReminderSetting {
    return new StockLevelReminderSetting({
      product: data[`${this.stockLevelReminderSettingProductField}`],
      minLevel: data[`${this.stockLevelReminderSettingMinLevelField}`],
    });
  }

}