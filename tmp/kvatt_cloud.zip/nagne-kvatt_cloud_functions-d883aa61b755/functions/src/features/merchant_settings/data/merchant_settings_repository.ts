import { MerchantSettings } from "../../../domain/merchant_settings/merchant_settings";
import { MerchantSettingsRepositoryInterface } from "../../../domain/merchant_settings/merchant_settings_repository_interface";
import { FirestoreClient } from "../../../services/firebase/firestore_client";
import { Serialisers } from "./serialisers";

export class MerchantSettingsRepository implements MerchantSettingsRepositoryInterface {

  async getMerchantSettings({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<MerchantSettings | null> {
    const res = await FirestoreClient.retrieveDocument({
      documentPath: `${Serialisers.MERCHANT_SETTINGS_COLLECTION}/${merchantId}`,
    });

    if (res === null) {
      return null;
    }

    return Serialisers.deserialiseMerchantSettings({
      data: res.data,
    });
  }
}