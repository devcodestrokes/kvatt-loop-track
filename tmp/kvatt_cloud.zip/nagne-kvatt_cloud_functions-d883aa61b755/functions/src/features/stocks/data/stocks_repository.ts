import { StocksRepositoryInterface } from "../../../domain/stocks/stocks_repository_interface";
import { FirestoreClient } from "../../../services/firebase/firestore_client";
import { Serialisers } from "../common/serialisers";

export class StocksRepository implements StocksRepositoryInterface {

  async incrementStockLevel({
    merchantId,
    product,
    incrementValue,
  }: {
    merchantId: string,
    product: string,
    incrementValue: number,
  }): Promise<void> {
    await FirestoreClient.incrementMapField({
      documentPath: `${Serialisers.STOCKS_COLLECTION}/${merchantId}`,
      mapName: Serialisers.levelsField,
      fieldName: product,
      incrementValue: incrementValue,
    });
  }

}