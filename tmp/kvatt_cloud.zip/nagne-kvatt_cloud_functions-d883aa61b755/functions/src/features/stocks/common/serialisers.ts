export class Serialisers {
  static STOCKS_COLLECTION: string = 'stocks';

  static levelsField: string = 'levels';
}