import { Merchant } from "../../domain/users/merchant";
import { UserAccountStatus } from "../../domain/users/user_account_status";
import { Serialisers } from "../../features/tracking/data/serialisers";
import { FirestoreClient, QueryResult } from "../../services/firebase/firestore_client";
import { USERS_COLLECTION } from "./constants";

export class UsersRepository {

  static async updateUserId({
    oldUserId,
    newUserId,
  }: {
    oldUserId: string,
    newUserId: string,
  }): Promise<void> {
    await FirestoreClient.replaceDocument({
      oldDocumentPath: `${USERS_COLLECTION}/${oldUserId}`,
      newDocumentPath: `${USERS_COLLECTION}/${newUserId}`
    });
  }

  static async retrieveActiveMerchantById({
    merchantId,
  }: {
    merchantId: string,
  }): Promise<Merchant | null> {
    const res = await FirestoreClient.retrieveDocument({
      documentPath: `${USERS_COLLECTION}/${merchantId}`
    });
    if (res === null) return null;

    const data = res.data;

    if (data['type'] !== 'merchant' || data['accountStatus'] !== 'active') {
      return null;
    }

    return new Merchant({
      id: merchantId,
      email: data['email'],
      name: data['name'],
      trackingSource: Serialisers.deserialiseTrackingSource({
        trackingSource: data['trackingSource'],
      })
    });
  }

  static async retrieveAllActiveMerchants(): Promise<Merchant[]> {
    const res = await FirestoreClient.retrieveDocuments({
      collectionPath: USERS_COLLECTION,
      fieldNames: ['type', 'accountStatus'],
      operators: ['==', '=='],
      targetValues: ['merchant', 'active'],
    });

    if (res.length === 0) return [];

    return res.map((r: QueryResult) => new Merchant({
      id: r.documentId,
      email: r.data['email'],
      name: r.data['name'],
      trackingSource: Serialisers.deserialiseTrackingSource({
        trackingSource: r.data['trackingSource'],
      })
    }));
  }

  static async isUserActiveAdmin({
    userId,
  }: {
    userId: string,
  }): Promise<boolean> {

    const res = await FirestoreClient.retrieveDocument({
      documentPath: `${USERS_COLLECTION}/${userId}`,
    });

    if (res === null) return false;

    const data = res.data;

    return data['type'] === 'admin' && data['accountStatus'] === 'active';
  }


  static async updateUserAccountStatus({
    userId,
    accountStatus,
  }: {
    userId: string,
    accountStatus: UserAccountStatus,
  }): Promise<void> {
    await FirestoreClient.saveDocument({
      documentPath: `${USERS_COLLECTION}/${userId}`,
      data: {
        'accountStatus': accountStatus === UserAccountStatus.active ? 'active' : 'pending',
      }
    });
  }

  static async deleteUser({
    userId,
  }: {
    userId: string,
  }): Promise<void> {
    await FirestoreClient.deleteDocument({
      documentPath: `${USERS_COLLECTION}/${userId}`
    });
  }
}