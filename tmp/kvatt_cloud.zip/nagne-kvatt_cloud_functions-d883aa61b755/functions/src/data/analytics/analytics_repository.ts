import { Packaging } from "../../domain/packagings/packaging";
import { FirestoreClient } from "../../services/firebase/firestore_client";
import { Serialisers } from "../../features/packagings/common/serialisers";
import { ANALYTICS_COLLECTION } from "./constants";

export class AnalyticsRepository {
  static async addAdditionalPackagingInfo({
    analyticsId,
    packaging,
  }: {
    analyticsId: string,
    packaging: Packaging,
  }): Promise<void> {
    await FirestoreClient.saveDocument({
      documentPath: `${ANALYTICS_COLLECTION}/${analyticsId}`,
      data: {
        'packagingStatus': Serialisers.serialisePackagingStatus(packaging.status),
        'merchantId': packaging.merchantId,
        'merchantName': packaging.merchantName,
      }
    });
  }
}