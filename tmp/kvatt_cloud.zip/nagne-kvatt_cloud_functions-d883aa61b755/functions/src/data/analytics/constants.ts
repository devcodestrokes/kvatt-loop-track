export const ANALYTICS_COLLECTION: string = 'analytics';
