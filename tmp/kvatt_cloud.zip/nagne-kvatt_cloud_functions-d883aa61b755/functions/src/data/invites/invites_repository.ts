import { Invite } from "../../domain/invites/invite";
import { FirestoreClient } from "../../services/firebase/firestore_client";
import { INVITES_COLLECTION } from "./constants";

export class InvitesRepository {

  static async saveInvite({
    email,
    code,
    userId,
    userType,
  }: {
    email: string,
    code: string,
    userId: string,
    userType: string,
  }) {
    await FirestoreClient.saveDocument({
      documentPath: `${INVITES_COLLECTION}/${code}`,
      data: {
        email: email,
        userId: userId,
        type: userType,
      },
    });
  }

  static async retrieveInviteByCode({
    code,
  }: {
    code: string,
  }): Promise<Invite | null> {
    const res = await FirestoreClient.retrieveDocument({
      documentPath: `${INVITES_COLLECTION}/${code}`,
    });
    if (res === null) return res;
    return new Invite({
      id: res.documentId,
      email: res.data['email'],
      userId: res.data['userId'],
      userType: res.data['type'],
    });
  }

  static async retrieveInviteByEmail({
    email,
  }: {
    email: string,
  }): Promise<Invite | null> {
    const res: any[] = await FirestoreClient.retrieveDocuments({
      collectionPath: `${INVITES_COLLECTION}`,
      fieldNames: ['email'],
      operators: ['=='],
      targetValues: [email],
    });

    if (res.length === 0 || res.length > 1) return null;
       
    return new Invite({
      id: res[0].documentId,
      email: res[0].data['email'],
      userId: res[0].data['userId'],
      userType: res[0].data['type'],
    });
  }

  static async deleteInvite({
    inviteId,
  }: {
    inviteId: string,
  }): Promise<void> {
    await FirestoreClient.deleteDocument({
      documentPath: `${INVITES_COLLECTION}/${inviteId}`
    });
  }
}