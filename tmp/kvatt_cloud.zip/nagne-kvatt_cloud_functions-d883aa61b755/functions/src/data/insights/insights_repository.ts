import { FirestoreClient } from "../../services/firebase/firestore_client";
import { ADMIN_INSIGHTS_DOCUMENT, MERCHANT_INSIGHTS_COLLECTION } from "./constants";

export class InsightsRepository {

  static async incrementMerchantTotalLevels({
    merchantId,
    numDelivered,
    numReturned,
  }: {
    merchantId: string,
    numDelivered: number,
    numReturned: number,
  }): Promise<void> {
    await Promise.all([
      FirestoreClient.incrementField({
        documentPath: `${MERCHANT_INSIGHTS_COLLECTION}/${merchantId}`,
        fieldName: 'totalDelivered',
        incrementValue: numDelivered,
      }),
      FirestoreClient.incrementField({
        documentPath: `${MERCHANT_INSIGHTS_COLLECTION}/${merchantId}`,
        fieldName: 'totalReturned',
        incrementValue: numReturned,
      }),

    ]);  
  }

  static async deleteMerchantInsights({
    merchantId,
  } : {
    merchantId: string,
  }): Promise<void> {
    await FirestoreClient.deleteDocument({
      documentPath: `${MERCHANT_INSIGHTS_COLLECTION}/${merchantId}`,
    });
  }

  static async updateAdminInsights({
    merchantId,
    numDelivered,
    numReturned,
  }: {
    merchantId: string,
    numDelivered: number,
    numReturned: number,
  }): Promise<void> {
    await Promise.all([
      FirestoreClient.incrementField({
        documentPath: `${ADMIN_INSIGHTS_DOCUMENT}`,
        fieldName: 'totalDelivered',
        incrementValue: numDelivered,
      }),
      FirestoreClient.incrementField({
        documentPath: `${ADMIN_INSIGHTS_DOCUMENT}`,
        fieldName: 'totalReturned',
        incrementValue: numReturned,
      }),
      FirestoreClient.arrayUnion({
        documentPath: `${ADMIN_INSIGHTS_DOCUMENT}`,
        fieldName: 'participatingMerchants',
        value: merchantId,
      }),
    ]);  
  }
}