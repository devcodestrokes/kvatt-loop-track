export const MERCHANT_INSIGHTS_COLLECTION: string = 'merchant_insights';
export const ADMIN_INSIGHTS_DOCUMENT: string = 'admin_insights/data';