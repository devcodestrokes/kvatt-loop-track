const uuid = require('uuid');
const crypto = require('crypto');
import { Mod37_36 } from '@konfirm/iso7064';

export class CryptoService {
  static generateRandomUuid(): string {
    return uuid.v4();
  }

  static computeMod37_36CheckSum(data: string): string {
    return Mod37_36.checksum(data);
  }

  static sha256Hash({
    data,
    secret,
  }: {
    data: string,
    secret: string,
  }): string {
    const hmac = crypto.createHmac('sha256', secret);
    const generated = hmac.update(data);
    return generated.digest('hex');
  }
}