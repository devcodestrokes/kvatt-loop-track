import { getConfigs } from "../../environments";

const SibApiV3Sdk = require("sib-api-v3-sdk");
const client = SibApiV3Sdk.ApiClient.instance;
const apiKey = client.authentications["api-key"];
apiKey.apiKey = getConfigs().SIB_API_KEY;

export class EmailClient {

  async sendEmail({
    email,
    templateId,
    params,
  }: {
    email: string,
    templateId: number,
    params: object,
  }): Promise<void> {
    const apiInstance = new SibApiV3Sdk.TransactionalEmailsApi();
    let smtpEmail = new SibApiV3Sdk.SendSmtpEmail();

    smtpEmail = {
      to: [
        {
          email: email,
        }
      ],
      templateId: templateId,
      params: params,
    };

    await apiInstance.sendTransacEmail(smtpEmail);
  }
}