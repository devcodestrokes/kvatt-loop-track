import { firestore } from 'firebase-admin';
import { FieldValue } from 'firebase-admin/firestore';

export interface QueryResult {
  data: firestore.DocumentData,
  documentId: string,
  parentId?: string,
}

export class FirestoreClient {

  static async createDocument({
    collectionPath,
    data,
  }: {
    collectionPath: string,
    data: object,
  }): Promise<void> {
    await firestore()
      .collection(collectionPath)
      .add(data);
  }

  static async saveDocument({
    documentPath,
    data,
  }: {
    documentPath: string,
    data: object,
  }): Promise<void> {
    await firestore()
      .doc(documentPath)
      .set(data, { merge: true });
  }

  static async retrieveDocument({
    documentPath
  }: {
    documentPath: string,
  }): Promise<QueryResult | null> {
    const doc = await firestore().doc(documentPath).get();
    if (doc.exists === false) return null;
    const data = doc.data();
    if (data === undefined) return null;
    return {
      data: data,
      documentId: doc.id,
    };
  }

  static async retrieveDocuments({
    collectionPath, fieldNames, operators, targetValues,
    orderBy, orderDirection, limit, startAt, endAt
  }: {
    collectionPath: string,
    fieldNames?: any[],
    operators?: any[],
    targetValues?: any[],
    orderBy?: string,
    orderDirection?: "asc" | "desc",
    limit?: number,
    startAt?: any,
    endAt?: any,
  }): Promise<QueryResult[]> {
    let snapshot = null;

    let query: any = firestore().collection(collectionPath);

    if (fieldNames !== undefined && fieldNames.length !== 0
      && operators !== undefined && operators.length !== 0
      && targetValues !== undefined && targetValues.length !== 0) {
      for (let i = 0; i < fieldNames.length; i++) {
        query = query.where(fieldNames[i], operators[i], targetValues[i]);
      }
    }

    if (orderBy !== undefined) {
      const direction = orderDirection === undefined ? 'asc' : orderDirection;
      query = query.orderBy(orderBy, direction);
    }

    if (limit !== undefined) {
      query = query.limit(limit);
    }

    if (startAt !== undefined) {
      query = query.startAt(startAt);
    }

    if (endAt !== undefined) {
      query = query.endAt(endAt);
    }

    snapshot = await query.get();

    if (snapshot === undefined) return [];
    return snapshot.docs.map((doc: any) => {
      return {
        data: doc.data(),
        documentId: doc.id
      }
    });
  }

  static async retrieveCollectionGroupDocuments({
    collectionPath, fieldNames, operators, targetValues,
    orderBy, orderDirection, limit, startAt, endAt
  }: {
    collectionPath: string,
    fieldNames?: any[],
    operators?: any[],
    targetValues?: any[],
    orderBy?: string,
    orderDirection?: "asc" | "desc",
    limit?: number,
    startAt?: any,
    endAt?: any,
  }): Promise<QueryResult[]> {
    let snapshot = null;

    let query: any = firestore().collectionGroup(collectionPath);

    if (fieldNames !== undefined && fieldNames.length !== 0
      && operators !== undefined && operators.length !== 0
      && targetValues !== undefined && targetValues.length !== 0) {
      for (let i = 0; i < fieldNames.length; i++) {
        query = query.where(fieldNames[i], operators[i], targetValues[i]);
      }
    }

    if (orderBy !== undefined) {
      const direction = orderDirection === undefined ? 'asc' : orderDirection;
      query = query.orderBy(orderBy, direction);
    }

    if (limit !== undefined) {
      query = query.limit(limit);
    }

    if (startAt !== undefined) {
      query = query.startAt(startAt);
    }

    if (endAt !== undefined) {
      query = query.endAt(endAt);
    }

    snapshot = await query.get();

    if (snapshot === undefined) return [];
    return snapshot.docs.map((doc: any) => {
      return {
        data: doc.data(),
        documentId: doc.id,
        parentId: doc.ref.parent.parent.id,
      }
    });
  }

  static async countDocuments({
    collectionPath, fieldNames, operators, targetValues,
  }: {
    collectionPath: string,
    fieldNames?: any[],
    operators?: any[],
    targetValues?: any[],
  }): Promise<number> {
    let snapshot = null;

    let query: any = firestore().collection(collectionPath);

    if (fieldNames !== undefined && fieldNames.length !== 0
      && operators !== undefined && operators.length !== 0
      && targetValues !== undefined && targetValues.length !== 0) {
      for (let i = 0; i < fieldNames.length; i++) {
        query = query.where(fieldNames[i], operators[i], targetValues[i]);
      }
    }

    snapshot = await query.count().get();
    return snapshot.data().count;
  }

  static async countCollectionGroupDocuments({
    collectionPath, fieldNames, operators, targetValues,
  }: {
    collectionPath: string,
    fieldNames?: any[],
    operators?: any[],
    targetValues?: any[],
  }): Promise<number> {
    let snapshot = null;

    let query: any = firestore().collectionGroup(collectionPath);

    if (fieldNames !== undefined && fieldNames.length !== 0
      && operators !== undefined && operators.length !== 0
      && targetValues !== undefined && targetValues.length !== 0) {
      for (let i = 0; i < fieldNames.length; i++) {
        query = query.where(fieldNames[i], operators[i], targetValues[i]);
      }
    }

    snapshot = await query.count().get();
    return snapshot.data().count;
  }

  static async replaceDocument({
    oldDocumentPath,
    newDocumentPath,
  }: {
    oldDocumentPath: string,
    newDocumentPath: string,
  }): Promise<void> {
    const doc = await firestore().doc(oldDocumentPath).get();
    if (doc.exists === false) return;
    const data = doc.data();
    if (data === undefined) return;
    await firestore()
      .doc(newDocumentPath)
      .set(data, { merge: true });
    await firestore().doc(oldDocumentPath).delete();
  }

  static async deleteDocument({
    documentPath,
  }: {
    documentPath: string,
  }): Promise<void> {
    await firestore().doc(documentPath).delete();
  }

  static async incrementMapField({
    documentPath,
    mapName,
    fieldName,
    incrementValue, //Negative if decrementing
  }: {
    documentPath: string,
    mapName: string,
    fieldName: string,
    incrementValue: number,
  }): Promise<void> {
    const docRef = firestore().doc(documentPath);
    const doc = await docRef.get();
    if (doc.exists !== true) {
      await firestore()
        .doc(documentPath)
        .set({}, { merge: true });
    }
    const data: any = {};
    data[`${mapName}.${fieldName}`] = FieldValue.increment(incrementValue);
    await docRef.update(data);
  }

  static async incrementField({
    documentPath,
    fieldName,
    incrementValue, //Negative if decrementing
  }: {
    documentPath: string,
    fieldName: string,
    incrementValue: number,
  }): Promise<void> {

    const docRef = firestore().doc(documentPath);
    const data: any = {};
    data[fieldName] = FieldValue.increment(incrementValue);
    await docRef.set(data, { merge: true });
  }

  static async arrayUnion({
    documentPath,
    fieldName,
    value,
  }: {
    documentPath: string,
    fieldName: string,
    value: any,
  }): Promise<void> {
    const docRef = firestore().doc(documentPath);
    const data: any = {};
    data[fieldName] = firestore.FieldValue.arrayUnion(value);
    await docRef.set(data, { merge: true });
  }

}




