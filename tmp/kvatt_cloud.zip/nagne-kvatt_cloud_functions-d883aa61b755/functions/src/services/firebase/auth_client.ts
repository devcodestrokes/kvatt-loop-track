const admin = require('firebase-admin');

export class AuthClient {

  static async createVerifiedUserAccount({
    email,
    password,
  }: {
    email: string,
    password: string,
  }): Promise<string> {
    const res = await admin.auth().createUser({
      email: email,
      emailVerified: true,
      password: password,
    });
    return res.uid;
  }

  static async updateUserEmail({
    userId,
    email,
  }: {
    userId: string,
    email: string,
  }): Promise<void> {
    await admin.auth().updateUser(userId, {
      email: email,
    });
  }

  static async deleteUser({
    userId,
  }: {
    userId: string,
  }): Promise<void> {
    await admin.auth().deleteUser(userId);
  }
}