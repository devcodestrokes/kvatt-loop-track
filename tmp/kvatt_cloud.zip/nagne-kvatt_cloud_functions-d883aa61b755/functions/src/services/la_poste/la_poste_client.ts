const axios = require('axios').default;

export interface PlagesRangeDefinition {
  minRangeNumber: number;
  maxRangeNumber: number;
}

export class LaPosteApiError extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class LaPosteClient {

  tokenEndpoint: string = '/token';

  defaultOriginCode: string = '88';
  defaultOfferCode: string = '3205';
  defaultProductCode: string = 'J9';
  defaultMediumType: string = 'vignette';
  articleCodeMeca: string = '84750';
  articleCodeNonMeca: string = '84751';


  baseUrl: string;
  plagesRangeEndpoint: string;
  environment: string;
  clientId: string;
  clientSecret: string;
  custAccNumber: string;
  contractNumber: string;
  compName: string;

  constructor({
    baseUrl,
    plagesRangeEndpoint,
    environment,
    clientId,
    clientSecret,
    custAccNumber,
    contractNumber,
    compName,
  }: {
    baseUrl: string,
    plagesRangeEndpoint: string,
    environment: string,
    clientId: string,
    clientSecret: string,
    custAccNumber: string,
    contractNumber: string,
    compName: string,
  }) {
    this.baseUrl = baseUrl;
    this.plagesRangeEndpoint = plagesRangeEndpoint;
    this.environment = environment;
    this.clientId = clientId;
    this.clientSecret = clientSecret;
    this.custAccNumber = custAccNumber;
    this.contractNumber = contractNumber;
    this.compName = compName;
  }

  async getPlagesRange({
    quantity,
  }: {
    quantity: number,
  }): Promise<PlagesRangeDefinition> {
    const token: string = await this.getToken();

    let headers = {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${token}`,
    };

    if (this.environment !== 'production') {
      headers = {
        ...headers,
        ...{
          'APIM-O2-EndPoint': 'sacc',
          'X-mq-requester': 'WER',
        }
      };
    }

    const options = {
      url: `${this.baseUrl}${this.plagesRangeEndpoint}`,
      method: 'post',
      headers: headers,
      data: {
        originCode: this.defaultOriginCode,
        rangeSize: quantity,
        custAccNumber: this.custAccNumber,
        contractNumber: this.contractNumber,
        compName: this.compName,
        usage: {
          offerCode: this.defaultOfferCode,
          articleCode: this.articleCodeMeca,
          productCode: this.defaultProductCode,
          mediumType: this.defaultMediumType,
        },
      },
    };

    try {
      const response = await axios.request(options);
      return {
        minRangeNumber: response.data.minRangeNumber,
        maxRangeNumber: response.data.maxRangeNumber,
      };
    } catch (e: any) {
      throw new LaPosteApiError(this.buildErrorMessage(e.response));
    }
  }

  private async getToken(): Promise<string> {
    const headers = {
      'Content-Type': 'application/x-www-form-urlencoded',
    };

    const options = {
      url: `${this.baseUrl}${this.tokenEndpoint}`,
      method: 'post',
      headers: headers,
      data: {
        client_id: this.clientId,
        client_secret: this.clientSecret,
        grant_type: 'client_credentials',
      },
    };

    try {
      const response = await axios.request(options);
      return response.data.access_token;
    } catch (e: any) {
      throw new LaPosteApiError(this.buildErrorMessage(e.response));
    }
  }

  private buildErrorMessage(response: any): string {
    let message = '';
    message += `Status code: ${response.status}`;
    message += `|Code: ${response.data.code}`;
    message += `|Message: ${response.data.message}`;
    return message;
  }
}