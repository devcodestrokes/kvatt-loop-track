import { SymbologyType, createStream } from 'symbology'


export class BarcodeService {

  //Returns a base64 encoded image of the datamatrix
  static async generate16x48Datamatrix(data: string): Promise<string> {
    const res: any = await createStream({
      symbology: SymbologyType.DATAMATRIX,
      showHumanReadableText: false,
      option2: 30,
    }, data);
    return res['data'];
  }
}