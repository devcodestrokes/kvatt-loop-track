import { shopifyApi, Session, ApiVersion, GraphqlQueryError, GraphqlClient } from '@shopify/shopify-api';
import { DeliveryProfileObject, OrderObject } from './models';
import { DeliveryProfilesFetchError, ShopifyOrderNotFound, WorkflowTriggerError } from './errors';



export class ShopifyGraphQLClient {

  shopify: any;
  client: GraphqlClient;

  constructor({
    clientId,
    clientSecret,
    scopes,
    hostName,
    shop,
    accessToken,
  }: {
    clientId: string,
    clientSecret: string,
    scopes: string[],
    hostName: string,
    shop: string,
    accessToken: string,
  }) {
    this.shopify = shopifyApi({
      apiKey: clientId,
      apiSecretKey: clientSecret,
      scopes: scopes,
      hostName: hostName,
      apiVersion: ApiVersion.January24,
      isEmbeddedApp: false,
    });

    const session = new Session({
      id: '',
      shop: shop,
      state: '',
      isOnline: false,
      accessToken: accessToken,
    });

    this.client = new this.shopify.clients.Graphql({
      session,
      apiVersion: ApiVersion.January24,
    });
  }

  async fetchOrderFromOrderId({
    orderId,
  }: {
    orderId: string,
  }): Promise<OrderObject> {
    interface ResponseBodyType {
      data: {
        order: OrderObject,
      }
    }

    try {
      const response = await this.client.query<ResponseBodyType>({
        data: `{
          order (id: "gid://shopify/Order/${orderId}") {
            id
            name
            shippingLine {
              id
              code
            }
          }
        }`,
      });

      return response.body.data.order;
    } catch (e) {
      let errorMessage: string = `Error retrieving order with order id ${orderId}`;

      if (e instanceof GraphqlQueryError) {
        if (Array.isArray(e.response.errors)) {
          errorMessage += `: ${e.response.errors[0].message}`;
        }
        throw new ShopifyOrderNotFound(errorMessage);
      } else {
        throw new ShopifyOrderNotFound(`${errorMessage}: ${e}`);
      }
    }
  }

  async fetchOrderIdAndCustomerIdFromOrderNumber({
    orderNumber,
  }: {
    orderNumber: string,
  }): Promise<OrderObject> {
    interface ResponseBodyType {
      data: {
        orders: {
          edges: any[],
        },
      }
    }

    try {
      const response = await this.client.query<ResponseBodyType>({
        data: `{
          orders (first: 1, query: "name:${orderNumber}") {
            edges {
              node {
                id
                customer {
                  id
                }
              }
            }
          }
        }`,
      });
      const fullOrderId: string = response.body.data.orders.edges[0].node.id;
      const fullCustomerId: string = response.body.data.orders.edges[0].node.customer.id;

      const orderId: string = this.getIdNumberFromFullIdString(fullOrderId);
      const customerId: string = this.getIdNumberFromFullIdString(fullCustomerId);

      return {
        id: orderId,
        customerId: customerId,
        name: orderNumber,
        shippingLine: undefined,
      }

    } catch (e) {
      let errorMessage: string = `Error retrieving order with order number ${orderNumber}`;

      if (e instanceof GraphqlQueryError) {
        if (Array.isArray(e.response.errors)) {
          errorMessage += `: ${e.response.errors[0].message}`;
        }
        throw new ShopifyOrderNotFound(errorMessage);
      } else {
        throw new ShopifyOrderNotFound(`${errorMessage}: ${e}`);
      }
    }
  }

  async fetchDeliveryProfiles(): Promise<DeliveryProfileObject[]> {
    interface ResponseBodyType {
      data: {
        deliveryProfiles: {
          edges: any[],
        },
      }
    }

    try {
      const response = await this.client.query<ResponseBodyType>({
        data: `{
          deliveryProfiles (first: 50) {
            edges {
              node {
                id
                name
                profileLocationGroups {
                  locationGroupZones(first: 100) {
                    edges {
                      node {
                        methodDefinitions(first: 100) {
                          edges {
                            node {
                              active
                              name
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }`,
      });

      const deliveryProfileObjects: DeliveryProfileObject[] = [];

      const deliveryProfiles = response.body.data.deliveryProfiles.edges;

      for (const deliveryProfile of deliveryProfiles) {
        const profile: any = {};
        profile['id'] = deliveryProfile.node.id;
        profile['name'] = deliveryProfile.node.name;
        profile['profileLocationGroups'] = [];

        for (const group of deliveryProfile.node.profileLocationGroups) {
          const locationGroup: any = [];
          locationGroup['locationGroupZones'] = [];
          for (const zone of group.locationGroupZones.edges) {
            const locationGroupZone: any = [];
            const methodDefinitions = [];
            for (const definition of zone.node.methodDefinitions.edges) {
              methodDefinitions.push({
                'name': definition.node.name,
                'active': definition.node.active,
              });
            }
            locationGroupZone['methodDefinitions'] = methodDefinitions;
            locationGroup['locationGroupZones'].push(locationGroupZone);
          }
          profile['profileLocationGroups'].push(locationGroup);
        }
        deliveryProfileObjects.push(profile);
      }

      return deliveryProfileObjects;
    } catch (e) {
      let errorMessage: string = `Error retrieving delivery profiles.`;

      if (e instanceof GraphqlQueryError) {
        if (Array.isArray(e.response.errors)) {
          errorMessage += `: ${e.response.errors[0].message}`;
        }
        throw new DeliveryProfilesFetchError(errorMessage);
      } else {
        throw new DeliveryProfilesFetchError(`${errorMessage}: ${e}`);
      }
    }
  }

  async triggerWorkflow({
    triggerId,
    fields,
    values,
  }: {
    triggerId: string,
    fields: string[],
    values: any[],
  }): Promise<void> {
    interface ResponseBodyType {
      data: {
        flowTriggerReceive: {
          userErrors: any[],
        },
      }
    }

    try {
      let properties: string = '{';

      for (let i = 0; i < fields.length; i++) {
        if (typeof values[i] === 'string') {
          properties += `\\"${fields[i]}\\":\\"${values[i]}\\"`;
        } else {
          properties += `\\"${fields[i]}\\":${values[i]}`;
        }
        if (i < (fields.length - 1)) {
          properties += ',';
        }
      }

      properties += '}';

      const data: string = `
        mutation {
          flowTriggerReceive(body: "{\\"trigger_id\\":\\"${triggerId}\\",\\"properties\\":${properties}}") {
            userErrors {
              field,
              message
            }
          }
        }
        `;

      await this.client.query<ResponseBodyType>({
        data: data,
      });

    } catch (e) {
      let errorMessage: string = `Error triggering workflow ${triggerId}`;

      if (e instanceof GraphqlQueryError) {
        if (Array.isArray(e.response.errors)) {
          errorMessage += `: ${e.response.errors[0].message}`;
        }
        throw new WorkflowTriggerError(errorMessage);
      } else {
        throw new WorkflowTriggerError(`${errorMessage}: ${e}`);
      }
    }
  }

  private getIdNumberFromFullIdString(fullId: string): string {
    const idParts: string[] = fullId.split('/');
    return idParts[idParts.length - 1];
  }

}