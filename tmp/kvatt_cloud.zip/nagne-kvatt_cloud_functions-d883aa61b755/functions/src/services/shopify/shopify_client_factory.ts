import { ShopifyStore } from "../../domain/shopify/shopify_store";
import { getConfigs } from "../../environments";
import { ShopifyGraphQLClient } from "./shopify_graphql_client";

export class ShopifyClientFactory {

  static buildShopifyGraphQLClient({
    shopifyStore,
    hostName,
  }: {
    shopifyStore: ShopifyStore,
    hostName: string,
  }): ShopifyGraphQLClient {
    const shopifyClient = new ShopifyGraphQLClient({
      clientId: getConfigs().SHOPIFY_CLIENT_ID,
      clientSecret: getConfigs().SHOPIFY_CLIENT_SECRET,
      scopes: getConfigs().SHOPIFY_SCOPES,
      hostName: hostName,
      shop: shopifyStore.shopId,
      accessToken: shopifyStore.accessToken!,
    });

    return shopifyClient;
  }

  static buildShopifyGraphQLClientLegacy({
    shopifyStore,
    hostName,
  }: {
    shopifyStore: ShopifyStore,
    hostName: string,
  }): ShopifyGraphQLClient {
    const shopifyClient = new ShopifyGraphQLClient({
      clientId: shopifyStore.clientId,
      clientSecret: shopifyStore.clientSecret,
      scopes: shopifyStore.scopes,
      hostName: hostName,
      shop: shopifyStore.shopId,
      accessToken: shopifyStore.accessToken!,
    });

    return shopifyClient;
  }
}