import { DeliveryMethodDefinitionObject, DeliveryProfileObject } from "./models";

export class ShopifyUtils {
  static getDeliveryMethodDefinitionsFromDeliveryProfiles({
    deliveryProfiles,
  }: {
    deliveryProfiles: DeliveryProfileObject[],
  }): DeliveryMethodDefinitionObject[] {
    const methodDefinitions: DeliveryMethodDefinitionObject[] = [];
    for (const profile of deliveryProfiles) {
      if (profile.profileLocationGroups !== undefined) {
        for (const group of profile.profileLocationGroups) {
          if (group.locationGroupZones !== undefined) {
            for (const zone of group.locationGroupZones) {
              if (zone.methodDefinitions !== undefined) {
                for (const method of zone.methodDefinitions) {
                  methodDefinitions.push({
                    'name': method.name,
                    'active': method.active,
                  });

                }
              }
            }
          }
        }
      }
    }
    return methodDefinitions;
  }
}