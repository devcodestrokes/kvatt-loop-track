export interface OrderObject {
  id: string | undefined;
  shippingLine: ShippingLineObject | undefined;
  name: string | undefined;
  customerId: string | undefined;
}

export interface ShippingLineObject {
  id: string | undefined;
  code: string | undefined;
}

export interface DeliveryMethodDefinitionObject {
  name: string | undefined;
  active: boolean | undefined;
}

export interface DeliveryLocationGroupZoneObject {
  methodDefinitions: DeliveryMethodDefinitionObject[] | undefined;
}

export interface DeliveryProfileLocationGroupObject {
  locationGroupZones: DeliveryLocationGroupZoneObject[] | undefined;
}

export interface DeliveryProfileObject {
  id: string | undefined;
  name: string | undefined;
  profileLocationGroups: DeliveryProfileLocationGroupObject[] | undefined;
}

