export class ShopifyOrderNotFound extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class WorkflowTriggerError extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class DeliveryProfilesFetchError extends Error {
  message: string;
  constructor(message: string) {
    super();
    this.message = message;
  }
}

export class ShopifyWebhookUnknownError extends Error {
  shopId: string;
  orderId: string;
  message: string;
  constructor(
    shopId: string,
    orderId: string,
    message: string,
  ) {
    super();
    this.shopId = shopId;
    this.orderId = orderId;
    this.message = message;
  }

  toString() {
    return `ShopifyWebhookUnknownError - ShopID: ${this.shopId} - OrderId: ${this.orderId} - ${this.message} `;
  }
}