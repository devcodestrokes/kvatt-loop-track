import '@shopify/shopify-api/adapters/node';
import { shopifyApi, DeliveryMethod, ApiVersion } from '@shopify/shopify-api';
import { getConfigs } from '../../environments';

export class ShopifyAuthClient {

  shopify: any;

  constructor({
    clientId,
    clientSecret,
    scopes,
    hostName,
  }: {
    clientId: string,
    clientSecret: string,
    scopes: string[],
    hostName: string,
  }) {
    this.shopify = shopifyApi({
      apiKey: clientId,
      apiSecretKey: clientSecret,
      scopes: scopes,
      hostName: hostName,
      apiVersion: ApiVersion.January24,
      isEmbeddedApp: false,
    });
  }

  async redirectToShopifyAuthScreen({
    request,
    response,
  }: {
    request: any,
    response: any,
  }): Promise<void> {
    await this.shopify.auth.begin({
      shop: this.shopify.utils.sanitizeShop(request.query.shop, true) ?? '',
      callbackPath: '/shopifyAuthCallback',
      isOnline: false,
      rawRequest: request,
      rawResponse: response,
    });
  }

  async getSession({
    request,
    response,
  }: {
    request: any,
    response: any,
  }) {
    const callback = await this.shopify.auth.callback({
      rawRequest: request,
      rawResponse: response,
    });
    return callback;
  }

  async setUpWebhooks({
    callbackSession,
  }: {
    callbackSession: any,
  }): Promise<void> {
    this.shopify.webhooks.addHandlers({
      FULFILLMENTS_CREATE: [
        {
          deliveryMethod: DeliveryMethod.PubSub,
          pubSubProject: getConfigs().PROJECT_ID,
          pubSubTopic: getConfigs().SHOPIFY_WEBHOOK_PUBSUB_TOPIC,
        }
      ],
      ORDERS_CREATE: [
        {
          deliveryMethod: DeliveryMethod.PubSub,
          pubSubProject: getConfigs().PROJECT_ID,
          pubSubTopic: getConfigs().SHOPIFY_WEBHOOK_PUBSUB_TOPIC,
        }
      ],
    });

    await this.shopify.webhooks.register({
      session: callbackSession,
    });
  }

  async verifyWebhook({
    request,
    response,
  }: {
    request: any,
    response: any,
  }): Promise<boolean> {
    const { valid } = await this.shopify.webhooks.validate({
      rawBody: request.rawBody,
      rawRequest: request,
      rawResponse: response,
    });
    return valid;
  }
}