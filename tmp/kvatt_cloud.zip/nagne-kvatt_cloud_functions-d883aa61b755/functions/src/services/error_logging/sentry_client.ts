import * as Sentry from '@sentry/node';
import { getConfigs } from '../../environments';

export class SentryClient {
    private static instance: SentryClient;

    private constructor() { }

    static getInstance({
        environment,
    }: {
        environment: string,
    }): SentryClient {
        if (!SentryClient.instance) {
            Sentry.init({
                dsn: getConfigs().SENTRY_DSN,
                environment: environment,
            });
            SentryClient.instance = new SentryClient();
        }

        return SentryClient.instance;
    }

    capture(e: Error, userId?: string, data?: object) {
        if (userId !== undefined) {
            Sentry.setUser({ id: userId });
        }
        if (data !== undefined) {
            Sentry.setContext("Additional Context", data);
        }
        Sentry.captureException(e);
    }

    captureWarning(message: string) {
        Sentry.captureMessage(message, "warning");
    }
}