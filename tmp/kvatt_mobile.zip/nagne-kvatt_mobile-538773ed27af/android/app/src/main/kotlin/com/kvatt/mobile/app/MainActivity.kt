package com.kvatt.mobile.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
