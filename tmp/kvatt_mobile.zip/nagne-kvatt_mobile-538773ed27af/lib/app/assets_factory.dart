class AssetsFactory {
  static const String _iconsFolder = 'assets/icons';
  static const String _logosFolder = 'assets/logos';

  //Logos
  static const String kvattLogoWhite = '$_logosFolder/kvatt_logo_white.png';
  static const String kvattLogoBlack = '$_logosFolder/kvatt_logo_black.png';

  //Icons
  static const String eyeIcon = '$_iconsFolder/eye_icon.png';
}
