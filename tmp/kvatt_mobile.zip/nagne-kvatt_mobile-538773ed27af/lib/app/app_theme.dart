import 'package:flutter/material.dart';

final appTheme = ThemeData(
  scaffoldBackgroundColor: const Color(0xFFFFFFFF),
  primaryColor: const Color(0xFF000F34),
  textTheme: const TextTheme(
    headlineMedium: TextStyle(
      fontFamily: 'OpenSans',
      fontWeight: FontWeight.w700,
      fontSize: 34.0,
      height: 1.1,
    ),
    headlineSmall: TextStyle(
      fontFamily: 'OpenSans',
      fontWeight: FontWeight.w700,
      fontSize: 24.0,
      height: 1.7,
      letterSpacing: 1.0,
    ),
    titleSmall: TextStyle(
      fontFamily: 'OpenSans',
      fontWeight: FontWeight.w600,
      fontSize: 14.0,
      height: 1.1,
      letterSpacing: 1.0,
    ),
    bodyMedium: TextStyle(
      fontFamily: 'OpenSans',
      fontWeight: FontWeight.w400,
      fontSize: 14.0,
      height: 1.4,
      letterSpacing: 1.0,
    ),
    bodySmall: TextStyle(
      fontFamily: 'Lato',
      fontWeight: FontWeight.w400,
      fontSize: 12.0,
      height: 1.3,
      letterSpacing: 0.4,
    ),
    labelLarge: TextStyle(
      fontFamily: 'Avenir',
      fontWeight: FontWeight.w800,
      fontSize: 14.0,
      height: 1.1,
      letterSpacing: 1.0,
    ),
  ),
);
