import 'package:flutter/material.dart';
import 'package:kvatt_mobile/domain/users/user.dart';

class AuthState extends ChangeNotifier {
  User? activeUser;

  AuthState();

  void loginUser({
    required User user,
  }) {
    activeUser = user;
  }

  void logoutUser() {
    activeUser = null;
  }
}
