import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/pages/home/home_factory.dart';
import 'package:kvatt_mobile/app/pages/sign_in/sign_in_factory.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_scan/tracking_scan_factory.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_mode.dart';
import 'package:kvatt_mobile/app/routing/routes.dart';

class Routing {
  static Route<dynamic> generateRoute(RouteSettings settings) {
    switch (settings.name) {
      case Routes.signIn:
        return _buildSignInRoute(settings);
      case Routes.home:
        return _buildHomeRoute(settings);
      case Routes.trackingScan:
        return _buildTrackingScanRoute(settings);
      default:
        return MaterialPageRoute(
          builder: (_) => const Scaffold(
            body: Center(
              child: Text('Oops! Something went wrong!'),
            ),
          ),
        );
    }
  }

  static MaterialPageRoute _buildSignInRoute(RouteSettings settings) {
    return MaterialPageRoute(
      builder: (_) {
        return SignInFactory.build();
      },
      settings: settings,
    );
  }

  static MaterialPageRoute _buildHomeRoute(RouteSettings settings) {
    return MaterialPageRoute(
      builder: (_) {
        return HomeFactory.build();
      },
      settings: settings,
    );
  }

  static MaterialPageRoute _buildTrackingScanRoute(RouteSettings settings) {
    TrackingMode? args = settings.arguments as TrackingMode;
    return MaterialPageRoute(
      builder: (_) {
        return TrackingScanFactory.build(
          trackingMode: args,
        );
      },
      settings: settings,
    );
  }
}
