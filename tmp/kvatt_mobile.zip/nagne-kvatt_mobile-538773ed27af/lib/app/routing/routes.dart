class Routes {
  static const String signIn = 'sign-in';
  static const String home = 'home';
  static const String trackingScan = 'tracking-scan';
}
