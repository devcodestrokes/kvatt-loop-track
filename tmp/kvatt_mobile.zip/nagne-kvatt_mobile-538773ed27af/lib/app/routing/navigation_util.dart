import 'package:flutter/material.dart';

class NavigationUtil {
  final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static final NavigationUtil _instance = NavigationUtil._internal();

  NavigationUtil._internal();

  factory NavigationUtil() {
    return _instance;
  }

  Future<dynamic> navigateTo<T extends Object?>(
      String routeName, bool? allowBackNavigation,
      {dynamic data}) {
    if (allowBackNavigation == false) {
      return navigatorKey.currentState!
          .pushReplacementNamed(routeName, arguments: data);
    }
    return navigatorKey.currentState!.pushNamed(routeName, arguments: data);
  }

  void goBack({data}) {
    navigatorKey.currentState!.pop(data);
  }
}
