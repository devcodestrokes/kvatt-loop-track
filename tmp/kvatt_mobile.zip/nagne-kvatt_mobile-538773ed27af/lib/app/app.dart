import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/app_theme.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/routing/routes.dart';
import 'package:kvatt_mobile/app/routing/routing.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:provider/provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

class App extends StatefulWidget {
  final AuthState authState;
  const App({
    Key? key,
    required this.authState,
  }) : super(key: key);

  @override
  AppState createState() => AppState();
}

class AppState extends State<App> {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Kvatt',
      onGenerateRoute: Routing.generateRoute,
      navigatorKey: Provider.of<NavigationUtil>(context).navigatorKey,
      navigatorObservers: [SentryNavigatorObserver()],
      theme: appTheme,
      initialRoute:
          widget.authState.activeUser == null ? Routes.signIn : Routes.home,
    );
  }
}
