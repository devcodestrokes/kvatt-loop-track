abstract class Config {
  String? environmentName;
  String? kvattLabelPath;
}
