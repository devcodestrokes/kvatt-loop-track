import 'config.dart';

class DevelopmentConfig implements Config {
  @override
  String? environmentName = 'development';

  @override
  String? kvattLabelPath = '/packaging-info';
}
