import 'config.dart';

class StagingConfig implements Config {
  @override
  String? environmentName = 'staging';

  @override
  String? kvattLabelPath = '/packaging-info';
}
