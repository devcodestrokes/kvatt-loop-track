import 'config.dart';

class ProductionConfig implements Config {
  @override
  String? environmentName = 'production';

  @override
  String? kvattLabelPath = '/packaging-info';
}
