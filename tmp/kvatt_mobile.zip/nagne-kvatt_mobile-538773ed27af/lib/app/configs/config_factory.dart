import 'package:kvatt_mobile/app/configs/development_config.dart';
import 'package:kvatt_mobile/app/configs/production_config.dart';
import 'package:kvatt_mobile/app/configs/staging_config.dart';

import 'config.dart';

class ConfigFactory {
  static Config getConfig(String environment) {
    switch (environment) {
      case 'development':
        return DevelopmentConfig();
      case 'staging':
        return StagingConfig();
      case 'production':
        return ProductionConfig();
      default:
        return DevelopmentConfig();
    }
  }
}
