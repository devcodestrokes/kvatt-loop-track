import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_core/domain/tracking/tracking_manager.dart';
import 'package:kvatt_mobile/app/pages/home/home.dart';
import 'package:kvatt_mobile/app/pages/home/home_view_model.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:kvatt_mobile/domain/app/app_manager.dart';
import 'package:kvatt_mobile/domain/auth/auth_manager.dart';

import 'package:provider/provider.dart';

class HomeFactory {
  static Widget build() {
    return ChangeNotifierProvider<HomeViewModel>(
      create: (context) {
        return HomeViewModel(
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
          authManager: Provider.of<AuthManager>(
            context,
            listen: false,
          ),
          navUtil: Provider.of<NavigationUtil>(
            context,
            listen: false,
          ),
          appManager: Provider.of<AppManager>(
            context,
            listen: false,
          ),
          trackingManager: Provider.of<TrackingManager>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<HomeViewModel>(
        builder: (context, model, child) => Home(
          viewModel: model,
        ),
      ),
    );
  }
}
