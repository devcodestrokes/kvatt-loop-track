import 'dart:async';

import 'package:flutter/material.dart';
import 'package:kvatt_core/domain/tracking/tracking_manager.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_mode.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/routing/routes.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:kvatt_mobile/domain/app/app_manager.dart';
import 'package:kvatt_mobile/domain/auth/auth_manager.dart';
import 'package:kvatt_mobile/domain/users/admin.dart';
import 'package:kvatt_mobile/domain/users/merchant.dart';

class HomeViewModel extends ChangeNotifier {
  AuthState authState;
  AuthManager authManager;
  NavigationUtil navUtil;
  AppManager appManager;
  TrackingManager trackingManager;

  HomeViewModel({
    required this.authState,
    required this.authManager,
    required this.navUtil,
    required this.appManager,
    required this.trackingManager,
  }) {
    trackCountSubscription = trackingManager
        .returnedToKvattCount(userId: authState.activeUser!.uid!)
        .listen((int? count) {
      trackCount = count;
      notifyListeners();
    });
  }

  late StreamSubscription trackCountSubscription;

  int? trackCount;

  bool get isAdmin => authState.activeUser is Admin;
  bool get isMerchant => authState.activeUser is Merchant;
  bool get showShipOptionButton =>
      isAdmin && (authState.activeUser as Admin).showShipOptionInApp != false;

  String get displayedVersionNumber =>
      "version: ${appManager.appVersion}b${appManager.appBuildNumber}";

  String get firstNameGuess {
    String name = '';
    if (isAdmin) {
      name = (authState.activeUser as Admin).name;
    }
    if (isMerchant) {
      name = (authState.activeUser as Merchant).name;
    }
    try {
      return name.split(' ')[0];
    } catch (e) {
      return name;
    }
  }

  String get welcomeMessage {
    DateTime now = DateTime.now();
    int hours = now.hour;
    if (hours >= 1 && hours <= 12) {
      return "Good morning";
    } else if (hours >= 12 && hours <= 16) {
      return "Good afternoon";
    } else {
      return "Good evening";
    }
  }

  onTrackReturnToKvattTapped() async {
    String? res = await navUtil.navigateTo(
      Routes.trackingScan,
      true,
      data: TrackingMode.returnToKvatt,
    );
    if (res != null) {
      _showResultPopUp(res);
    }
    notifyListeners();
  }

  onTrackSendToMaintenanceTapped() async {
    String? res = await navUtil.navigateTo(
      Routes.trackingScan,
      true,
      data: TrackingMode.sendToMaintenance,
    );
    if (res != null) {
      _showResultPopUp(res);
    }
    notifyListeners();
  }

  onTrackOutOfMaintenanceTapped() async {
    String? res = await navUtil.navigateTo(
      Routes.trackingScan,
      true,
      data: TrackingMode.outOfMaintenance,
    );
    if (res != null) {
      _showResultPopUp(res);
    }

    notifyListeners();
  }

  onTrackShipToMerchantTapped() async {
    String? res = await navUtil.navigateTo(
      Routes.trackingScan,
      true,
      data: TrackingMode.shipToMerchant,
    );
    if (res != null) {
      _showResultPopUp(res);
    }

    notifyListeners();
  }

  onTrackShipToCustomersTapped() async {
    String? res = await navUtil.navigateTo(
      Routes.trackingScan,
      true,
      data: TrackingMode.shipToCustomer,
    );
    if (res != null) {
      _showResultPopUp(res);
    }

    notifyListeners();
  }

  onTrackReturnToMerchantTapped() async {
    String? res = await navUtil.navigateTo(
      Routes.trackingScan,
      true,
      data: TrackingMode.returnToMerchant,
    );
    if (res != null) {
      _showResultPopUp(res);
    }

    notifyListeners();
  }

  @override
  void dispose() {
    trackCountSubscription.cancel();
    super.dispose();
  }

  _showResultPopUp(String message) {
    showDialog(
      context: navUtil.navigatorKey.currentContext!,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          backgroundColor: Theme.of(context).colorScheme.tertiaryColor,
          title: Text(
            'Well done!',
            style: Theme.of(context).textTheme.headlineSmall,
          ),
          content: Text(
            message,
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          actions: [
            TextButton(
              onPressed: () {
                navUtil.goBack();
              },
              child: Text(
                'OK',
                style: Theme.of(context).textTheme.labelLarge?.copyWith(
                      color: Theme.of(context).colorScheme.secondaryColor,
                    ),
              ),
            ),
          ],
        );
      },
    );
  }

  Future<void> onLogoutTapped() async {
    await authManager.signOut();
    authState.logoutUser();
    navUtil.navigateTo(Routes.signIn, false);
  }
}
