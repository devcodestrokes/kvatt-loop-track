import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/common/widgets/buttons/large_button.dart';
import 'package:kvatt_mobile/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_mobile/app/common/widgets/nav_bars/top_nav_bar.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';
import 'package:kvatt_mobile/app/pages/home/home_view_model.dart';

class Home extends StatefulWidget {
  final HomeViewModel viewModel;

  const Home({
    super.key,
    required this.viewModel,
  });

  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  bool _showAdminMaintenanceOptions = false;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surfaceColor,
      bottomSheet: Container(
        color: Theme.of(context).colorScheme.surfaceColor,
        padding: const EdgeInsets.fromLTRB(0.0, 0.0, 24.0, 8.0),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.end,
          children: [
            Text(
              widget.viewModel.displayedVersionNumber,
              style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceDisabled),
              textAlign: TextAlign.right,
            ),
          ],
        ),
      ),
      appBar: PreferredSize(
        preferredSize: const Size.fromHeight(kToolbarHeight),
        child: TopNavBar(
          actions: [
            IconButton(
              onPressed: () => widget.viewModel.onLogoutTapped(),
              icon: Icon(
                Icons.logout,
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
            ),
          ],
        ),
      ),
      body: SizedBox(
        height: MediaQuery.of(context).size.height,
        child: _buildOptions(context),
      ),
    );
  }

  Widget _buildOptions(BuildContext context) {
    if (widget.viewModel.isAdmin) {
      if (_showAdminMaintenanceOptions == true) {
        return _buildAdminMaintenanceOptions(context);
      } else {
        return _buildAdminAllOptions(context);
      }
    }
    if (widget.viewModel.isMerchant) {
      return _buildMerchantOptions(context);
    }
    return const SizedBox();
  }

  Widget _buildAdminAllOptions(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 48.0),
      child: SingleChildScrollView(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const SizedBox(height: 24.0),
            Container(
              width: MediaQuery.of(context).size.width,
              padding: const EdgeInsets.symmetric(vertical: 6.0),
              decoration: BoxDecoration(
                color: Theme.of(context).colorScheme.tertiaryColor,
                borderRadius: const BorderRadius.all(Radius.circular(4.0)),
              ),
              child: Text(
                widget.viewModel.trackCount == null
                    ? 'Total returns tracked: 0'
                    : 'Total returns tracked: ${widget.viewModel.trackCount.toString()}',
                style: Theme.of(context).textTheme.bodyMedium,
                textAlign: TextAlign.center,
              ),
            ),
            const SizedBox(height: 24.0),
            widget.viewModel.showShipOptionButton
                ? Column(
                    children: [
                      LargeButton(
                        label: 'Ship',
                        height: 168.0,
                        fontColor:
                            Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                        backgroundColor:
                            Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                        borderColor:
                            Theme.of(context).colorScheme.tertiaryColor,
                        onTapped: () =>
                            widget.viewModel.onTrackShipToMerchantTapped(),
                      ),
                      const SizedBox(height: 16.0),
                    ],
                  )
                : const SizedBox(),
            LargeButton(
              label: 'Scan Returns',
              height: 168.0,
              fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
              backgroundColor: Theme.of(context).colorScheme.secondaryColor,
              onTapped: () => widget.viewModel.onTrackReturnToKvattTapped(),
            ),
            const SizedBox(height: 16.0),
            LargeButton(
              label: 'Start Maintenance',
              height: 168.0,
              fontColor: Theme.of(context).colorScheme.onPrimaryHighEmphasis,
              backgroundColor: Theme.of(context).primaryColor,
              onTapped: () {
                setState(() {
                  _showAdminMaintenanceOptions = true;
                });
              },
            ),
            const SizedBox(height: 48.0),
          ],
        ),
      ),
    );
  }

  Widget _buildAdminMaintenanceOptions(BuildContext context) {
    return Stack(
      children: [
        Positioned(
          top: 16.0,
          left: 16.0,
          child: IconButton(
            onPressed: () {
              setState(() {
                _showAdminMaintenanceOptions = false;
              });
            },
            icon: const Icon(
              Icons.arrow_back,
              size: 36.0,
            ),
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 48.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              LargeButton(
                label: 'Track beginning of maintenance',
                height: 168.0,
                fontColor: Theme.of(context).colorScheme.customGreen,
                backgroundColor:
                    Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                borderColor: Theme.of(context).colorScheme.tertiaryColor,
                onTapped: () =>
                    widget.viewModel.onTrackSendToMaintenanceTapped(),
              ),
              const SizedBox(height: 48.0),
              LargeButton(
                label: 'Track end of maintenance',
                height: 168.0,
                fontColor: Theme.of(context).colorScheme.customRed,
                backgroundColor:
                    Theme.of(context).colorScheme.onPrimaryHighEmphasis,
                borderColor: Theme.of(context).colorScheme.tertiaryColor,
                onTapped: () =>
                    widget.viewModel.onTrackOutOfMaintenanceTapped(),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildMerchantOptions(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 48.0),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Column(
            children: [
              const SizedBox(height: 48.0),
              Align(
                alignment: Alignment.topLeft,
                child: Text(
                  '${widget.viewModel.welcomeMessage},',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontSize: 36.0,
                      ),
                ),
              ),
              Align(
                alignment: Alignment.topLeft,
                child: Text(
                  widget.viewModel.firstNameGuess,
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(
                        fontSize: 44.0,
                        color: Theme.of(context).primaryColor,
                      ),
                ),
              ),
            ],
          ),
          Column(
            children: [
              PrimaryButton(
                label: 'Track shipping to customers',
                onPressed: () =>
                    widget.viewModel.onTrackShipToCustomersTapped(),
              ),
              const SizedBox(height: 12.0),
              PrimaryButton(
                label: 'Track returns from customers',
                onPressed: () =>
                    widget.viewModel.onTrackReturnToMerchantTapped(),
                backgroundColor: Theme.of(context).primaryColor,
              ),
              const SizedBox(height: 48.0)
            ],
          ),
        ],
      ),
    );
  }
}
