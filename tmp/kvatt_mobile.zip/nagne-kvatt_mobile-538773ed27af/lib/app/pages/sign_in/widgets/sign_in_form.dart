import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_mobile/app/common/widgets/form_fields/text_field_white.dart';

class SignInForm extends StatefulWidget {
  final Function(String?) emailValidator;
  final Function(String?) passwordValidator;
  final Function(String email, String password) onSignInPressed;

  const SignInForm({
    super.key,
    required this.emailValidator,
    required this.passwordValidator,
    required this.onSignInPressed,
  });

  @override
  State<SignInForm> createState() => SignInFormState();
}

class SignInFormState extends State<SignInForm> {
  TextEditingController emailTextController = TextEditingController();
  TextEditingController passwordTextController = TextEditingController();

  final _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _formKey,
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          TextFieldWhite(
            validator: (String? email) => widget.emailValidator(email),
            label: 'Email Address',
            keyboardType: TextInputType.emailAddress,
            controller: emailTextController,
          ),
          const SizedBox(height: 28.0),
          TextFieldWhite(
            validator: (String? password) => widget.passwordValidator(password),
            label: 'Password',
            keyboardType: TextInputType.text,
            controller: passwordTextController,
            obscureText: true,
          ),
          const SizedBox(height: 36.0),
          PrimaryButton(
            label: 'Sign In',
            onPressed: () async {
              if (_formKey.currentState!.validate()) {
                widget.onSignInPressed(
                  emailTextController.text.trim(),
                  passwordTextController.text.trim(),
                );
              }
            },
          ),
        ],
      ),
    );
  }

  @override
  void dispose() {
    emailTextController.dispose();
    passwordTextController.dispose();
    super.dispose();
  }
}
