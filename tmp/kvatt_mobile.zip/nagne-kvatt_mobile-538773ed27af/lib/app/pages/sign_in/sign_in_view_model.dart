import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/routing/routes.dart';
import 'package:kvatt_mobile/app/services/auth/auth_service.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:kvatt_mobile/domain/auth/auth_manager.dart';
import 'package:kvatt_mobile/domain/users/user.dart';

class SignInViewModel extends ChangeNotifier {
  AuthManager authManager;
  NavigationUtil navUtil;
  AuthState authState;

  String? errorMessage;

  SignInViewModel({
    required this.authManager,
    required this.navUtil,
    required this.authState,
  });

  Future<void> onSignInPressed({
    required String email,
    required String password,
  }) async {
    try {
      User? user = await authManager.signIn(
        email: email,
        password: password,
      );

      if (user == null) throw Exception();
      authState.loginUser(user: user);
      navUtil.goBack(); //Dismisses loading dialog
      navUtil.navigateTo(Routes.home, false);
    } catch (e) {
      navUtil.goBack(); //Dismisses loading dialog
      if (e is AuthInvalidCredentialsException) {
        errorMessage = 'The email/password you\'ve entered are incorrect.';
      } else {
        errorMessage =
            'There was an issue signing you in. Please try again later.';
      }
      notifyListeners();
    }
  }
}
