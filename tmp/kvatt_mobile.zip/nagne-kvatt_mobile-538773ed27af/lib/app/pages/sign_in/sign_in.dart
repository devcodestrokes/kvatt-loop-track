import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/assets_factory.dart';
import 'package:kvatt_mobile/app/common/utils/validators.dart';
import 'package:kvatt_mobile/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';
import 'package:kvatt_mobile/app/pages/sign_in/sign_in_view_model.dart';
import 'package:kvatt_mobile/app/pages/sign_in/widgets/sign_in_form.dart';

class SignIn extends StatelessWidget {
  final SignInViewModel viewModel;

  const SignIn({
    super.key,
    required this.viewModel,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).primaryColor,
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Image.asset(
              AssetsFactory.kvattLogoWhite,
              width: 110.0,
              height: 50.0,
            ),
            const SizedBox(height: 60.0),
            viewModel.errorMessage != null
                ? Column(
                    children: [
                      Container(
                        color: Theme.of(context).colorScheme.trafficLightAmber,
                        padding:
                            const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
                        child: Text(
                          viewModel.errorMessage!,
                          style:
                              Theme.of(context).textTheme.bodySmall?.copyWith(
                                    color: Theme.of(context)
                                        .colorScheme
                                        .onTrafficLightAmber,
                                  ),
                          textAlign: TextAlign.center,
                        ),
                      ),
                      const SizedBox(height: 24.0),
                    ],
                  )
                : const SizedBox(),
            SignInForm(
              emailValidator: (String? email) =>
                  Validators.validateEmail(email),
              passwordValidator: (String? password) =>
                  Validators.validatePassword(password),
              onSignInPressed: (String email, String password) {
                LoadingDialog.show(
                  context,
                  'signing in...',
                  loadingDialogMode: LoadingDialogMode.onPrimary,
                );
                viewModel.onSignInPressed(
                  email: email,
                  password: password,
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
