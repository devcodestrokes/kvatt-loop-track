import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_mobile/app/pages/sign_in/sign_in.dart';
import 'package:kvatt_mobile/app/pages/sign_in/sign_in_view_model.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:kvatt_mobile/domain/auth/auth_manager.dart';

import 'package:provider/provider.dart';

class SignInFactory {
  static Widget build() {
    return ChangeNotifierProvider<SignInViewModel>(
      create: (context) {
        return SignInViewModel(
          authManager: Provider.of<AuthManager>(context, listen: false),
          navUtil: Provider.of<NavigationUtil>(
            context,
            listen: false,
          ),
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<SignInViewModel>(
        builder: (context, model, child) => SignIn(
          viewModel: model,
        ),
      ),
    );
  }
}
