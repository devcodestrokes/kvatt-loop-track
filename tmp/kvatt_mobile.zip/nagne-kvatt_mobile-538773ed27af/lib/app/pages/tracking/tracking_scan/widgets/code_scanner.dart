import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';
import 'package:kvatt_mobile/app/services/feedback/haptic_feedback_service.dart';
import 'package:kvatt_mobile/app/services/feedback/sound_feedback_service.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

enum ScanResult {
  success,
  failure,
  alreadyScanned,
}

class CodeScanner extends StatefulWidget {
  final Future<ScanResult> Function(String?) onDetected;
  final double height;

  const CodeScanner({
    super.key,
    required this.onDetected,
    required this.height,
  });

  @override
  State<CodeScanner> createState() => _CodeScannerState();
}

class _CodeScannerState extends State<CodeScanner> {
  bool _isValidating = false;
  ScanResult? _scanResult;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: widget.height,
      child: Stack(
        children: [
          MobileScanner(
            allowDuplicates: false,
            onDetect: (Barcode barcode, MobileScannerArguments? args) async {
              if (_isValidating == true) return;

              if (barcode.rawValue != null) {
                final String code = barcode.rawValue!;
                setState(() {
                  _isValidating = true;
                });
                ScanResult? result = await widget.onDetected(code);
                await _provideHapticSoundFeedback(result);
                setState(() {
                  _isValidating = false;
                });
                setState(() {
                  _scanResult = result;
                });
                await Future.delayed(
                  const Duration(
                    milliseconds: 500,
                  ),
                );
                setState(() {
                  _scanResult = null;
                });
              }
            },
          ),
          _isValidating || _scanResult != null
              ? Container(
                  height: widget.height,
                  color: Colors.black.withOpacity(0.7),
                )
              : const SizedBox(),
          _isValidating
              ? const Center(
                  child: CircularProgressIndicator(
                    color: Colors.white,
                  ),
                )
              : const SizedBox(),
          _scanResult != null
              ? Center(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(
                        _getScanResultIcon(),
                        color: _getScanResultIconColor(),
                        size: widget.height * 0.35,
                      ),
                      const SizedBox(height: 8.0),
                      _scanResult == ScanResult.alreadyScanned
                          ? Text(
                              'Already scanned',
                              style: Theme.of(context)
                                  .textTheme
                                  .bodySmall
                                  ?.copyWith(
                                    color: Colors.white,
                                  ),
                            )
                          : const SizedBox(),
                    ],
                  ),
                )
              : const SizedBox(),
        ],
      ),
    );
  }

  IconData _getScanResultIcon() {
    switch (_scanResult) {
      case ScanResult.success:
        return Icons.check_circle_outline_rounded;
      case ScanResult.failure:
        return Icons.close;
      default:
        return Icons.donut_large;
    }
  }

  Color _getScanResultIconColor() {
    switch (_scanResult) {
      case ScanResult.success:
        return Theme.of(context).colorScheme.trafficLightGreen;
      case ScanResult.failure:
        return Theme.of(context).colorScheme.trafficLightRed;
      default:
        return Colors.white;
    }
  }

  Future<void> _provideHapticSoundFeedback(ScanResult? result) async {
    switch (result) {
      case ScanResult.success:
        return await SoundFeedbackService.beep(isSuccess: true);
      case ScanResult.failure:
        await HapticFeedbackService.vibrate(duration: 200);
        return await SoundFeedbackService.beep(isSuccess: false);
      case ScanResult.alreadyScanned:
        return await HapticFeedbackService.vibrate(duration: 500);
      default:
        return;
    }
  }
}
