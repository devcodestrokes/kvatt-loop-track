import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:kvatt_mobile/app/configs/config.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_scan/tracking_scan.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_mode.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_scan/tracking_scan_view_model.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:kvatt_mobile/domain/users/user_manager.dart';

import 'package:provider/provider.dart';

class TrackingScanFactory {
  static Widget build({
    required TrackingMode trackingMode,
  }) {
    return ChangeNotifierProvider<TrackingScanViewModel>(
      create: (context) {
        return TrackingScanViewModel(
          packagingsManager: Provider.of<PackagingsManager>(
            context,
            listen: false,
          ),
          userManager: Provider.of<UserManager>(
            context,
            listen: false,
          ),
          navigationUtil: Provider.of<NavigationUtil>(
            context,
            listen: false,
          ),
          authState: Provider.of<AuthState>(
            context,
            listen: false,
          ),
          trackingMode: trackingMode,
          config: Provider.of<Config>(
            context,
            listen: false,
          ),
        );
      },
      child: Consumer<TrackingScanViewModel>(
        builder: (context, model, child) => TrackingScan(
          viewModel: model,
        ),
      ),
    );
  }
}
