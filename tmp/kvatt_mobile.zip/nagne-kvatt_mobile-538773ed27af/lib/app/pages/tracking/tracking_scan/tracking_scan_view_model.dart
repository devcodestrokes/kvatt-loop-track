import 'package:flutter/material.dart';
import 'package:kvatt_core/domain/packaging_codes/packaging_code.dart';
import 'package:kvatt_core/domain/packagings/packaging.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:kvatt_mobile/app/configs/config.dart';
import 'package:kvatt_mobile/app/pages/tracking/scanned_packaging.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_mode.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_scan/widgets/code_scanner.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:kvatt_mobile/domain/users/merchant.dart';
import 'package:kvatt_mobile/domain/users/user_manager.dart';

enum MerchantSelectMode {
  selectExisting,
  manual,
}

class TrackingScanViewModel extends ChangeNotifier {
  PackagingsManager packagingsManager;
  UserManager userManager;
  NavigationUtil navigationUtil;
  AuthState authState;
  TrackingMode trackingMode;
  Config config;

  TrackingScanViewModel({
    required this.packagingsManager,
    required this.userManager,
    required this.navigationUtil,
    required this.authState,
    required this.trackingMode,
    required this.config,
  });

  List<Merchant> activeMerchants = [];

  List<ScannedPackaging> scannedPackagings = [];

  bool trackingInProgress = false;

  bool isLoading = true;

  Merchant? selectedMerchant;
  String? enteredMerchantName;
  MerchantSelectMode? merchantSelectMode;

  String? customerName;
  String? orderNumber;

  String? errorMessage;

  DateTime? scanDate;
  TimeOfDay? scanTime;

  final List<String> _scannedPackagingIds = [];

  List<String> get merchantNames {
    return activeMerchants
        .map(
          (Merchant merchant) => merchant.name,
        )
        .toList();
  }

  String? get outboundMerchantName {
    if (merchantSelectMode == MerchantSelectMode.selectExisting) {
      return selectedMerchant?.name;
    }
    if (merchantSelectMode == MerchantSelectMode.manual) {
      return enteredMerchantName;
    }
    return '';
  }

  Future<void> init() async {
    if (trackingMode == TrackingMode.shipToMerchant) {
      activeMerchants = await userManager.retrieveActiveMerchants();
    }
    isLoading = false;
    notifyListeners();
  }

  onMerchantDetailsSubmitted({
    required MerchantSelectMode merchantSelectMode,
    required String? selectedMerchant,
    required String? enteredMerchantName,
    required DateTime? date,
    required TimeOfDay? time,
  }) {
    scanDate = date;
    scanTime = time;
    this.merchantSelectMode = merchantSelectMode;
    if (merchantSelectMode == MerchantSelectMode.selectExisting) {
      this.selectedMerchant = activeMerchants
          .where((Merchant merchant) => merchant.name == selectedMerchant)
          .first;
    }
    if (merchantSelectMode == MerchantSelectMode.manual) {
      this.enteredMerchantName = enteredMerchantName;
    }

    notifyListeners();
  }

  onCustomerDetailsSubmitted({
    required String customerName,
    required String orderNumber,
  }) {
    this.customerName = customerName;
    this.orderNumber = orderNumber;
    notifyListeners();
  }

  onStartStopScanTapped() {
    trackingInProgress = !trackingInProgress;
    notifyListeners();
  }

  Future<ScanResult> onCodeDetected(String? code) async {
    if (code == null) return ScanResult.failure;

    PackagingCode packagingCode = PackagingCode.parse(
      code: code,
      kvattLabelPath: config.kvattLabelPath!,
    );

    String? id = packagingCode.identifier;

    if (id == null) return ScanResult.failure;

    return await _addScannedPackaging(
      id: id,
      isCustom: packagingCode.isCustom,
    );
  }

  Future<bool> onSaveTapped() async {
    try {
      switch (trackingMode) {
        case TrackingMode.shipToMerchant:
          await packagingsManager.recordOutboundToMerchantPackagings(
            userId: authState.activeUser!.uid!,
            merchantId: selectedMerchant?.uid,
            merchantName: enteredMerchantName,
            date: _getScannedDateTime(),
            packagings: scannedPackagings
                .map(
                  (ScannedPackaging p) => p.packaging,
                )
                .toList(),
          );
          break;
        case TrackingMode.shipToCustomer:
          await packagingsManager.recordOutboundToCustomerPackagings(
            merchantId: authState.activeUser!.uid!,
            packagings: scannedPackagings
                .map(
                  (ScannedPackaging p) => p.packaging,
                )
                .toList(),
            customerName: customerName ?? '',
            orderNumber: orderNumber ?? '',
          );
          break;
        case TrackingMode.returnToMerchant:
          await packagingsManager.recordInboundFromCustomerPackagings(
            merchantId: authState.activeUser!.uid!,
            packagings: scannedPackagings
                .map(
                  (ScannedPackaging p) => p.packaging,
                )
                .toList(),
          );
          break;
        case TrackingMode.returnToKvatt:
          await packagingsManager.recordReturnedToKvattPackagings(
            userId: authState.activeUser!.uid!,
            packagings: scannedPackagings
                .map((ScannedPackaging p) => p.packaging)
                .toList(),
          );
          break;
        case TrackingMode.sendToMaintenance:
          await packagingsManager.recordSentToMaintenancePackagings(
            userId: authState.activeUser!.uid!,
            packagings: scannedPackagings
                .map((ScannedPackaging p) => p.packaging)
                .toList(),
          );
          break;
        case TrackingMode.outOfMaintenance:
          await packagingsManager.recordOutOfMaintenancePackagings(
            userId: authState.activeUser!.uid!,
            packagings: scannedPackagings
                .map((ScannedPackaging p) => p.packaging)
                .toList(),
          );
          break;
      }

      navigationUtil.goBack(); //Dismisses loading modal
      navigationUtil.goBack(); //Dismisses review sheet
      navigationUtil.goBack(
        data: _getReturnMessage(),
      );
      return true;
    } catch (e) {
      navigationUtil.goBack(); //Dismisses loading modal
      return false;
    }
  }

  Future<ScanResult> _addScannedPackaging({
    required String id,
    required bool isCustom,
  }) async {
    try {
      Packaging? packaging =
          await packagingsManager.retrievePackagingByIdentifier(
        identifier: id,
        isCustom: isCustom,
      );
      if (packaging == null) return ScanResult.failure;
      ScannedPackaging scannedPackaging = ScannedPackaging(
        packaging: packaging,
      );
      if (_scannedPackagingIds
          .contains(scannedPackaging.packaging.identifier)) {
        return ScanResult.alreadyScanned;
      }
      scannedPackagings.add(scannedPackaging);
      _scannedPackagingIds.add(scannedPackaging.packaging.identifier);

      notifyListeners();
      return ScanResult.success;
    } catch (e) {
      notifyListeners();
      return ScanResult.failure;
    }
  }

  String _getReturnMessage() {
    switch (trackingMode) {
      case TrackingMode.shipToMerchant:
        if (merchantSelectMode == MerchantSelectMode.selectExisting) {
          return 'You have successfully tracked ${scannedPackagings.length} packs as shipped to ${selectedMerchant?.name}';
        } else if (merchantSelectMode == MerchantSelectMode.manual) {
          return 'You have successfully tracked ${scannedPackagings.length} packs as shipped to $enteredMerchantName';
        } else {
          return '';
        }
      case TrackingMode.returnToKvatt:
        return 'You have successfully tracked ${scannedPackagings.length} packs as returned to Kvatt.';
      case TrackingMode.sendToMaintenance:
        return 'You have successfully tracked ${scannedPackagings.length} packs as sent to maintenance.';
      case TrackingMode.outOfMaintenance:
        return 'You have successfully tracked ${scannedPackagings.length} packs as out of maintenance and ready for use.';
      case TrackingMode.shipToCustomer:
        if (customerName != null &&
            customerName != '' &&
            orderNumber != null &&
            orderNumber != '') {
          return 'You have successfully tracked ${scannedPackagings.length} packs which have been sent to $customerName as part of order $orderNumber.';
        }
        if (customerName != null && customerName != '') {
          return 'You have successfully tracked ${scannedPackagings.length} packs which have been sent to $customerName.';
        }
        if (orderNumber != null && orderNumber != '') {
          return 'You have successfully tracked ${scannedPackagings.length} packs which have been sent as part of order $orderNumber.';
        }
        return 'You have successfully tracked ${scannedPackagings.length} packs which have been sent to a customer.';
      case TrackingMode.returnToMerchant:
        return 'You have successfully tracked ${scannedPackagings.length} packs which have been returned from customers.';
    }
  }

  DateTime? _getScannedDateTime() {
    DateTime? scannedDateTime;
    scannedDateTime = scanDate ?? DateTime.now();
    if (scanTime != null) {
      return DateTime(
        scannedDateTime.year,
        scannedDateTime.month,
        scannedDateTime.day,
        scanTime!.hour,
        scanTime!.minute,
      );
    }
    return scannedDateTime;
  }
}
