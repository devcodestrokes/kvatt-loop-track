import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_mobile/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_mobile/app/common/widgets/form_fields/custom_date_picker.dart';
import 'package:kvatt_mobile/app/common/widgets/form_fields/custom_time_picker.dart';
import 'package:kvatt_mobile/app/common/widgets/form_fields/drop_down_field_black.dart';
import 'package:kvatt_mobile/app/common/widgets/form_fields/text_field_black.dart';
import 'package:kvatt_mobile/app/common/widgets/loading/loading_dialog.dart';
import 'package:kvatt_mobile/app/common/widgets/nav_bars/top_nav_bar.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_mode.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_scan/tracking_review_sheet.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_scan/tracking_scan_view_model.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_scan/widgets/code_scanner.dart';
import 'package:intl/intl.dart';

class TrackingScan extends StatefulWidget {
  final TrackingScanViewModel viewModel;

  const TrackingScan({
    super.key,
    required this.viewModel,
  });

  @override
  State<TrackingScan> createState() => _TrackingScanState();
}

class _TrackingScanState extends State<TrackingScan> {
  TextEditingController enteredMerchantNameTextController =
      TextEditingController();
  TextEditingController customerNameTextController = TextEditingController();
  TextEditingController orderNumberTextController = TextEditingController();
  TextEditingController dateTextController = TextEditingController();
  TextEditingController timeTextController = TextEditingController();

  String? _selectedMerchant;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;

  MerchantSelectMode? merchantSelectMode;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      widget.viewModel.init();
      dateTextController.text = DateFormat('dd/MM/yyyy').format(DateTime.now());
      timeTextController.text = TimeOfDay.now().format(context);
      enteredMerchantNameTextController.addListener(() {
        setState(() {});
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: const PreferredSize(
        preferredSize: Size.fromHeight(kToolbarHeight),
        child: TopNavBar(),
      ),
      body: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 24.0),
        child: widget.viewModel.isLoading == true
            ? Column(
                children: [
                  const SizedBox(height: 96.0),
                  Align(
                    alignment: Alignment.center,
                    child: CircularProgressIndicator(
                      color: Theme.of(context).colorScheme.secondaryColor,
                    ),
                  ),
                ],
              )
            : _buildBody(),
      ),
    );
  }

  Widget _buildBody() {
    if (widget.viewModel.trackingMode == TrackingMode.shipToMerchant &&
        widget.viewModel.selectedMerchant == null &&
        widget.viewModel.enteredMerchantName == null) {
      return _buildMerchantSelect();
    }
    if (widget.viewModel.trackingMode == TrackingMode.shipToCustomer &&
        (widget.viewModel.customerName == null ||
            widget.viewModel.orderNumber == null)) {
      return _buildCustomerDetails();
    }
    return _buildScan(context);
  }

  Widget _buildScan(BuildContext context) {
    Size size = MediaQuery.of(context).size;

    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Column(
          children: [
            const SizedBox(height: 24.0),
            Container(
              padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
              decoration: BoxDecoration(
                color: Theme.of(context).primaryColor.withOpacity(0.1),
                borderRadius: BorderRadius.circular(8.0),
                border: Border.all(
                  color: Theme.of(context).primaryColor,
                ),
              ),
              child: Text(
                _getInfoText(),
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: Theme.of(context).primaryColor,
                    ),
              ),
            ),
            const SizedBox(height: 32.0),
            Column(
              children: [
                Text(
                  'Number of packs scanned',
                  style: Theme.of(context).textTheme.titleSmall?.copyWith(
                        color:
                            Theme.of(context).colorScheme.onTrafficLightGreen,
                      ),
                ),
                const SizedBox(height: 8.0),
                Text(
                  widget.viewModel.scannedPackagings.length.toString(),
                  style: Theme.of(context).textTheme.headlineMedium?.copyWith(
                        color:
                            Theme.of(context).colorScheme.onTrafficLightGreen,
                        fontSize: 40.0,
                      ),
                ),
              ],
            ),
          ],
        ),
        Container(
          padding: const EdgeInsets.fromLTRB(12.0, 8.0, 12.0, 8.0),
          decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(8.0),
              border: Border.all(
                color: Theme.of(context).primaryColor,
              )),
          child: Stack(
            children: [
              widget.viewModel.trackingInProgress
                  ? CodeScanner(
                      onDetected: (String? code) =>
                          widget.viewModel.onCodeDetected(code),
                      height: size.height * 0.4,
                    )
                  : const SizedBox(),
              widget.viewModel.trackingInProgress == false
                  ? SizedBox(
                      width: size.width,
                      height: size.height * 0.4,
                      child: Icon(
                        Icons.qr_code,
                        size: size.height * 0.2,
                        color: Theme.of(context).primaryColor,
                      ),
                    )
                  : const SizedBox(),
            ],
          ),
        ),
        PrimaryButton(
          label: widget.viewModel.trackingInProgress
              ? 'Finish scanning'
              : 'Scan packs',
          onPressed: () {
            if (widget.viewModel.trackingInProgress == true) {
              showModalBottomSheet(
                isScrollControlled: true,
                isDismissible: false,
                enableDrag: false,
                backgroundColor: Colors.transparent,
                shape: const RoundedRectangleBorder(
                  borderRadius: BorderRadius.only(
                    topLeft: Radius.circular(24),
                    topRight: Radius.circular(24),
                  ),
                ),
                context: context,
                builder: (context) => FractionallySizedBox(
                  heightFactor: 0.65,
                  child: TrackingReviewSheet(
                    onSaveTapped: () async {
                      LoadingDialog.show(
                        context,
                        'saving...',
                        loadingDialogMode: LoadingDialogMode.onPrimary,
                      );
                      return await widget.viewModel.onSaveTapped();
                    },
                    onScanMoreTapped: () {
                      Navigator.of(context).pop();
                    },
                    numScanned: widget.viewModel.scannedPackagings.length,
                    trackingMode: widget.viewModel.trackingMode,
                    merchantName: widget.viewModel.outboundMerchantName,
                    customerName: widget.viewModel.customerName,
                    orderNumber: widget.viewModel.orderNumber,
                  ),
                ),
              );
            }
            widget.viewModel.onStartStopScanTapped();
          },
        ),
        const SizedBox(height: 48.0),
      ],
    );
  }

  Widget _buildMerchantSelect() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0),
      child: Column(
        children: [
          const SizedBox(height: 96.0),
          merchantSelectMode == null
              ? Column(
                  children: [
                    PrimaryButton(
                      label: 'Select an already registered merchant',
                      onPressed: () {
                        setState(() {
                          merchantSelectMode =
                              MerchantSelectMode.selectExisting;
                        });
                      },
                    ),
                    const SizedBox(height: 12.0),
                    SecondaryButton(
                      label: 'Enter a merchant name manually',
                      onPressed: () {
                        setState(() {
                          merchantSelectMode = MerchantSelectMode.manual;
                        });
                      },
                    ),
                  ],
                )
              : const SizedBox(),
          merchantSelectMode == MerchantSelectMode.selectExisting
              ? Column(
                  children: [
                    Text(
                      'Select the merchant who you are tracking shipment to:',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis),
                    ),
                    const SizedBox(height: 24.0),
                    DropDownFieldBlack(
                      label: 'Select merchant',
                      items: widget.viewModel.merchantNames,
                      onItemSelected: (String item) {
                        setState(() {
                          _selectedMerchant = item;
                        });
                      },
                    ),
                  ],
                )
              : const SizedBox(),
          merchantSelectMode == MerchantSelectMode.manual
              ? Column(
                  children: [
                    Text(
                      'Enter the name of the merchant who you are tracking shipment to:',
                      style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          color: Theme.of(context)
                              .colorScheme
                              .onSurfaceMediumEmphasis),
                    ),
                    const SizedBox(height: 24.0),
                    TextFieldBlack(
                      validator: (String? value) {},
                      label: 'Merchant name',
                      keyboardType: TextInputType.text,
                      controller: enteredMerchantNameTextController,
                    ),
                  ],
                )
              : const SizedBox(),
          const SizedBox(height: 48.0),
          Text(
            'Select the date and time (defaults to the current date and time)',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis),
          ),
          const SizedBox(height: 24.0),
          CustomDatePicker(
            textController: dateTextController,
            label: 'Select date',
            initialDate: DateTime.now(),
            firstDate: DateTime.parse('2020-01-01'),
            lastDate: DateTime.now(),
            onDateSelected: (DateTime date) {
              setState(() {
                _selectedDate = date;
                dateTextController.text = DateFormat('dd/MM/yyyy').format(date);
              });
            },
            isEnabled: true,
          ),
          const SizedBox(height: 24.0),
          CustomTimePicker(
            textController: timeTextController,
            label: 'Select time',
            onTimeSelected: (TimeOfDay time) {
              setState(() {
                _selectedTime = time;
                timeTextController.text = time.format(context);
              });
            },
            isEnabled: true,
          ),
          const SizedBox(height: 24.0),
          (merchantSelectMode == MerchantSelectMode.selectExisting &&
                      _selectedMerchant != null) ||
                  (merchantSelectMode == MerchantSelectMode.manual &&
                      enteredMerchantNameTextController.text.isNotEmpty)
              ? PrimaryButton(
                  label: 'Continue',
                  onPressed: () => widget.viewModel.onMerchantDetailsSubmitted(
                    merchantSelectMode: merchantSelectMode!,
                    selectedMerchant: _selectedMerchant,
                    enteredMerchantName:
                        enteredMerchantNameTextController.text.trim(),
                    date: _selectedDate,
                    time: _selectedTime,
                  ),
                )
              : const SizedBox(),
        ],
      ),
    );
  }

  Widget _buildCustomerDetails() {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12.0),
      child: Column(
        children: [
          const SizedBox(height: 96.0),
          Text(
            'Enter details of the customer and order you are scanning for:',
            style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceMediumEmphasis),
          ),
          const SizedBox(height: 24.0),
          TextFieldBlack(
            validator: (String? value) {},
            label: 'Customer name',
            keyboardType: TextInputType.text,
            controller: customerNameTextController,
          ),
          const SizedBox(height: 24.0),
          TextFieldBlack(
            validator: (String? value) {},
            label: 'Order number',
            keyboardType: TextInputType.text,
            controller: orderNumberTextController,
          ),
          const SizedBox(height: 24.0),
          PrimaryButton(
            label: 'Continue',
            onPressed: () => widget.viewModel.onCustomerDetailsSubmitted(
              customerName: customerNameTextController.text,
              orderNumber: orderNumberTextController.text,
            ),
          ),
        ],
      ),
    );
  }

  String _getInfoText() {
    switch (widget.viewModel.trackingMode) {
      case TrackingMode.returnToKvatt:
        return 'You are scanning packs which have been returned.';
      case TrackingMode.sendToMaintenance:
        return 'You are scanning packs which are being sent to maintenance.';
      case TrackingMode.outOfMaintenance:
        return 'You are scanning packs which are out of maintenance and ready for use.';
      case TrackingMode.shipToMerchant:
        if (widget.viewModel.merchantSelectMode ==
            MerchantSelectMode.selectExisting) {
          return 'You are scanning packs which are to be shipped to ${widget.viewModel.selectedMerchant?.name}';
        } else if (widget.viewModel.merchantSelectMode ==
            MerchantSelectMode.manual) {
          return 'You are scanning packs which are to be shipped to ${widget.viewModel.enteredMerchantName}';
        } else {
          return '';
        }
      case TrackingMode.shipToCustomer:
        if (widget.viewModel.customerName != null &&
            widget.viewModel.customerName != '' &&
            widget.viewModel.orderNumber != null &&
            widget.viewModel.orderNumber != '') {
          return 'You are scanning packs which are to be shipped to ${widget.viewModel.customerName} as part of order ${widget.viewModel.orderNumber}';
        }
        if (widget.viewModel.customerName != null &&
            widget.viewModel.customerName != '') {
          return 'You are scanning packs which are to be shipped to ${widget.viewModel.customerName}';
        }
        if (widget.viewModel.orderNumber != null &&
            widget.viewModel.orderNumber != '') {
          return 'You are scanning packs which are to be shipped as part of order ${widget.viewModel.orderNumber}';
        }
        return 'You are scanning packs which are to be shipped to a customer';
      case TrackingMode.returnToMerchant:
        return 'You are scanning packs which have been returned from customers';
      default:
        return '';
    }
  }

  @override
  void dispose() {
    enteredMerchantNameTextController.dispose();
    customerNameTextController.dispose();
    orderNumberTextController.dispose();
    dateTextController.dispose();
    timeTextController.dispose();
    super.dispose();
  }
}
