import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/common/widgets/buttons/primary_button.dart';
import 'package:kvatt_mobile/app/common/widgets/buttons/secondary_button.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';
import 'package:kvatt_mobile/app/pages/tracking/tracking_mode.dart';

class TrackingReviewSheet extends StatefulWidget {
  final Function onSaveTapped;
  final Function onScanMoreTapped;
  final int numScanned;
  final TrackingMode trackingMode;
  final String? merchantName;
  final String? customerName;
  final String? orderNumber;

  const TrackingReviewSheet({
    super.key,
    required this.onSaveTapped,
    required this.onScanMoreTapped,
    required this.numScanned,
    required this.trackingMode,
    this.merchantName,
    this.customerName,
    this.orderNumber,
  });

  @override
  State<TrackingReviewSheet> createState() => _TrackingReviewSheetState();
}

class _TrackingReviewSheetState extends State<TrackingReviewSheet> {
  bool _hasError = false;

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.only(
        topRight: Radius.circular(24.0),
        topLeft: Radius.circular(24.0),
      ),
      child: Scaffold(
        body: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const SizedBox(height: 48.0),
              Text(
                _getReviewText(),
                style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    ),
              ),
              Text(
                'Are you sure you want to record those changes?',
                style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color:
                          Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                    ),
              ),
              Column(
                children: [
                  PrimaryButton(
                    label: 'Yes, record changes',
                    onPressed: () async {
                      setState(() {
                        _hasError = false;
                      });
                      bool res = await widget.onSaveTapped();
                      setState(() {
                        _hasError = !res;
                      });
                    },
                  ),
                  const SizedBox(height: 12.0),
                  SecondaryButton(
                    label: 'No, take me back',
                    onPressed: () => widget.onScanMoreTapped(),
                  ),
                  _hasError == true
                      ? Column(
                          children: [
                            const SizedBox(height: 12.0),
                            Container(
                              color: Theme.of(context)
                                  .colorScheme
                                  .trafficLightAmber,
                              padding: const EdgeInsets.fromLTRB(
                                  12.0, 8.0, 12.0, 8.0),
                              child: Text(
                                'There was an issue saving your changes. Please try again later.',
                                style: Theme.of(context)
                                    .textTheme
                                    .bodySmall
                                    ?.copyWith(
                                      color: Theme.of(context)
                                          .colorScheme
                                          .onTrafficLightAmber,
                                    ),
                                textAlign: TextAlign.center,
                              ),
                            ),
                          ],
                        )
                      : const SizedBox(),
                  const SizedBox(height: 36.0),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  String _getReviewText() {
    switch (widget.trackingMode) {
      case TrackingMode.returnToKvatt:
        return 'You have scanned ${widget.numScanned} packs as being returned to Kvatt.';
      case TrackingMode.sendToMaintenance:
        return 'You have scanned ${widget.numScanned} packs as being sent for maintenance.';
      case TrackingMode.outOfMaintenance:
        return 'You have scanned ${widget.numScanned} packs as being out of maintenance and ready for use.';
      case TrackingMode.shipToMerchant:
        return 'You have scanned ${widget.numScanned} packs to be tracked as being shipped to\n${widget.merchantName}';
      case TrackingMode.shipToCustomer:
        if (widget.customerName != null &&
            widget.customerName != '' &&
            widget.orderNumber != null &&
            widget.orderNumber != '') {
          return 'You have scanned ${widget.numScanned} packs to be tracked as being shipped to ${widget.customerName} as part of order ${widget.orderNumber}';
        }
        if (widget.customerName != null && widget.customerName != '') {
          return 'You have scanned ${widget.numScanned} packs to be tracked as being shipped to ${widget.customerName}.';
        }
        if (widget.orderNumber != null && widget.orderNumber != '') {
          return 'You have scanned ${widget.numScanned} packs to be tracked as being shipped as part of order ${widget.orderNumber}';
        }
        return 'You have scanned ${widget.numScanned} packs to be tracked as being shipped to a customer';
      case TrackingMode.returnToMerchant:
        return 'You have scanned ${widget.numScanned} packs to be tracked as being returned from customers';
      default:
        return '';
    }
  }
}
