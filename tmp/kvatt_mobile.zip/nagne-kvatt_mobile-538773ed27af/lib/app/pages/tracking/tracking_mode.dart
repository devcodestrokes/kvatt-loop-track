enum TrackingMode {
  shipToMerchant,
  returnToKvatt,
  sendToMaintenance,
  outOfMaintenance,
  shipToCustomer,
  returnToMerchant,
}
