import 'package:kvatt_core/domain/packagings/packaging.dart';

class ScannedPackaging {
  Packaging packaging;

  ScannedPackaging({
    required this.packaging,
  });
}
