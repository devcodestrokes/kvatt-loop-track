import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/assets_factory.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';

class TopNavBar extends StatelessWidget {
  final List<Widget>? actions;

  const TopNavBar({
    super.key,
    this.actions,
  });

  @override
  Widget build(BuildContext context) {
    return AppBar(
      backgroundColor: Theme.of(context).colorScheme.tertiaryColor,
      elevation: 0.0,
      actions: actions,
      foregroundColor: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
      title: Row(
        children: [
          Text(
            'Powered by',
            style: Theme.of(context).textTheme.titleSmall?.copyWith(
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  fontSize: 11.0,
                  letterSpacing: 0.2,
                ),
          ),
          const SizedBox(width: 5.0),
          Image.asset(
            AssetsFactory.kvattLogoBlack,
            height: 18.0,
          ),
        ],
      ),
    );
  }
}
