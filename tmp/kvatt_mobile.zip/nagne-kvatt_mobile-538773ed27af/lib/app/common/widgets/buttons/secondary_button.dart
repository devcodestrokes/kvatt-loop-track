import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';

class SecondaryButton extends StatelessWidget {
  final Function? onPressed;
  final String label;

  const SecondaryButton({
    Key? key,
    this.onPressed,
    required this.label,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48.0,
      width: double.infinity,
      child: TextButton(
        style: TextButton.styleFrom(
          backgroundColor: Colors.white,
          side: BorderSide(
            color: Theme.of(context).colorScheme.secondaryColor,
            width: 2.0,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(4.0),
          ),
        ),
        onPressed: onPressed != null ? () => onPressed!() : null,
        child: Text(
          label,
          style: Theme.of(context).textTheme.labelLarge?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
