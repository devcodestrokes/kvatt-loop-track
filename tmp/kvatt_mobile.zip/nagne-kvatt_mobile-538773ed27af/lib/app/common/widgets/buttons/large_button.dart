import 'package:flutter/material.dart';

class LargeButton extends StatelessWidget {
  final String label;
  final Color fontColor;
  final Color backgroundColor;
  final Function onTapped;
  final Color? borderColor;
  final double? height;

  const LargeButton({
    super.key,
    required this.label,
    required this.fontColor,
    required this.backgroundColor,
    required this.onTapped,
    this.borderColor,
    this.height,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: () => onTapped(),
      child: Container(
        width: MediaQuery.of(context).size.width,
        height: height,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: backgroundColor,
          borderRadius: const BorderRadius.all(Radius.circular(20.0)),
          border: borderColor != null
              ? Border.all(
                  color: borderColor!,
                )
              : null,
        ),
        child: Text(
          label,
          style: Theme.of(context).textTheme.headlineSmall?.copyWith(
                color: fontColor,
                height: 1.2,
              ),
          textAlign: TextAlign.center,
        ),
      ),
    );
  }
}
