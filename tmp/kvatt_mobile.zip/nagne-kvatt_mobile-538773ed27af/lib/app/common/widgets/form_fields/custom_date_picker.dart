import 'package:flutter/material.dart';
import 'package:kvatt_mobile/app/common/utils/validators.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';

class CustomDatePicker extends StatefulWidget {
  final TextEditingController textController;
  final String? validatorMessage;
  final String label;
  final DateTime initialDate;
  final DateTime firstDate;
  final DateTime lastDate;
  final Function(DateTime) onDateSelected;
  final bool isEnabled;

  const CustomDatePicker({
    Key? key,
    required this.textController,
    this.validatorMessage,
    required this.label,
    required this.initialDate,
    required this.firstDate,
    required this.lastDate,
    required this.onDateSelected,
    required this.isEnabled,
  }) : super(key: key);

  @override
  State<CustomDatePicker> createState() => _CustomDatePickerState();
}

class _CustomDatePickerState extends State<CustomDatePicker> {
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: widget.isEnabled == false
          ? null
          : () async {
              final DateTime? datePicked = await showDatePicker(
                  context: context,
                  locale: const Locale('en', 'GB'),
                  initialDate: widget.initialDate,
                  firstDate: widget.firstDate,
                  lastDate: widget.lastDate,
                  initialEntryMode: DatePickerEntryMode.calendarOnly,
                  builder: (context, child) {
                    return Theme(
                      data: Theme.of(context).copyWith(
                        colorScheme: ColorScheme.light(
                          primary: Theme.of(context).primaryColor,
                          onPrimary: Theme.of(context)
                              .colorScheme
                              .onPrimaryHighEmphasis,
                          onSurface: Theme.of(context)
                              .colorScheme
                              .onSurfaceHighEmphasis,
                        ),
                        textButtonTheme: TextButtonThemeData(
                          style: TextButton.styleFrom(
                              foregroundColor:
                                  Theme.of(context).colorScheme.secondaryColor,
                              textStyle: Theme.of(context).textTheme.bodySmall),
                        ),
                      ),
                      child: child!,
                    );
                  });
              if (datePicked != null) {
                widget.onDateSelected(datePicked);
              }
            },
      child: TextFormField(
        controller: widget.textController,
        enabled: false,
        readOnly: true,
        validator: (String? value) {
          if (widget.validatorMessage == null) return null;
          return Validators.validateNotEmpty(value, widget.validatorMessage!);
        },
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
            ),
        decoration: InputDecoration(
          contentPadding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 16.0),
          labelText: widget.label,
          labelStyle: Theme.of(context).textTheme.titleSmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceDisabled,
              ),
          errorBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                width: 1.0),
          ),
          // enabledBorder: OutlineInputBorder(
          //   borderSide: BorderSide(
          //       color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
          //       width: 1.0),
          // ),
          disabledBorder: OutlineInputBorder(
            borderSide: BorderSide(
                color: widget.isEnabled == true
                    ? Theme.of(context).colorScheme.onSurfaceHighEmphasis
                    : Theme.of(context).colorScheme.onSurfaceDisabled,
                width: 1.0),
          ),
          // border: OutlineInputBorder(
          //   borderSide: BorderSide(
          //       color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
          //       width: 1.0),
          // ),
          errorStyle: Theme.of(context).textTheme.bodySmall?.copyWith(
                color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              ),
        ),
      ),
    );
  }
}
