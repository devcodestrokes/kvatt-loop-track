import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kvatt_mobile/app/assets_factory.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';

class TextFieldBlack extends StatefulWidget {
  final Function(String?) validator;
  final String label;
  final TextInputType keyboardType;
  final TextEditingController controller;
  final bool obscureText;
  final bool? readOnly;
  final String? errorText;
  final int? maxLines;

  const TextFieldBlack({
    Key? key,
    required this.validator,
    required this.label,
    required this.keyboardType,
    required this.controller,
    this.obscureText = false,
    this.readOnly = false,
    this.errorText,
    this.maxLines = 1,
  }) : super(key: key);

  @override
  TextFieldBlackState createState() => TextFieldBlackState();
}

class TextFieldBlackState extends State<TextFieldBlack> {
  bool _isObscure = false;
  @override
  void initState() {
    super.initState();
    _isObscure = widget.obscureText;
  }

  @override
  Widget build(BuildContext context) {
    return TextFormField(
      maxLines: widget.maxLines,
      inputFormatters: widget.keyboardType == TextInputType.number
          ? [FilteringTextInputFormatter.digitsOnly]
          : null,
      enabled: widget.readOnly != true,
      controller: widget.controller,
      readOnly: widget.readOnly ?? false,
      obscureText: _isObscure,
      validator: (String? value) => widget.validator(value),
      keyboardType: widget.keyboardType,
      style: Theme.of(context).textTheme.titleSmall?.copyWith(
            color: widget.readOnly == true
                ? Theme.of(context).colorScheme.onSurfaceDisabled
                : Theme.of(context).colorScheme.onSurfaceHighEmphasis,
          ),
      cursorColor: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
      decoration: InputDecoration(
        errorText: widget.errorText,
        contentPadding: const EdgeInsets.fromLTRB(16.0, 16.0, 16.0, 16.0),
        labelText: widget.label,
        labelStyle: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceDisabled,
            ),
        errorBorder: OutlineInputBorder(
          borderSide: BorderSide(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              width: 1.0),
        ),
        focusedErrorBorder: OutlineInputBorder(
          borderSide: BorderSide(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              width: 2.0),
        ),
        focusedBorder: OutlineInputBorder(
          borderSide: BorderSide(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              width: 2.0),
        ),
        enabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              width: 1.0),
        ),
        disabledBorder: OutlineInputBorder(
          borderSide: BorderSide(
              color: Theme.of(context).colorScheme.onSurfaceDisabled,
              width: 1.0),
        ),
        border: OutlineInputBorder(
          borderSide: BorderSide(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
              width: 1.0),
        ),
        errorStyle: Theme.of(context).textTheme.bodySmall?.copyWith(
              color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
            ),
        suffixIcon: widget.obscureText == true
            ? IconButton(
                onPressed: () {
                  setState(() {
                    _isObscure = !_isObscure;
                  });
                },
                icon: ImageIcon(
                  const AssetImage(AssetsFactory.eyeIcon),
                  color: Theme.of(context).colorScheme.onSurfaceHighEmphasis,
                  size: 24.0,
                ),
              )
            : null,
      ),
    );
  }
}
