import 'package:email_validator/email_validator.dart';

class Validators {
  static String? validateEmail(String? email) {
    if (email == null) return 'Please enter a valid email address.';
    if (EmailValidator.validate(email) == false) {
      return 'Please enter a valid email address.';
    }
    return null;
  }

  static String? validatePassword(String? password) {
    if (password == null || password.length < 8) {
      return 'Your password should be at least 8 characters long';
    }
    return null;
  }

  static String? validateNotEmpty(
    String? text,
    String message,
  ) {
    if (text == null || text.isEmpty) {
      return message;
    }
    return null;
  }
}
