import 'package:kvatt_core/data/base/db/document_data.dart';
import 'package:kvatt_mobile/app/services/firestore/firestore_service.dart';
import 'package:kvatt_mobile/domain/contracts/merchant_contract_info.dart';
import 'package:kvatt_mobile/domain/contracts/packaging_info.dart';
import 'package:kvatt_mobile/domain/users/admin.dart';
import 'package:kvatt_mobile/domain/users/merchant.dart';
import 'package:kvatt_mobile/domain/users/user.dart';
import 'package:kvatt_mobile/domain/users/user_account_status.dart';
import 'package:kvatt_mobile/domain/users/user_repository_interface.dart';
import 'package:kvatt_mobile/domain/users/user_type.dart';

class UserAccountStatusDeserialisationException implements Exception {
  String? message;
  UserAccountStatusDeserialisationException(message);
}

class UserRepository implements UserRepositoryInterface {
  final String usersCollection = 'users';

  FirestoreService firestoreService;

  UserRepository({
    required this.firestoreService,
  });

  @override
  Future<User?> findUserById({
    required String userId,
  }) async {
    DocumentData? doc = await firestoreService.retrieveDocument(
      documentPath: '$usersCollection/$userId',
    );
    if (doc == null) return null;
    return _deserialiseUser(doc.id, doc.data);
  }

  @override
  Future<List<User>> findUsers({
    required UserType userType,
    required UserAccountStatus accountStatus,
  }) async {
    List<String> fieldNames = ['type', 'accountStatus'];
    List<String> targetValues = [
      _serialiseUserType(userType),
      accountStatus == UserAccountStatus.active ? 'active' : 'pending',
    ];

    List<DocumentData> docs = await firestoreService.retrieveDocuments(
      collectionPath: usersCollection,
      fieldNamesEqual: fieldNames,
      targetValuesEqual: targetValues,
    );
    return docs
        .map((DocumentData doc) => _deserialiseUser(doc.id, doc.data))
        .whereType<User>()
        .toList();
  }

  String _serialiseUserType(UserType type) {
    switch (type) {
      case UserType.admin:
        return 'admin';
      case UserType.partner:
        return 'partner';
      case UserType.merchant:
        return 'merchant';
    }
  }

  User? _deserialiseUser(String id, Map<String, dynamic> data) {
    String email = data['email'];
    UserAccountStatus accountStatus =
        _deserialiseUserAccountStatus(data['accountStatus']);
    switch (data['type']) {
      case 'admin':
        return Admin(
          uid: id,
          email: email,
          accountStatus: accountStatus,
          name: data['name'] ?? '',
          showShipOptionInApp: data['showShipOptionInApp'] ?? true,
        );
      case 'merchant':
        return Merchant(
          uid: id,
          email: email,
          accountStatus: accountStatus,
          name: data['name'],
          contractInfo: MerchantContractInfo(
            deliveryAddress: data['deliveryAddress'],
            contractType: data['contractType'],
            packagings:
                (data['packagings'] as List<dynamic>).map((dynamic packaging) {
              return PackagingInfo(
                packagingType: packaging['type'],
                numberOfUnits: packaging['numUnits'],
              );
            }).toList(),
            packagingLossCompensationIncluded:
                data['packagingLossCompensationIncluded'],
            packagingMaintenanceIncluded: data['packagingMaintenanceIncluded'],
          ),
        );
      default:
        return null;
    }
  }

  UserAccountStatus _deserialiseUserAccountStatus(String status) {
    switch (status) {
      case 'active':
        return UserAccountStatus.active;
      case 'pending':
        return UserAccountStatus.pending;
      default:
        throw UserAccountStatusDeserialisationException(
            '$status is not a valid account status');
    }
  }
}
