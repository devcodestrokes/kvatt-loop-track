import 'package:cloud_functions/cloud_functions.dart';
import 'package:kvatt_core/data/base/db/cloud_function_callable_interface.dart';

class CloudFunctionService implements CloudFunctionCallableInterface {
  @override
  Future<dynamic> callFunction({
    required String functionName,
    required String functionRegion,
    Map<String, dynamic>? data,
  }) async {
    HttpsCallable callable =
        FirebaseFunctions.instanceFor(region: functionRegion).httpsCallable(
      functionName,
      options: HttpsCallableOptions(
        timeout: const Duration(seconds: 540),
      ),
    );

    HttpsCallableResult results = await callable.call(data);

    List<String> errorCodes = [
      'failed-precondition',
      'unauthenticated',
      'internal',
    ];

    //TODO: Figure out why this is causing issues
    // if (results.data != null && errorCodes.contains(results.data['code'])) {
    //   throw Error();
    // }
    return results.data;
  }
}
