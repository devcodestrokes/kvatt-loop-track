import 'package:flutter_beep/flutter_beep.dart';

class SoundFeedbackService {
  static Future<void> beep({
    required bool isSuccess,
  }) async {
    await FlutterBeep.beep(isSuccess);
  }
}
