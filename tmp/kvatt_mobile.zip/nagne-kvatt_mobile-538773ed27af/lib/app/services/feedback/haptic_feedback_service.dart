import 'package:vibration/vibration.dart';

class HapticFeedbackService {
  static Future<void> vibrate({
    int duration = 300,
  }) async {
    bool? hasVibrator = await Vibration.hasVibrator();

    if (hasVibrator == true) {
      await Vibration.vibrate(
        duration: duration,
      );
    }
  }
}
