import 'package:firebase_auth/firebase_auth.dart';

class AuthInvalidCredentialsException implements Exception {
  String? message;
  AuthInvalidCredentialsException(message);
}

class AuthUnknownException implements Exception {
  String? message;
  AuthUnknownException(message);
}

class InvalidActionCodeException implements Exception {
  String? message;
  InvalidActionCodeException(message);
}

class AuthService {
  FirebaseAuth auth = FirebaseAuth.instance;

  Stream<String?> authStateChanges() {
    return auth.authStateChanges().map((User? user) {
      if (user == null) return null;
      return user.uid;
    });
  }

  Future<String?> login({
    required String email,
    required String password,
  }) async {
    try {
      UserCredential userCredential = await auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      if (userCredential.user != null) {
        return userCredential.user!.uid;
      } else {
        throw Exception();
      }
    } on FirebaseAuthException catch (e) {
      if (['invalid-email', 'user-not-found', 'wrong-password']
          .contains(e.code)) {
        throw AuthInvalidCredentialsException(e.message);
      }
      throw AuthUnknownException(e.message);
    } catch (e) {
      throw AuthUnknownException(e.toString());
    }
  }

  Future<void> logout() async {
    await auth.signOut();
  }

  String? getLoggedInUser() {
    return auth.currentUser?.uid;
  }

  Future<void> sendPasswordResetEmail({
    required String email,
  }) async {
    try {
      await auth.sendPasswordResetEmail(
        email: email,
      );
    } on FirebaseAuthException catch (e) {
      if (e.code != 'user-not-found') {
        throw AuthUnknownException(e.message);
      }
    } catch (e) {
      throw AuthUnknownException(e.toString());
    }
  }

  Future<void> confirmPasswordReset({
    required String code,
    required String password,
  }) async {
    try {
      await auth.confirmPasswordReset(
        code: code,
        newPassword: password,
      );
    } on FirebaseAuthException catch (e) {
      if (['expired-action-code', 'invalid-action-code'].contains(e.code)) {
        throw InvalidActionCodeException(e.message);
      }
      throw AuthUnknownException(e.message);
    } catch (e) {
      throw AuthUnknownException(e.toString());
    }
  }
}
