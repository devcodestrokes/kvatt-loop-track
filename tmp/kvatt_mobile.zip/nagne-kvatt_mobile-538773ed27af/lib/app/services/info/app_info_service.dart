import 'package:package_info_plus/package_info_plus.dart';

class AppInfoService {
  late PackageInfo packageInfo;

  init() async {
    packageInfo = await PackageInfo.fromPlatform();
  }

  String get version => packageInfo.version;

  String get buildNumber => packageInfo.buildNumber;
}
