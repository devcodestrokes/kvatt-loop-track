class PackagingInfo {
  String packagingType;
  int numberOfUnits;

  PackagingInfo({
    required this.packagingType,
    required this.numberOfUnits,
  });
}
