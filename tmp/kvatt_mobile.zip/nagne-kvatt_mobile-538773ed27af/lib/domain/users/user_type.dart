enum UserType {
  admin,
  partner,
  merchant,
}
