import 'package:kvatt_mobile/domain/users/merchant.dart';
import 'package:kvatt_mobile/domain/users/user.dart';
import 'package:kvatt_mobile/domain/users/user_account_status.dart';
import 'package:kvatt_mobile/domain/users/user_repository_interface.dart';
import 'package:kvatt_mobile/domain/users/user_type.dart';

class UserManager {
  UserRepositoryInterface userRepo;

  UserManager({
    required this.userRepo,
  });

  Future<User?> findUser({
    required String userId,
  }) async {
    return await userRepo.findUserById(userId: userId);
  }

  Future<List<Merchant>> retrieveActiveMerchants() async {
    List<User> users = await userRepo.findUsers(
      userType: UserType.merchant,
      accountStatus: UserAccountStatus.active,
    );
    return users.map((User user) => user as Merchant).toList();
  }
}
