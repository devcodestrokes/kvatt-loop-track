import 'package:kvatt_mobile/domain/contracts/merchant_contract_info.dart';
import 'package:kvatt_mobile/domain/users/user.dart';

class Merchant extends User {
  String name;
  MerchantContractInfo contractInfo;

  Merchant({
    required super.uid,
    required super.email,
    required super.accountStatus,
    required this.name,
    required this.contractInfo,
  });
}
