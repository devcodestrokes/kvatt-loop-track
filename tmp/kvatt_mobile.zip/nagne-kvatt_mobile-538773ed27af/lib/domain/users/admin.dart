import 'package:kvatt_mobile/domain/users/user.dart';

class Admin extends User {
  String name;
  bool showShipOptionInApp;

  Admin({
    required super.uid,
    required super.email,
    required super.accountStatus,
    required this.name,
    required this.showShipOptionInApp,
  });
}
