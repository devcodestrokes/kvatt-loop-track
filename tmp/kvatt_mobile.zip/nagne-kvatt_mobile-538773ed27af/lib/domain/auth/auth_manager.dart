import 'package:kvatt_mobile/app/services/auth/auth_service.dart';
import 'package:kvatt_mobile/domain/users/user.dart';
import 'package:kvatt_mobile/domain/users/user_manager.dart';

class AuthManager {
  AuthService authService;
  UserManager userManager;

  AuthManager({
    required this.authService,
    required this.userManager,
  });

  Future<User?> signIn({
    required String email,
    required String password,
  }) async {
    String? uid = await authService.login(
      email: email,
      password: password,
    );
    if (uid == null) return null;
    return await userManager.findUser(userId: uid);
  }

  signOut() async {
    await authService.logout();
  }

  Future<User?> retrieveLoggedInUser() async {
    String? uid = authService.getLoggedInUser();
    if (uid == null) return null;
    return await userManager.findUser(userId: uid);
  }
}
