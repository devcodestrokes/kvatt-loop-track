import 'package:kvatt_mobile/app/services/info/app_info_service.dart';

class AppManager {
  AppInfoService appInfoService;

  AppManager({
    required this.appInfoService,
  });

  String get appVersion => appInfoService.version;

  String get appBuildNumber => appInfoService.buildNumber;
}
