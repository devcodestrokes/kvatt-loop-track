import 'dart:async';

import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:kvatt_core/data/packaging_shipments/packaging_shipments_repository.dart';
import 'package:kvatt_core/data/packagings/packagings_repository.dart';
import 'package:kvatt_core/data/stocks/stock_repository.dart';
import 'package:kvatt_core/data/tracking/tracking_counters_repository.dart';
import 'package:kvatt_core/data/tracking/tracking_history_repository.dart';
import 'package:kvatt_core/domain/labels/custom/goliath_labels_config.dart';
import 'package:kvatt_core/domain/labels/kvatt/kvatt_labels_config.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_manager.dart';
import 'package:kvatt_core/domain/packaging_shipments/packaging_shipments_repository_interface.dart';
import 'package:kvatt_core/domain/packagings/packagings_manager.dart';
import 'package:kvatt_core/domain/packagings/packagings_repository_interface.dart';
import 'package:kvatt_core/domain/stocks/stock_repository_interface.dart';
import 'package:kvatt_core/domain/stocks/stocks_manager.dart';
import 'package:kvatt_core/domain/tracking/tracking_counters_repository_interface.dart';
import 'package:kvatt_core/domain/tracking/tracking_history_repository_interface.dart';
import 'package:kvatt_core/domain/tracking/tracking_manager.dart';
import 'package:kvatt_mobile/app/app.dart';
import 'package:kvatt_mobile/app/app_theme.dart';
import 'package:kvatt_mobile/app/configs/config.dart';
import 'package:kvatt_mobile/app/configs/config_factory.dart';
import 'package:kvatt_mobile/app/data/users/user_repository.dart';
import 'package:kvatt_mobile/app/extended_color_scheme.dart';
import 'package:kvatt_mobile/app/routing/navigation_util.dart';
import 'package:kvatt_mobile/app/services/auth/auth_service.dart';
import 'package:kvatt_mobile/app/services/cloud_functions/cloud_functions_service.dart';
import 'package:kvatt_mobile/app/services/firestore/firestore_service.dart';
import 'package:kvatt_mobile/app/services/info/app_info_service.dart';
import 'package:kvatt_mobile/app/states/auth_state.dart';
import 'package:kvatt_mobile/domain/app/app_manager.dart';
import 'package:kvatt_mobile/domain/auth/auth_manager.dart';
import 'package:kvatt_mobile/domain/users/user.dart';
import 'package:kvatt_mobile/domain/users/user_manager.dart';
import 'package:kvatt_mobile/domain/users/user_repository_interface.dart';
import 'package:provider/provider.dart';
import 'package:sentry_flutter/sentry_flutter.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();

  SystemChrome.setSystemUIOverlayStyle(
    SystemUiOverlayStyle(
      statusBarColor: appTheme.colorScheme.tertiaryColor,
    ),
  );

  const String env = String.fromEnvironment('app.flavor');
  Config config = ConfigFactory.getConfig(env);

  await Firebase.initializeApp();

  AuthService authService = AuthService();
  FirestoreService firestoreService = FirestoreService();
  CloudFunctionService cloudFunctionService = CloudFunctionService();
  AppInfoService appInfoService = AppInfoService();
  await appInfoService.init();

  KvattLabelsConfig kvattLabelsConfig = KvattLabelsConfig();
  GoliathLabelsConfig goliathLabelsConfig = GoliathLabelsConfig();

  NavigationUtil navUtil = NavigationUtil();

  UserRepositoryInterface userRepository = UserRepository(
    firestoreService: firestoreService,
  );

  PackagingsRepositoryInterface packagingsRepository = PackagingsRepository(
    db: firestoreService,
  );

  TrackingHistoryRepositoryInterface trackingHistoryRepository =
      TrackingHistoryRepository(
    db: firestoreService,
  );

  StocksRepositoryInterface stocksRepository = StocksRepository(
    db: firestoreService,
  );

  PackagingShipmentsRepositoryInterface packagingShipmentsRepository =
      PackagingShipmentsRepository(
    db: firestoreService,
  );

  TrackingCountersRepositoryInterface trackingCountersRepository =
      TrackingCountersRepository(
    db: firestoreService,
  );

  UserManager userManager = UserManager(
    userRepo: userRepository,
  );

  AuthManager authManager = AuthManager(
    authService: authService,
    userManager: userManager,
  );

  PackagingShipmentsManager packagingShipmentsManager =
      PackagingShipmentsManager(
    packagingShipmentsRepository: packagingShipmentsRepository,
  );

  PackagingsManager packagingsManager = PackagingsManager(
    packagingsRepo: packagingsRepository,
    trackingHistoryRepo: trackingHistoryRepository,
    packagingShipmentsManager: packagingShipmentsManager,
    kvattLabelsConfig: kvattLabelsConfig,
    goliathLabelsConfig: goliathLabelsConfig,
    cloudFunctionCallable: cloudFunctionService,
  );

  StocksManager stocksManager = StocksManager(
    stocksRepository: stocksRepository,
    packagingsManager: packagingsManager,
  );

  AppManager appManager = AppManager(
    appInfoService: appInfoService,
  );

  TrackingManager trackingManager = TrackingManager(
    trackingHistoryRepo: trackingHistoryRepository,
    trackingCountersRepo: trackingCountersRepository,
  );

  AuthState authState = AuthState();

  User? user = await authManager.retrieveLoggedInUser();
  if (user != null) {
    authState.loginUser(user: user);
  }

  runZonedGuarded(() async {
    await SentryFlutter.init((options) {
      options.environment = config.environmentName;
      options.dsn =
          'https://4f154b57d3c44ec08fb998bf8b997321@o348728.ingest.sentry.io/4503920873439232';
    });

    runApp(
      MultiProvider(
        providers: [
          ChangeNotifierProvider(create: (context) => authState),
          Provider.value(value: config),
          Provider.value(value: navUtil),
          Provider.value(value: authManager),
          Provider.value(value: userManager),
          Provider.value(value: packagingsManager),
          Provider.value(value: stocksManager),
          Provider.value(value: appManager),
          Provider.value(value: trackingManager),
        ],
        child: App(
          authState: authState,
        ),
      ),
    );
  }, (exception, stackTrace) async {
    Sentry.captureException(exception, stackTrace: stackTrace);
  });
}
